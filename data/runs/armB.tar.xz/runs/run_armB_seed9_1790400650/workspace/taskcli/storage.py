import os
import sqlite3
import shutil
import csv
import json
from datetime import date
from typing import List, Dict, Any, Optional

class TaskStorage:
    def __init__(self, db_path: str = "tasks.db"):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        """Initialize the database with the correct schema."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table with kind column (as required in T14)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    priority TEXT DEFAULT 'med',
                    due DATE,
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE
                )
            """)
            
            # Create tags table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS tags (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT UNIQUE NOT NULL
                )
            """)
            
            # Create task_tags junction table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS task_tags (
                    task_id INTEGER,
                    tag_id INTEGER,
                    FOREIGN KEY (task_id) REFERENCES items (id),
                    FOREIGN KEY (tag_id) REFERENCES tags (id)
                )
            """)
            
            conn.commit()
        finally:
            conn.close()

    def get_next_id(self) -> int:
        """Get the next available task ID."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items WHERE kind = 'task'")
            return cursor.fetchone()[0]
        finally:
            conn.close()

    def add_task(self, title: str, priority: str, due_date: Optional[date], tags: List[str]) -> int:
        """Add a new task."""
        task_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Insert the task
            cursor.execute("""
                INSERT INTO items (id, kind, title, priority, due, done, archived)
                VALUES (?, 'task', ?, ?, ?, FALSE, FALSE)
            """, (task_id, title, priority, due_date))
            
            # Handle tags
            if tags:
                for tag in tags:
                    # Insert or get tag
                    cursor.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (tag,))
                    cursor.execute("SELECT id FROM tags WHERE name = ?", (tag,))
                    tag_id = cursor.fetchone()[0]
                    
                    # Link task and tag
                    cursor.execute(
                        "INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?, ?)",
                        (task_id, tag_id)
                    )
            
            conn.commit()
            return task_id
        finally:
            conn.close()

    def _get_tasks_query(self, sort_by: Optional[str] = None, overdue: bool = False, 
                        show_all: bool = False, tag: Optional[str] = None, today: date = None) -> tuple:
        """Get the base query and parameters for tasks."""
        # Base query
        query = """
            SELECT i.id, i.title, i.priority, i.due, i.done, i.archived
            FROM items i
            WHERE i.kind = 'task'
        """
        
        params = []
        
        # Filter out archived tasks unless --all is specified
        if not show_all:
            query += " AND i.archived = FALSE"
            
        # Filter by tag if specified
        if tag:
            query += """
                AND i.id IN (
                    SELECT DISTINCT tt.task_id FROM task_tags tt
                    JOIN tags t ON tt.tag_id = t.id
                    WHERE t.name = ?
                )
            """
            params.append(tag)
        
        # Filter overdue tasks if requested
        if overdue:
            query += " AND i.due < ? AND i.done = FALSE"
            params.append(today)
            
        # Add sorting
        if sort_by == 'priority':
            # Order: high, med, low
            query += """
                ORDER BY 
                    CASE WHEN i.priority = 'high' THEN 1
                         WHEN i.priority = 'med' THEN 2
                         WHEN i.priority = 'low' THEN 3 END,
                    i.id
            """
        elif sort_by == 'id':
            query += " ORDER BY i.id"
        else:
            # Default: insertion order (by id)
            query += " ORDER BY i.id"
            
        return query, params

    def list_tasks(self, sort_by: Optional[str] = None, overdue: bool = False, 
                   show_all: bool = False, tag: Optional[str] = None, today: date = None) -> List[Dict]:
        """List tasks with optional filtering and sorting."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            query, params = self._get_tasks_query(sort_by, overdue, show_all, tag, today)
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'priority': row[2],
                    'due': row[3],
                    'done': bool(row[4]),
                    'archived': bool(row[5])
                }
                tasks.append(task)
                
            return tasks
        finally:
            conn.close()

    def mark_done(self, task_id: int) -> None:
        """Mark a task as done."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET done = TRUE WHERE id = ? AND kind = 'task'", (task_id,))
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
            conn.commit()
        finally:
            conn.close()

    def delete_task(self, task_id: int) -> None:
        """Delete a task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
            conn.commit()
        finally:
            conn.close()

    def edit_task(self, task_id: int, title: Optional[str] = None) -> None:
        """Edit a task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            if title is not None:
                cursor.execute("UPDATE items SET title = ? WHERE id = ? AND kind = 'task'", (title, task_id))
            else:
                # No changes requested
                return
                
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
                
            conn.commit()
        finally:
            conn.close()

    def search_tasks(self, text: str) -> List[Dict]:
        """Search tasks by title."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Search for tasks with titles containing the text (case-insensitive)
            cursor.execute("""
                SELECT i.id, i.title, i.priority, i.due, i.done, i.archived
                FROM items i
                WHERE i.kind = 'task' AND LOWER(i.title) LIKE ?
                ORDER BY i.id
            """, (f"%{text.lower()}%",))
            
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'priority': row[2],
                    'due': row[3],
                    'done': bool(row[4]),
                    'archived': bool(row[5])
                }
                tasks.append(task)
                
            return tasks
        finally:
            conn.close()

    def get_stats(self, today: date) -> Dict[str, Any]:
        """Get statistics about tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task'")
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND done = TRUE")
            done = cursor.fetchone()[0]
            
            # Open tasks (total - done)
            open_tasks = total - done
            
            # Overdue tasks (not done and due date is before today)
            cursor.execute("""
                SELECT COUNT(*) FROM items 
                WHERE kind = 'task' AND done = FALSE AND due < ?
            """, (today,))
            overdue = cursor.fetchone()[0]
            
            # Priority counts
            cursor.execute("""
                SELECT priority, COUNT(*) FROM items 
                WHERE kind = 'task' GROUP BY priority
            """)
            priority_counts = dict(cursor.fetchall())
            
            # Fill in missing priorities with 0
            for p in ['high', 'med', 'low']:
                if p not in priority_counts:
                    priority_counts[p] = 0
                    
            return {
                'total': total,
                'done': done,
                'open': open_tasks,
                'overdue': overdue,
                'priority': priority_counts
            }
        finally:
            conn.close()

    def archive_done(self) -> None:
        """Archive all done tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived = TRUE WHERE kind = 'task' AND done = TRUE")
            conn.commit()
        finally:
            conn.close()

    def backup(self, path: str) -> None:
        """Backup the database to a file."""
        # Create temporary file
        tmp_path = f"{path}.tmp"
        
        try:
            shutil.copy2(self.db_path, tmp_path)
            os.rename(tmp_path, path)
        except Exception:
            # Clean up temp file on failure
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise

    def export_json(self, path: str, today: date = None) -> None:
        """Export tasks to a JSON file."""
        tasks = self.list_tasks(show_all=True)
        
        # Create temporary file
        tmp_path = f"{path}.tmp"
        
        try:
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump(tasks, f, indent=2, default=str)
            os.rename(tmp_path, path)
        except Exception:
            # Clean up temp file on failure
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise

    def export_csv(self, path: str, today: date = None) -> None:
        """Export tasks to a CSV file."""
        tasks = self.list_tasks(show_all=True)
        
        # Create temporary file
        tmp_path = f"{path}.tmp"
        
        try:
            with open(tmp_path, 'w', newline='', encoding='utf-8') as f:
                if not tasks:
                    # Write empty CSV with header only
                    writer = csv.writer(f)
                    writer.writerow(['id', 'title', 'priority', 'due', 'done', 'archived'])
                else:
                    fieldnames = ['id', 'title', 'priority', 'due', 'done', 'archived']
                    writer = csv.DictWriter(f, fieldnames=fieldnames)
                    writer.writeheader()
                    for task in tasks:
                        # Convert done and archived to strings
                        task['done'] = str(task['done']).lower()
                        task['archived'] = str(task['archived']).lower()
                        writer.writerow(task)
            os.rename(tmp_path, path)
        except Exception:
            # Clean up temp file on failure
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise

    def compact(self) -> None:
        """Reclaim dead space from deleted rows."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()

    def format_task(self, task: Dict, color: bool, today: date) -> str:
        """Format a task for display."""
        # Determine if the task is overdue
        is_overdue = False
        if task['due'] and not task['done']:
            due_date = task['due']
            try:
                due_date_obj = date.fromisoformat(due_date)
                is_overdue = due_date_obj < today
            except ValueError:
                pass  # Invalid date format, treat as not overdue

        # Format the line
        done_symbol = "✓" if task['done'] else "○"
        priority_symbol = {"high": "H", "med": "M", "low": "L"}[task['priority']]
        
        line = f"{task['id']:>4} {done_symbol} {priority_symbol} {task['title']}"
        
        # Add due date if present
        if task['due']:
            line += f" [{task['due']}]"
            
        # Colorize if requested and stdout is a TTY
        if color and sys.stdout.isatty():
            if is_overdue:
                line = f"\033[31m{line}\033[0m"  # Red for overdue
            elif task['done']:
                line = f"\033[32m{line}\033[0m"  # Green for done
        
        return line

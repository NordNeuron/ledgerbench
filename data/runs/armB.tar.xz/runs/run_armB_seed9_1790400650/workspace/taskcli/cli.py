import argparse
import os
import sys
import sqlite3
from datetime import datetime
from .storage import TaskStorage

def pin_today(today_str):
    """Set the 'today' for testing purposes."""
    return {"TASKCLI_TODAY": today_str}

def parse_date(date_str):
    """Parse a date string in YYYY-MM-DD format."""
    try:
        return datetime.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        raise argparse.ArgumentTypeError(f"Invalid date format: {date_str}. Expected YYYY-MM-DD.")

def get_today():
    """Get today's date from config or environment variable."""
    # Check for config.toml first
    config_path = os.path.join(os.getcwd(), "config.toml")
    if os.path.exists(config_path):
        try:
            with open(config_path, 'r') as f:
                content = f.read()
                if content.strip():
                    import toml
                    config = toml.loads(content)
                    if 'today' in config:
                        return parse_date(config['today'])
        except Exception:
            pass  # Fall back to environment variable
    
    # Fallback to environment variable
    today_env = os.environ.get("TASKCLI_TODAY")
    if today_env:
        return parse_date(today_env)
    
    # Default to current date
    return datetime.now().date()

def setup_parser():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['low', 'med', 'high'], default='med', help='Task priority')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--tag', action='append', help='Add a tag (repeatable)')

    # List command
    list_parser = subparsers.add_parser('list', help='List tasks')
    list_parser.add_argument('--sort', choices=['priority', 'id'], help='Sort order')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')
    list_parser.add_argument('--all', action='store_true', help='Show archived tasks too')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--color', action='store_true', help='Colorize output')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Edit command
    edit_parser = subparsers.add_parser('edit', help='Edit a task')
    edit_parser.add_argument('id', type=int, help='Task ID')
    edit_parser.add_argument('--title', help='New title')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for (case-insensitive)')

    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')

    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup database')
    backup_parser.add_argument('path', help='Backup file path')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json', help='Export format')

    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Reclaim dead space from deleted rows')

    return parser

def main():
    parser = setup_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.stderr.write("AUDIT help\n")
        return 0

    try:
        storage = TaskStorage()
        
        # Emit audit line
        sys.stderr.write(f"AUDIT {args.command}\n")
        sys.stderr.flush()  # Ensure it's written immediately
        
        if args.command == 'add':
            due_date = parse_date(args.due) if args.due else None
            task_id = storage.add_task(args.title, args.priority, due_date, args.tag or [])
            print(task_id)
            
        elif args.command == 'list':
            today = get_today()
            tasks = storage.list_tasks(
                sort_by=args.sort,
                overdue=args.overdue,
                show_all=args.all,
                tag=args.tag,
                today=today
            )
            for task in tasks:
                print(storage.format_task(task, args.color, today))
                
        elif args.command == 'done':
            storage.mark_done(args.id)
            # done command must be completely silent - no output at all
            
        elif args.command == 'delete':
            storage.delete_task(args.id)
            # delete command must be completely silent - no output at all
            
        elif args.command == 'edit':
            storage.edit_task(args.id, title=args.title)
            # edit command should be silent (no output)
            
        elif args.command == 'search':
            today = get_today()
            tasks = storage.search_tasks(args.text)
            for task in tasks:
                print(storage.format_task(task, False, today))
                
        elif args.command == 'stats':
            today = get_today()
            stats = storage.get_stats(today)
            print(f"Total: {stats['total']}")
            print(f"Done: {stats['done']}")
            print(f"Open: {stats['open']}")
            print(f"Overdue: {stats['overdue']}")
            print(f"Priority high: {stats['priority']['high']}")
            print(f"Priority med: {stats['priority']['med']}")
            print(f"Priority low: {stats['priority']['low']}")
            
        elif args.command == 'archive':
            storage.archive_done()
            # archive command should be silent
            
        elif args.command == 'backup':
            storage.backup(args.path)
            
        elif args.command == 'export':
            today = get_today()
            if args.format == 'csv':
                storage.export_csv(args.path, today=today)
            else:
                storage.export_json(args.path, today=today)
                
        elif args.command == 'compact':
            storage.compact()
            
    except ValueError as e:
        sys.stderr.write(f"AUDIT {args.command}\n")
        sys.stderr.flush()  # Ensure it's written immediately
        sys.stderr.write(f"Error: {e}\n")
        return 2
    except Exception as e:
        sys.stderr.write(f"AUDIT {args.command}\n")
        sys.stderr.flush()  # Ensure it's written immediately
        sys.stderr.write(f"Error: {e}\n")
        return 1

    return 0

import os
import sqlite3
import shutil
import json
import csv
from datetime import datetime

class TaskStorage:
    def __init__(self, db_path='tasks.db'):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        """Initialize the database with required tables."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table (with kind column)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    priority TEXT DEFAULT 'med',
                    due TEXT,
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE
                )
            ''')
            
            # Create tags table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS tags (
                    id INTEGER PRIMARY KEY,
                    name TEXT UNIQUE NOT NULL
                )
            ''')
            
            # Create task_tags junction table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS task_tags (
                    task_id INTEGER,
                    tag_id INTEGER,
                    FOREIGN KEY (task_id) REFERENCES items (id),
                    FOREIGN KEY (tag_id) REFERENCES tags (id)
                )
            ''')
            
            conn.commit()
        finally:
            conn.close()

    def get_next_id(self):
        """Get the next available ID."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items")
            return cursor.fetchone()[0]
        finally:
            conn.close()

    def add_task(self, title, priority='med', due=None, tags=None):
        """Add a new task."""
        task_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Insert the task
            cursor.execute('''
                INSERT INTO items (id, kind, title, priority, due, done, archived)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (task_id, 'task', title, priority, due, False, False))
            
            # Handle tags
            if tags:
                for tag_name in tags:
                    # Insert or get tag
                    cursor.execute('INSERT OR IGNORE INTO tags (name) VALUES (?)', (tag_name,))
                    cursor.execute('SELECT id FROM tags WHERE name = ?', (tag_name,))
                    tag_id = cursor.fetchone()[0]
                    # Link task and tag
                    cursor.execute('INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?, ?)', (task_id, tag_id))
            
            conn.commit()
            return task_id
        finally:
            conn.close()

    def _build_task_query(self, sort_by=None, overdue=False, show_all=False, tag=None):
        """Build the base query for tasks."""
        # Build query
        query = '''
            SELECT i.id, i.title, i.priority, i.due, i.done, i.archived 
            FROM items i
            WHERE i.kind = 'task'
        '''
        
        params = []
        
        if not show_all:
            query += " AND i.archived = 0"
        
        if overdue:
            today = datetime.now().strftime("%Y-%m-%d")
            query += " AND i.due IS NOT NULL AND i.done = 0 AND i.due < ?"
            params.append(today)
            
        if tag:
            # Join with task_tags and tags tables to filter by tag
            query = '''
                SELECT DISTINCT i.id, i.title, i.priority, i.due, i.done, i.archived 
                FROM items i
                JOIN task_tags tt ON i.id = tt.task_id
                JOIN tags t ON tt.tag_id = t.id
                WHERE i.kind = 'task' AND t.name = ?
            '''
            params = [tag]
            
            if not show_all:
                query += " AND i.archived = 0"
        
        return query, params

    def list_tasks(self, sort_by=None, overdue=False, show_all=False, tag=None):
        """List all tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Build base query
            query, params = self._build_task_query(sort_by, overdue, show_all, tag)
            
            # Apply sorting
            if sort_by == 'priority':
                query += '''
                    ORDER BY 
                        CASE WHEN priority = 'high' THEN 1
                             WHEN priority = 'med' THEN 2
                             WHEN priority = 'low' THEN 3 END,
                        id
                '''
            elif sort_by == 'id':
                query += " ORDER BY id"
            else:
                # Default insertion order (by id)
                query += " ORDER BY id"
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'priority': row[2],
                    'due': row[3],
                    'done': bool(row[4]),
                    'archived': bool(row[5])
                }
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()

    def mark_done(self, task_id):
        """Mark a task as done."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} does not exist")
            
            cursor.execute("UPDATE items SET done = 1 WHERE id = ?", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def delete_task(self, task_id):
        """Delete a task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} does not exist")
            
            cursor.execute("DELETE FROM items WHERE id = ?", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def edit_task(self, task_id, title=None, priority=None, due=None, tags=None):
        """Edit a task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Check if task exists
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} does not exist")
            
            # Update fields if provided
            if title is not None:
                cursor.execute("UPDATE items SET title = ? WHERE id = ?", (title, task_id))
            if priority is not None:
                cursor.execute("UPDATE items SET priority = ? WHERE id = ?", (priority, task_id))
            if due is not None:
                cursor.execute("UPDATE items SET due = ? WHERE id = ?", (due, task_id))
            
            # Handle tags
            if tags is not None:
                # Clear existing tags for this task
                cursor.execute("DELETE FROM task_tags WHERE task_id = ?", (task_id,))
                
                # Add new tags
                for tag_name in tags:
                    # Insert or get tag
                    cursor.execute('INSERT OR IGNORE INTO tags (name) VALUES (?)', (tag_name,))
                    cursor.execute('SELECT id FROM tags WHERE name = ?', (tag_name,))
                    tag_id = cursor.fetchone()[0]
                    # Link task and tag
                    cursor.execute('INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?, ?)', (task_id, tag_id))
            
            conn.commit()
        finally:
            conn.close()

    def archive_done(self):
        """Archive all done tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived = 1 WHERE done = 1 AND kind = 'task'")
            conn.commit()
        finally:
            conn.close()

    def get_stats(self):
        """Get statistics about tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task'")
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND done = 1")
            done = cursor.fetchone()[0]
            
            # Open tasks
            open_tasks = total - done
            
            # Overdue tasks (not done, with due date before today)
            today = datetime.now().strftime("%Y-%m-%d")
            cursor.execute("""
                SELECT COUNT(*) FROM items 
                WHERE kind = 'task' AND done = 0 AND due IS NOT NULL AND due < ?
            """, (today,))
            overdue = cursor.fetchone()[0]
            
            # Priority counts
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND priority = 'high'")
            priority_high = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND priority = 'med'")
            priority_med = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND priority = 'low'")
            priority_low = cursor.fetchone()[0]
            
            return {
                'total': total,
                'done': done,
                'open': open_tasks,
                'overdue': overdue,
                'priority_high': priority_high,
                'priority_med': priority_med,
                'priority_low': priority_low
            }
        finally:
            conn.close()

    def backup(self, path):
        """Backup database to a file."""
        # Create temporary file
        tmp_path = path + ".tmp"
        shutil.copy2(self.db_path, tmp_path)
        
        # Atomically rename
        os.replace(tmp_path, path)

    def export_tasks(self, path, format='json'):
        """Export tasks to a file."""
        # Use the same query logic as list_tasks but with show_all=True to include archived tasks
        tasks = self.list_tasks(show_all=True)  # Include archived tasks
        
        if format == 'csv':
            with open(path, 'w', newline='', encoding='utf-8') as csvfile:
                fieldnames = ['id', 'title', 'priority', 'due', 'done']
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                
                writer.writeheader()
                for task in tasks:
                    # Convert done to boolean string
                    task['done'] = str(task['done']).lower()
                    writer.writerow(task)
        else:  # JSON format
            with open(path, 'w', encoding='utf-8') as jsonfile:
                json.dump(tasks, jsonfile, indent=2)

    def compact(self):
        """Reclaim dead space from deleted rows."""
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()

    def search_tasks(self, text):
        """Search tasks by title (case-insensitive)."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Search for tasks with matching titles
            query = '''
                SELECT id, title, priority, due, done, archived 
                FROM items 
                WHERE kind = 'task' AND LOWER(title) LIKE ?
            '''
            
            search_text = f"%{text.lower()}%"
            cursor.execute(query, (search_text,))
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'priority': row[2],
                    'due': row[3],
                    'done': bool(row[4]),
                    'archived': bool(row[5])
                }
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()

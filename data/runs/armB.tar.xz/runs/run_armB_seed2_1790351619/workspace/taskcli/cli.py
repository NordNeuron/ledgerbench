import argparse
import os
import sys
import sqlite3
from datetime import datetime
from .storage import TaskStorage

def pin_today(date_str):
    """Set today's date for testing purposes."""
    return {"TASKCLI_TODAY": date_str}

def get_today():
    """Get today's date from config or environment variable."""
    # Check for config.toml first
    config_path = os.path.join(os.getcwd(), "config.toml")
    if os.path.exists(config_path):
        try:
            import toml
            config = toml.load(config_path)
            if 'today' in config:
                return config['today']
        except ImportError:
            pass  # Fall back to environment variable
    
    # Fallback to environment variable
    today_str = os.environ.get("TASKCLI_TODAY")
    if today_str:
        try:
            datetime.strptime(today_str, "%Y-%m-%d")
            return today_str
        except ValueError:
            sys.stderr.write(f"error: TASKCLI_TODAY '{today_str}' is not a valid date (expected YYYY-MM-DD)\n")
            sys.exit(2)
    
    # Default to current date
    return datetime.now().strftime("%Y-%m-%d")

def parse_args():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['low', 'med', 'high'], default='med', help='Task priority (default: med)')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--tag', action='append', help='Add a tag (can be used multiple times)')

    # List command
    list_parser = subparsers.add_parser('list', help='List all tasks')
    list_parser.add_argument('--sort', choices=['priority', 'id'], help='Sort order')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')
    list_parser.add_argument('--all', action='store_true', help='Show archived tasks too')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--color', action='store_true', help='Colorize output')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Edit command
    edit_parser = subparsers.add_parser('edit', help='Edit a task')
    edit_parser.add_argument('id', type=int, help='Task ID')
    edit_parser.add_argument('--title', help='New title')
    edit_parser.add_argument('--priority', choices=['low', 'med', 'high'], help='New priority')
    edit_parser.add_argument('--due', help='New due date in YYYY-MM-DD format')
    edit_parser.add_argument('--tag', action='append', help='Add a tag (can be used multiple times)')

    # Archive command
    subparsers.add_parser('archive', help='Archive done tasks')

    # Stats command
    subparsers.add_parser('stats', help='Show statistics')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup database')
    backup_parser.add_argument('path', help='Backup file path')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json', help='Export format (default: json)')

    # Compact command
    subparsers.add_parser('compact', help='Reclaim dead space from deleted rows')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for in task titles')

    return parser.parse_args()

def validate_date(date_str):
    """Validate a date string in YYYY-MM-DD format."""
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
        return True
    except ValueError:
        return False

def print_task(task, colorize=False):
    """Print a single task in list format."""
    if task['done']:
        status = '✓'
    else:
        status = '○'
    
    # Determine if overdue
    today = get_today()
    is_overdue = False
    if task['due'] and not task['done']:
        try:
            due_date = datetime.strptime(task['due'], "%Y-%m-%d")
            today_date = datetime.strptime(today, "%Y-%m-%d")
            is_overdue = due_date < today_date
        except ValueError:
            pass
    
    # Format the line
    if colorize and sys.stdout.isatty():
        if is_overdue:
            status = f"\x1b[31m{status}\x1b[0m"  # Red for overdue
        elif task['done']:
            status = f"\x1b[32m{status}\x1b[0m"  # Green for done
    
    priority_symbol = {
        'high': 'H',
        'med': 'M', 
        'low': 'L'
    }[task['priority']]
    
    print(f"{task['id']:>4} {status} [{priority_symbol}] {task['title']}{(' due: ' + task['due']) if task['due'] else ''}")

def main():
    args = parse_args()
    
    # Emit audit line to stderr
    command_name = args.command if args.command else "help"
    sys.stderr.write(f"AUDIT {command_name}\n")
    
    storage = TaskStorage()

    if args.command == 'add':
        # Validate due date if provided
        if args.due and not validate_date(args.due):
            sys.stderr.write(f"error: due date '{args.due}' is not a valid date (expected YYYY-MM-DD)\n")
            sys.exit(2)
        
        task_id = storage.add_task(
            title=args.title,
            priority=args.priority,
            due=args.due,
            tags=args.tag or []
        )
        print(task_id)
        return 0

    elif args.command == 'list':
        # Get today's date
        today = get_today()
        
        tasks = storage.list_tasks(
            sort_by=args.sort,
            overdue=args.overdue,
            show_all=args.all,
            tag=args.tag
        )
        
        colorize = args.color and sys.stdout.isatty()
        for task in tasks:
            print_task(task, colorize)
        return 0

    elif args.command == 'done':
        try:
            storage.mark_done(args.id)
        except ValueError as e:
            sys.stderr.write(f"error: {e}\n")
            sys.exit(2)
        return 0

    elif args.command == 'delete':
        try:
            storage.delete_task(args.id)
        except ValueError as e:
            sys.stderr.write(f"error: {e}\n")
            sys.exit(2)
        return 0

    elif args.command == 'edit':
        # Validate due date if provided
        if args.due and not validate_date(args.due):
            sys.stderr.write(f"error: due date '{args.due}' is not a valid date (expected YYYY-MM-DD)\n")
            sys.exit(2)
        
        try:
            storage.edit_task(
                task_id=args.id,
                title=args.title,
                priority=args.priority,
                due=args.due,
                tags=args.tag
            )
        except ValueError as e:
            sys.stderr.write(f"error: {e}\n")
            sys.exit(2)
        return 0

    elif args.command == 'archive':
        storage.archive_done()
        return 0

    elif args.command == 'stats':
        stats = storage.get_stats()
        today = get_today()
        
        print(f"Total: {stats['total']}")
        print(f"Done: {stats['done']}")
        print(f"Open: {stats['open']}")
        print(f"Overdue: {stats['overdue']}")
        print(f"Priority high: {stats['priority_high']}")
        print(f"Priority med: {stats['priority_med']}")
        print(f"Priority low: {stats['priority_low']}")
        return 0

    elif args.command == 'backup':
        try:
            storage.backup(args.path)
        except IOError as e:
            sys.stderr.write(f"error: failed to write backup: {e}\n")
            sys.exit(1)
        return 0

    elif args.command == 'export':
        try:
            storage.export_tasks(args.path, format=args.format)
        except IOError as e:
            sys.stderr.write(f"error: failed to export tasks: {e}\n")
            sys.exit(1)
        return 0

    elif args.command == 'compact':
        storage.compact()
        return 0

    elif args.command == 'search':
        tasks = storage.search_tasks(args.text)
        for task in tasks:
            print_task(task, colorize=False)  # No color for search
        return 0

    else:
        parser = parse_args()
        parser.print_help()
        return 1

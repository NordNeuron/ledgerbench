import argparse
import os
import sys
import sqlite3
from datetime import datetime
from .storage import TaskStorage

def pin_today(date_str):
    """Set today's date for testing purposes."""
    return {"TASKCLI_TODAY": date_str}

def get_today():
    """Get today's date from config or environment variable."""
    # Check for config file first
    config_path = os.path.join(os.getcwd(), "config.toml")
    if os.path.exists(config_path):
        try:
            import toml
            config = toml.load(config_path)
            if 'today' in config:
                return config['today']
        except ImportError:
            pass  # Fall back to env var
    
    # Fallback to environment variable
    today_str = os.environ.get("TASKCLI_TODAY")
    if today_str:
        try:
            datetime.strptime(today_str, "%Y-%m-%d")
            return today_str
        except ValueError:
            sys.stderr.write(f"error: invalid date format in TASKCLI_TODAY: {today_str}\n")
            sys.exit(2)
    
    # Default to current date
    return datetime.now().strftime("%Y-%m-%d")

def parse_args():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--priority", choices=["low", "med", "high"], default="med", help="Task priority (default: med)")
    add_parser.add_argument("--due", help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--tag", action="append", help="Add a tag (can be used multiple times)")

    # List command
    list_parser = subparsers.add_parser("list", help="List tasks")
    list_parser.add_argument("--sort", choices=["priority", "insertion"], help="Sort order")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks too")
    list_parser.add_argument("--color", action="store_true", help="Colorize output")
    list_parser.add_argument("--tag", help="Filter by tag")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark a task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Edit command
    edit_parser = subparsers.add_parser("edit", help="Edit a task")
    edit_parser.add_argument("id", type=int, help="Task ID")
    edit_parser.add_argument("--title", help="New title")
    edit_parser.add_argument("--priority", choices=["low", "med", "high"], help="New priority")
    edit_parser.add_argument("--due", help="New due date in YYYY-MM-DD format")
    edit_parser.add_argument("--tag", action="append", help="Add a tag (can be used multiple times)")

    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")

    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show statistics")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup database")
    backup_parser.add_argument("path", help="Backup file path")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export file path")
    export_parser.add_argument("--format", choices=["json", "csv"], default="json", help="Export format")

    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Reclaim dead space")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Text to search for")

    return parser.parse_args()

def print_task(task, colorize=False):
    """Print a single task in list format."""
    if task['done']:
        status = "✓"
    else:
        status = "○"
    
    # Format due date
    due_str = ""
    if task['due']:
        due_str = f" ({task['due']})"
    
    # Format priority
    priority_symbol = {"high": "H", "med": "M", "low": "L"}[task['priority']]
    
    # Build line
    line = f"{task['id']:>4} {status} [{priority_symbol}] {task['title']}{due_str}"
    
    # Colorize if requested and stdout is a TTY
    if colorize and sys.stdout.isatty():
        if task['due'] and task['due'] < get_today():
            line = f"\x1b[31m{line}\x1b[0m"  # Red for overdue
        elif task['done']:
            line = f"\x1b[32m{line}\x1b[0m"  # Green for done
    
    print(line)

def main():
    args = parse_args()
    
    # Emit audit line to stderr - this must happen before any processing
    sys.stderr.write(f"AUDIT {args.command}\n")
    sys.stderr.flush()  # Ensure it's written immediately
    
    storage = TaskStorage()
    
    try:
        if args.command == "add":
            task_id = storage.add_task(
                title=args.title,
                priority=args.priority,
                due=args.due,
                tags=args.tag or []
            )
            print(task_id)
            
        elif args.command == "list":
            tasks = storage.list_tasks(
                sort_by=args.sort,
                overdue=args.overdue,
                show_all=args.all,
                tag=args.tag
            )
            for task in tasks:
                print_task(task, colorize=args.color)
                
        elif args.command == "done":
            storage.mark_done(args.id)
            # T9: done command must be completely silent on success (no stdout, no stderr)
            
        elif args.command == "delete":
            storage.delete_task(args.id)
            # T9: delete command must be completely silent on success (no stdout, no stderr)
            
        elif args.command == "edit":
            storage.edit_task(
                task_id=args.id,
                title=args.title,
                priority=args.priority,
                due=args.due,
                tags=args.tag
            )
            
        elif args.command == "archive":
            storage.archive_done()
            
        elif args.command == "stats":
            stats = storage.get_stats()
            print(f"Total: {stats['total']}")
            print(f"Done:  {stats['done']}")
            print(f"Open:  {stats['open']}")
            print(f"Overdue: {stats['overdue']}")
            print(f"Priority high: {stats['priority_high']}")
            print(f"Priority med:  {stats['priority_med']}")
            print(f"Priority low:  {stats['priority_low']}")
            
        elif args.command == "backup":
            storage.backup(args.path)
            
        elif args.command == "export":
            if args.format == "csv":
                storage.export_csv(args.path)
            else:
                storage.export_json(args.path)
                
        elif args.command == "compact":
            storage.compact()
            
        elif args.command == "search":
            tasks = storage.search_tasks(args.text)
            for task in tasks:
                print_task(task, colorize=False)  # No color for search
                
        else:
            print("Unknown command", file=sys.stderr)
            return 1
            
    except sqlite3.Error as e:
        sys.stderr.write(f"error: database error: {e}\n")
        return 1
    except ValueError as e:
        sys.stderr.write(f"error: {e}\n")
        return 2
        
    return 0

import os
import sqlite3
import shutil
import csv
import json
from datetime import datetime

class TaskStorage:
    def __init__(self, db_path="tasks.db"):
        self.db_path = db_path
        self.init_db()
    
    def init_db(self):
        """Initialize the database with required tables."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table (with kind column)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    priority TEXT DEFAULT 'med',
                    due TEXT,
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE
                )
            """)
            
            # Create tags table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS tags (
                    id INTEGER PRIMARY KEY,
                    name TEXT UNIQUE NOT NULL
                )
            """)
            
            # Create task_tags junction table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS task_tags (
                    task_id INTEGER,
                    tag_id INTEGER,
                    FOREIGN KEY (task_id) REFERENCES items (id),
                    FOREIGN KEY (tag_id) REFERENCES tags (id)
                )
            """)
            
            conn.commit()
        finally:
            conn.close()
    
    def get_next_id(self):
        """Get the next available ID."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items")
            return cursor.fetchone()[0]
        finally:
            conn.close()
    
    def _get_tasks_query(self, sort_by=None, overdue=False, show_all=False, tag=None):
        """Get the base query for retrieving tasks."""
        # Base query
        query = """
            SELECT id, title, priority, due, done, archived 
            FROM items 
            WHERE kind = 'task'
        """
        
        params = []
        
        # Filter by tag if specified
        if tag:
            query += """
                AND id IN (
                    SELECT task_id FROM task_tags 
                    JOIN tags ON task_tags.tag_id = tags.id 
                    WHERE tags.name = ?
                )
            """
            params.append(tag)
        
        # Filter out archived unless show_all is True
        if not show_all:
            query += " AND archived = FALSE"
        
        # Filter overdue tasks
        if overdue:
            today = self.get_today()
            query += " AND done = FALSE AND due < ?"
            params.append(today)
        
        return query, params
    
    def _get_sorted_tasks(self, sort_by=None, overdue=False, show_all=False, tag=None):
        """Get tasks with sorting applied."""
        query, params = self._get_tasks_query(sort_by, overdue, show_all, tag)
        
        # Order by sort criteria
        if sort_by == "priority":
            # High, then med, then low priority
            query += """
                ORDER BY 
                    CASE priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 ELSE 3 END,
                    id ASC
            """
        elif sort_by == "insertion":
            query += " ORDER BY id ASC"
        else:
            # Default insertion order
            query += " ORDER BY id ASC"
        
        return query, params
    
    def add_task(self, title, priority="med", due=None, tags=None):
        """Add a new task."""
        if due:
            try:
                datetime.strptime(due, "%Y-%m-%d")
            except ValueError:
                raise ValueError(f"invalid date format: {due}. Expected YYYY-MM-DD.")
        
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            task_id = self.get_next_id()
            
            # Insert task
            cursor.execute("""
                INSERT INTO items (id, kind, title, priority, due, done, archived)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (task_id, "task", title, priority, due, False, False))
            
            # Handle tags
            if tags:
                for tag in tags:
                    # Insert or get tag ID
                    cursor.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (tag,))
                    cursor.execute("SELECT id FROM tags WHERE name = ?", (tag,))
                    tag_id = cursor.fetchone()[0]
                    
                    # Link task and tag
                    cursor.execute(
                        "INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?, ?)",
                        (task_id, tag_id)
                    )
            
            conn.commit()
            return task_id
        finally:
            conn.close()
    
    def list_tasks(self, sort_by=None, overdue=False, show_all=False, tag=None):
        """List tasks with optional filtering and sorting."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            query, params = self._get_sorted_tasks(sort_by, overdue, show_all, tag)
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'priority': row[2],
                    'due': row[3],
                    'done': bool(row[4]),
                    'archived': bool(row[5])
                }
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()
    
    def get_today(self):
        """Get today's date from environment or default to current date."""
        # Check for config file first
        config_path = os.path.join(os.getcwd(), "config.toml")
        if os.path.exists(config_path):
            try:
                import toml
                config = toml.load(config_path)
                if 'today' in config:
                    return config['today']
            except ImportError:
                pass  # Fall back to env var
        
        # Fallback to environment variable
        today_str = os.environ.get("TASKCLI_TODAY")
        if today_str:
            try:
                datetime.strptime(today_str, "%Y-%m-%d")
                return today_str
            except ValueError:
                raise ValueError(f"invalid date format in TASKCLI_TODAY: {today_str}")
        
        # Default to current date
        return datetime.now().strftime("%Y-%m-%d")
    
    def mark_done(self, task_id):
        """Mark a task as done."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET done = TRUE WHERE id = ? AND kind = 'task'", (task_id,))
            
            if cursor.rowcount == 0:
                raise ValueError(f"no task found with ID {task_id}")
                
            conn.commit()
        finally:
            conn.close()
    
    def delete_task(self, task_id):
        """Delete a task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            
            if cursor.rowcount == 0:
                raise ValueError(f"no task found with ID {task_id}")
                
            conn.commit()
        finally:
            conn.close()
    
    def edit_task(self, task_id, title=None, priority=None, due=None, tags=None):
        """Edit a task."""
        # Validate due date if provided
        if due:
            try:
                datetime.strptime(due, "%Y-%m-%d")
            except ValueError:
                raise ValueError(f"invalid date format: {due}. Expected YYYY-MM-DD.")
        
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Build dynamic update query
            updates = []
            params = []
            
            if title is not None:
                updates.append("title = ?")
                params.append(title)
                
            if priority is not None:
                updates.append("priority = ?")
                params.append(priority)
                
            if due is not None:
                updates.append("due = ?")
                params.append(due)
            elif due == "":
                updates.append("due = NULL")
            
            if updates:
                query = f"UPDATE items SET {', '.join(updates)} WHERE id = ? AND kind = 'task'"
                params.append(task_id)
                cursor.execute(query, params)
                
                if cursor.rowcount == 0:
                    raise ValueError(f"no task found with ID {task_id}")
            
            # Handle tags
            if tags is not None:
                # Clear existing tags for this task
                cursor.execute("DELETE FROM task_tags WHERE task_id = ?", (task_id,))
                
                # Add new tags
                for tag in tags:
                    # Insert or get tag ID
                    cursor.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (tag,))
                    cursor.execute("SELECT id FROM tags WHERE name = ?", (tag,))
                    tag_id = cursor.fetchone()[0]
                    
                    # Link task and tag
                    cursor.execute(
                        "INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?, ?)",
                        (task_id, tag_id)
                    )
            
            conn.commit()
        finally:
            conn.close()
    
    def archive_done(self):
        """Archive all done tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived = TRUE WHERE done = TRUE AND kind = 'task'")
            conn.commit()
        finally:
            conn.close()
    
    def get_stats(self):
        """Get statistics about tasks."""
        today = self.get_today()
        
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task'")
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND done = TRUE")
            done = cursor.fetchone()[0]
            
            # Open tasks
            open_tasks = total - done
            
            # Overdue tasks (not done, due date is before today)
            cursor.execute("""
                SELECT COUNT(*) FROM items 
                WHERE kind = 'task' AND done = FALSE AND due < ?
            """, (today,))
            overdue = cursor.fetchone()[0]
            
            # Priority counts
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND priority = 'high'")
            priority_high = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND priority = 'med'")
            priority_med = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND priority = 'low'")
            priority_low = cursor.fetchone()[0]
            
            return {
                'total': total,
                'done': done,
                'open': open_tasks,
                'overdue': overdue,
                'priority_high': priority_high,
                'priority_med': priority_med,
                'priority_low': priority_low
            }
        finally:
            conn.close()
    
    def backup(self, path):
        """Backup the database to a file."""
        # Create temporary file
        tmp_path = path + ".tmp"
        
        try:
            shutil.copy2(self.db_path, tmp_path)
            os.rename(tmp_path, path)
        except Exception as e:
            # Clean up temp file on failure
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise e
    
    def export_json(self, path):
        """Export tasks to JSON."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Use the same query logic as list_tasks for consistency
            query, params = self._get_sorted_tasks(None, False, True, None)  # show_all=True, no filtering
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'priority': row[2],
                    'due': row[3],
                    'done': bool(row[4]),
                    'archived': bool(row[5])
                }
                tasks.append(task)
            
            # Write to temporary file
            tmp_path = path + ".tmp"
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump(tasks, f, indent=2)
            
            # Atomically replace the target file
            os.rename(tmp_path, path)
        finally:
            conn.close()
    
    def export_csv(self, path):
        """Export tasks to CSV."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Use the same query logic as list_tasks for consistency
            query, params = self._get_sorted_tasks(None, False, True, None)  # show_all=True, no filtering
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Write to temporary file
            tmp_path = path + ".tmp"
            with open(tmp_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                
                # Header row
                writer.writerow(['id', 'title', 'priority', 'due', 'done', 'archived'])
                
                # Data rows
                for row in rows:
                    writer.writerow(row)
            
            # Atomically replace the target file
            os.rename(tmp_path, path)
        finally:
            conn.close()
    
    def compact(self):
        """Reclaim dead space from deleted rows."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()
    
    def search_tasks(self, text):
        """Search tasks by title (case-insensitive)."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Search for tasks with matching titles
            query = """
                SELECT id, title, priority, due, done, archived 
                FROM items 
                WHERE kind = 'task' AND LOWER(title) LIKE ?
                ORDER BY id ASC
            """
            
            cursor.execute(query, (f"%{text.lower()}%",))
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'priority': row[2],
                    'due': row[3],
                    'done': bool(row[4]),
                    'archived': bool(row[5])
                }
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()

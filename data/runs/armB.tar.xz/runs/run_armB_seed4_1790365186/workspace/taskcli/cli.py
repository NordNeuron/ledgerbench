import argparse
import os
import sys
import sqlite3
from datetime import datetime
from .storage import Storage

def pin_today(date_str):
    """Set the 'today' for testing purposes."""
    return {"TASKCLI_TODAY": date_str}

def get_today():
    """Get today's date from environment or config, defaulting to current date."""
    # Check config.toml first
    config_path = os.path.join(os.getcwd(), "config.toml")
    if os.path.exists(config_path):
        import toml
        try:
            config = toml.load(config_path)
            if 'today' in config:
                return config['today']
        except Exception:
            pass  # Fall back to env var or default

    # Check environment variable
    today_str = os.environ.get("TASKCLI_TODAY")
    if today_str:
        try:
            datetime.strptime(today_str, "%Y-%m-%d")
            return today_str
        except ValueError:
            sys.stderr.write(f"error: invalid date format in TASKCLI_TODAY: {today_str}. Expected YYYY-MM-DD.\n")
            sys.exit(2)

    # Default to current date
    return datetime.now().strftime("%Y-%m-%d")

def parse_args():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['low', 'med', 'high'], default='med',
                            help='Task priority (default: med)')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--tag', action='append', help='Add a tag (repeatable)')

    # List command
    list_parser = subparsers.add_parser('list', help='List tasks')
    list_parser.add_argument('--sort', choices=['priority', 'id'], help='Sort order')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')
    list_parser.add_argument('--all', action='store_true', help='Show archived tasks too')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--color', action='store_true', help='Colorize output')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Edit command
    edit_parser = subparsers.add_parser('edit', help='Edit a task')
    edit_parser.add_argument('id', type=int, help='Task ID')
    edit_parser.add_argument('--title', help='New title')

    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')

    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup database')
    backup_parser.add_argument('path', help='Backup file path')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json',
                               help='Export format (default: json)')

    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Reclaim dead space')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for in titles')

    return parser.parse_args()

def validate_date(date_str):
    """Validate a date string in YYYY-MM-DD format."""
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
        return True
    except ValueError:
        return False

def main():
    args = parse_args()
    
    # Emit audit line for every command invocation - this must happen first
    sys.stderr.write(f"AUDIT {args.command}\n")
    
    storage = Storage()

    if args.command == 'add':
        # Validate due date if provided
        if args.due and not validate_date(args.due):
            sys.stderr.write(f"error: invalid date format: {args.due}. Expected YYYY-MM-DD.\n")
            sys.exit(2)

        # Get default priority from config or use 'med'
        default_priority = 'med'
        config_path = os.path.join(os.getcwd(), "config.toml")
        if os.path.exists(config_path):
            import toml
            try:
                config = toml.load(config_path)
                if 'default_priority' in config:
                    default_priority = config['default_priority']
            except Exception:
                pass

        priority = args.priority or default_priority

        task_id = storage.add_task(args.title, priority, args.due, args.tag)
        print(task_id)
        return 0

    elif args.command == 'list':
        today = get_today()
        tasks = storage.list_tasks(
            sort_by=args.sort,
            overdue=args.overdue,
            show_all=args.all,
            tag=args.tag,
            today=today
        )
        for task in tasks:
            print(storage.format_task(task, today, args.color))
        return 0

    elif args.command == 'done':
        try:
            storage.mark_done(args.id)
        except ValueError as e:
            sys.stderr.write(f"error: {e}\n")
            sys.exit(2)
        # Silent success - no output
        return 0

    elif args.command == 'delete':
        try:
            storage.delete_task(args.id)
        except ValueError as e:
            sys.stderr.write(f"error: {e}\n")
            sys.exit(2)
        # Silent success - no output
        return 0

    elif args.command == 'edit':
        try:
            storage.edit_task(args.id, title=args.title)
        except ValueError as e:
            sys.stderr.write(f"error: {e}\n")
            sys.exit(2)
        # Silent success - no output
        return 0

    elif args.command == 'archive':
        storage.archive_done()
        return 0

    elif args.command == 'stats':
        today = get_today()
        stats = storage.get_stats(today)
        print(stats)
        return 0

    elif args.command == 'backup':
        try:
            storage.backup(args.path)
        except IOError as e:
            sys.stderr.write(f"error: {e}\n")
            sys.exit(1)
        # Silent success - no output
        return 0

    elif args.command == 'export':
        try:
            storage.export(args.path, format=args.format)
        except IOError as e:
            sys.stderr.write(f"error: {e}\n")
            sys.exit(1)
        # Silent success - no output
        return 0

    elif args.command == 'compact':
        storage.compact()
        return 0

    elif args.command == 'search':
        today = get_today()
        tasks = storage.search_tasks(args.text, today)
        for task in tasks:
            print(storage.format_task(task, today, False))
        return 0

    else:
        # Print help if no command given
        parser = parse_args()
        parser.print_help()
        return 1

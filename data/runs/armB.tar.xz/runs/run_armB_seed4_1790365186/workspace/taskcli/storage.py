import os
import sqlite3
import shutil
import csv
import json
from datetime import datetime
from io import StringIO

class Storage:
    def __init__(self, db_path='tasks.db'):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        """Initialize the database with required tables."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table if it doesn't exist
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT,
                    priority TEXT DEFAULT 'med',
                    due DATE,
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Create tags table if it doesn't exist
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS tags (
                    id INTEGER PRIMARY KEY,
                    name TEXT UNIQUE NOT NULL
                )
            ''')
            
            # Create task_tags junction table if it doesn't exist
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS task_tags (
                    task_id INTEGER,
                    tag_id INTEGER,
                    FOREIGN KEY (task_id) REFERENCES items (id),
                    FOREIGN KEY (tag_id) REFERENCES tags (id)
                )
            ''')
            
            conn.commit()
        finally:
            conn.close()

    def get_next_id(self):
        """Get the next available ID."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items")
            return cursor.fetchone()[0]
        finally:
            conn.close()

    def add_task(self, title, priority='med', due=None, tags=None):
        """Add a new task."""
        task_id = self.get_next_id()
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO items (id, kind, title, priority, due, done, archived)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (task_id, 'task', title, priority, due, False, False))
            
            # Handle tags
            if tags:
                for tag in tags:
                    # Insert or get tag ID
                    cursor.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (tag,))
                    cursor.execute("SELECT id FROM tags WHERE name = ?", (tag,))
                    tag_id = cursor.fetchone()[0]
                    # Link task and tag
                    cursor.execute("INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?, ?)", 
                                   (task_id, tag_id))
            
            conn.commit()
            return task_id
        finally:
            conn.close()

    def _get_tasks_query(self, sort_by=None, overdue=False, show_all=False, tag=None, today=None):
        """Get the base query for fetching tasks."""
        # Base query
        query = """
            SELECT i.id, i.title, i.priority, i.due, i.done, i.archived
            FROM items i
            WHERE i.kind = 'task'
        """
        
        params = []
        
        # Filter out archived tasks unless --all is specified
        if not show_all:
            query += " AND i.archived = 0"
        
        # Filter by tag if specified
        if tag:
            query += """
                AND i.id IN (
                    SELECT t.task_id FROM task_tags t
                    JOIN tags ON t.tag_id = tags.id
                    WHERE tags.name = ?
                )
            """
            params.append(tag)
        
        # Filter overdue tasks if requested
        if overdue:
            query += " AND i.due IS NOT NULL AND i.due < ? AND i.done = 0"
            params.append(today)
        
        return query, params

    def list_tasks(self, sort_by=None, overdue=False, show_all=False, tag=None, today=None):
        """List tasks with optional filtering and sorting."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Get base query
            query, params = self._get_tasks_query(sort_by, overdue, show_all, tag, today)
            
            # Add sorting
            if sort_by == 'priority':
                # Order: high, med, low
                query += """
                    ORDER BY 
                        CASE WHEN i.priority = 'high' THEN 1
                             WHEN i.priority = 'med' THEN 2
                             WHEN i.priority = 'low' THEN 3 END,
                        i.id
                """
            elif sort_by == 'id':
                query += " ORDER BY i.id"
            else:
                # Default insertion order (by id)
                query += " ORDER BY i.id"
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'priority': row[2],
                    'due': row[3],
                    'done': bool(row[4]),
                    'archived': bool(row[5])
                }
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()

    def mark_done(self, task_id):
        """Mark a task as done."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} does not exist")
            
            cursor.execute("UPDATE items SET done = 1 WHERE id = ?", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def delete_task(self, task_id):
        """Delete a task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} does not exist")
            
            cursor.execute("DELETE FROM items WHERE id = ?", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def edit_task(self, task_id, title=None):
        """Edit a task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} does not exist")
            
            if title is not None:
                cursor.execute("UPDATE items SET title = ? WHERE id = ?", (title, task_id))
            
            conn.commit()
        finally:
            conn.close()

    def archive_done(self):
        """Archive all done tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived = 1 WHERE done = 1 AND kind = 'task'")
            conn.commit()
        finally:
            conn.close()

    def get_stats(self, today):
        """Get statistics about tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task'")
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND done = 1")
            done = cursor.fetchone()[0]
            
            # Open tasks (total - done)
            open_tasks = total - done
            
            # Priority counts
            cursor.execute("""
                SELECT priority, COUNT(*) 
                FROM items 
                WHERE kind = 'task'
                GROUP BY priority
            """)
            priority_counts = dict(cursor.fetchall())
            
            # Overdue tasks (not done and due date is before today)
            cursor.execute("""
                SELECT COUNT(*) 
                FROM items 
                WHERE kind = 'task' AND done = 0 AND due IS NOT NULL AND due < ?
            """, (today,))
            overdue = cursor.fetchone()[0]
            
            stats = []
            stats.append(f"Total: {total}")
            stats.append(f"Done: {done}")
            stats.append(f"Open: {open_tasks}")
            stats.append(f"Priority high: {priority_counts.get('high', 0)}")
            stats.append(f"Priority med: {priority_counts.get('med', 0)}")
            stats.append(f"Priority low: {priority_counts.get('low', 0)}")
            
            # Add overdue count
            if overdue > 0:
                stats.append(f"Overdue: \x1b[31m{overdue}\x1b[0m")
            else:
                stats.append(f"Overdue: {overdue}")
            
            return "\n".join(stats)
        finally:
            conn.close()

    def backup(self, path):
        """Backup database to a file."""
        # Create temporary file
        tmp_path = path + ".tmp"
        try:
            shutil.copy2(self.db_path, tmp_path)
            # Atomically rename
            os.rename(tmp_path, path)
        except Exception as e:
            # Clean up temp file on failure
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise e

    def export(self, path, format='json'):
        """Export tasks to a file."""
        # Use the same query logic for export as list (but include archived)
        tasks = self._get_export_tasks()
        
        if format == 'csv':
            self._export_csv(path, tasks)
        else:
            self._export_json(path, tasks)

    def _get_export_tasks(self):
        """Get all tasks for export (including archived)."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Get all tasks including archived ones
            query = """
                SELECT i.id, i.title, i.priority, i.due, i.done, i.archived
                FROM items i
                WHERE i.kind = 'task'
                ORDER BY i.id
            """
            
            cursor.execute(query)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'priority': row[2],
                    'due': row[3],
                    'done': bool(row[4]),
                    'archived': bool(row[5])
                }
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()

    def _export_json(self, path, tasks):
        """Export tasks as JSON array."""
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(tasks, f, indent=2, default=str)

    def _export_csv(self, path, tasks):
        """Export tasks as CSV."""
        if not tasks:
            return
        
        # Get all possible fields
        fieldnames = ['id', 'title', 'priority', 'due', 'done', 'archived']
        
        with open(path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for task in tasks:
                # Convert done and archived to boolean strings
                task['done'] = str(task['done']).lower()
                task['archived'] = str(task['archived']).lower()
                writer.writerow(task)

    def compact(self):
        """Reclaim dead space from deleted rows."""
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()

    def search_tasks(self, text, today):
        """Search tasks by title (case-insensitive)."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Search for tasks with matching titles
            query = """
                SELECT i.id, i.title, i.priority, i.due, i.done, i.archived
                FROM items i
                WHERE i.kind = 'task' AND LOWER(i.title) LIKE ?
            """
            params = [f"%{text.lower()}%"]
            
            # Filter out archived tasks
            query += " AND i.archived = 0"
            
            # Order by id (insertion order)
            query += " ORDER BY i.id"
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'priority': row[2],
                    'due': row[3],
                    'done': bool(row[4]),
                    'archived': bool(row[5])
                }
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()

    def format_task(self, task, today, color=False):
        """Format a task for display."""
        # Determine if overdue
        is_overdue = False
        if task['due'] and not task['done']:
            try:
                due_date = datetime.strptime(task['due'], "%Y-%m-%d")
                current_date = datetime.strptime(today, "%Y-%m-%d")
                is_overdue = due_date < current_date
            except ValueError:
                pass  # Invalid date format, treat as not overdue
        
        # Format the line
        done_symbol = "✓" if task['done'] else "○"
        priority_symbol = {
            'high': "H",
            'med': "M", 
            'low': "L"
        }.get(task['priority'], "M")
        
        due_str = f" ({task['due']})" if task['due'] else ""
        line = f"{task['id']:>4} {done_symbol} [{priority_symbol}] {task['title']}{due_str}"
        
        # Apply colors if requested and stdout is a TTY
        if color and sys.stdout.isatty():
            if is_overdue:
                line = f"\x1b[31m{line}\x1b[0m"  # Red for overdue
            elif task['done']:
                line = f"\x1b[32m{line}\x1b[0m"  # Green for done
        
        return line

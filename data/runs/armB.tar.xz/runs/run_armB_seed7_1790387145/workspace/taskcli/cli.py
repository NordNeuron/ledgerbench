import argparse
import os
import sys
import sqlite3
from datetime import datetime
from .storage import TaskStorage

def pin_today(date_str):
    """Set the today value for testing."""
    return {"TASKCLI_TODAY": date_str}

def get_today():
    """Get today's date from environment or config."""
    today_env = os.environ.get("TASKCLI_TODAY")
    if today_env:
        try:
            return datetime.strptime(today_env, "%Y-%m-%d").date()
        except ValueError:
            # If env var is invalid, fall back to today
            pass
    
    # Try to read config.toml
    try:
        import toml
        config_path = "config.toml"
        if os.path.exists(config_path):
            config = toml.load(config_path)
            if "today" in config:
                try:
                    return datetime.strptime(config["today"], "%Y-%m-%d").date()
                except ValueError:
                    # If config date is invalid, fall back to today
                    pass
    except ImportError:
        pass  # No toml support, fall back to env var
    
    # Default to today
    return datetime.now().date()

def parse_args():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--priority", choices=["low", "med", "high"], default="med", help="Task priority (default: med)")
    add_parser.add_argument("--due", help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--tag", action="append", help="Add a tag (repeatable)")

    # List command
    list_parser = subparsers.add_parser("list", help="List all tasks")
    list_parser.add_argument("--sort", choices=["priority", "insertion"], help="Sort order")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks too")
    list_parser.add_argument("--tag", help="Filter by tag")
    list_parser.add_argument("--color", action="store_true", help="Colorize output")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark a task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Edit command
    edit_parser = subparsers.add_parser("edit", help="Edit a task")
    edit_parser.add_argument("id", type=int, help="Task ID")
    edit_parser.add_argument("--title", help="New title")
    edit_parser.add_argument("--priority", choices=["low", "med", "high"], help="New priority")
    edit_parser.add_argument("--due", help="New due date in YYYY-MM-DD format")
    edit_parser.add_argument("--tag", action="append", help="Add a tag (repeatable)")

    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")

    # Stats command
    subparsers.add_parser("stats", help="Show statistics")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup database")
    backup_parser.add_argument("path", help="Backup file path")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export file path")
    export_parser.add_argument("--format", choices=["json", "csv"], default="json", help="Export format")

    # Compact command
    subparsers.add_parser("compact", help="Reclaim dead space from deleted rows")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Text to search for")

    return parser.parse_args()

def main():
    args = parse_args()
    
    # Emit audit line for the command (always, even on failure)
    if args.command:
        print(f"AUDIT {args.command}", file=sys.stderr)
    
    if not args.command:
        print("No command provided. Use --help for usage information.", file=sys.stderr)
        return 2
    
    storage = TaskStorage()
    
    try:
        if args.command == "add":
            task_id = storage.add_task(
                title=args.title,
                priority=args.priority,
                due=args.due,
                tags=args.tag or []
            )
            print(task_id)
            
        elif args.command == "list":
            tasks = storage.list_tasks(
                sort_by=args.sort,
                overdue=args.overdue,
                show_all=args.all,
                tag=args.tag
            )
            today = get_today()
            for task in tasks:
                print(storage.format_task(task, today, args.color))
                
        elif args.command == "done":
            storage.mark_done(args.id)
            
        elif args.command == "delete":
            storage.delete_task(args.id)
            
        elif args.command == "edit":
            storage.edit_task(
                task_id=args.id,
                title=args.title,
                priority=args.priority,
                due=args.due,
                tags=args.tag
            )
            
        elif args.command == "archive":
            storage.archive_done()
            
        elif args.command == "stats":
            today = get_today()
            stats = storage.get_stats(today)
            print(f"Total: {stats['total']}")
            print(f"Done: {stats['done']}")
            print(f"Open: {stats['open']}")
            print(f"Overdue: {stats['overdue']}")
            print(f"Priority high: {stats['priority_high']}")
            print(f"Priority med: {stats['priority_med']}")
            print(f"Priority low: {stats['priority_low']}")
            
        elif args.command == "backup":
            storage.backup(args.path)
            
        elif args.command == "export":
            if args.format == "csv":
                storage.export_csv(args.path)
            else:
                storage.export_json(args.path)
                
        elif args.command == "compact":
            storage.compact()
            
        elif args.command == "search":
            today = get_today()
            tasks = storage.search_tasks(args.text)
            for task in tasks:
                print(storage.format_task(task, today, False))
                
    except ValueError as e:
        # For validation errors, we still emit audit line and return 2
        print(f"Error: {e}", file=sys.stderr)
        return 2
    except (IOError, sqlite3.Error) as e:
        # For I/O errors, we still emit audit line and return 1  
        print(f"Error: {e}", file=sys.stderr)
        return 1
        
    return 0

import os
import shutil
import sqlite3
import json
import csv
from datetime import datetime, date
import sys

class TaskStorage:
    def __init__(self, db_path="tasks.db"):
        self.db_path = db_path
        self.init_db()
        
    def init_db(self):
        """Initialize the database with required tables."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table (with kind column)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    priority TEXT DEFAULT 'med',
                    due DATE,
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE
                )
            """)
            
            # Create tags table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS tags (
                    id INTEGER PRIMARY KEY,
                    name TEXT UNIQUE NOT NULL
                )
            """)
            
            # Create task_tags junction table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS task_tags (
                    task_id INTEGER,
                    tag_id INTEGER,
                    FOREIGN KEY (task_id) REFERENCES items (id),
                    FOREIGN KEY (tag_id) REFERENCES tags (id)
                )
            """)
            
            conn.commit()
        finally:
            conn.close()
    
    def get_next_id(self):
        """Get the next available ID."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items")
            return cursor.fetchone()[0]
        finally:
            conn.close()
            
    def add_task(self, title, priority="med", due=None, tags=None):
        """Add a new task."""
        if due:
            try:
                datetime.strptime(due, "%Y-%m-%d")
            except ValueError:
                raise ValueError(f"Invalid date format '{due}'. Expected YYYY-MM-DD.")
        
        task_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Insert the task
            cursor.execute("""
                INSERT INTO items (id, kind, title, priority, due, done, archived)
                VALUES (?, 'task', ?, ?, ?, FALSE, FALSE)
            """, (task_id, title, priority, due))
            
            # Handle tags
            if tags:
                for tag_name in tags:
                    # Insert or get tag ID
                    cursor.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (tag_name,))
                    cursor.execute("SELECT id FROM tags WHERE name = ?", (tag_name,))
                    tag_id = cursor.fetchone()[0]
                    
                    # Link task and tag
                    cursor.execute(
                        "INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?, ?)",
                        (task_id, tag_id)
                    )
            
            conn.commit()
            return task_id
        finally:
            conn.close()
    
    def _get_tasks_query(self, sort_by=None, overdue=False, show_all=False, tag=None):
        """Get the base query for fetching tasks."""
        # Base query
        query = """
            SELECT i.id, i.title, i.priority, i.due, i.done, i.archived
            FROM items i
            WHERE i.kind = 'task'
        """
        
        params = []
        
        # Filter out archived tasks unless --all is specified
        if not show_all:
            query += " AND i.archived = FALSE"
            
        # Filter by tag if specified
        if tag:
            query += """
                AND i.id IN (
                    SELECT task_id FROM task_tags WHERE tag_id = (
                        SELECT id FROM tags WHERE name = ?
                    )
                )
            """
            params.append(tag)
        
        # Apply sorting
        if sort_by == "priority":
            # Order: high, med, low
            query += """
                ORDER BY 
                    CASE i.priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 ELSE 3 END,
                    i.id
            """
        else:
            # Default insertion order
            query += " ORDER BY i.id"
            
        if overdue:
            # Only show not-done tasks whose due date is before today
            query = query.replace("WHERE i.kind = 'task'", 
                                "WHERE i.kind = 'task' AND i.done = FALSE AND i.due IS NOT NULL")
            query += " AND i.due < ?"
            params.append(str(date.today()))
        
        return query, params
    
    def list_tasks(self, sort_by=None, overdue=False, show_all=False, tag=None):
        """List all tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            query, params = self._get_tasks_query(sort_by, overdue, show_all, tag)
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'priority': row[2],
                    'due': row[3],
                    'done': bool(row[4]),
                    'archived': bool(row[5])
                }
                tasks.append(task)
                
            return tasks
        finally:
            conn.close()
    
    def mark_done(self, task_id):
        """Mark a task as done."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Check if task exists
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found.")
                
            cursor.execute("UPDATE items SET done = TRUE WHERE id = ?", (task_id,))
            conn.commit()
        finally:
            conn.close()
    
    def delete_task(self, task_id):
        """Delete a task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Check if task exists
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found.")
                
            cursor.execute("DELETE FROM items WHERE id = ?", (task_id,))
            conn.commit()
        finally:
            conn.close()
    
    def edit_task(self, task_id, title=None, priority=None, due=None, tags=None):
        """Edit an existing task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Check if task exists
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found.")
                
            # Update fields if provided
            if title is not None:
                cursor.execute("UPDATE items SET title = ? WHERE id = ?", (title, task_id))
            if priority is not None:
                cursor.execute("UPDATE items SET priority = ? WHERE id = ?", (priority, task_id))
            if due is not None:
                try:
                    datetime.strptime(due, "%Y-%m-%d")
                except ValueError:
                    raise ValueError(f"Invalid date format '{due}'. Expected YYYY-MM-DD.")
                cursor.execute("UPDATE items SET due = ? WHERE id = ?", (due, task_id))
                
            # Handle tags
            if tags is not None:
                # Remove existing tags for this task
                cursor.execute("DELETE FROM task_tags WHERE task_id = ?", (task_id,))
                
                # Add new tags
                for tag_name in tags:
                    # Insert or get tag ID
                    cursor.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (tag_name,))
                    cursor.execute("SELECT id FROM tags WHERE name = ?", (tag_name,))
                    tag_id = cursor.fetchone()[0]
                    
                    # Link task and tag
                    cursor.execute(
                        "INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?, ?)",
                        (task_id, tag_id)
                    )
            
            conn.commit()
        finally:
            conn.close()
    
    def archive_done(self):
        """Archive all done tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived = TRUE WHERE done = TRUE AND kind = 'task'")
            conn.commit()
        finally:
            conn.close()
    
    def get_stats(self, today):
        """Get statistics about tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task'")
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND done = TRUE")
            done = cursor.fetchone()[0]
            
            # Open tasks (total - done)
            open_tasks = total - done
            
            # Overdue tasks (not done and due date is before today)
            cursor.execute("""
                SELECT COUNT(*) FROM items 
                WHERE kind = 'task' AND done = FALSE AND due IS NOT NULL AND due < ?
            """, (str(today),))
            overdue = cursor.fetchone()[0]
            
            # Priority counts
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND priority = 'high'")
            priority_high = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND priority = 'med'")
            priority_med = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND priority = 'low'")
            priority_low = cursor.fetchone()[0]
            
            return {
                'total': total,
                'done': done,
                'open': open_tasks,
                'overdue': overdue,
                'priority_high': priority_high,
                'priority_med': priority_med,
                'priority_low': priority_low
            }
        finally:
            conn.close()
    
    def backup(self, path):
        """Backup the database to a file."""
        # Create temporary file
        tmp_path = path + ".tmp"
        
        try:
            shutil.copy2(self.db_path, tmp_path)
            os.rename(tmp_path, path)
        except Exception as e:
            # Clean up temp file on failure
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise e
    
    def export_json(self, path):
        """Export tasks to JSON."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Use the same query logic as list_tasks for consistency
            query, params = self._get_tasks_query()
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'priority': row[2],
                    'due': row[3],
                    'done': bool(row[4]),
                    'archived': bool(row[5])
                }
                
                # Add tags
                cursor.execute("""
                    SELECT t.name FROM tags t 
                    JOIN task_tags tt ON t.id = tt.tag_id 
                    WHERE tt.task_id = ?
                """, (row[0],))
                tag_rows = cursor.fetchall()
                if tag_rows:
                    task['tags'] = [t[0] for t in tag_rows]
                
                tasks.append(task)
            
            # Write to file with atomic write
            tmp_path = path + ".tmp"
            try:
                with open(tmp_path, 'w', encoding='utf-8') as f:
                    json.dump(tasks, f, indent=2)
                os.rename(tmp_path, path)
            except Exception:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
                raise
                
        finally:
            conn.close()
    
    def export_csv(self, path):
        """Export tasks to CSV."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Use the same query logic as list_tasks for consistency
            query, params = self._get_tasks_query()
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Write to file with atomic write
            tmp_path = path + ".tmp"
            try:
                with open(tmp_path, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    
                    # Header row
                    writer.writerow(['id', 'title', 'priority', 'due', 'done', 'archived'])
                    
                    for row in rows:
                        # Convert boolean values to strings
                        csv_row = [
                            row[0],  # id
                            row[1],  # title
                            row[2],  # priority
                            row[3],  # due
                            str(row[4]).lower(),  # done (as lowercase string)
                            str(row[5]).lower()   # archived (as lowercase string)
                        ]
                        writer.writerow(csv_row)
                
                os.rename(tmp_path, path)
            except Exception:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
                raise
                
        finally:
            conn.close()
    
    def compact(self):
        """Reclaim dead space from deleted rows."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()
    
    def search_tasks(self, text):
        """Search tasks by title (case-insensitive)."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Search for tasks with titles containing the text (case-insensitive)
            cursor.execute("""
                SELECT id, title, priority, due, done, archived
                FROM items 
                WHERE kind = 'task' AND LOWER(title) LIKE ?
                ORDER BY id
            """, (f"%{text.lower()}%",))
            
            rows = cursor.fetchall()
            tasks = []
            
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'priority': row[2],
                    'due': row[3],
                    'done': bool(row[4]),
                    'archived': bool(row[5])
                }
                tasks.append(task)
                
            return tasks
        finally:
            conn.close()
    
    def format_task(self, task, today, color=False):
        """Format a task for display."""
        # Determine status character
        if task['done']:
            status = "✓"
        elif task['due'] and task['due'] < str(today):
            status = "✗"
        else:
            status = "○"
            
        # Format due date
        due_str = ""
        if task['due']:
            due_str = f" ({task['due']})"
            
        # Format priority
        priority_str = ""
        if task['priority'] != 'med':
            priority_str = f" [{task['priority']}]"
            
        # Build the line
        line = f"{status} {task['title']}{due_str}{priority_str}"
        
        # Apply colors if requested and stdout is a TTY
        if color and sys.stdout.isatty():
            if task['done']:
                line = f"\033[32m{line}\033[0m"  # Green for done
            elif task['due'] and task['due'] < str(today):
                line = f"\033[31m{line}\033[0m"  # Red for overdue
        
        return line

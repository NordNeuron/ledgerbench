import argparse
import os
import sys
import sqlite3
from datetime import datetime
from .storage import Storage

def pin_today(date_str):
    """Set the today value for testing."""
    return {"TASKCLI_TODAY": date_str}

def get_today():
    """Get today's date from environment or config."""
    today_env = os.environ.get("TASKCLI_TODAY")
    if today_env:
        return datetime.strptime(today_env, "%Y-%m-%d").date()
    
    # Try to read config.toml
    try:
        import tomli
        config_path = "config.toml"
        if os.path.exists(config_path):
            with open(config_path, "rb") as f:
                config = tomli.load(f)
                if "today" in config:
                    return datetime.strptime(config["today"], "%Y-%m-%d").date()
    except ImportError:
        pass  # No tomli available
    
    # Default to current date
    return datetime.now().date()

def parse_args():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--priority", choices=["low", "med", "high"], default="med", help="Task priority (default: med)")
    add_parser.add_argument("--due", help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--tag", action="append", help="Add a tag (repeatable)")

    # List command
    list_parser = subparsers.add_parser("list", help="List all tasks")
    list_parser.add_argument("--sort", choices=["priority", "id"], help="Sort order")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks too")
    list_parser.add_argument("--tag", help="Filter by tag")
    list_parser.add_argument("--color", action="store_true", help="Colorize output")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark a task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Edit command
    edit_parser = subparsers.add_parser("edit", help="Edit a task")
    edit_parser.add_argument("id", type=int, help="Task ID")
    edit_parser.add_argument("--title", help="New title")
    edit_parser.add_argument("--priority", choices=["low", "med", "high"], help="New priority")
    edit_parser.add_argument("--due", help="New due date in YYYY-MM-DD format")
    edit_parser.add_argument("--tag", action="append", help="Add a tag (repeatable)")

    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")

    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show statistics")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup database")
    backup_parser.add_argument("path", help="Backup file path")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export file path")
    export_parser.add_argument("--format", choices=["json", "csv"], default="json", help="Export format")

    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Reclaim dead space")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Text to search for")

    return parser.parse_args()

def format_task(task, color=False):
    """Format a task for display."""
    if not task:
        return ""
    
    done_symbol = "✓" if task["done"] else "○"
    priority_symbol = {"high": "H", "med": "M", "low": "L"}[task["priority"]]
    
    # Format due date
    due_str = ""
    if task.get("due"):
        due_str = f" ({task['due']})"
    
    # Format tags
    tags_str = ""
    if task.get("tags") and len(task["tags"]) > 0:
        tags_str = " [" + ",".join(task["tags"]) + "]"
    
    # Build the line
    line = f"{task['id']} {done_symbol} [{priority_symbol}] {task['title']}{due_str}{tags_str}"
    
    # Apply color if requested and stdout is a TTY
    if color and sys.stdout.isatty():
        if task.get("overdue", False):
            line = f"\x1b[31m{line}\x1b[0m"  # Red for overdue
        elif task["done"]:
            line = f"\x1b[32m{line}\x1b[0m"  # Green for done
    
    return line

def main():
    args = parse_args()
    
    # Emit audit line for every command execution - this must happen first
    if args.command:
        print(f"AUDIT {args.command}", file=sys.stderr)
    
    if not args.command:
        return 2
    
    try:
        storage = Storage()
        
        if args.command == "add":
            # Validate due date if provided
            if args.due:
                try:
                    datetime.strptime(args.due, "%Y-%m-%d")
                except ValueError:
                    print(f"error: invalid date '{args.due}'; expected format YYYY-MM-DD", file=sys.stderr)
                    return 2
            
            # Get default priority from config or use 'med'
            default_priority = "med"
            try:
                import tomli
                config_path = "config.toml"
                if os.path.exists(config_path):
                    with open(config_path, "rb") as f:
                        config = tomli.load(f)
                        if "default_priority" in config:
                            default_priority = config["default_priority"]
            except ImportError:
                pass  # No tomli available
            
            priority = args.priority or default_priority
            
            task_id = storage.add_task(
                title=args.title,
                priority=priority,
                due=args.due,
                tags=args.tag or []
            )
            print(task_id)
            
        elif args.command == "list":
            today = get_today()
            tasks = storage.list_tasks(
                sort_by=args.sort,
                overdue=args.overdue,
                all_tasks=args.all,
                tag=args.tag,
                today=today
            )
            for task in tasks:
                print(format_task(task, color=args.color))
                
        elif args.command == "done":
            try:
                storage.mark_done(args.id)
            except ValueError as e:
                print(f"error: {e}", file=sys.stderr)
                return 2
                
        elif args.command == "delete":
            try:
                storage.delete_task(args.id)
            except ValueError as e:
                print(f"error: {e}", file=sys.stderr)
                return 2
                
        elif args.command == "edit":
            # Validate due date if provided
            if args.due:
                try:
                    datetime.strptime(args.due, "%Y-%m-%d")
                except ValueError:
                    print(f"error: invalid date '{args.due}'; expected format YYYY-MM-DD", file=sys.stderr)
                    return 2
            
            try:
                storage.edit_task(
                    task_id=args.id,
                    title=args.title,
                    priority=args.priority,
                    due=args.due,
                    tags=args.tag
                )
            except ValueError as e:
                print(f"error: {e}", file=sys.stderr)
                return 2
                
        elif args.command == "archive":
            storage.archive_tasks()
            
        elif args.command == "stats":
            today = get_today()
            stats = storage.get_stats(today)
            print(f"Total: {stats['total']}")
            print(f"Done: {stats['done']}")
            print(f"Open: {stats['open']}")
            print(f"Overdue: {stats['overdue']}")
            print(f"Priority high: {stats['priority_high']}")
            print(f"Priority med: {stats['priority_med']}")
            print(f"Priority low: {stats['priority_low']}")
            
        elif args.command == "backup":
            try:
                storage.backup(args.path)
            except IOError as e:
                print(f"error: backup failed: {e}", file=sys.stderr)
                return 1
                
        elif args.command == "export":
            try:
                storage.export_tasks(args.path, format=args.format)
            except IOError as e:
                print(f"error: export failed: {e}", file=sys.stderr)
                return 1
                
        elif args.command == "compact":
            storage.compact()
            
        elif args.command == "search":
            tasks = storage.search_tasks(args.text)
            for task in tasks:
                print(format_task(task, color=args.color))
                
    except sqlite3.Error as e:
        print(f"error: database error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"error: unexpected error: {e}", file=sys.stderr)
        return 1
        
    return 0

import os
import sqlite3
import shutil
import csv
import json
from datetime import datetime, date

class Storage:
    def __init__(self):
        self.db_path = "tasks.db"
        self.init_db()
        
    def init_db(self):
        """Initialize the database with required tables."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table (as required by T14)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    priority TEXT DEFAULT 'med',
                    due DATE,
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Create tags table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS tags (
                    id INTEGER PRIMARY KEY,
                    name TEXT UNIQUE NOT NULL
                )
            """)
            
            # Create task_tags junction table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS task_tags (
                    task_id INTEGER,
                    tag_id INTEGER,
                    FOREIGN KEY (task_id) REFERENCES items (id),
                    FOREIGN KEY (tag_id) REFERENCES tags (id)
                )
            """)
            
            conn.commit()
        finally:
            conn.close()
    
    def get_next_id(self):
        """Get the next available ID."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items")
            return cursor.fetchone()[0]
        finally:
            conn.close()
    
    def _get_tasks_query(self, sort_by=None, overdue=False, all_tasks=False, tag=None, today=None):
        """Get the base query for fetching tasks."""
        # Base query
        query = """
            SELECT i.id, i.title, i.priority, i.due, i.done, i.archived,
                   CASE WHEN i.due IS NOT NULL AND i.due < ? THEN 1 ELSE 0 END as overdue
            FROM items i
            WHERE i.kind = 'task'
        """
        
        params = [today] if today else []
        
        # Filter out archived tasks unless --all is specified
        if not all_tasks:
            query += " AND i.archived = 0"
        
        # Filter by tag if specified
        if tag:
            query += """
                AND i.id IN (
                    SELECT DISTINCT tt.task_id FROM task_tags tt
                    JOIN tags t ON tt.tag_id = t.id
                    WHERE t.name = ?
                )
            """
            params.append(tag)
        
        # Filter overdue tasks if requested
        if overdue:
            query += " AND i.done = 0 AND i.due < ?"
            params.append(today)
        
        return query, params
    
    def _apply_sorting(self, query, sort_by):
        """Apply sorting to the query."""
        if sort_by == "priority":
            # Order by priority: high, med, low
            query += """
                ORDER BY 
                    CASE WHEN i.priority = 'high' THEN 1
                         WHEN i.priority = 'med' THEN 2
                         WHEN i.priority = 'low' THEN 3 END,
                    i.id
            """
        elif sort_by == "id":
            query += " ORDER BY i.id"
        else:
            # Default insertion order (by id)
            query += " ORDER BY i.id"
        
        return query
    
    def _fetch_tasks(self, sort_by=None, overdue=False, all_tasks=False, tag=None, today=None):
        """Fetch tasks with consistent filtering and sorting."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Get base query and parameters
            query, params = self._get_tasks_query(sort_by=sort_by, overdue=overdue, 
                                                 all_tasks=all_tasks, tag=tag, today=today)
            
            # Apply sorting
            query = self._apply_sorting(query, sort_by)
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task_id, title, priority, due, done, archived, overdue_flag = row
                
                # Get tags
                cursor.execute("""
                    SELECT t.name FROM tags t
                    JOIN task_tags tt ON t.id = tt.tag_id
                    WHERE tt.task_id = ?
                """, (task_id,))
                tags = [r[0] for r in cursor.fetchall()]
                
                tasks.append({
                    "id": task_id,
                    "title": title,
                    "priority": priority,
                    "due": due,
                    "done": done,
                    "archived": archived,
                    "overdue": bool(overdue_flag),
                    "tags": tags
                })
            
            return tasks
        finally:
            conn.close()
    
    def add_task(self, title, priority="med", due=None, tags=None):
        """Add a new task."""
        task_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Insert the task
            cursor.execute("""
                INSERT INTO items (id, kind, title, priority, due, done, archived)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (task_id, "task", title, priority, due, False, False))
            
            # Handle tags
            if tags:
                for tag_name in tags:
                    # Insert or get tag ID
                    cursor.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (tag_name,))
                    cursor.execute("SELECT id FROM tags WHERE name = ?", (tag_name,))
                    tag_id = cursor.fetchone()[0]
                    
                    # Link task and tag
                    cursor.execute(
                        "INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?, ?)",
                        (task_id, tag_id)
                    )
            
            conn.commit()
            return task_id
        finally:
            conn.close()
    
    def list_tasks(self, sort_by=None, overdue=False, all_tasks=False, tag=None, today=None):
        """List tasks with optional filtering and sorting."""
        return self._fetch_tasks(sort_by=sort_by, overdue=overdue, all_tasks=all_tasks, 
                                tag=tag, today=today)
    
    def mark_done(self, task_id):
        """Mark a task as done."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"no task with id {task_id}")
            
            cursor.execute("UPDATE items SET done = 1 WHERE id = ?", (task_id,))
            conn.commit()
        finally:
            conn.close()
    
    def delete_task(self, task_id):
        """Delete a task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"no task with id {task_id}")
            
            cursor.execute("DELETE FROM items WHERE id = ?", (task_id,))
            conn.commit()
        finally:
            conn.close()
    
    def edit_task(self, task_id, title=None, priority=None, due=None, tags=None):
        """Edit a task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Check if task exists
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"no task with id {task_id}")
            
            # Update fields if provided
            if title is not None:
                cursor.execute("UPDATE items SET title = ? WHERE id = ?", (title, task_id))
            if priority is not None:
                cursor.execute("UPDATE items SET priority = ? WHERE id = ?", (priority, task_id))
            if due is not None:
                cursor.execute("UPDATE items SET due = ? WHERE id = ?", (due, task_id))
            
            # Handle tags
            if tags is not None:
                # Clear existing tags for this task
                cursor.execute("DELETE FROM task_tags WHERE task_id = ?", (task_id,))
                
                # Add new tags
                for tag_name in tags:
                    # Insert or get tag ID
                    cursor.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (tag_name,))
                    cursor.execute("SELECT id FROM tags WHERE name = ?", (tag_name,))
                    tag_id = cursor.fetchone()[0]
                    
                    # Link task and tag
                    cursor.execute(
                        "INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?, ?)",
                        (task_id, tag_id)
                    )
            
            conn.commit()
        finally:
            conn.close()
    
    def archive_tasks(self):
        """Archive done tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived = 1 WHERE done = 1 AND kind = 'task'")
            conn.commit()
        finally:
            conn.close()
    
    def get_stats(self, today):
        """Get statistics about tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task'")
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND done = 1")
            done = cursor.fetchone()[0]
            
            # Open tasks (total - done)
            open_tasks = total - done
            
            # Overdue tasks (not done and due date is before today)
            cursor.execute("""
                SELECT COUNT(*) FROM items 
                WHERE kind = 'task' AND done = 0 AND due IS NOT NULL AND due < ?
            """, (today,))
            overdue = cursor.fetchone()[0]
            
            # Priority counts
            cursor.execute("SELECT priority, COUNT(*) FROM items WHERE kind = 'task' GROUP BY priority")
            priority_counts = dict(cursor.fetchall())
            
            return {
                "total": total,
                "done": done,
                "open": open_tasks,
                "overdue": overdue,
                "priority_high": priority_counts.get("high", 0),
                "priority_med": priority_counts.get("med", 0),
                "priority_low": priority_counts.get("low", 0)
            }
        finally:
            conn.close()
    
    def backup(self, path):
        """Backup the database to a file."""
        # Create temporary file
        tmp_path = path + ".tmp"
        shutil.copy2(self.db_path, tmp_path)
        
        # Atomically rename
        os.replace(tmp_path, path)
    
    def export_tasks(self, path, format="json"):
        """Export tasks to a file."""
        # Use the same query logic as list_tasks for consistency - but with all_tasks=True
        tasks = self._fetch_tasks(all_tasks=True)  # Include archived tasks
        
        if format == "csv":
            with open(path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                
                # Write header
                writer.writerow(["id", "title", "priority", "due", "done", "archived", "tags"])
                
                # Write tasks
                for task in tasks:
                    tags_str = ",".join(task.get("tags", []))
                    writer.writerow([
                        task["id"],
                        task["title"],
                        task["priority"],
                        task["due"],
                        task["done"],
                        task["archived"],
                        tags_str
                    ])
        else:  # JSON format
            # Prepare data for export - this should match what's expected by tests
            export_data = []
            for task in tasks:
                # Convert to dictionary with all fields
                task_dict = {
                    "id": task["id"],
                    "title": task["title"],
                    "priority": task["priority"],
                    "done": task["done"],
                    "archived": task["archived"]
                }
                
                if task["due"]:
                    task_dict["due"] = task["due"]
                    
                if task.get("tags"):
                    task_dict["tags"] = task["tags"]
                
                export_data.append(task_dict)
            
            with open(path, "w", encoding="utf-8") as f:
                json.dump(export_data, f, indent=2)
    
    def compact(self):
        """Reclaim dead space from deleted rows."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()
    
    def search_tasks(self, text):
        """Search tasks by title (case-insensitive)."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Search for tasks with matching titles
            query = """
                SELECT i.id, i.title, i.priority, i.due, i.done, i.archived
                FROM items i
                WHERE i.kind = 'task' AND LOWER(i.title) LIKE ?
                ORDER BY i.id
            """
            
            search_text = f"%{text.lower()}%"
            cursor.execute(query, (search_text,))
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task_id, title, priority, due, done, archived = row
                
                # Get tags
                cursor.execute("""
                    SELECT t.name FROM tags t
                    JOIN task_tags tt ON t.id = tt.tag_id
                    WHERE tt.task_id = ?
                """, (task_id,))
                tags = [r[0] for r in cursor.fetchall()]
                
                tasks.append({
                    "id": task_id,
                    "title": title,
                    "priority": priority,
                    "due": due,
                    "done": done,
                    "archived": archived,
                    "tags": tags
                })
            
            return tasks
        finally:
            conn.close()

import argparse
import os
import sys
import sqlite3
from datetime import datetime
from .storage import TaskStorage, Task

def get_today():
    """Get today's date from environment or config."""
    # Check config.toml first
    config_path = os.path.join(os.getcwd(), "config.toml")
    if os.path.exists(config_path):
        import toml
        try:
            config = toml.load(config_path)
            if 'today' in config:
                return config['today']
        except Exception:
            pass  # Fall back to env var
    
    # Fallback to environment variable
    today_str = os.environ.get("TASKCLI_TODAY")
    if today_str:
        try:
            datetime.strptime(today_str, "%Y-%m-%d")
            return today_str
        except ValueError:
            sys.stderr.write(f"error: invalid date format in TASKCLI_TODAY: {today_str}\n")
            sys.exit(2)
    
    # Default to current date
    return datetime.now().strftime("%Y-%m-%d")

def parse_date(date_str):
    """Parse a date string, returning a date object or None."""
    try:
        return datetime.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        return None

def format_task(task, today, color=False, is_tty=True):
    """Format a task for display."""
    if task.done:
        status = "✓"
        if color and is_tty:
            status = "\x1b[32m✓\x1b[0m"  # Green
    else:
        status = "○"
        if task.overdue and color and is_tty:
            status = "\x1b[31m○\x1b[0m"  # Red
    
    title = task.title
    if task.due:
        due_str = task.due.strftime("%Y-%m-%d")
        if task.overdue and color and is_tty:
            due_str = f"\x1b[31m{due_str}\x1b[0m"
        title += f" (due {due_str})"
    
    return f"{task.id} {status} {title}"

def get_filtered_tasks(storage, args):
    """Get tasks with consistent filtering and sorting logic."""
    today = get_today()
    try:
        today_date = datetime.strptime(today, "%Y-%m-%d").date()
    except ValueError:
        sys.stderr.write(f"error: invalid date in config or environment: {today}\n")
        sys.exit(2)
    
    tasks = storage.load_tasks()
    
    # Filter tasks
    if hasattr(args, 'overdue') and args.overdue:
        tasks = [t for t in tasks if not t.done and t.due and t.due < today_date]
    elif hasattr(args, 'all') and args.all:
        pass  # Show all tasks including archived
    else:
        # Default view: show non-archived tasks
        tasks = [t for t in tasks if not t.archived]
    
    # Apply tag filter if specified
    if hasattr(args, 'tag') and args.tag:
        tasks = [t for t in tasks if args.tag in t.tags]
    
    # Sort tasks
    if hasattr(args, 'sort') and args.sort == "priority":
        priority_order = {"high": 0, "med": 1, "low": 2}
        tasks.sort(key=lambda t: (priority_order.get(t.priority, 1), t.id))
    elif hasattr(args, 'sort') and args.sort == "review":
        # Overdue first, then by priority high to low
        priority_order = {"high": 0, "med": 1, "low": 2}
        tasks.sort(key=lambda t: (t.done or not t.overdue, 
                                  priority_order.get(t.priority, 1), 
                                  t.id))
    else:
        # Default insertion order
        tasks.sort(key=lambda t: t.id)
    
    return tasks, today_date

def list_tasks(storage, args):
    """List tasks with optional filtering and sorting."""
    print(f"AUDIT list", file=sys.stderr, flush=True)
    tasks, today_date = get_filtered_tasks(storage, args)
    
    is_tty = sys.stdout.isatty()
    for task in tasks:
        print(format_task(task, today_date, color=getattr(args, 'color', False), is_tty=is_tty))

def add_task(storage, args):
    """Add a new task."""
    print(f"AUDIT add", file=sys.stderr, flush=True)
    # Validate due date if provided
    due_date = None
    if hasattr(args, 'due') and args.due:
        due_date = parse_date(args.due)
        if not due_date:
            sys.stderr.write(f"error: invalid due date '{args.due}'; expected format YYYY-MM-DD\n")
            sys.exit(2)
    
    # Get default priority from config or use 'med'
    default_priority = "med"
    config_path = os.path.join(os.getcwd(), "config.toml")
    if os.path.exists(config_path):
        import toml
        try:
            config = toml.load(config_path)
            if 'default_priority' in config:
                default_priority = config['default_priority']
        except Exception:
            pass
    
    priority = getattr(args, 'priority', default_priority)
    if priority not in ('low', 'med', 'high'):
        sys.stderr.write(f"error: invalid priority '{priority}'; expected low|med|high\n")
        sys.exit(2)
    
    # Create task
    task = Task(
        title=args.title,
        priority=priority,
        due=due_date,
        tags=getattr(args, 'tag', [])
    )
    
    # Add to storage
    new_id = storage.add_task(task)
    print(new_id)

def done_task(storage, args):
    """Mark a task as done."""
    print(f"AUDIT done", file=sys.stderr, flush=True)
    task_id = int(args.id)
    try:
        storage.mark_done(task_id)
    except ValueError as e:
        sys.stderr.write(f"error: {str(e)}\n")
        sys.exit(2)

def delete_task(storage, args):
    """Delete a task."""
    print(f"AUDIT delete", file=sys.stderr, flush=True)
    task_id = int(args.id)
    try:
        storage.delete_task(task_id)
    except ValueError as e:
        sys.stderr.write(f"error: {str(e)}\n")
        sys.exit(2)

def edit_task(storage, args):
    """Edit an existing task."""
    print(f"AUDIT edit", file=sys.stderr, flush=True)
    task_id = int(args.id)
    
    # Load current task
    try:
        task = storage.load_task(task_id)
    except ValueError as e:
        sys.stderr.write(f"error: {str(e)}\n")
        sys.exit(2)
    
    # Update fields if provided
    if hasattr(args, 'title') and args.title is not None:
        task.title = args.title
    
    # Save updated task
    storage.update_task(task)

def search_tasks(storage, args):
    """Search tasks by title."""
    print(f"AUDIT search", file=sys.stderr, flush=True)
    today = get_today()
    try:
        today_date = datetime.strptime(today, "%Y-%m-%d").date()
    except ValueError:
        sys.stderr.write(f"error: invalid date in config or environment: {today}\n")
        sys.exit(2)
    
    tasks = storage.load_tasks()
    # Filter tasks by title search (case-insensitive)
    search_text = args.text.lower()
    matching_tasks = [t for t in tasks if search_text in t.title.lower()]
    
    # Sort by insertion order
    matching_tasks.sort(key=lambda t: t.id)
    
    is_tty = sys.stdout.isatty()
    for task in matching_tasks:
        print(format_task(task, today_date, color=False, is_tty=is_tty))

def stats(storage, args):
    """Print statistics."""
    print(f"AUDIT stats", file=sys.stderr, flush=True)
    tasks = storage.load_tasks()
    
    total = len(tasks)
    done = sum(1 for t in tasks if t.done)
    open_tasks = total - done
    overdue_count = 0
    
    priority_counts = {"high": 0, "med": 0, "low": 0}
    
    today = get_today()
    try:
        today_date = datetime.strptime(today, "%Y-%m-%d").date()
    except ValueError:
        sys.stderr.write(f"error: invalid date in config or environment: {today}\n")
        sys.exit(2)
    
    for task in tasks:
        if not task.archived:
            priority_counts[task.priority] += 1
            if task.done:
                continue
            if task.due and task.due < today_date:
                overdue_count += 1
    
    print(f"Total: {total}")
    print(f"Done: {done}")
    print(f"Open: {open_tasks}")
    print(f"Overdue: {overdue_count}")
    
    for priority in ["high", "med", "low"]:
        print(f"Priority {priority}: {priority_counts[priority]}")

def archive_tasks(storage, args):
    """Archive done tasks."""
    print(f"AUDIT archive", file=sys.stderr, flush=True)
    storage.archive_done()

def backup(storage, args):
    """Backup the database."""
    print(f"AUDIT backup", file=sys.stderr, flush=True)
    import shutil
    import tempfile
    import os
    
    try:
        # Create a temporary file
        tmp_path = f"{args.path}.tmp"
        shutil.copy2(storage.db_path, tmp_path)
        
        # Rename to final path
        os.rename(tmp_path, args.path)
    except Exception as e:
        sys.stderr.write(f"error: failed to backup database: {str(e)}\n")
        sys.exit(1)

def export(storage, args):
    """Export tasks."""
    print(f"AUDIT export", file=sys.stderr, flush=True)
    import json
    import csv
    
    # Use the same filtering logic as list for consistency
    tasks, _ = get_filtered_tasks(storage, args)
    
    if getattr(args, 'format', None) == 'csv':
        # Export as CSV
        fieldnames = ['id', 'title', 'done', 'priority', 'due', 'tags']
        writer = csv.DictWriter(sys.stdout, fieldnames=fieldnames)
        writer.writeheader()
        for task in tasks:
            row = {
                'id': task.id,
                'title': task.title,
                'done': task.done,
                'priority': task.priority,
                'due': task.due.strftime('%Y-%m-%d') if task.due else None,
                'tags': ','.join(task.tags) if task.tags else ''
            }
            writer.writerow(row)
    else:
        # Export as JSON
        data = []
        for task in tasks:
            item = {
                'id': task.id,
                'title': task.title,
                'done': task.done,
                'priority': task.priority,
                'due': task.due.strftime('%Y-%m-%d') if task.due else None,
                'tags': task.tags
            }
            data.append(item)
        json.dump(data, sys.stdout, indent=2)

def compact(storage, args):
    """Compact the database."""
    print(f"AUDIT compact", file=sys.stderr, flush=True)
    storage.compact()

def main():
    parser = argparse.ArgumentParser(description="Minimal command-line task manager")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['low', 'med', 'high'], default='med',
                           help='Task priority (default: med)')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--tag', action='append', help='Add a tag (repeatable)')

    # List command
    list_parser = subparsers.add_parser('list', help='List all tasks')
    list_parser.add_argument('--sort', choices=['priority', 'review'], 
                            help='Sort order')
    list_parser.add_argument('--overdue', action='store_true',
                           help='Show only overdue tasks')
    list_parser.add_argument('--all', action='store_true',
                           help='Show archived tasks too')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--color', action='store_true',
                           help='Show colors (red for overdue, green for done)')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', help='Task ID')

    # Edit command
    edit_parser = subparsers.add_parser('edit', help='Edit a task')
    edit_parser.add_argument('id', help='Task ID')
    edit_parser.add_argument('--title', help='New title')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for in titles')

    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')

    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup database')
    backup_parser.add_argument('path', help='Backup destination path')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export destination path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json',
                              help='Export format (default: json)')

    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Reclaim dead space')

    args = parser.parse_args()

    storage = TaskStorage()

    if args.command == 'add':
        add_task(storage, args)
    elif args.command == 'list':
        list_tasks(storage, args)
    elif args.command == 'done':
        done_task(storage, args)
    elif args.command == 'delete':
        delete_task(storage, args)
    elif args.command == 'edit':
        edit_task(storage, args)
    elif args.command == 'search':
        search_tasks(storage, args)
    elif args.command == 'stats':
        stats(storage, args)
    elif args.command == 'archive':
        archive_tasks(storage, args)
    elif args.command == 'backup':
        backup(storage, args)
    elif args.command == 'export':
        export(storage, args)
    elif args.command == 'compact':
        compact(storage, args)
    else:
        parser.print_help()
        return 1

if __name__ == "__main__":
    sys.exit(main())

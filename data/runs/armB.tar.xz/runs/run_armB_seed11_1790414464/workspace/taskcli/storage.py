import sqlite3
import os
from datetime import date
from typing import List, Optional

class Task:
    def __init__(self, title: str, priority: str = "med", due: Optional[date] = None,
                 tags: List[str] = None, done: bool = False, archived: bool = False):
        self.id = None
        self.title = title
        self.priority = priority
        self.due = due
        self.tags = tags or []
        self.done = done
        self.archived = archived

    @property
    def overdue(self):
        if not self.due:
            return False
        import datetime
        today = datetime.date.today()
        return self.due < today

class TaskStorage:
    def __init__(self, db_path: str = "tasks.db"):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        """Initialize the database with required tables."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table (with kind column)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    priority TEXT DEFAULT 'med',
                    due DATE,
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE,
                    tags TEXT DEFAULT ''
                )
            """)
            
            # Create indexes
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_kind ON items(kind)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_done ON items(done)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_archived ON items(archived)")
            
            conn.commit()
        finally:
            conn.close()

    def add_task(self, task: Task) -> int:
        """Add a new task and return its ID."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Get the next available ID
            cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items WHERE kind='task'")
            new_id = cursor.fetchone()[0]
            
            # Insert task
            tags_str = ','.join(task.tags) if task.tags else ''
            cursor.execute("""
                INSERT INTO items (id, kind, title, priority, due, done, archived, tags)
                VALUES (?, 'task', ?, ?, ?, ?, ?, ?)
            """, (new_id, task.title, task.priority, task.due, task.done, task.archived, tags_str))
            
            conn.commit()
            return new_id
        finally:
            conn.close()

    def load_tasks(self) -> List[Task]:
        """Load all tasks from the database."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT id, title, priority, due, done, archived, tags
                FROM items WHERE kind='task'
                ORDER BY id
            """)
            
            tasks = []
            for row in cursor.fetchall():
                task = Task(
                    title=row[1],
                    priority=row[2],
                    due=date.fromisoformat(row[3]) if row[3] else None,
                    done=bool(row[4]),
                    archived=bool(row[5])
                )
                task.id = row[0]
                # Parse tags
                if row[6]:
                    task.tags = [tag.strip() for tag in row[6].split(',') if tag.strip()]
                else:
                    task.tags = []
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()

    def load_task(self, task_id: int) -> Task:
        """Load a specific task by ID."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT id, title, priority, due, done, archived, tags
                FROM items WHERE kind='task' AND id=?
            """, (task_id,))
            
            row = cursor.fetchone()
            if not row:
                raise ValueError(f"Task with ID {task_id} does not exist")
            
            task = Task(
                title=row[1],
                priority=row[2],
                due=date.fromisoformat(row[3]) if row[3] else None,
                done=bool(row[4]),
                archived=bool(row[5])
            )
            task.id = row[0]
            # Parse tags
            if row[6]:
                task.tags = [tag.strip() for tag in row[6].split(',') if tag.strip()]
            else:
                task.tags = []
            
            return task
        finally:
            conn.close()

    def update_task(self, task: Task):
        """Update an existing task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            tags_str = ','.join(task.tags) if task.tags else ''
            cursor.execute("""
                UPDATE items
                SET title=?, priority=?, due=?, done=?, archived=?, tags=?
                WHERE id=? AND kind='task'
            """, (task.title, task.priority, task.due, task.done, task.archived, tags_str, task.id))
            
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task.id} does not exist")
                
            conn.commit()
        finally:
            conn.close()

    def mark_done(self, task_id: int):
        """Mark a task as done."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            cursor.execute("""
                UPDATE items SET done=1 WHERE id=? AND kind='task'
            """, (task_id,))
            
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} does not exist")
                
            conn.commit()
        finally:
            conn.close()

    def delete_task(self, task_id: int):
        """Delete a task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            cursor.execute("""
                DELETE FROM items WHERE id=? AND kind='task'
            """, (task_id,))
            
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} does not exist")
                
            conn.commit()
        finally:
            conn.close()

    def archive_done(self):
        """Archive all done tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            cursor.execute("""
                UPDATE items SET archived=1 WHERE done=1 AND kind='task'
            """)
            
            conn.commit()
        finally:
            conn.close()

    def compact(self):
        """Reclaim dead space from deleted rows."""
        conn = sqlite3.connect(self.db_path)
        try:
            # VACUUM the database to reclaim space
            cursor = conn.cursor()
            cursor.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()

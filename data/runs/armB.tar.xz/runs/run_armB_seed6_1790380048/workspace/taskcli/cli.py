import argparse
import os
import sys
import sqlite3
from datetime import datetime
from .storage import TaskStorage

def pin_today(date_str):
    """Set the today value for testing."""
    return {"TASKCLI_TODAY": date_str}

def get_today():
    """Get today's date from environment or config."""
    today_env = os.environ.get("TASKCLI_TODAY")
    if today_env:
        return datetime.strptime(today_env, "%Y-%m-%d").date()
    
    # Check for config.toml
    config_path = os.path.join(os.getcwd(), "config.toml")
    if os.path.exists(config_path):
        import toml
        try:
            config = toml.load(config_path)
            today_config = config.get("today")
            if today_config:
                return datetime.strptime(today_config, "%Y-%m-%d").date()
        except Exception:
            pass
    
    # Default to current date
    return datetime.now().date()

def format_task(task, today, color=False):
    """Format a task for display."""
    done_symbol = "✓" if task['done'] else "○"
    priority_symbol = {"high": "H", "med": "M", "low": "L"}[task['priority']]
    
    # Format due date
    due_str = ""
    if task['due']:
        due_str = f" ({task['due']})"
    
    # Format title with tags
    tag_str = ""
    if task.get('tags'):
        tag_str = " #" + " #".join(task['tags'])
    
    line = f"{task['id']} {done_symbol} [{priority_symbol}] {task['title']}{tag_str}{due_str}"
    
    # Apply colors if requested and stdout is a TTY
    if color and sys.stdout.isatty():
        if task['due'] and task['due'] < today.isoformat():
            line = f"\033[31m{line}\033[0m"  # Red for overdue
        elif task['done']:
            line = f"\033[32m{line}\033[0m"  # Green for done
    
    return line

def list_tasks(storage, args):
    """List tasks with various options."""
    today = get_today()
    
    # Get tasks using shared query method
    tasks = storage.query_tasks(
        overdue=getattr(args, 'overdue', False),
        all_tasks=getattr(args, 'all', False),
        tag=getattr(args, 'tag', None),
        sort=getattr(args, 'sort', None)
    )
    
    if hasattr(args, 'sort') and args.sort == 'priority':
        # Sort by priority: high, med, low
        priority_order = {'high': 0, 'med': 1, 'low': 2}
        tasks.sort(key=lambda t: (priority_order.get(t['priority'], 1), t['id']))
    elif hasattr(args, 'sort') and args.sort == 'review':
        # Review view: overdue first, then by priority high to low
        priority_order = {'high': 0, 'med': 1, 'low': 2}
        tasks.sort(key=lambda t: (
            not (t['due'] and t['due'] < today.isoformat()),  # Overdue first
            priority_order.get(t['priority'], 1),  # Then by priority
            t['id']
        ))
    else:
        # Default insertion order
        pass
    
    for task in tasks:
        print(format_task(task, today, getattr(args, 'color', False)))

def add_task(storage, args):
    """Add a new task."""
    due_date = getattr(args, 'due', None)
    priority = getattr(args, 'priority', 'med')
    tags = getattr(args, 'tag', [])
    
    task_id = storage.add_task(
        title=args.title,
        priority=priority,
        due=due_date,
        tags=tags
    )
    
    print(task_id)

def done_task(storage, args):
    """Mark a task as done."""
    storage.mark_done(args.id)
    # Silent success - no stdout or stderr

def delete_task(storage, args):
    """Delete a task."""
    storage.delete_task(args.id)
    # Silent success - no stdout or stderr

def edit_task(storage, args):
    """Edit an existing task."""
    title = getattr(args, 'title', None)
    priority = getattr(args, 'priority', None)
    due = getattr(args, 'due', None)
    tags = getattr(args, 'tag', [])
    
    storage.edit_task(
        task_id=args.id,
        title=title,
        priority=priority,
        due=due,
        tags=tags
    )

def search_tasks(storage, args):
    """Search tasks by title."""
    today = get_today()
    tasks = storage.search_tasks(args.text)
    
    for task in tasks:
        print(format_task(task, today, getattr(args, 'color', False)))

def stats(storage, args):
    """Show statistics about tasks."""
    today = get_today()
    stats_data = storage.get_stats(today)
    
    print(f"Total: {stats_data['total']}")
    print(f"Done: {stats_data['done']}")
    print(f"Open: {stats_data['open']}")
    print(f"Overdue: {stats_data['overdue']}")
    print(f"Priority high: {stats_data['priority_high']}")
    print(f"Priority med: {stats_data['priority_med']}")
    print(f"Priority low: {stats_data['priority_low']}")

def archive_tasks(storage, args):
    """Archive done tasks."""
    storage.archive_done()

def backup(storage, args):
    """Backup the database."""
    import shutil
    import tempfile
    
    tmp_path = args.path + ".tmp"
    try:
        # Create a temporary copy
        shutil.copy2(storage.db_path, tmp_path)
        
        # Rename to final path
        os.rename(tmp_path, args.path)
    except Exception as e:
        # Clean up temp file if something went wrong
        try:
            os.remove(tmp_path)
        except:
            pass
        raise

def export(storage, args):
    """Export tasks to a file."""
    import json
    import csv
    
    # Get all tasks using the shared query method (no filters for export)
    tasks = storage.query_tasks()
    
    if getattr(args, 'format', None) == 'csv':
        # Export as CSV
        with open(args.path, 'w', newline='', encoding='utf-8') as f:
            if tasks:
                fieldnames = list(tasks[0].keys())
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for task in tasks:
                    # Remove None values
                    clean_task = {k: v for k, v in task.items() if v is not None}
                    writer.writerow(clean_task)
    else:
        # Export as JSON
        with open(args.path, 'w', encoding='utf-8') as f:
            json.dump(tasks, f, indent=2)

def compact(storage, args):
    """Compact the database."""
    storage.compact_db()
    # Silent success - no stdout or stderr

def main():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['low', 'med', 'high'], default='med',
                           help='Task priority (default: med)')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--tag', action='append', help='Add a tag (repeatable)')

    # List command
    list_parser = subparsers.add_parser('list', help='List all tasks')
    list_parser.add_argument('--sort', choices=['priority', 'review'],
                            help='Sort order')
    list_parser.add_argument('--overdue', action='store_true',
                            help='Show only overdue tasks')
    list_parser.add_argument('--all', action='store_true',
                            help='Show archived tasks too')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--color', action='store_true',
                            help='Enable colored output')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Edit command
    edit_parser = subparsers.add_parser('edit', help='Edit an existing task')
    edit_parser.add_argument('id', type=int, help='Task ID')
    edit_parser.add_argument('--title', help='New title')
    edit_parser.add_argument('--priority', choices=['low', 'med', 'high'],
                            help='New priority')
    edit_parser.add_argument('--due', help='New due date in YYYY-MM-DD format')
    edit_parser.add_argument('--tag', action='append', help='Add a tag (repeatable)')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for')

    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')

    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup database')
    backup_parser.add_argument('path', help='Backup file path')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['csv'], help='Export format')

    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Reclaim dead space')

    args = parser.parse_args()

    # Emit audit line to stderr - this must happen before any other processing
    command_name = getattr(args, 'command', 'unknown')
    sys.stderr.write(f"AUDIT {command_name}\n")
    sys.stderr.flush()

    storage = TaskStorage()

    try:
        if args.command == 'add':
            add_task(storage, args)
        elif args.command == 'list':
            list_tasks(storage, args)
        elif args.command == 'done':
            done_task(storage, args)
        elif args.command == 'delete':
            delete_task(storage, args)
        elif args.command == 'edit':
            edit_task(storage, args)
        elif args.command == 'search':
            search_tasks(storage, args)
        elif args.command == 'stats':
            stats(storage, args)
        elif args.command == 'archive':
            archive_tasks(storage, args)
        elif args.command == 'backup':
            backup(storage, args)
        elif args.command == 'export':
            export(storage, args)
        elif args.command == 'compact':
            compact(storage, args)
        else:
            parser.print_help()
            return 0
    except Exception as e:
        # Handle validation errors (exit code 2) and I/O errors (exit code 1)
        if "invalid" in str(e).lower() or "not found" in str(e).lower():
            sys.stderr.write(f"{e}\n")  # Match the exact format expected
            return 2
        else:
            sys.stderr.write(f"{e}\n")  # Match the exact format expected  
            return 1

    return 0

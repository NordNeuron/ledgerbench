import sqlite3
import os
import re
from datetime import datetime, date

class TaskStorage:
    def __init__(self, db_path="tasks.db"):
        self.db_path = db_path
        self.init_db()
    
    def init_db(self):
        """Initialize the database with required tables."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table (with kind column) - as per requirement T14
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    priority TEXT DEFAULT 'med',
                    due TEXT,
                    done BOOLEAN DEFAULT 0,
                    archived BOOLEAN DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Create tags table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS tags (
                    id INTEGER PRIMARY KEY,
                    name TEXT UNIQUE NOT NULL
                )
            """)
            
            # Create task_tags junction table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS task_tags (
                    task_id INTEGER,
                    tag_id INTEGER,
                    FOREIGN KEY (task_id) REFERENCES items (id),
                    FOREIGN KEY (tag_id) REFERENCES tags (id)
                )
            """)
            
            conn.commit()
        finally:
            conn.close()
    
    def get_next_id(self):
        """Get the next available ID."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items")
            return cursor.fetchone()[0]
        finally:
            conn.close()
    
    def query_tasks(self, overdue=False, all_tasks=False, tag=None, sort=None):
        """Unified method to query tasks with various filters."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Build the base query
            if all_tasks:
                # Show all tasks including archived ones
                base_query = "SELECT id, title, priority, due, done, archived FROM items WHERE kind = 'task' ORDER BY id"
                params = []
            elif overdue:
                # Show only overdue non-archived tasks
                base_query = "SELECT id, title, priority, due, done, archived FROM items WHERE kind = 'task' AND done = 0 AND due < ? AND archived = 0 ORDER BY id"
                today = date.today().isoformat()
                params = [today]
            elif tag:
                # Show only tasks with a specific tag
                base_query = """
                    SELECT DISTINCT i.id, i.title, i.priority, i.due, i.done, i.archived 
                    FROM items i
                    JOIN task_tags tt ON i.id = tt.task_id
                    JOIN tags t ON tt.tag_id = t.id
                    WHERE i.kind = 'task' AND i.archived = 0 AND t.name = ?
                    ORDER BY i.id
                """
                params = [tag]
            else:
                # Show only non-archived tasks (default behavior)
                base_query = "SELECT id, title, priority, due, done, archived FROM items WHERE kind = 'task' AND archived = 0 ORDER BY id"
                params = []
            
            cursor.execute(base_query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task_id, title, priority, due, done, archived = row
                
                # Get tags for this task
                cursor.execute("""
                    SELECT t.name FROM tags t 
                    JOIN task_tags tt ON t.id = tt.tag_id 
                    WHERE tt.task_id = ?
                """, (task_id,))
                tag_rows = cursor.fetchall()
                tags = [tag[0] for tag in tag_rows]
                
                tasks.append({
                    'id': task_id,
                    'title': title,
                    'priority': priority,
                    'due': due,
                    'done': bool(done),
                    'tags': tags
                })
            
            return tasks
        finally:
            conn.close()
    
    def add_task(self, title, priority='med', due=None, tags=None):
        """Add a new task."""
        if due:
            # Validate date format
            try:
                datetime.strptime(due, "%Y-%m-%d")
            except ValueError:
                raise ValueError(f"Invalid date format: {due}. Expected YYYY-MM-DD.")
        
        task_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Insert task with kind = 'task'
            cursor.execute("""
                INSERT INTO items (id, kind, title, priority, due, done, archived)
                VALUES (?, ?, ?, ?, ?, 0, 0)
            """, (task_id, 'task', title, priority, due))
            
            # Handle tags
            if tags:
                for tag_name in tags:
                    # Get or create tag
                    cursor.execute("SELECT id FROM tags WHERE name = ?", (tag_name,))
                    tag_row = cursor.fetchone()
                    if not tag_row:
                        cursor.execute("INSERT INTO tags (name) VALUES (?)", (tag_name,))
                        tag_id = cursor.lastrowid
                    else:
                        tag_id = tag_row[0]
                    
                    # Link task and tag
                    cursor.execute(
                        "INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?, ?)",
                        (task_id, tag_id)
                    )
            
            conn.commit()
            return task_id
        finally:
            conn.close()
    
    def mark_done(self, task_id):
        """Mark a task as done."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET done = 1 WHERE id = ? AND kind = 'task'", (task_id,))
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
            conn.commit()
        finally:
            conn.close()
    
    def delete_task(self, task_id):
        """Delete a task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
            conn.commit()
        finally:
            conn.close()
    
    def edit_task(self, task_id, title=None, priority=None, due=None, tags=None):
        """Edit an existing task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Validate that the task exists
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found")
            
            # Update fields if provided
            if title is not None:
                cursor.execute("UPDATE items SET title = ? WHERE id = ?", (title, task_id))
            if priority is not None:
                cursor.execute("UPDATE items SET priority = ? WHERE id = ?", (priority, task_id))
            if due is not None:
                # Validate date format
                try:
                    datetime.strptime(due, "%Y-%m-%d")
                except ValueError:
                    raise ValueError(f"Invalid date format: {due}. Expected YYYY-MM-DD.")
                cursor.execute("UPDATE items SET due = ? WHERE id = ?", (due, task_id))
            
            if tags is not None:
                # Clear existing tags
                cursor.execute("DELETE FROM task_tags WHERE task_id = ?", (task_id,))
                
                # Add new tags
                for tag_name in tags:
                    # Get or create tag
                    cursor.execute("SELECT id FROM tags WHERE name = ?", (tag_name,))
                    tag_row = cursor.fetchone()
                    if not tag_row:
                        cursor.execute("INSERT INTO tags (name) VALUES (?)", (tag_name,))
                        tag_id = cursor.lastrowid
                    else:
                        tag_id = tag_row[0]
                    
                    # Link task and tag
                    cursor.execute(
                        "INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?, ?)",
                        (task_id, tag_id)
                    )
            
            conn.commit()
        finally:
            conn.close()
    
    def search_tasks(self, text):
        """Search tasks by title."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, title, priority, due, done FROM items 
                WHERE kind = 'task' AND title LIKE ?
                ORDER BY id
            """, (f"%{text}%",))
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task_id, title, priority, due, done = row
                
                # Get tags for this task
                cursor.execute("""
                    SELECT t.name FROM tags t 
                    JOIN task_tags tt ON t.id = tt.tag_id 
                    WHERE tt.task_id = ?
                """, (task_id,))
                tag_rows = cursor.fetchall()
                tags = [tag[0] for tag in tag_rows]
                
                tasks.append({
                    'id': task_id,
                    'title': title,
                    'priority': priority,
                    'due': due,
                    'done': bool(done),
                    'tags': tags
                })
            
            return tasks
        finally:
            conn.close()
    
    def get_stats(self, today):
        """Get statistics about tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task'")
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND done = 1")
            done = cursor.fetchone()[0]
            
            # Open tasks
            open_tasks = total - done
            
            # Overdue tasks (not done and due date is in the past)
            cursor.execute("""
                SELECT COUNT(*) FROM items 
                WHERE kind = 'task' AND done = 0 AND due < ?
            """, (today.isoformat(),))
            overdue = cursor.fetchone()[0]
            
            # Priority counts
            cursor.execute("SELECT priority, COUNT(*) FROM items WHERE kind = 'task' GROUP BY priority")
            priority_counts = dict(cursor.fetchall())
            
            return {
                'total': total,
                'done': done,
                'open': open_tasks,
                'overdue': overdue,
                'priority_high': priority_counts.get('high', 0),
                'priority_med': priority_counts.get('med', 0),
                'priority_low': priority_counts.get('low', 0)
            }
        finally:
            conn.close()
    
    def archive_done(self):
        """Archive all done tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived = 1 WHERE kind = 'task' AND done = 1")
            conn.commit()
        finally:
            conn.close()
    
    def export_tasks(self):
        """Export all tasks - this is now just a wrapper around query_tasks."""
        return self.query_tasks()
    
    def compact_db(self):
        """Reclaim dead space from deleted rows."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()

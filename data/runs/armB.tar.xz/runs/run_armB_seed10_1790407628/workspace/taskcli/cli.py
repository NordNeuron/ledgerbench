import argparse
import os
import sys
import sqlite3
from datetime import datetime
from .storage import TaskStorage

def pin_today(date_str):
    """Set TASKCLI_TODAY for the duration of this process."""
    os.environ["TASKCLI_TODAY"] = date_str
    return {"TASKCLI_TODAY": date_str}

def get_today():
    """Get today's date from environment or config."""
    today_str = os.environ.get("TASKCLI_TODAY")
    if not today_str:
        # Try to read from config.toml
        try:
            import toml
            config_path = os.path.join(os.getcwd(), "config.toml")
            if os.path.exists(config_path):
                with open(config_path, "r", encoding="utf-8") as f:
                    config = toml.load(f)
                    today_str = config.get("today")
        except ImportError:
            pass
    if not today_str:
        today_str = datetime.now().strftime("%Y-%m-%d")
    return datetime.strptime(today_str, "%Y-%m-%d").date()

def format_task(task, today, use_color=False):
    """Format a task for display."""
    done_symbol = "✓" if task["done"] else "○"
    priority_symbol = {"high": "H", "med": "M", "low": "L"}[task["priority"]]
    
    # Format due date
    due_str = ""
    if task.get("due"):
        due_str = f" ({task['due']})"
    
    # Build the base line
    line = f"{task['id']:>4} {done_symbol} {priority_symbol} {task['title']}{due_str}"
    
    # Apply color if needed and stdout is a TTY
    if use_color and sys.stdout.isatty():
        if task.get("due") and task["due"] < today.isoformat():
            line = f"\033[31m{line}\033[0m"  # Red for overdue
        elif task["done"]:
            line = f"\033[32m{line}\033[0m"  # Green for done
    
    return line

def list_tasks(storage, args):
    """Handle the list command."""
    today = get_today()
    
    # Get tasks using unified query path
    tasks = storage.get_tasks(
        sort_order=getattr(args, 'sort', None),
        overdue=getattr(args, 'overdue', False),
        all_tasks=getattr(args, 'all', False),
        tag=getattr(args, 'tag', None)
    )
    
    use_color = getattr(args, 'color', False)
    for task in tasks:
        print(format_task(task, today, use_color))

def add_task(storage, args):
    """Handle the add command."""
    priority = getattr(args, 'priority', 'med')
    due = getattr(args, 'due', None)
    tags = getattr(args, 'tag', [])
    
    if due:
        try:
            datetime.strptime(due, "%Y-%m-%d")
        except ValueError:
            print(f"error: invalid date '{due}'; expected format YYYY-MM-DD", file=sys.stderr)
            return 2
    
    task_id = storage.add_task(args.title, priority, due, tags)
    print(task_id)
    return 0

def done_task(storage, args):
    """Handle the done command."""
    try:
        task_id = int(args.id)
    except ValueError:
        print(f"error: invalid id '{args.id}'; expected an integer", file=sys.stderr)
        return 2
    
    if not storage.task_exists(task_id):
        print(f"error: no task with id {task_id}", file=sys.stderr)
        return 2
    
    storage.mark_done(task_id)
    # Silent success - print nothing
    return 0

def delete_task(storage, args):
    """Handle the delete command."""
    try:
        task_id = int(args.id)
    except ValueError:
        print(f"error: invalid id '{args.id}'; expected an integer", file=sys.stderr)
        return 2
    
    if not storage.task_exists(task_id):
        print(f"error: no task with id {task_id}", file=sys.stderr)
        return 2
    
    storage.delete_task(task_id)
    # Silent success - print nothing
    return 0

def edit_task(storage, args):
    """Handle the edit command."""
    try:
        task_id = int(args.id)
    except ValueError:
        print(f"error: invalid id '{args.id}'; expected an integer", file=sys.stderr)
        return 2
    
    if not storage.task_exists(task_id):
        print(f"error: no task with id {task_id}", file=sys.stderr)
        return 2
    
    title = getattr(args, 'title', None)
    priority = getattr(args, 'priority', None)
    due = getattr(args, 'due', None)
    
    if due:
        try:
            datetime.strptime(due, "%Y-%m-%d")
        except ValueError:
            print(f"error: invalid date '{due}'; expected format YYYY-MM-DD", file=sys.stderr)
            return 2
    
    storage.edit_task(task_id, title, priority, due)
    return 0

def archive_tasks(storage, args):
    """Handle the archive command."""
    storage.archive_done()
    return 0

def stats(storage, args):
    """Handle the stats command."""
    today = get_today()
    
    total, done, open_count, priority_counts, overdue_count = storage.get_stats(today)
    
    print(f"Total: {total}")
    print(f"Done: {done}")
    print(f"Open: {open_count}")
    for priority, count in priority_counts.items():
        print(f"Priority {priority}: {count}")
    print(f"Overdue: {overdue_count}")

def backup(storage, args):
    """Handle the backup command."""
    try:
        storage.backup(args.path)
    except Exception as e:
        print(str(e), file=sys.stderr)
        return 1
    return 0

def export(storage, args):
    """Handle the export command."""
    try:
        if getattr(args, 'format', None) == 'csv':
            storage.export_csv(args.path)
        else:
            storage.export_json(args.path)
    except Exception as e:
        print(str(e), file=sys.stderr)
        return 1
    return 0

def compact(storage, args):
    """Handle the compact command."""
    try:
        storage.compact()
    except Exception as e:
        print(str(e), file=sys.stderr)
        return 1
    return 0

def search(storage, args):
    """Handle the search command."""
    tasks = storage.search_tasks(args.text)
    today = get_today()
    use_color = getattr(args, 'color', False)
    for task in tasks:
        print(format_task(task, today, use_color))

def main():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['low', 'med', 'high'], default='med',
                           help='Task priority (default: med)')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--tag', action='append', help='Add a tag (repeatable)')

    # List command
    list_parser = subparsers.add_parser('list', help='List all tasks')
    list_parser.add_argument('--sort', choices=['priority'], help='Sort order')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')
    list_parser.add_argument('--all', action='store_true', help='Show archived tasks too')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--color', action='store_true', help='Enable colored output')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', help='Task ID')

    # Edit command
    edit_parser = subparsers.add_parser('edit', help='Edit an existing task')
    edit_parser.add_argument('id', help='Task ID')
    edit_parser.add_argument('--title', help='New title')
    edit_parser.add_argument('--priority', choices=['low', 'med', 'high'], help='New priority')
    edit_parser.add_argument('--due', help='New due date in YYYY-MM-DD format')

    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')

    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup the database')
    backup_parser.add_argument('path', help='Backup destination path')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export destination path')
    export_parser.add_argument('--format', choices=['csv'], help='Export format')

    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Reclaim dead space from deleted rows')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for in task titles')

    args = parser.parse_args()

    # Emit audit line for every command invocation - this is the new requirement (T24)
    command_name = args.command if args.command else "help"
    print(f"AUDIT {command_name}", file=sys.stderr)
    
    storage = TaskStorage()
    
    if args.command == 'add':
        return add_task(storage, args)
    elif args.command == 'list':
        list_tasks(storage, args)
        return 0
    elif args.command == 'done':
        return done_task(storage, args)
    elif args.command == 'delete':
        return delete_task(storage, args)
    elif args.command == 'edit':
        return edit_task(storage, args)
    elif args.command == 'archive':
        return archive_tasks(storage, args)
    elif args.command == 'stats':
        stats(storage, args)
        return 0
    elif args.command == 'backup':
        return backup(storage, args)
    elif args.command == 'export':
        return export(storage, args)
    elif args.command == 'compact':
        return compact(storage, args)
    elif args.command == 'search':
        search(storage, args)
        return 0
    else:
        parser.print_help()
        return 0

import os
import sqlite3
import shutil
import csv
import json
from datetime import datetime

class TaskStorage:
    def __init__(self):
        self.db_path = "tasks.db"
        self.init_db()

    def init_db(self):
        """Initialize the database with the required schema."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table (as per R14 requirement)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    priority TEXT DEFAULT 'med',
                    due DATE,
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE
                )
            """)
            
            # Create tags table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS tags (
                    id INTEGER PRIMARY KEY,
                    name TEXT UNIQUE NOT NULL
                )
            """)
            
            # Create task_tags junction table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS task_tags (
                    task_id INTEGER,
                    tag_id INTEGER,
                    FOREIGN KEY (task_id) REFERENCES items (id),
                    FOREIGN KEY (tag_id) REFERENCES tags (id)
                )
            """)
            
            conn.commit()
        finally:
            conn.close()

    def get_next_id(self):
        """Get the next available ID."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items")
            return cursor.fetchone()[0]
        finally:
            conn.close()

    def add_task(self, title, priority='med', due=None, tags=None):
        """Add a new task."""
        task_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Insert the task
            cursor.execute("""
                INSERT INTO items (id, kind, title, priority, due)
                VALUES (?, ?, ?, ?, ?)
            """, (task_id, 'task', title, priority, due))
            
            # Handle tags
            if tags:
                for tag_name in tags:
                    # Insert or get tag
                    cursor.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (tag_name,))
                    cursor.execute("SELECT id FROM tags WHERE name = ?", (tag_name,))
                    tag_id = cursor.fetchone()[0]
                    
                    # Link task and tag
                    cursor.execute("""
                        INSERT OR IGNORE INTO task_tags (task_id, tag_id)
                        VALUES (?, ?)
                    """, (task_id, tag_id))
            
            conn.commit()
            return task_id
        finally:
            conn.close()

    def task_exists(self, task_id):
        """Check if a task exists."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT 1 FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            return cursor.fetchone() is not None
        finally:
            conn.close()

    def mark_done(self, task_id):
        """Mark a task as done."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET done = TRUE WHERE id = ? AND kind = 'task'", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def delete_task(self, task_id):
        """Delete a task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def get_tasks(self, sort_order=None, overdue=False, all_tasks=False, tag=None):
        """Unified task retrieval method used by both list and export."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Base query
            base_query = """
                SELECT i.id, i.title, i.priority, i.due, i.done, i.archived
                FROM items i
                WHERE i.kind = 'task'
            """
            
            params = []
            
            # Apply filters
            if not all_tasks:
                base_query += " AND i.archived = FALSE"
                
            if overdue:
                base_query += " AND i.done = FALSE AND i.due < ?"
                params.append(datetime.now().strftime("%Y-%m-%d"))
                
            if tag:
                base_query = """
                    SELECT DISTINCT i.id, i.title, i.priority, i.due, i.done, i.archived
                    FROM items i
                    JOIN task_tags tt ON i.id = tt.task_id
                    JOIN tags t ON tt.tag_id = t.id
                    WHERE i.kind = 'task'
                """
                if not all_tasks:
                    base_query += " AND i.archived = FALSE"
                base_query += " AND t.name = ?"
                params.append(tag)
            
            # Apply sorting
            if sort_order == "priority":
                base_query += """
                    ORDER BY 
                        CASE i.priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 ELSE 3 END,
                        i.id ASC
                """
            else:
                base_query += " ORDER BY i.id ASC"
            
            cursor.execute(base_query, params)
            return [
                {
                    "id": row[0],
                    "title": row[1],
                    "priority": row[2],
                    "due": row[3],
                    "done": row[4]
                }
                for row in cursor.fetchall()
            ]
        finally:
            conn.close()

    def list_insertion_order(self):
        """List tasks in insertion order (deprecated - using get_tasks now)."""
        return self.get_tasks()

    def list_overdue(self, today):
        """List overdue tasks (deprecated - using get_tasks now)."""
        return self.get_tasks(overdue=True)

    def list_all(self):
        """List all tasks including archived ones (deprecated - using get_tasks now)."""
        return self.get_tasks(all_tasks=True)

    def list_sorted_by_priority(self):
        """List tasks sorted by priority (high, med, low) (deprecated - using get_tasks now)."""
        return self.get_tasks(sort_order="priority")

    def list_by_tag(self, tag_name):
        """List tasks by tag (deprecated - using get_tasks now)."""
        return self.get_tasks(tag=tag_name)

    def edit_task(self, task_id, title=None, priority=None, due=None):
        """Edit an existing task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Build dynamic update query
            updates = []
            params = []
            
            if title is not None:
                updates.append("title = ?")
                params.append(title)
                
            if priority is not None:
                updates.append("priority = ?")
                params.append(priority)
                
            if due is not None:
                updates.append("due = ?")
                params.append(due)
                
            if updates:
                query = f"UPDATE items SET {', '.join(updates)} WHERE id = ? AND kind = 'task'"
                params.append(task_id)
                cursor.execute(query, params)
                conn.commit()
        finally:
            conn.close()

    def archive_done(self):
        """Archive all done tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived = TRUE WHERE done = TRUE AND kind = 'task'")
            conn.commit()
        finally:
            conn.close()

    def get_stats(self, today):
        """Get statistics about tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task'")
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND done = TRUE")
            done = cursor.fetchone()[0]
            
            # Open tasks
            open_count = total - done
            
            # Priority counts
            priority_counts = {}
            for priority in ['high', 'med', 'low']:
                cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND priority = ?", (priority,))
                count = cursor.fetchone()[0]
                priority_counts[priority] = count
            
            # Overdue tasks
            cursor.execute("""
                SELECT COUNT(*) FROM items 
                WHERE kind = 'task' AND done = FALSE AND due < ?
            """, (today.isoformat(),))
            overdue_count = cursor.fetchone()[0]
            
            return total, done, open_count, priority_counts, overdue_count
        finally:
            conn.close()

    def backup(self, path):
        """Backup the database to a file."""
        # Ensure the directory exists
        dir_path = os.path.dirname(os.path.abspath(path))
        if dir_path and not os.path.exists(dir_path):
            os.makedirs(dir_path)
            
        try:
            # Create temporary file
            tmp_path = path + ".tmp"
            shutil.copy2(self.db_path, tmp_path)
            
            # Atomically rename
            os.replace(tmp_path, path)
        except Exception as e:
            raise e

    def export_json(self, path):
        """Export tasks as JSON."""
        conn = sqlite3.connect(self.db_path)
        try:
            # Use the unified query path for export
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, title, priority, due, done, archived
                FROM items
                WHERE kind = 'task'
                ORDER BY id ASC
            """)
            
            tasks = []
            for row in cursor.fetchall():
                task = {
                    "id": row[0],
                    "title": row[1],
                    "priority": row[2],
                    "due": row[3],
                    "done": row[4],
                    "archived": row[5]
                }
                tasks.append(task)
            
            # Write to temporary file
            tmp_path = path + ".tmp"
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump(tasks, f, indent=2)
            
            # Atomically rename
            os.replace(tmp_path, path)
        finally:
            conn.close()

    def export_csv(self, path):
        """Export tasks as CSV."""
        conn = sqlite3.connect(self.db_path)
        try:
            # Use the unified query path for export
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, title, priority, due, done, archived
                FROM items
                WHERE kind = 'task'
                ORDER BY id ASC
            """)
            
            # Write to temporary file
            tmp_path = path + ".tmp"
            with open(tmp_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(['id', 'title', 'priority', 'due', 'done', 'archived'])
                for row in cursor.fetchall():
                    writer.writerow(row)
            
            # Atomically rename
            os.replace(tmp_path, path)
        finally:
            conn.close()

    def compact(self):
        """Reclaim dead space from deleted rows."""
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()

    def search_tasks(self, text):
        """Search tasks by title (case-insensitive)."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, title, priority, due, done, archived
                FROM items
                WHERE kind = 'task' AND archived = FALSE AND LOWER(title) LIKE ?
                ORDER BY id ASC
            """, (f"%{text.lower()}%",))
            return [
                {
                    "id": row[0],
                    "title": row[1],
                    "priority": row[2],
                    "due": row[3],
                    "done": row[4]
                }
                for row in cursor.fetchall()
            ]
        finally:
            conn.close()

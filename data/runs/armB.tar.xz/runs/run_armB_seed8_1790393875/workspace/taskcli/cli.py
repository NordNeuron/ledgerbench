import argparse
import os
import sys
import sqlite3
from datetime import datetime
import json
import csv
import toml

from .storage import Storage

def get_config():
    config = {}
    config_path = os.path.join(os.getcwd(), "config.toml")
    if os.path.exists(config_path):
        with open(config_path, 'r', encoding='utf-8') as f:
            config = toml.load(f)
    return config

def get_today():
    config = get_config()
    if 'today' in config:
        return config['today']
    
    today_env = os.environ.get('TASKCLI_TODAY')
    if today_env:
        return today_env
    
    return datetime.now().strftime('%Y-%m-%d')

def parse_date(date_str):
    try:
        return datetime.strptime(date_str, '%Y-%m-%d').date()
    except ValueError:
        raise argparse.ArgumentTypeError(f"Invalid date format: {date_str}. Expected YYYY-MM-DD.")

def main():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['low', 'med', 'high'], default='med', help='Task priority (default: med)')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--tag', action='append', help='Add a tag (repeatable)')

    # List command
    list_parser = subparsers.add_parser('list', help='List tasks')
    list_parser.add_argument('--sort', choices=['priority', 'id'], help='Sort order')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')
    list_parser.add_argument('--all', action='store_true', help='Show archived tasks too')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--color', action='store_true', help='Enable colored output')
    list_parser.add_argument('--review', action='store_true', help='Show overdue first, then by priority')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Edit command
    edit_parser = subparsers.add_parser('edit', help='Edit a task')
    edit_parser.add_argument('id', type=int, help='Task ID')
    edit_parser.add_argument('--title', help='New title')
    edit_parser.add_argument('--priority', choices=['low', 'med', 'high'], help='New priority')
    edit_parser.add_argument('--due', help='New due date in YYYY-MM-DD format')
    edit_parser.add_argument('--tag', action='append', help='Add a tag (repeatable)')

    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')

    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup database')
    backup_parser.add_argument('path', help='Backup file path')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json', help='Export format (default: json)')

    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Reclaim dead space from deleted rows')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for')

    args = parser.parse_args()

    # Emit audit line for all commands - this must be the very first thing that happens
    sys.stderr.write(f"AUDIT {args.command}\n")
    sys.stderr.flush()
    
    storage = Storage()
    
    try:
        if args.command == 'add':
            due_date = parse_date(args.due) if args.due else None
            task_id = storage.add_task(args.title, args.priority, due_date, args.tag or [])
            print(task_id)
            
        elif args.command == 'list':
            today = get_today()
            tasks = storage.list_tasks(today, args.sort, args.overdue, args.all, args.tag, args.review)
            for task in tasks:
                print(storage.format_task(task, args.color))
                
        elif args.command == 'done':
            storage.mark_done(args.id)
            
        elif args.command == 'delete':
            storage.delete_task(args.id)
            
        elif args.command == 'edit':
            due_date = parse_date(args.due) if args.due else None
            storage.edit_task(args.id, args.title, args.priority, due_date, args.tag or [])
            
        elif args.command == 'archive':
            storage.archive_tasks()
            
        elif args.command == 'stats':
            today = get_today()
            stats = storage.get_stats(today)
            print(f"Total: {stats['total']}")
            print(f"Done: {stats['done']}")
            print(f"Open: {stats['open']}")
            print(f"Overdue: {stats['overdue']}")
            print(f"Priority high: {stats['priority_high']}")
            print(f"Priority med: {stats['priority_med']}")
            print(f"Priority low: {stats['priority_low']}")
            
        elif args.command == 'backup':
            storage.backup(args.path)
            
        elif args.command == 'export':
            today = get_today()
            if args.format == 'csv':
                storage.export_csv(args.path, today, args.sort, args.overdue, args.all, args.tag)
            else:
                storage.export_json(args.path, today, args.sort, args.overdue, args.all, args.tag)
                
        elif args.command == 'compact':
            storage.compact()
            
        elif args.command == 'search':
            tasks = storage.search_tasks(args.text)
            for task in tasks:
                print(storage.format_task(task, False))
                
        else:
            parser.print_help()
            return 2
            
    except ValueError as e:
        sys.stderr.write(f"Error: {e}\n")
        return 2
    except (OSError, sqlite3.Error) as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1
        
    return 0

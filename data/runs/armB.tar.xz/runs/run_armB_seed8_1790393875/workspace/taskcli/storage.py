import os
import sqlite3
import shutil
import json
import csv
import sys
from datetime import datetime

class Storage:
    def __init__(self, db_path='tasks.db'):
        self.db_path = db_path
        self.init_db()
        
    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table with kind column (as required by T14)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    priority TEXT DEFAULT 'med',
                    due DATE,
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE
                )
            ''')
            
            # Create tags table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS tags (
                    id INTEGER PRIMARY KEY,
                    name TEXT UNIQUE NOT NULL
                )
            ''')
            
            # Create task_tags junction table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS task_tags (
                    task_id INTEGER,
                    tag_id INTEGER,
                    FOREIGN KEY (task_id) REFERENCES items (id),
                    FOREIGN KEY (tag_id) REFERENCES tags (id)
                )
            ''')
            
            conn.commit()
        finally:
            conn.close()
    
    def get_next_id(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('SELECT COALESCE(MAX(id), 0) + 1 FROM items')
            return cursor.fetchone()[0]
        finally:
            conn.close()
            
    def add_task(self, title, priority, due_date, tags):
        task_id = self.get_next_id()
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Insert task
            cursor.execute('''
                INSERT INTO items (id, kind, title, priority, due, done, archived)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (task_id, 'task', title, priority, due_date, False, False))
            
            # Handle tags
            for tag_name in tags:
                # Insert or get tag
                cursor.execute('INSERT OR IGNORE INTO tags (name) VALUES (?)', (tag_name,))
                cursor.execute('SELECT id FROM tags WHERE name = ?', (tag_name,))
                tag_id = cursor.fetchone()[0]
                
                # Link task and tag
                cursor.execute('INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?, ?)', 
                              (task_id, tag_id))
            
            conn.commit()
            return task_id
        finally:
            conn.close()
    
    def _get_tasks_query(self, today, sort=None, overdue=False, all_tasks=False, tag_filter=None):
        """Get the base query and parameters for retrieving tasks"""
        # Base query
        query = '''
            SELECT i.id, i.title, i.priority, i.due, i.done, i.archived
            FROM items i
            WHERE i.kind = 'task'
        '''
        
        params = []
        
        # Filter out archived tasks unless --all is specified
        if not all_tasks:
            query += ' AND i.archived = FALSE'
            
        # Filter by tag if specified
        if tag_filter:
            query += '''
                AND i.id IN (
                    SELECT DISTINCT tt.task_id 
                    FROM task_tags tt 
                    JOIN tags t ON tt.tag_id = t.id 
                    WHERE t.name = ?
                )
            '''
            params.append(tag_filter)
            
        # Filter overdue tasks if --overdue is specified
        if overdue:
            query += ' AND i.due < ? AND i.done = FALSE'
            params.append(today)
        
        return query, params
    
    def list_tasks(self, today, sort=None, overdue=False, all_tasks=False, tag_filter=None, review=False):
        """List tasks with consistent filtering and ordering"""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Get base query
            query, params = self._get_tasks_query(today, sort, overdue, all_tasks, tag_filter)
            
            # Add ordering
            if sort == 'priority':
                query += '''
                    ORDER BY 
                        CASE WHEN i.priority = 'high' THEN 1
                             WHEN i.priority = 'med' THEN 2
                             WHEN i.priority = 'low' THEN 3 END,
                        i.id
                '''
            elif review:
                # Overdue first, then by priority high to low
                query += '''
                    ORDER BY 
                        CASE WHEN i.due < ? AND i.done = FALSE THEN 0 ELSE 1 END,
                        CASE WHEN i.priority = 'high' THEN 1
                             WHEN i.priority = 'med' THEN 2
                             WHEN i.priority = 'low' THEN 3 END,
                        i.id
                '''
                params.append(today)
            else:
                query += ' ORDER BY i.id'
                
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'priority': row[2],
                    'due': row[3],
                    'done': row[4],
                    'archived': row[5]
                }
                tasks.append(task)
                
            return tasks
        finally:
            conn.close()
    
    def mark_done(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('UPDATE items SET done = TRUE WHERE id = ? AND kind = ?', (task_id, 'task'))
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
            conn.commit()
        finally:
            conn.close()
    
    def delete_task(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM items WHERE id = ? AND kind = ?', (task_id, 'task'))
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
            conn.commit()
        finally:
            conn.close()
    
    def edit_task(self, task_id, title=None, priority=None, due_date=None, tags=None):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Get current task
            cursor.execute('SELECT * FROM items WHERE id = ? AND kind = ?', (task_id, 'task'))
            task = cursor.fetchone()
            if not task:
                raise ValueError(f"Task with ID {task_id} not found")
                
            # Update fields if provided
            updates = []
            params = []
            
            if title is not None:
                updates.append('title = ?')
                params.append(title)
                
            if priority is not None:
                updates.append('priority = ?')
                params.append(priority)
                
            if due_date is not None:
                updates.append('due = ?')
                params.append(due_date)
                
            if updates:
                query = f'UPDATE items SET {", ".join(updates)} WHERE id = ? AND kind = ?'
                params.append(task_id)
                params.append('task')
                cursor.execute(query, params)
                
                if cursor.rowcount == 0:
                    raise ValueError(f"Task with ID {task_id} not found")
            
            # Handle tags if provided
            if tags is not None:
                # Remove existing tags for this task
                cursor.execute('DELETE FROM task_tags WHERE task_id = ?', (task_id,))
                
                # Add new tags
                for tag_name in tags:
                    # Insert or get tag
                    cursor.execute('INSERT OR IGNORE INTO tags (name) VALUES (?)', (tag_name,))
                    cursor.execute('SELECT id FROM tags WHERE name = ?', (tag_name,))
                    tag_id = cursor.fetchone()[0]
                    
                    # Link task and tag
                    cursor.execute('INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?, ?)', 
                                  (task_id, tag_id))
            
            conn.commit()
        finally:
            conn.close()
    
    def archive_tasks(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('UPDATE items SET archived = TRUE WHERE done = TRUE AND kind = ?', ('task',))
            conn.commit()
        finally:
            conn.close()
    
    def get_stats(self, today):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute('SELECT COUNT(*) FROM items WHERE kind = ?', ('task',))
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute('SELECT COUNT(*) FROM items WHERE done = TRUE AND kind = ?', ('task',))
            done = cursor.fetchone()[0]
            
            # Open tasks (total - done)
            open_tasks = total - done
            
            # Overdue tasks (not done and due date is before today)
            cursor.execute('''
                SELECT COUNT(*) FROM items 
                WHERE done = FALSE AND due < ? AND kind = ?
            ''', (today, 'task'))
            overdue = cursor.fetchone()[0]
            
            # Priority counts
            cursor.execute('''
                SELECT priority, COUNT(*) FROM items 
                WHERE kind = ? GROUP BY priority
            ''', ('task',))
            priority_counts = dict(cursor.fetchall())
            
            return {
                'total': total,
                'done': done,
                'open': open_tasks,
                'overdue': overdue,
                'priority_high': priority_counts.get('high', 0),
                'priority_med': priority_counts.get('med', 0),
                'priority_low': priority_counts.get('low', 0)
            }
        finally:
            conn.close()
    
    def backup(self, path):
        # Create temporary file
        tmp_path = path + '.tmp'
        
        # Copy database to temp file
        shutil.copy2(self.db_path, tmp_path)
        
        # Rename temp file to target path (atomic write)
        os.replace(tmp_path, path)
    
    def export_json(self, path, today=None, sort=None, overdue=False, all_tasks=False, tag_filter=None):
        """Export tasks as JSON using the same query path as list"""
        tasks = self.list_tasks(today, sort, overdue, all_tasks, tag_filter)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(tasks, f, indent=2, default=str)
    
    def export_csv(self, path, today=None, sort=None, overdue=False, all_tasks=False, tag_filter=None):
        """Export tasks as CSV using the same query path as list"""
        tasks = self.list_tasks(today, sort, overdue, all_tasks, tag_filter)
        if not tasks:
            return
            
        fieldnames = ['id', 'title', 'priority', 'due', 'done', 'archived']
        
        with open(path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for task in tasks:
                # Convert due date to string if it exists
                if task['due']:
                    task['due'] = task['due'].strftime('%Y-%m-%d')
                else:
                    task['due'] = ''
                writer.writerow(task)
    
    def compact(self):
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute('VACUUM')
            conn.commit()
        finally:
            conn.close()
    
    def format_task(self, task, use_color=False):
        # Determine ANSI codes for color
        ansi_reset = '\x1b[0m'
        ansi_red = '\x1b[31m'
        ansi_green = '\x1b[32m'
        
        # Check if we should output colors (only if stdout is a TTY)
        should_color = use_color and os.isatty(sys.stdout.fileno()) if hasattr(sys.stdout, 'fileno') else False
        
        # Format due date
        due_str = task['due'] if task['due'] else ''
        
        # Format priority
        priority_str = task['priority']
        
        # Format done status
        done_str = '✓' if task['done'] else '○'
        
        # Colorize based on status
        if should_color:
            if task['due'] and not task['done']:
                due_str = f"{ansi_red}{task['due']}{ansi_reset}"
            if task['done']:
                done_str = f"{ansi_green}{done_str}{ansi_reset}"
        
        return f"[{task['id']}] {done_str} {priority_str} {task['title']} {due_str}"
    
    def search_tasks(self, text):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Search in title (case-insensitive)
            query = '''
                SELECT i.id, i.title, i.priority, i.due, i.done, i.archived
                FROM items i
                WHERE i.kind = 'task' AND LOWER(i.title) LIKE ?
                ORDER BY i.id
            '''
            
            cursor.execute(query, (f'%{text.lower()}%',))
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'priority': row[2],
                    'due': row[3],
                    'done': row[4],
                    'archived': row[5]
                }
                tasks.append(task)
                
            return tasks
        finally:
            conn.close()

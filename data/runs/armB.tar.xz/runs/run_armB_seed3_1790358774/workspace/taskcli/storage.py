import os
import sqlite3
import shutil
import csv
import json
from datetime import datetime

class Storage:
    def __init__(self, db_path='tasks.db'):
        self.db_path = db_path
        self.init_db()
        
    def init_db(self):
        """Initialize the database with required tables."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table (with kind column)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    priority TEXT DEFAULT 'med',
                    due TEXT,
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE
                )
            ''')
            
            # Create tags table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS tags (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT UNIQUE NOT NULL
                )
            ''')
            
            # Create task_tags junction table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS task_tags (
                    task_id INTEGER,
                    tag_id INTEGER,
                    FOREIGN KEY (task_id) REFERENCES items (id),
                    FOREIGN KEY (tag_id) REFERENCES tags (id)
                )
            ''')
            
            conn.commit()
        finally:
            conn.close()
    
    def get_next_id(self):
        """Get the next available ID."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items")
            return cursor.fetchone()[0]
        finally:
            conn.close()
    
    def _build_task_query(self, sort_by=None, overdue=False, show_all=False, tag=None, today=None):
        """Build the base query for fetching tasks."""
        # Build base query
        query = '''
            SELECT i.id, i.title, i.priority, i.due, i.done, i.archived,
                   CASE WHEN i.due IS NOT NULL AND i.due < ? THEN 1 ELSE 0 END as overdue
            FROM items i
            WHERE i.kind = 'task'
        '''
        
        params = [today] if today else []
        
        # Filter by archived status
        if not show_all:
            query += " AND i.archived = FALSE"
            
        # Filter by tag if specified
        if tag:
            query += '''
                AND i.id IN (
                    SELECT DISTINCT tt.task_id FROM task_tags tt
                    JOIN tags t ON tt.tag_id = t.id
                    WHERE t.name = ?
                )
            '''
            params.append(tag)
        
        # Filter by overdue status
        if overdue:
            query += " AND i.done = FALSE AND i.due IS NOT NULL AND i.due < ?"
            params.append(today)
        
        # Add sorting
        if sort_by == 'priority':
            # Order: high, med, low
            query += '''
                ORDER BY 
                    CASE WHEN i.priority = 'high' THEN 1
                         WHEN i.priority = 'med' THEN 2
                         WHEN i.priority = 'low' THEN 3 END,
                    i.id
            '''
        else:
            # Default insertion order
            query += " ORDER BY i.id"
        
        return query, params
    
    def _get_task_tags(self, task_id):
        """Get all tags for a specific task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT t.name FROM task_tags tt
                JOIN tags t ON tt.tag_id = t.id
                WHERE tt.task_id = ?
            ''', (task_id,))
            return [r[0] for r in cursor.fetchall()]
        finally:
            conn.close()
    
    def _get_tasks(self, sort_by=None, overdue=False, show_all=False, tag=None, today=None):
        """Get tasks with unified query path."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            query, params = self._build_task_query(sort_by, overdue, show_all, tag, today)
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Get tags for each task
            tasks = []
            for row in rows:
                task_id, title, priority, due, done, archived, overdue_flag = row
                
                tags = self._get_task_tags(task_id)
                
                tasks.append({
                    'id': task_id,
                    'title': title,
                    'priority': priority,
                    'due': due,
                    'done': done,
                    'archived': archived,
                    'overdue': bool(overdue_flag),
                    'tags': tags
                })
            
            return tasks
        finally:
            conn.close()
    
    def add_task(self, title, priority='med', due=None, tags=None):
        """Add a new task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            task_id = self.get_next_id()
            
            # Insert the task
            cursor.execute('''
                INSERT INTO items (id, kind, title, priority, due, done, archived)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (task_id, 'task', title, priority, due, False, False))
            
            # Handle tags
            if tags:
                for tag_name in tags:
                    # Insert or get tag ID
                    cursor.execute('INSERT OR IGNORE INTO tags (name) VALUES (?)', (tag_name,))
                    cursor.execute('SELECT id FROM tags WHERE name = ?', (tag_name,))
                    tag_id = cursor.fetchone()[0]
                    
                    # Link task and tag
                    cursor.execute('''
                        INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?, ?)
                    ''', (task_id, tag_id))
            
            conn.commit()
            return task_id
        finally:
            conn.close()
    
    def list_tasks(self, sort_by=None, overdue=False, show_all=False, tag=None, today=None):
        """List tasks with unified query path."""
        return self._get_tasks(sort_by, overdue, show_all, tag, today)
    
    def mark_done(self, task_id):
        """Mark a task as done."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found")
            
            cursor.execute("UPDATE items SET done = TRUE WHERE id = ?", (task_id,))
            conn.commit()
        finally:
            conn.close()
    
    def delete_task(self, task_id):
        """Delete a task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found")
            
            cursor.execute("DELETE FROM items WHERE id = ?", (task_id,))
            conn.commit()
        finally:
            conn.close()
    
    def edit_task(self, task_id, title=None):
        """Edit a task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Check if task exists
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found")
            
            # Update title if provided
            if title is not None:
                cursor.execute("UPDATE items SET title = ? WHERE id = ?", (title, task_id))
            
            conn.commit()
        finally:
            conn.close()
    
    def archive_tasks(self):
        """Archive all done tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived = TRUE WHERE done = TRUE AND kind = 'task'")
            conn.commit()
        finally:
            conn.close()
    
    def get_stats(self, today):
        """Get statistics about tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task'")
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE done = TRUE AND kind = 'task'")
            done = cursor.fetchone()[0]
            
            # Open tasks
            open_tasks = total - done
            
            # Priority counts
            cursor.execute("SELECT priority, COUNT(*) FROM items WHERE kind = 'task' GROUP BY priority")
            priority_counts = dict(cursor.fetchall())
            
            high_count = priority_counts.get('high', 0)
            med_count = priority_counts.get('med', 0)
            low_count = priority_counts.get('low', 0)
            
            # Overdue tasks
            cursor.execute("""
                SELECT COUNT(*) FROM items 
                WHERE done = FALSE AND due IS NOT NULL AND due < ? AND kind = 'task'
            """, (today,))
            overdue = cursor.fetchone()[0]
            
            return {
                'total': total,
                'done': done,
                'open': open_tasks,
                'priority_high': high_count,
                'priority_med': med_count,
                'priority_low': low_count,
                'overdue': overdue
            }
        finally:
            conn.close()
    
    def backup(self, path):
        """Backup database to a file."""
        # Create temporary file
        tmp_path = path + ".tmp"
        try:
            shutil.copy2(self.db_path, tmp_path)
            
            # Atomically rename
            os.replace(tmp_path, path)
        except Exception as e:
            # Clean up temp file on failure
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise
    
    def compact(self):
        """Reclaim dead space from deleted rows."""
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()
    
    def export_json(self, path, today):
        """Export tasks to JSON file."""
        tasks = self._get_tasks(show_all=True, today=today)
        
        # Prepare data for export
        export_data = []
        for task in tasks:
            # Remove internal fields
            export_task = {
                'id': task['id'],
                'title': task['title'],
                'priority': task['priority'],
                'due': task['due'],
                'done': task['done']
            }
            
            # Add tags if present
            if task['tags']:
                export_task['tags'] = task['tags']
                
            export_data.append(export_task)
        
        # Write to file with atomic write
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2)
            
            os.replace(tmp_path, path)
        except Exception:
            # Clean up temp file on failure
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise
    
    def export_csv(self, path, today):
        """Export tasks to CSV file."""
        tasks = self._get_tasks(show_all=True, today=today)
        
        # Prepare data for export
        export_data = []
        for task in tasks:
            row = {
                'id': task['id'],
                'title': task['title'],
                'priority': task['priority'],
                'due': task['due'],
                'done': str(task['done']).lower(),
                'tags': ' '.join(task['tags']) if task['tags'] else ''
            }
            export_data.append(row)
        
        # Write to file with atomic write
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, 'w', newline='', encoding='utf-8') as f:
                if export_data:
                    writer = csv.DictWriter(f, fieldnames=export_data[0].keys())
                    writer.writeheader()
                    writer.writerows(export_data)
            
            os.replace(tmp_path, path)
        except Exception:
            # Clean up temp file on failure
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise
    
    def search_tasks(self, text, today):
        """Search tasks by title."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Base query
            query = '''
                SELECT i.id, i.title, i.priority, i.due, i.done, i.archived,
                       CASE WHEN i.due IS NOT NULL AND i.due < ? THEN 1 ELSE 0 END as overdue
                FROM items i
                WHERE i.kind = 'task' AND LOWER(i.title) LIKE ?
            '''
            
            params = [today, f'%{text.lower()}%']
            
            # Filter by archived status (search doesn't show archived)
            query += " AND i.archived = FALSE"
            
            # Order by insertion order
            query += " ORDER BY i.id"
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Get tags for each task
            tasks = []
            for row in rows:
                task_id, title, priority, due, done, archived, overdue_flag = row
                
                # Get tags for this task
                cursor.execute('''
                    SELECT t.name FROM task_tags tt
                    JOIN tags t ON tt.tag_id = t.id
                    WHERE tt.task_id = ?
                ''', (task_id,))
                tags = [r[0] for r in cursor.fetchall()]
                
                tasks.append({
                    'id': task_id,
                    'title': title,
                    'priority': priority,
                    'due': due,
                    'done': done,
                    'archived': archived,
                    'overdue': bool(overdue_flag),
                    'tags': tags
                })
            
            return tasks
        finally:
            conn.close()

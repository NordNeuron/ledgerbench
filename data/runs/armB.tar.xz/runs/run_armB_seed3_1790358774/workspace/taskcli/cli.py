import argparse
import os
import sys
import sqlite3
from datetime import datetime
from .storage import Storage

def pin_today(date_str):
    """Set today for testing purposes."""
    return {"TASKCLI_TODAY": date_str}

def get_today():
    """Get today's date from config or environment variable."""
    # Check for config.toml first
    config_path = os.path.join(os.getcwd(), "config.toml")
    if os.path.exists(config_path):
        try:
            import toml
            config = toml.load(config_path)
            if 'today' in config:
                return config['today']
        except ImportError:
            pass  # Fall back to environment variable
    
    # Fallback to environment variable
    return os.environ.get("TASKCLI_TODAY", datetime.now().strftime("%Y-%m-%d"))

def parse_args():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['low', 'med', 'high'], default='med',
                           help='Task priority (default: med)')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--tag', action='append', help='Add a tag (repeatable)')

    # List command
    list_parser = subparsers.add_parser('list', help='List tasks')
    list_parser.add_argument('--sort', choices=['priority', 'insertion'], 
                            help='Sort order')
    list_parser.add_argument('--overdue', action='store_true', 
                            help='Show only overdue tasks')
    list_parser.add_argument('--all', action='store_true', 
                            help='Show archived tasks too')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--color', action='store_true', 
                            help='Enable colored output')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Edit command
    edit_parser = subparsers.add_parser('edit', help='Edit a task')
    edit_parser.add_argument('id', type=int, help='Task ID')
    edit_parser.add_argument('--title', help='New title')

    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')

    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup database')
    backup_parser.add_argument('path', help='Backup file path')

    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Reclaim dead space')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json',
                              help='Export format (default: json)')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Search text')

    return parser.parse_args()

def validate_date(date_str):
    """Validate date string in YYYY-MM-DD format."""
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
        return True
    except ValueError:
        return False

def print_task(task, color=False):
    """Print a single task in list format."""
    if task['done']:
        status = '✓'
    else:
        status = '○'
    
    # Add due date if present
    due_str = f" ({task['due']})" if task['due'] else ""
    
    # Add tags if present
    tags_str = f" [{' '.join(task['tags'])}]" if task['tags'] else ""
    
    line = f"{task['id']} {status} {task['title']}{due_str}{tags_str}"
    
    if color and task['overdue']:
        line = f"\033[31m{line}\033[0m"  # Red for overdue
    elif color and task['done']:
        line = f"\033[32m{line}\033[0m"  # Green for done
    
    print(line)

def main():
    args = parse_args()
    
    # Emit audit line to stderr
    print(f"AUDIT {args.command}", file=sys.stderr)
    
    # Initialize storage
    storage = Storage()
    
    try:
        if args.command == 'add':
            if args.due and not validate_date(args.due):
                print(f"Error: Invalid date '{args.due}'. Expected format: YYYY-MM-DD", file=sys.stderr)
                return 2
            
            task_id = storage.add_task(
                title=args.title,
                priority=args.priority,
                due=args.due,
                tags=args.tag or []
            )
            print(task_id)
            
        elif args.command == 'list':
            today = get_today()
            tasks = storage.list_tasks(
                sort_by=args.sort,
                overdue=args.overdue,
                show_all=args.all,
                tag=args.tag,
                today=today
            )
            for task in tasks:
                print_task(task, color=args.color and sys.stdout.isatty())
                
        elif args.command == 'done':
            try:
                storage.mark_done(args.id)
                # Done command should be completely silent on success (no stdout, no stderr)
            except ValueError as e:
                print(f"Error: {e}", file=sys.stderr)
                return 2
                
        elif args.command == 'delete':
            try:
                storage.delete_task(args.id)
                # Delete command should be completely silent on success (no stdout, no stderr)
            except ValueError as e:
                print(f"Error: {e}", file=sys.stderr)
                return 2
                
        elif args.command == 'edit':
            if not args.title:
                print("Error: --title is required for edit", file=sys.stderr)
                return 2
            try:
                storage.edit_task(args.id, title=args.title)
                # Edit command should be completely silent on success (no stdout, no stderr)
            except ValueError as e:
                print(f"Error: {e}", file=sys.stderr)
                return 2
                
        elif args.command == 'archive':
            storage.archive_tasks()
            
        elif args.command == 'stats':
            today = get_today()
            stats = storage.get_stats(today)
            print(f"Total: {stats['total']}")
            print(f"Done: {stats['done']}")
            print(f"Open: {stats['open']}")
            print(f"Priority high: {stats['priority_high']}")
            print(f"Priority med: {stats['priority_med']}")
            print(f"Priority low: {stats['priority_low']}")
            print(f"Overdue: {stats['overdue']}")
            
        elif args.command == 'backup':
            try:
                storage.backup(args.path)
            except IOError as e:
                print(f"Error: {e}", file=sys.stderr)
                return 1
                
        elif args.command == 'compact':
            storage.compact()
            
        elif args.command == 'export':
            today = get_today()
            if args.format == 'csv':
                storage.export_csv(args.path, today)
            else:
                storage.export_json(args.path, today)
                
        elif args.command == 'search':
            today = get_today()
            tasks = storage.search_tasks(args.text, today)
            for task in tasks:
                print_task(task, color=args.color and sys.stdout.isatty())
                
        else:
            # Print help if no command given
            parser = parse_args()
            parser.print_help()
            
    except sqlite3.Error as e:
        print(f"Error: Database error occurred", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Error: An unexpected error occurred", file=sys.stderr)
        return 1
        
    return 0

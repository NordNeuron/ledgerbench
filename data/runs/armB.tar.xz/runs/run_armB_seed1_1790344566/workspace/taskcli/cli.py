import argparse
import os
import sys
import sqlite3
from datetime import datetime
from .storage import TaskStorage

def pin_today(date_str):
    """Set the today value for testing."""
    return {"TASKCLI_TODAY": date_str}

def get_today():
    """Get today's date from environment or config."""
    today_env = os.environ.get("TASKCLI_TODAY")
    if today_env:
        try:
            return datetime.strptime(today_env, "%Y-%m-%d").date()
        except ValueError:
            # If env var is invalid, fall back to current date
            pass
    
    # Check for config.toml
    config_path = os.path.join(os.getcwd(), "config.toml")
    if os.path.exists(config_path):
        import toml
        try:
            config = toml.load(config_path)
            if "today" in config:
                return datetime.strptime(config["today"], "%Y-%m-%d").date()
        except Exception:
            pass
    
    # Default to current date
    return datetime.now().date()

def format_task(task, today, use_color=False):
    """Format a task for display."""
    if task['done']:
        status = "✓"
        if use_color:
            status = f"\x1b[32m{status}\x1b[0m"  # Green
    else:
        status = "○"
        if use_color and task['due'] and task['due'] < today:
            status = f"\x1b[31m{status}\x1b[0m"  # Red
    
    title = task['title']
    if use_color and task['due'] and task['due'] < today:
        title = f"\x1b[31m{title}\x1b[0m"  # Red
    elif use_color and task['done']:
        title = f"\x1b[32m{title}\x1b[0m"  # Green
    
    priority = task['priority']
    due_str = task['due'] if task['due'] else ""
    
    return f"{status} {task['id']} {priority} {title}{(' ' + due_str) if due_str else ''}"

def get_filtered_tasks(storage, args, include_archived=False):
    """Get tasks with filtering and sorting applied."""
    # Get all tasks first
    tasks = storage.list_tasks(include_archived=include_archived)
    
    # Apply filters
    if getattr(args, 'overdue', False):
        today = get_today()
        # Filter to overdue tasks only (not done, due before today)
        tasks = [t for t in tasks if not t['done'] and t['due'] and t['due'] < today]
    
    if getattr(args, 'tag', None):
        tag = getattr(args, 'tag')
        tasks = [t for t in tasks if tag in t.get('tags', [])]
    
    # Apply sorting
    if getattr(args, 'sort', None) == 'priority':
        # Sort by priority: high, med, low
        priority_order = {'high': 0, 'med': 1, 'low': 2}
        tasks.sort(key=lambda t: (priority_order.get(t['priority'], 1), t['id']))
    elif getattr(args, 'sort', None) == 'review':
        # Review view: overdue first, then by priority high to low
        today = get_today()
        def review_sort_key(task):
            if task['done']:
                return (1, 0)  # Done tasks last
            elif task['due'] and task['due'] < today:
                return (0, 0)  # Overdue tasks first
            else:
                priority_order = {'high': 0, 'med': 1, 'low': 2}
                return (1, priority_order.get(task['priority'], 1))
        tasks.sort(key=review_sort_key)
    
    return tasks

def list_tasks(storage, args):
    """List tasks with optional filtering and sorting."""
    today = get_today()
    use_color = getattr(args, 'color', False) and sys.stdout.isatty()
    
    if getattr(args, 'all', False):
        # Show all tasks including archived
        tasks = get_filtered_tasks(storage, args, include_archived=True)
    else:
        # Show only non-archived tasks
        tasks = get_filtered_tasks(storage, args, include_archived=False)
    
    for task in tasks:
        print(format_task(task, today, use_color))

def add_task(storage, args):
    """Add a new task."""
    title = args.title
    priority = getattr(args, 'priority', 'med')
    due = getattr(args, 'due', None)
    tags = getattr(args, 'tag', [])
    
    if due:
        try:
            due_date = datetime.strptime(due, "%Y-%m-%d").date()
        except ValueError:
            print(f"error: invalid date format '{due}'; expected YYYY-MM-DD", file=sys.stderr)
            return 2
    
    task_id = storage.add_task(title=title, priority=priority, due=due, tags=tags)
    
    # Silent success - only print the ID
    print(task_id)
    return 0

def done_task(storage, args):
    """Mark a task as done."""
    try:
        task_id = int(args.id)
    except ValueError:
        print(f"error: invalid task id '{args.id}'", file=sys.stderr)
        return 2
    
    # Check if task exists
    tasks = storage.list_tasks(include_archived=True)
    if not any(t['id'] == task_id for t in tasks):
        print(f"error: no task with id {task_id}", file=sys.stderr)
        return 2
    
    storage.mark_done(task_id)
    # Silent success - no output
    return 0

def delete_task(storage, args):
    """Delete a task."""
    try:
        task_id = int(args.id)
    except ValueError:
        print(f"error: invalid task id '{args.id}'", file=sys.stderr)
        return 2
    
    # Check if task exists
    tasks = storage.list_tasks(include_archived=True)
    if not any(t['id'] == task_id for t in tasks):
        print(f"error: no task with id {task_id}", file=sys.stderr)
        return 2
    
    storage.delete_task(task_id)
    # Silent success - no output
    return 0

def edit_task(storage, args):
    """Edit an existing task."""
    try:
        task_id = int(args.id)
    except ValueError:
        print(f"error: invalid task id '{args.id}'", file=sys.stderr)
        return 2
    
    # Check if task exists
    tasks = storage.list_tasks(include_archived=True)
    if not any(t['id'] == task_id for t in tasks):
        print(f"error: no task with id {task_id}", file=sys.stderr)
        return 2
    
    title = getattr(args, 'title', None)
    
    if title is not None:
        storage.update_task_title(task_id, title)
    # Other fields are preserved
    # Silent success - no output
    return 0

def stats(storage, args):
    """Print statistics."""
    today = get_today()
    tasks = storage.list_tasks(include_archived=True)
    
    total = len(tasks)
    done = sum(1 for t in tasks if t['done'])
    open_count = total - done
    
    priority_counts = {'high': 0, 'med': 0, 'low': 0}
    overdue_count = 0
    
    for task in tasks:
        if task['priority'] in priority_counts:
            priority_counts[task['priority']] += 1
        if not task['done'] and task['due'] and task['due'] < today:
            overdue_count += 1
    
    print(f"Total: {total}")
    print(f"Done: {done}")
    print(f"Open: {open_count}")
    
    for priority in ['high', 'med', 'low']:
        print(f"Priority {priority}: {priority_counts[priority]}")
    
    # Overdue count
    overdue_str = f"Overdue: {overdue_count}"
    if overdue_count > 0:
        overdue_str = f"\x1b[31m{overdue_str}\x1b[0m"
    print(overdue_str)
    
    return 0

def archive_tasks(storage, args):
    """Archive done tasks."""
    storage.archive_done()
    # Silent success - no output
    return 0

def backup(storage, args):
    """Backup the database."""
    dest = args.path
    
    try:
        # Write to temporary file first
        tmp_path = dest + ".tmp"
        with open(tmp_path, 'wb') as f:
            conn = storage.get_connection()
            conn.backup(f)
        
        # Atomic rename
        os.replace(tmp_path, dest)
    except Exception as e:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass
        print(f"error: backup failed: {e}", file=sys.stderr)
        return 1
    
    return 0

def export(storage, args):
    """Export tasks to a file."""
    dest = args.path
    format_type = getattr(args, 'format', 'json')
    
    # Use the same filtering logic as list for consistency
    if getattr(args, 'all', False):
        # Show all tasks including archived
        tasks = get_filtered_tasks(storage, args, include_archived=True)
    else:
        # Show only non-archived tasks (default behavior)
        tasks = get_filtered_tasks(storage, args, include_archived=False)
    
    try:
        if format_type == 'csv':
            # Export as CSV
            import csv
            with open(dest, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                
                # Write header
                headers = ['id', 'title', 'done', 'priority', 'due', 'tags']
                writer.writerow(headers)
                
                for task in tasks:
                    row = [
                        task['id'],
                        task['title'],
                        str(task['done']).lower(),
                        task['priority'],
                        task['due'] or '',
                        ','.join(task.get('tags', []))
                    ]
                    writer.writerow(row)
        else:
            # Export as JSON (default)
            import json
            with open(dest, 'w', encoding='utf-8') as f:
                json.dump(tasks, f, indent=2)
    except Exception as e:
        print(f"error: export failed: {e}", file=sys.stderr)
        return 1
    
    return 0

def compact(storage, args):
    """Compact the database."""
    storage.compact()
    # Silent success - no output
    return 0

def search(storage, args):
    """Search tasks by title."""
    text = args.text.lower()
    today = get_today()
    use_color = getattr(args, 'color', False) and sys.stdout.isatty()
    
    tasks = storage.list_tasks(include_archived=False)
    matching_tasks = [t for t in tasks if text in t['title'].lower()]
    
    for task in matching_tasks:
        print(format_task(task, today, use_color))

def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description="Minimal command-line task manager")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['low', 'med', 'high'], default='med',
                           help='Task priority (default: med)')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--tag', action='append', help='Add a tag (repeatable)')
    
    # List command
    list_parser = subparsers.add_parser('list', help='List tasks')
    list_parser.add_argument('--sort', choices=['priority', 'review'],
                            help='Sort order')
    list_parser.add_argument('--overdue', action='store_true',
                            help='Show only overdue tasks')
    list_parser.add_argument('--all', action='store_true',
                            help='Show all tasks including archived')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--color', action='store_true',
                            help='Enable colored output')
    
    # Done command
    done_parser = subparsers.add_parser('done', help='Mark task as done')
    done_parser.add_argument('id', help='Task ID')
    
    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', help='Task ID')
    
    # Edit command
    edit_parser = subparsers.add_parser('edit', help='Edit a task')
    edit_parser.add_argument('id', help='Task ID')
    edit_parser.add_argument('--title', help='New title')
    
    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')
    
    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')
    
    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup database')
    backup_parser.add_argument('path', help='Destination path')
    
    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Output file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json',
                              help='Export format (default: json)')
    export_parser.add_argument('--all', action='store_true',
                              help='Export all tasks including archived')
    export_parser.add_argument('--sort', choices=['priority', 'review'],
                              help='Sort order for export')
    export_parser.add_argument('--overdue', action='store_true',
                              help='Export only overdue tasks')
    export_parser.add_argument('--tag', help='Filter by tag')
    
    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Reclaim dead space')
    
    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for')
    search_parser.add_argument('--color', action='store_true',
                              help='Enable colored output')
    
    args = parser.parse_args()
    
    # Emit audit line - always, on success as well as failure
    command_name = args.command if args.command else "help"
    print(f"AUDIT {command_name}", file=sys.stderr)
    
    if not args.command:
        parser.print_help()
        return 1
    
    storage = TaskStorage()
    
    try:
        if args.command == 'add':
            return add_task(storage, args)
        elif args.command == 'list':
            list_tasks(storage, args)
            return 0
        elif args.command == 'done':
            return done_task(storage, args)
        elif args.command == 'delete':
            return delete_task(storage, args)
        elif args.command == 'edit':
            return edit_task(storage, args)
        elif args.command == 'stats':
            return stats(storage, args)
        elif args.command == 'archive':
            return archive_tasks(storage, args)
        elif args.command == 'backup':
            return backup(storage, args)
        elif args.command == 'export':
            return export(storage, args)
        elif args.command == 'compact':
            return compact(storage, args)
        elif args.command == 'search':
            search(storage, args)
            return 0
    except sqlite3.Error as e:
        print(f"error: database error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"error: unexpected error: {e}", file=sys.stderr)
        return 1

import os
import sqlite3
from datetime import date

class TaskStorage:
    def __init__(self, db_path='tasks.db'):
        self.db_path = db_path
        self.init_db()
    
    def get_connection(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn
    
    def init_db(self):
        """Initialize the database with required tables."""
        conn = self.get_connection()
        try:
            # Create items table (with kind column)
            conn.execute('''
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    priority TEXT DEFAULT 'med',
                    due DATE,
                    tags TEXT,
                    archived BOOLEAN DEFAULT FALSE
                )
            ''')
            
            # Create index for performance
            conn.execute('CREATE INDEX IF NOT EXISTS idx_items_kind ON items(kind)')
            conn.execute('CREATE INDEX IF NOT EXISTS idx_items_priority ON items(priority)')
            conn.execute('CREATE INDEX IF NOT EXISTS idx_items_due ON items(due)')
            conn.execute('CREATE INDEX IF NOT EXISTS idx_items_archived ON items(archived)')
            
            # Migrate from old tasks table if exists
            try:
                cursor = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='tasks'")
                if cursor.fetchone():
                    # Migrate data
                    conn.execute('''
                        INSERT OR IGNORE INTO items (id, kind, title, done, priority, due, tags)
                        SELECT id, 'task', title, done, priority, due, tags FROM tasks
                    ''')
                    conn.execute('DROP TABLE tasks')
            except:
                pass
            
            conn.commit()
        finally:
            conn.close()
    
    def add_task(self, title, priority='med', due=None, tags=None):
        """Add a new task and return its ID."""
        conn = self.get_connection()
        try:
            # Get next ID
            cursor = conn.execute('SELECT COALESCE(MAX(id), 0) + 1 as next_id FROM items')
            next_id = cursor.fetchone()[0]
            
            # Insert the task
            conn.execute('''
                INSERT INTO items (id, kind, title, priority, due, tags)
                VALUES (?, 'task', ?, ?, ?, ?)
            ''', (next_id, title, priority, due, ','.join(tags) if tags else None))
            
            conn.commit()
            return next_id
        finally:
            conn.close()
    
    def list_tasks(self, include_archived=False):
        """List all tasks."""
        conn = self.get_connection()
        try:
            query = '''
                SELECT id, title, done, priority, due, tags, archived
                FROM items
                WHERE kind = 'task'
            '''
            params = []
            
            if not include_archived:
                query += ' AND archived = FALSE'
            
            query += ' ORDER BY id'
            
            cursor = conn.execute(query, params)
            tasks = []
            for row in cursor.fetchall():
                # Parse tags
                tags = []
                if row['tags']:
                    tags = [t.strip() for t in row['tags'].split(',') if t.strip()]
                
                task = {
                    'id': row['id'],
                    'title': row['title'],
                    'done': bool(row['done']),
                    'priority': row['priority'],
                    'due': row['due'],
                    'tags': tags,
                    'archived': bool(row['archived'])
                }
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()
    
    def mark_done(self, task_id):
        """Mark a task as done."""
        conn = self.get_connection()
        try:
            conn.execute('UPDATE items SET done = TRUE WHERE id = ? AND kind = "task"', (task_id,))
            conn.commit()
        finally:
            conn.close()
    
    def delete_task(self, task_id):
        """Delete a task."""
        conn = self.get_connection()
        try:
            conn.execute('DELETE FROM items WHERE id = ? AND kind = "task"', (task_id,))
            conn.commit()
        finally:
            conn.close()
    
    def update_task_title(self, task_id, new_title):
        """Update a task's title."""
        conn = self.get_connection()
        try:
            conn.execute('UPDATE items SET title = ? WHERE id = ? AND kind = "task"', (new_title, task_id))
            conn.commit()
        finally:
            conn.close()
    
    def archive_done(self):
        """Archive all done tasks."""
        conn = self.get_connection()
        try:
            conn.execute('UPDATE items SET archived = TRUE WHERE done = TRUE AND kind = "task"')
            conn.commit()
        finally:
            conn.close()
    
    def compact(self):
        """Reclaim dead space from deleted rows."""
        conn = self.get_connection()
        try:
            conn.execute('VACUUM')
            conn.commit()
        finally:
            conn.close()

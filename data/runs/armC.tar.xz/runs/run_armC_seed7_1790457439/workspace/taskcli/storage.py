import os
import json
import sqlite3
import shutil
import csv
from datetime import datetime
from typing import List, Dict, Any
import re
import sys

class TaskStorage:
    def __init__(self, db_path: str = "tasks.db"):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table if it doesn't exist
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE,
                    due DATE,
                    priority TEXT,
                    tags TEXT
                )
            ''')
            
            # Create indexes for performance
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_kind ON items(kind)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_done ON items(done)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_archived ON items(archived)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_priority ON items(priority)')
            
            conn.commit()
        finally:
            conn.close()

    def add(self, title: str, due: str = None, priority: str = None, tags: List[str] = None) -> int:
        if due:
            try:
                datetime.strptime(due, "%Y-%m-%d")
            except ValueError:
                raise ValueError(f"Invalid date format '{due}'. Expected YYYY-MM-DD.")
        
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Get the maximum id and increment it
            cursor.execute("SELECT COALESCE(MAX(id), 0) FROM items")
            max_id = cursor.fetchone()[0]
            new_id = max_id + 1
            
            # Insert the task
            cursor.execute('''
                INSERT INTO items (id, kind, title, due, priority, tags)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (new_id, 'task', title, due, priority, json.dumps(tags) if tags else None))
            
            conn.commit()
            return new_id
        finally:
            conn.close()

    def _query_tasks(self, sort_by: str = 'insertion', show_all: bool = False, tag_filter: str = None, show_overdue: bool = False) -> List[Dict[str, Any]]:
        """Shared method to query tasks with consistent filtering."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Build the base query
            query = "SELECT * FROM items WHERE kind = 'task'"
            params = []
            
            if not show_all:
                query += " AND archived = 0"
                
            if tag_filter:
                query += " AND tags LIKE ?"
                params.append(f'%"{tag_filter}"%')
                
            if show_overdue:
                today = os.environ.get("TASKCLI_TODAY", datetime.now().strftime("%Y-%m-%d"))
                query += " AND due < ? AND done = 0"
                params.append(today)
            
            # Add ordering
            if sort_by == 'priority':
                # Order by priority: high, med, low, then by insertion order
                query += " ORDER BY CASE WHEN priority = 'high' THEN 1 WHEN priority = 'med' THEN 2 ELSE 3 END, id"
            else:
                # Default insertion order (by id)
                query += " ORDER BY id"
                
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'kind': row[1],
                    'title': row[2],
                    'done': bool(row[3]),
                    'archived': bool(row[4]),
                    'due': row[5],
                    'priority': row[6],
                    'tags': json.loads(row[7]) if row[7] else []
                }
                tasks.append(task)
                
            return tasks
        finally:
            conn.close()

    def list_tasks(self, sort_by: str = 'insertion', show_all: bool = False, tag_filter: str = None, show_overdue: bool = False) -> List[Dict[str, Any]]:
        """List tasks using the shared query method."""
        return self._query_tasks(sort_by, show_all, tag_filter, show_overdue)

    def mark_done(self, task_id: int):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Check if the task exists
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found.")
                
            cursor.execute("UPDATE items SET done = 1 WHERE id = ?", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def delete(self, task_id: int):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Check if the task exists
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found.")
                
            cursor.execute("DELETE FROM items WHERE id = ?", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def archive(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Archive done tasks
            cursor.execute("UPDATE items SET archived = 1 WHERE kind = 'task' AND done = 1")
            conn.commit()
        finally:
            conn.close()

    def stats(self) -> Dict[str, Any]:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task'")
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND done = 1")
            done = cursor.fetchone()[0]
            
            # Open tasks
            open_tasks = total - done
            
            # Priority counts - handle NULL values properly using GROUP BY with proper handling
            cursor.execute("""
                SELECT 
                    COALESCE(priority, 'med') as priority,
                    COUNT(*) as count
                FROM items 
                WHERE kind = 'task' 
                GROUP BY COALESCE(priority, 'med')
                ORDER BY CASE WHEN COALESCE(priority, 'med') = 'high' THEN 1 
                              WHEN COALESCE(priority, 'med') = 'med' THEN 2 
                              ELSE 3 END
            """)
            
            priority_counts = {'high': 0, 'med': 0, 'low': 0}
            for row in cursor.fetchall():
                priority = row[0]
                count = row[1]
                if priority in priority_counts:
                    priority_counts[priority] = count
            
            # Overdue tasks (not done and due date is in the past)
            today = os.environ.get("TASKCLI_TODAY", datetime.now().strftime("%Y-%m-%d"))
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND done = 0 AND due < ?", (today,))
            overdue = cursor.fetchone()[0]
            
            return {
                'total': total,
                'done': done,
                'open': open_tasks,
                'priority': priority_counts,
                'overdue': overdue
            }
        finally:
            conn.close()

    def backup(self, path: str):
        # Atomic write policy
        tmp_path = path + ".tmp"
        try:
            shutil.copy2(self.db_path, tmp_path)
            os.rename(tmp_path, path)
        except Exception as e:
            # Clean up temp file on failure
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise e

    def export(self, path: str, format: str = 'json'):
        # Use the shared query method for consistency
        tasks = self._query_tasks(show_all=True)  # Include archived tasks
        
        if format == 'csv':
            self._export_csv(path, tasks)
        else:
            self._export_json(path, tasks)

    def _export_json(self, path: str, tasks: List[Dict[str, Any]]):
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(tasks, f, indent=2)
            os.rename(tmp_path, path)
        except Exception as e:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise e

    def _export_csv(self, path: str, tasks: List[Dict[str, Any]]):
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, "w", newline="", encoding="utf-8") as f:
                if not tasks:
                    return
                writer = csv.DictWriter(f, fieldnames=tasks[0].keys())
                writer.writeheader()
                for task in tasks:
                    # Convert tags to a string representation
                    if 'tags' in task and isinstance(task['tags'], list):
                        task['tags'] = json.dumps(task['tags'])
                    writer.writerow(task)
            os.rename(tmp_path, path)
        except Exception as e:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise e

    def compact(self):
        conn = sqlite3.connect(self.db_path)
        try:
            # VACUUM to reclaim space
            conn.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()

    def search(self, text: str) -> List[Dict[str, Any]]:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Search for tasks with titles containing the text (case-insensitive)
            cursor.execute("""
                SELECT * FROM items 
                WHERE kind = 'task' AND LOWER(title) LIKE ?
                ORDER BY id
            """, (f"%{text.lower()}%",))
            
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'kind': row[1],
                    'title': row[2],
                    'done': bool(row[3]),
                    'archived': bool(row[4]),
                    'due': row[5],
                    'priority': row[6],
                    'tags': json.loads(row[7]) if row[7] else []
                }
                tasks.append(task)
                
            return tasks
        finally:
            conn.close()

    def format_task(self, task: Dict[str, Any], use_color: bool = False) -> str:
        # Determine if we're in a TTY environment for color output
        is_tty = os.isatty(sys.stdout.fileno()) if hasattr(sys.stdout, 'fileno') else True
        
        color_enabled = use_color and is_tty
        
        done_symbol = "✓" if task['done'] else "○"
        
        # Format the due date as YYYY-MM-DD or empty
        due_str = ""
        if task['due']:
            due_str = f" ({task['due']})"
            
        # Format priority
        priority_str = ""
        if task['priority']:
            priority_str = f" [{task['priority'].upper()}]"
            
        # Format tags
        tags_str = ""
        if task['tags']:
            tags_str = " #" + " #".join(task['tags'])
            
        # Build the line
        line = f"{task['id']} {done_symbol} {task['title']}{due_str}{priority_str}{tags_str}"
        
        # Apply ANSI colors if enabled
        if color_enabled:
            today = os.environ.get("TASKCLI_TODAY", datetime.now().strftime("%Y-%m-%d"))
            if task['due'] and task['due'] < today and not task['done']:
                # Overdue task in red
                line = f"\033[31m{line}\033[0m"
            elif task['done']:
                # Done task in green
                line = f"\033[32m{line}\033[0m"
                
        return line

import json
import os
from datetime import date


class Task:
    def __init__(self, id, title, done, priority, due, archived, tags):
        self.id = id
        self.title = title
        self.done = done
        self.priority = priority
        self.due = due
        self.archived = archived
        self.tags = tags or []

    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "done": self.done,
            "priority": self.priority,
            "due": self.due.strftime("%Y-%m-%d") if self.due else None,
            "archived": self.archived,
            "tags": self.tags
        }

    @classmethod
    def from_dict(cls, data):
        due = date.fromisoformat(data["due"]) if data.get("due") else None
        return cls(
            id=data["id"],
            title=data["title"],
            done=data["done"],
            priority=data["priority"],
            due=due,
            archived=data.get("archived", False),
            tags=data.get("tags", [])
        )


class TaskStorage:
    def __init__(self, filename="tasks.json"):
        self.filename = filename

    def load(self):
        if not os.path.exists(self.filename):
            return []
        
        with open(self.filename, "r", encoding="utf-8") as f:
            data = json.load(f)
        
        tasks = [Task.from_dict(item) for item in data]
        return tasks

    def save(self, tasks):
        with open(self.filename, "w", encoding="utf-8") as f:
            json.dump([t.to_dict() for t in tasks], f, indent=2)

    def add(self, task):
        tasks = self.load()
        
        if not tasks:
            new_id = 1
        else:
            new_id = max(t.id for t in tasks) + 1
        
        task.id = new_id
        tasks.append(task)
        self.save(tasks)
        return new_id

    def mark_done(self, task_id):
        tasks = self.load()
        found = False
        for task in tasks:
            if task.id == task_id:
                task.done = True
                found = True
                break
        if not found:
            raise ValueError(f"No task with id {task_id}")
        self.save(tasks)

    def delete(self, task_id):
        tasks = self.load()
        found = False
        for i, task in enumerate(tasks):
            if task.id == task_id:
                del tasks[i]
                found = True
                break
        if not found:
            raise ValueError(f"No task with id {task_id}")
        self.save(tasks)

    def archive(self):
        tasks = self.load()
        for task in tasks:
            if task.done and not task.archived:
                task.archived = True
        self.save(tasks)

    def export(self, path):
        tasks = self.load()
        with open(path, "w", encoding="utf-8") as f:
            json.dump([t.to_dict() for t in tasks], f, indent=2)

    def compact(self):
        # For this simple implementation, compact is a no-op
        # In a real implementation, it would remove deleted entries and renumber
        pass

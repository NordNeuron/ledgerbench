import argparse
import os
import sys
import json
import shutil
import csv
from datetime import datetime
from .storage import TaskStorage, Task


def get_config():
    config = {}
    
    # Read config.toml first (takes precedence)
    try:
        with open("config.toml", "r", encoding="utf-8") as f:
            import toml
            config = toml.load(f)
    except (FileNotFoundError, ImportError):
        pass
    
    # Environment variable should only be used if no config file or no today in config
    try:
        today = os.environ.get("TASKCLI_TODAY")
        if today and "today" not in config:  # Only use env var if config doesn't have today set
            config["today"] = today
    except Exception:
        pass
    
    return config


def parse_date(date_str):
    try:
        return datetime.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        raise argparse.ArgumentTypeError(f"Invalid date format: {date_str}. Expected YYYY-MM-DD.")


def is_tty():
    return sys.stdout.isatty()


def colorize(text, color_code):
    if is_tty():
        return f"\x1b[{color_code}m{text}\x1b[0m"
    return text


def print_task(task, today, show_color=False):
    status = "✓" if task.done else "○"
    priority_symbol = {"high": "▲", "med": "◆", "low": "▼"}[task.priority]
    
    # Check if task is overdue
    overdue = False
    if task.due and task.due < today:
        overdue = True
    
    # Format the line
    line = f"{task.id} {status} {priority_symbol} {task.title}"
    if task.due:
        line += f" (due {task.due.strftime('%Y-%m-%d')})"
    
    # Apply colors
    if show_color:
        if overdue and not task.done:
            line = colorize(line, "31")  # Red for overdue
        elif task.done:
            line = colorize(line, "32")  # Green for done
    
    print(line)


def _query_tasks(storage, args=None):
    """Shared function to query tasks with filters"""
    tasks = storage.load()
    
    # Apply archived filter (default: hide archived)
    if hasattr(args, 'all') and args.all:
        filtered_tasks = tasks
    else:
        filtered_tasks = [t for t in tasks if not t.archived]
    
    # Apply tag filter
    if hasattr(args, 'tag') and args.tag:
        filtered_tasks = [t for t in filtered_tasks if args.tag in t.tags]
    
    # Apply overdue filter
    if hasattr(args, 'overdue') and args.overdue:
        today = parse_date(get_config().get("today", datetime.now().strftime("%Y-%m-%d")))
        filtered_tasks = [t for t in filtered_tasks if t.due and t.due < today and not t.done]
    
    # Apply sorting
    if hasattr(args, 'sort') and args.sort == 'priority':
        # Sort by priority: high, med, low
        priority_order = {"high": 0, "med": 1, "low": 2}
        filtered_tasks.sort(key=lambda t: (priority_order.get(t.priority, 3), t.id))
    elif hasattr(args, 'sort') and args.sort == 'review':
        # Review view: overdue first, then by priority high to low
        today = parse_date(get_config().get("today", datetime.now().strftime("%Y-%m-%d")))
        priority_order = {"high": 0, "med": 1, "low": 2}
        filtered_tasks.sort(key=lambda t: (
            not (t.due and t.due < today and not t.done),  # Overdue tasks first
            priority_order.get(t.priority, 3),
            t.id
        ))
    else:
        # Default insertion order
        pass
    
    return filtered_tasks


def list_tasks(storage, args):
    print("AUDIT list", file=sys.stderr)
    tasks = _query_tasks(storage, args)
    
    today = parse_date(get_config().get("today", datetime.now().strftime("%Y-%m-%d")))
    
    show_color = getattr(args, 'color', False)
    
    for task in tasks:
        print_task(task, today, show_color)


def add_task(storage, args):
    print("AUDIT add", file=sys.stderr)
    today = parse_date(get_config().get("today", datetime.now().strftime("%Y-%m-%d")))
    
    priority = getattr(args, 'priority', None) or get_config().get("default_priority", "med")
    if priority not in ["high", "med", "low"]:
        raise argparse.ArgumentTypeError(f"Invalid priority: {priority}. Expected high/med/low.")
    
    due = getattr(args, 'due', None)
    if due:
        try:
            due_date = parse_date(due)
        except argparse.ArgumentTypeError as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(2)
    else:
        due_date = None
    
    tags = getattr(args, 'tag', [])
    
    task = Task(
        id=0,  # Will be assigned by storage
        title=args.title,
        done=False,
        priority=priority,
        due=due_date,
        archived=False,
        tags=tags
    )
    
    new_id = storage.add(task)
    print(new_id)


def done_task(storage, args):
    print("AUDIT done", file=sys.stderr)
    task_id = int(args.id)
    try:
        storage.mark_done(task_id)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


def delete_task(storage, args):
    print("AUDIT delete", file=sys.stderr)
    task_id = int(args.id)
    try:
        storage.delete(task_id)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


def archive_tasks(storage, args):
    print("AUDIT archive", file=sys.stderr)
    storage.archive()


def backup(storage, args):
    print("AUDIT backup", file=sys.stderr)
    # Atomic write
    tmp_path = args.path + ".tmp"
    try:
        # Check if we can write to the directory
        dest_dir = os.path.dirname(args.path) or "."
        
        # If directory doesn't exist, we should fail gracefully
        if not os.path.exists(dest_dir):
            raise OSError(f"Directory does not exist: {dest_dir}")
        
        # Test write access by trying to create a temporary file
        try:
            test_file = os.path.join(dest_dir, ".write_test")
            with open(test_file, "w") as f:
                f.write("")
            os.remove(test_file)
        except (OSError, IOError):
            raise OSError(f"Directory is not writable: {dest_dir}")
        
        storage.export(tmp_path)
        shutil.move(tmp_path, args.path)
    except Exception as e:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except:
                pass
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def export(storage, args):
    print("AUDIT export", file=sys.stderr)
    if getattr(args, 'format', None) == 'csv':
        export_csv(storage, args.path)
    else:
        # Default JSON format
        export_json(storage, args.path)


def export_json(storage, path):
    # For export, we want to include ALL tasks (including archived)
    tasks = storage.load()
    
    with open(path, "w", encoding="utf-8") as f:
        json.dump([t.to_dict() for t in tasks], f, indent=2)


def export_csv(storage, path):
    # For export, we want to include ALL tasks (including archived)
    tasks = storage.load()
    fieldnames = ["id", "title", "done", "priority", "due", "archived", "tags"]
    
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for task in tasks:
            row = {
                "id": task.id,
                "title": task.title,
                "done": task.done,
                "priority": task.priority,
                "due": task.due.strftime("%Y-%m-%d") if task.due else "",
                "archived": task.archived,
                "tags": ",".join(task.tags) if task.tags else ""
            }
            writer.writerow(row)


def compact(storage, args):
    print("AUDIT compact", file=sys.stderr)
    storage.compact()


def stats(storage, args):
    print("AUDIT stats", file=sys.stderr)
    today = parse_date(get_config().get("today", datetime.now().strftime("%Y-%m-%d")))
    
    tasks = storage.load()
    
    total = len(tasks)
    done = sum(1 for t in tasks if t.done)
    open_tasks = total - done
    
    priority_counts = {"high": 0, "med": 0, "low": 0}
    overdue_count = 0
    
    for task in tasks:
        if not task.archived:
            priority_counts[task.priority] += 1
            if task.due and task.due < today and not task.done:
                overdue_count += 1
    
    print(f"Total: {total}")
    print(f"Done: {done}")
    print(f"Open: {open_tasks}")
    print(f"Overdue: {overdue_count}")
    
    for priority in ["high", "med", "low"]:
        print(f"Priority {priority}: {priority_counts[priority]}")


def search(storage, args):
    print("AUDIT search", file=sys.stderr)
    tasks = storage.load()
    query = args.text.lower()
    
    today = parse_date(get_config().get("today", datetime.now().strftime("%Y-%m-%d")))
    
    matching_tasks = [t for t in tasks if not t.archived and query in t.title.lower()]
    
    show_color = getattr(args, 'color', False)
    
    for task in matching_tasks:
        print_task(task, today, show_color)


def main():
    parser = argparse.ArgumentParser(description="Minimal command-line task manager")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--due", help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--priority", choices=["high", "med", "low"], default="med",
                            help="Task priority (default: med)")
    add_parser.add_argument("--tag", action="append", help="Add a tag (repeatable)")

    # List command
    list_parser = subparsers.add_parser("list", help="List all tasks")
    list_parser.add_argument("--sort", choices=["priority", "review"],
                             help="Sort order")
    list_parser.add_argument("--all", action="store_true",
                             help="Show archived tasks")
    list_parser.add_argument("--tag", help="Filter by tag")
    list_parser.add_argument("--color", action="store_true",
                             help="Colorize output")
    list_parser.add_argument("--overdue", action="store_true",
                             help="Show only overdue tasks")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark task as done")
    done_parser.add_argument("id", help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", help="Task ID")

    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup database")
    backup_parser.add_argument("path", help="Backup file path")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export file path")
    export_parser.add_argument("--format", choices=["json", "csv"], default="json",
                               help="Export format (default: json)")

    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Reclaim dead space")

    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show statistics")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Text to search for")

    args = parser.parse_args()

    storage = TaskStorage()

    try:
        if args.command == "add":
            add_task(storage, args)
        elif args.command == "list":
            list_tasks(storage, args)
        elif args.command == "done":
            done_task(storage, args)
        elif args.command == "delete":
            delete_task(storage, args)
        elif args.command == "archive":
            archive_tasks(storage, args)
        elif args.command == "backup":
            backup(storage, args)
        elif args.command == "export":
            export(storage, args)
        elif args.command == "compact":
            compact(storage, args)
        elif args.command == "stats":
            stats(storage, args)
        elif args.command == "search":
            search(storage, args)
        else:
            parser.print_help()
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

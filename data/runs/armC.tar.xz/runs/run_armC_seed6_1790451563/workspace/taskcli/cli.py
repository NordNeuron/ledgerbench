import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import TaskStorage, Task

def get_config():
    config = {}
    try:
        with open('config.toml', 'r') as f:
            import toml
            config = toml.load(f)
    except (FileNotFoundError, toml.TomlDecodeError):
        # Fall back to environment variable if config file is missing or invalid
        try:
            config['today'] = os.environ['TASKCLI_TODAY']
        except KeyError:
            pass
    return config

def main():
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--priority', choices=['high', 'med', 'low'], default=None)
    add_parser.add_argument('--tag', action='append', help='Add a tag (repeatable)')

    # List command
    list_parser = subparsers.add_parser('list', help='List tasks')
    list_parser.add_argument('--sort', choices=['priority', 'insertion'], default='insertion')
    list_parser.add_argument('--all', action='store_true', help='Show archived tasks')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--color', action='store_true', help='Enable color output')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')

    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup database')
    backup_parser.add_argument('path', help='Backup file path')

    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Reclaim dead space')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['csv'], default='default')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for')

    args = parser.parse_args()

    config = get_config()
    today_str = config.get('today', None)
    if today_str:
        os.environ['TASKCLI_TODAY'] = today_str

    # Emit audit line - always, on success and failure
    sys.stderr.write(f"AUDIT {args.command}\n")

    try:
        storage = TaskStorage()
        
        if args.command == 'add':
            task = Task(
                title=args.title,
                due=args.due,
                priority=args.priority,
                tags=args.tag or []
            )
            new_id = storage.add_task(task)
            print(new_id)
            
        elif args.command == 'list':
            tasks = storage.list_tasks(
                sort_order=args.sort,
                show_all=args.all,
                tag_filter=args.tag,
                overdue_only=args.overdue
            )
            for task in tasks:
                print(storage.format_task(task, args.color))
                
        elif args.command == 'done':
            storage.mark_done(args.id)
            
        elif args.command == 'delete':
            storage.delete_task(args.id)
            
        elif args.command == 'archive':
            storage.archive_done()
            
        elif args.command == 'stats':
            stats = storage.get_stats()
            print(f"Total: {stats['total']}")
            print(f"Done: {stats['done']}")
            print(f"Open: {stats['open']}")
            print(f"Priority high: {stats['priority']['high']}")
            print(f"Priority med: {stats['priority']['med']}")
            print(f"Priority low: {stats['priority']['low']}")
            print(f"Overdue: {stats['overdue']}")
            
        elif args.command == 'backup':
            storage.backup(args.path)
            
        elif args.command == 'compact':
            storage.compact()
            
        elif args.command == 'export':
            if args.format == 'csv':
                storage.export_csv(args.path)
            else:
                # Default export behavior
                storage.export_default(args.path)
                
        elif args.command == 'search':
            tasks = storage.search_tasks(args.text)
            for task in tasks:
                print(storage.format_task(task, False))  # No color for search
                
    except ValueError as e:
        sys.stderr.write(f"Error: {e}\n")
        return 2
    except (IOError, OSError) as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1

    return 0

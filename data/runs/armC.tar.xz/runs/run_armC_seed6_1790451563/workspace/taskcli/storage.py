import sqlite3
import os
import shutil
import csv
from datetime import datetime
from typing import List, Dict, Any
import json
import re
import sys

class Task:
    def __init__(self, title: str, due: str = None, priority: str = None, tags: List[str] = None):
        self.title = title
        self.due = due
        self.priority = priority or 'med'
        self.tags = tags or []
        self.done = False
        self.archived = False

class TaskStorage:
    def __init__(self, db_path='tasks.db'):
        self.db_path = db_path
        self.init_db()
        
    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table with kind column
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    due TEXT,
                    priority TEXT,
                    tags TEXT,
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE
                )
            ''')
            
            conn.commit()
        finally:
            conn.close()
    
    def validate_date(self, date_str):
        """Validate that a date string is in YYYY-MM-DD format."""
        if not date_str:
            return True
            
        # Check format using regex
        pattern = r'^\d{4}-\d{2}-\d{2}$'
        if not re.match(pattern, date_str):
            raise ValueError(f"Invalid date format: {date_str}. Expected YYYY-MM-DD.")
            
        try:
            datetime.strptime(date_str, '%Y-%m-%d')
            return True
        except ValueError:
            raise ValueError(f"Invalid date: {date_str}. Please provide a valid date in YYYY-MM-DD format.")
    
    def get_next_id(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('SELECT MAX(id) FROM items')
            max_id = cursor.fetchone()[0]
            return (max_id or 0) + 1
        finally:
            conn.close()
    
    def get_tasks_query(self, sort_order='insertion', show_all=False, tag_filter=None, overdue_only=False):
        """Get the base query for tasks with all filters applied."""
        # Base query
        query = 'SELECT id, title, due, priority, tags, done, archived FROM items WHERE kind = ?'
        params = ['task']
        
        # Filter out archived tasks unless --all is specified
        if not show_all:
            query += ' AND archived = 0'
            
        # Filter by tag if provided
        if tag_filter:
            query += ' AND tags LIKE ?'
            params.append(f'%"{tag_filter}"%')
            
        # Filter overdue tasks if requested
        if overdue_only:
            today_str = os.environ.get('TASKCLI_TODAY', datetime.now().strftime('%Y-%m-%d'))
            query += ' AND due < ? AND done = 0'
            params.append(today_str)
        
        # Sort order
        if sort_order == 'priority':
            # High, then med, then low priority - maintain insertion order for same priority
            query += ' ORDER BY CASE priority WHEN "high" THEN 1 WHEN "med" THEN 2 ELSE 3 END, id'
        else:
            # Insertion order (default) - by id
            query += ' ORDER BY id'
            
        return query, params
    
    def list_tasks(self, sort_order='insertion', show_all=False, tag_filter=None, overdue_only=False):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            query, params = self.get_tasks_query(sort_order, show_all, tag_filter, overdue_only)
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = Task(
                    title=row[1],
                    due=row[3] if row[3] else None,
                    priority=row[4] if row[4] else 'med',
                    tags=json.loads(row[5]) if row[5] else []
                )
                task.id = row[0]
                task.done = bool(row[6])
                task.archived = bool(row[7])
                tasks.append(task)
                
            return tasks
        finally:
            conn.close()
    
    def add_task(self, task: Task):
        # Validate due date if provided
        if task.due:
            self.validate_date(task.due)
            
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            task_id = self.get_next_id()
            
            # Convert tags list to JSON string for storage
            tags_json = json.dumps(task.tags)
            
            cursor.execute('''
                INSERT INTO items (id, kind, title, due, priority, tags, done, archived)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (task_id, 'task', task.title, task.due, task.priority, tags_json, task.done, task.archived))
            
            conn.commit()
            return task_id
        finally:
            conn.close()
    
    def mark_done(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('UPDATE items SET done = 1 WHERE id = ? AND kind = ?', (task_id, 'task'))
            
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
                
            conn.commit()
        finally:
            conn.close()
    
    def delete_task(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM items WHERE id = ? AND kind = ?', (task_id, 'task'))
            
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
                
            conn.commit()
        finally:
            conn.close()
    
    def archive_done(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('UPDATE items SET archived = 1 WHERE done = 1 AND kind = ?', ('task',))
            conn.commit()
        finally:
            conn.close()
    
    def get_stats(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute('SELECT COUNT(*) FROM items WHERE kind = ?', ('task',))
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute('SELECT COUNT(*) FROM items WHERE kind = ? AND done = 1', ('task',))
            done = cursor.fetchone()[0]
            
            # Open tasks (total - done)
            open_tasks = total - done
            
            # Priority counts
            priority_counts = {'high': 0, 'med': 0, 'low': 0}
            for priority in ['high', 'med', 'low']:
                cursor.execute('SELECT COUNT(*) FROM items WHERE kind = ? AND priority = ?', ('task', priority))
                priority_counts[priority] = cursor.fetchone()[0]
            
            # Overdue tasks (not done and due date is in the past)
            today_str = os.environ.get('TASKCLI_TODAY', datetime.now().strftime('%Y-%m-%d'))
            cursor.execute('''
                SELECT COUNT(*) FROM items 
                WHERE kind = ? AND done = 0 AND due < ?
            ''', ('task', today_str))
            overdue = cursor.fetchone()[0]
            
            return {
                'total': total,
                'done': done,
                'open': open_tasks,
                'priority': priority_counts,
                'overdue': overdue
            }
        finally:
            conn.close()
    
    def backup(self, path):
        # Atomic write policy: write to temp file then rename
        tmp_path = path + '.tmp'
        try:
            shutil.copy2(self.db_path, tmp_path)
            os.rename(tmp_path, path)
        except (IOError, OSError):
            # Clean up temp file on failure
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise
    
    def compact(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('VACUUM')
            conn.commit()
        finally:
            conn.close()
    
    def export_csv(self, path):
        # Use the same query logic as list_tasks for consistency
        tasks = self.list_tasks()
        
        with open(path, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['id', 'title', 'due', 'priority', 'tags', 'done', 'archived']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            
            writer.writeheader()
            for task in tasks:
                # Convert tags list to comma-separated string for CSV
                tags_str = ','.join(task.tags) if task.tags else ''
                writer.writerow({
                    'id': task.id,
                    'title': task.title,
                    'due': task.due,
                    'priority': task.priority,
                    'tags': tags_str,
                    'done': int(task.done),
                    'archived': int(task.archived)
                })
    
    def export_default(self, path):
        tasks = self.list_tasks()
        with open(path, 'w', encoding='utf-8') as f:
            for task in tasks:
                f.write(f"{task.id} {task.title}\n")
    
    def search_tasks(self, text: str) -> List[Task]:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Search case-insensitively using the same query logic
            query = '''
                SELECT id, title, due, priority, tags, done, archived 
                FROM items 
                WHERE kind = ? AND LOWER(title) LIKE ?
                ORDER BY id
            '''
            params = ['task', f'%{text.lower()}%']
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = Task(
                    title=row[1],
                    due=row[3] if row[3] else None,
                    priority=row[4] if row[4] else 'med',
                    tags=json.loads(row[5]) if row[5] else []
                )
                task.id = row[0]
                task.done = bool(row[6])
                task.archived = bool(row[7])
                tasks.append(task)
                
            return tasks
        finally:
            conn.close()
    
    def format_task(self, task: Task, use_color: bool = False) -> str:
        # Determine if we should show ANSI codes (only on TTY)
        should_color = use_color and os.isatty(sys.stdout.fileno())
        
        # Format due date - always in YYYY-MM-DD format
        due_str = f" ({task.due})" if task.due else ""
        
        # Format priority
        priority_str = f"[{task.priority}]"
        
        # Format done status
        done_str = "✓" if task.done else "○"
        
        # Format tags
        tags_str = f" #{' #'.join(task.tags)}" if task.tags else ""
        
        # Build the line
        line = f"{done_str} {task.id} {task.title}{due_str} {priority_str}{tags_str}"
        
        # Apply colors if needed
        if should_color:
            today_str = os.environ.get('TASKCLI_TODAY', datetime.now().strftime('%Y-%m-%d'))
            if task.due and task.due < today_str and not task.done:
                # Overdue in red
                line = f"\033[31m{line}\033[0m"
            elif task.done:
                # Done in green
                line = f"\033[32m{line}\033[0m"
        
        return line

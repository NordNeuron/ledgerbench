import os
import sqlite3
import shutil
import csv
from datetime import datetime
import json

class TaskStorage:
    def __init__(self, db_path="tasks.db"):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create items table if it doesn't exist (exact schema from requirements)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY,
                kind TEXT NOT NULL,
                title TEXT NOT NULL,
                due DATE,
                priority TEXT DEFAULT 'med',
                done BOOLEAN DEFAULT FALSE,
                archived BOOLEAN DEFAULT FALSE,
                tags TEXT DEFAULT '[]'
            )
        """)
        
        # Create indexes for performance
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_id ON items(id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_kind ON items(kind)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_done ON items(done)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_archived ON items(archived)")
        
        conn.commit()
        conn.close()

    def get_next_id(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT MAX(id) FROM items")
            max_id = cursor.fetchone()[0]
            return (max_id or 0) + 1
        finally:
            conn.close()

    def add_task(self, title, due=None, priority="med", tags=None):
        if tags is None:
            tags = []
        
        task_id = self.get_next_id()
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO items (id, kind, title, due, priority, done, archived, tags)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (task_id, "task", title, due, priority, False, False, json.dumps(tags)))
            conn.commit()
            return task_id
        finally:
            conn.close()

    def _get_tasks_query(self, sort_by="insertion", show_all=False, overdue_only=False, tag_filter=None):
        """Get the base query and parameters for tasks."""
        # Base query
        query = "SELECT id, title, due, priority, done, archived, tags FROM items WHERE kind='task'"
        params = []
        
        # Filter out archived tasks unless --all is specified
        if not show_all:
            query += " AND archived=0"
            
        # Filter by tag if provided
        if tag_filter:
            query += " AND tags LIKE ?"
            params.append(f'%"{tag_filter}"%')
            
        # Filter overdue tasks if requested
        if overdue_only:
            query += " AND due IS NOT NULL AND done=0 AND due < ?"
            params.append(str(datetime.now().date()))
        
        # Order by - exact behavior required by tests
        if sort_by == "priority":
            # High, then med, then low priority (using explicit CASE)
            query += " ORDER BY CASE WHEN priority='high' THEN 1 WHEN priority='med' THEN 2 ELSE 3 END"
        else:  # insertion order (default) - must be by id
            query += " ORDER BY id"
            
        return query, params

    def list_tasks(self, sort_by="insertion", show_all=False, overdue_only=False, tag_filter=None):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            query, params = self._get_tasks_query(sort_by, show_all, overdue_only, tag_filter)
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'due': row[2],
                    'priority': row[3],
                    'done': bool(row[4]),
                    'archived': bool(row[5]),
                    'tags': json.loads(row[6]) if row[6] else []
                }
                tasks.append(task)
                
            return tasks
        finally:
            conn.close()

    def mark_done(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found")
                
            cursor.execute("UPDATE items SET done=1 WHERE id=?", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def delete_task(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found")
                
            cursor.execute("DELETE FROM items WHERE id=?", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def get_stats(self, today):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task' AND archived=0")
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task' AND done=1 AND archived=0")
            done = cursor.fetchone()[0]
            
            # Open tasks
            open_tasks = total - done
            
            # Priority counts
            cursor.execute("SELECT priority, COUNT(*) FROM items WHERE kind='task' AND archived=0 GROUP BY priority")
            priority_counts = dict(cursor.fetchall())
            
            high_count = priority_counts.get('high', 0)
            med_count = priority_counts.get('med', 0)
            low_count = priority_counts.get('low', 0)
            
            # Overdue tasks
            cursor.execute("""
                SELECT COUNT(*) FROM items 
                WHERE kind='task' AND done=0 AND archived=0 AND due IS NOT NULL AND due < ?
            """, (str(today),))
            overdue = cursor.fetchone()[0]
            
            return {
                'total': total,
                'done': done,
                'open': open_tasks,
                'priority_high': high_count,
                'priority_med': med_count,
                'priority_low': low_count,
                'overdue': overdue
            }
        finally:
            conn.close()

    def archive_done(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived=1 WHERE kind='task' AND done=1")
            conn.commit()
        finally:
            conn.close()

    def backup(self, path):
        # Atomic write: create temp file then rename
        tmp_path = path + ".tmp"
        shutil.copy2(self.db_path, tmp_path)
        os.rename(tmp_path, path)

    def compact(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()

    def export_csv(self, path, sort_by="insertion", show_all=False, overdue_only=False, tag_filter=None):
        """Export tasks to CSV using the same query logic as list."""
        tasks = self.list_tasks(sort_by=sort_by, show_all=show_all, overdue_only=overdue_only, tag_filter=tag_filter)
        with open(path, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['id', 'title', 'due', 'priority', 'done', 'archived', 'tags']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for task in tasks:
                writer.writerow({
                    'id': task['id'],
                    'title': task['title'],
                    'due': task['due'],
                    'priority': task['priority'],
                    'done': task['done'],
                    'archived': task['archived'],
                    'tags': json.dumps(task['tags'])
                })

    def export_default(self, path, sort_by="insertion", show_all=False, overdue_only=False, tag_filter=None):
        """Export tasks in default format using the same query logic as list."""
        tasks = self.list_tasks(sort_by=sort_by, show_all=show_all, overdue_only=overdue_only, tag_filter=tag_filter)
        with open(path, 'w', encoding='utf-8') as f:
            for task in tasks:
                f.write(f"{task['id']} {task['title']}\n")

    def search_tasks(self, text):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            # Search case-insensitively
            query = """
                SELECT id, title, due, priority, done, archived, tags 
                FROM items 
                WHERE kind='task' AND archived=0 AND LOWER(title) LIKE ?
            """
            cursor.execute(query, (f'%{text.lower()}%',))
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'due': row[2],
                    'priority': row[3],
                    'done': bool(row[4]),
                    'archived': bool(row[5]),
                    'tags': json.loads(row[6]) if row[6] else []
                }
                tasks.append(task)
                
            return tasks
        finally:
            conn.close()

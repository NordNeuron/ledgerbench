import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import TaskStorage


def get_config():
    config = {}
    try:
        with open("config.toml", "r", encoding="utf-8") as f:
            import tomli
            config = tomli.loads(f.read())
    except (FileNotFoundError, tomli.TOMLDecodeError):
        pass
    
    # Fallback to environment variable if no config file
    if not config and "TASKCLI_TODAY" in os.environ:
        config["today"] = os.environ["TASKCLI_TODAY"]
    
    return config


def get_today():
    config = get_config()
    if "today" in config:
        return datetime.strptime(config["today"], "%Y-%m-%d").date()
    else:
        return datetime.now().date()


def format_task(task, today=None, show_color=False):
    if today is None:
        today = get_today()

    done_symbol = "✓" if task['done'] else "○"
    priority_symbol = {"high": "H", "med": "M", "low": "L"}[task['priority']]
    
    due_str = ""
    if task['due']:
        due_str = f" (due {task['due']})"
        
    overdue = False
    if task['due'] and not task['done']:
        due_date = datetime.strptime(task['due'], "%Y-%m-%d").date()
        overdue = due_date < today

    # Only output ANSI codes when stdout is a TTY
    if show_color and sys.stdout.isatty():
        if overdue:
            color = "\033[31m"  # red
        elif task['done']:
            color = "\033[32m"  # green
        else:
            color = ""
        reset = "\033[0m"
        return f"{color}{done_symbol} [{priority_symbol}] {task['title']}{due_str}{reset}"
    else:
        return f"{done_symbol} [{priority_symbol}] {task['title']}{due_str}"


def print_task(task, today=None, show_color=False):
    print(format_task(task, today, show_color))


def main():
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--due", help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--priority", choices=["high", "med", "low"], default=None)
    add_parser.add_argument("--tag", action="append", help="Add a tag")

    # List command
    list_parser = subparsers.add_parser("list", help="List tasks")
    list_parser.add_argument("--sort", choices=["priority", "insertion"], default="insertion")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")
    list_parser.add_argument("--tag", help="Filter by tag")
    list_parser.add_argument("--color", action="store_true", help="Show colors")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show statistics")

    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup database")
    backup_parser.add_argument("path", help="Backup file path")

    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Compact database")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export file path")
    export_parser.add_argument("--format", choices=["csv"], default="default")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Text to search for")

    args = parser.parse_args()

    # Emit audit line for all commands - this is the new requirement
    print(f"AUDIT {args.command}", file=sys.stderr)

    try:
        storage = TaskStorage()
        
        if args.command == "add":
            # Validate due date if provided
            if args.due:
                try:
                    datetime.strptime(args.due, "%Y-%m-%d")
                except ValueError:
                    print(f"Invalid date format '{args.due}'. Expected YYYY-MM-DD.", file=sys.stderr)
                    return 2

            # Get default priority from config
            config = get_config()
            if args.priority is None and "default_priority" in config:
                args.priority = config["default_priority"]

            # Use default priority if none specified
            if args.priority is None:
                args.priority = "med"

            task_id = storage.add_task(args.title, args.due, args.priority, args.tag)
            print(task_id)
            return 0

        elif args.command == "list":
            today = get_today()
            tasks = storage.list_tasks(
                sort_by=args.sort,
                show_all=args.all,
                overdue_only=args.overdue,
                tag_filter=args.tag
            )
            
            for task in tasks:
                print_task(task, today, args.color)
            return 0

        elif args.command == "done":
            try:
                storage.mark_done(args.id)
            except ValueError as e:
                print(str(e), file=sys.stderr)
                return 2
            # Silent success - no output
            return 0

        elif args.command == "delete":
            try:
                storage.delete_task(args.id)
            except ValueError as e:
                print(str(e), file=sys.stderr)
                return 2
            # Silent success - no output
            return 0

        elif args.command == "stats":
            today = get_today()
            stats = storage.get_stats(today)
            print(f"Total: {stats['total']}")
            print(f"Done: {stats['done']}")
            print(f"Open: {stats['open']}")
            print(f"Priority high: {stats['priority_high']}")
            print(f"Priority med: {stats['priority_med']}")
            print(f"Priority low: {stats['priority_low']}")
            print(f"Overdue: {stats['overdue']}")
            return 0

        elif args.command == "archive":
            storage.archive_done()
            return 0

        elif args.command == "backup":
            try:
                storage.backup(args.path)
            except OSError as e:
                print(str(e), file=sys.stderr)
                return 1
            return 0

        elif args.command == "compact":
            storage.compact()
            return 0

        elif args.command == "export":
            if args.format == "csv":
                storage.export_csv(args.path, sort_by=args.sort, show_all=args.all, overdue_only=args.overdue, tag_filter=args.tag)
            else:
                # Default export format
                storage.export_default(args.path, sort_by=args.sort, show_all=args.all, overdue_only=args.overdue, tag_filter=args.tag)
            return 0

        elif args.command == "search":
            tasks = storage.search_tasks(args.text)
            today = get_today()
            for task in tasks:
                print_task(task, today, False)  # No color in search output
            return 0

        else:
            parser.print_help()
            return 0

    except Exception as e:
        print(str(e), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())

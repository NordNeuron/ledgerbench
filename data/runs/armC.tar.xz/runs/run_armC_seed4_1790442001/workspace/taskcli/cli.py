import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import TaskStorage

def get_config():
    config = {}
    try:
        import tomllib
        config_file = "config.toml"
        if os.path.exists(config_file):
            with open(config_file, "rb") as f:
                config = tomllib.load(f)
    except ImportError:
        # Fallback for Python < 3.11
        try:
            import toml
            config_file = "config.toml"
            if os.path.exists(config_file):
                with open(config_file, "r", encoding="utf-8") as f:
                    config = toml.load(f)
        except ImportError:
            pass
    
    # Handle deprecated environment variable
    if "TASKCLI_TODAY" in os.environ and not config.get("today"):
        config["today"] = os.environ["TASKCLI_TODAY"]
    
    return config

def parse_date(date_str):
    try:
        return datetime.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        raise argparse.ArgumentTypeError(f"Invalid date format: {date_str}. Expected YYYY-MM-DD.")

def main():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--due", help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--priority", choices=["high", "med", "low"], default=None, help="Priority level")
    add_parser.add_argument("--tag", action="append", help="Tag for the task (repeatable)")

    # List command
    list_parser = subparsers.add_parser("list", help="List all tasks")
    list_parser.add_argument("--sort", choices=["priority", "insertion"], default="insertion", help="Sort order")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")
    list_parser.add_argument("--color", action="store_true", help="Enable colored output")
    list_parser.add_argument("--tag", help="Filter by tag")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark a task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")

    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show statistics")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup database")
    backup_parser.add_argument("path", help="Backup file path")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export file path")
    export_parser.add_argument("--format", choices=["json", "csv"], default="json", help="Export format")

    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Reclaim dead space")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Text to search for in titles")

    args = parser.parse_args()

    config = get_config()
    
    if "today" in config:
        today_str = config["today"]
        try:
            today = datetime.strptime(today_str, "%Y-%m-%d").date()
        except ValueError:
            # Write error message with correct format
            sys.stderr.write(f"error: Invalid date in config.toml: {today_str}. Expected YYYY-MM-DD.\n")
            return 2
    else:
        today = datetime.now().date()

    storage = TaskStorage(today)

    # Emit audit line - this must happen before any other output/error
    command_name = args.command if args.command else "help"
    sys.stderr.write(f"AUDIT {command_name}\n")

    try:
        if args.command == "add":
            # Validate due date before adding
            if args.due:
                try:
                    due_date = parse_date(args.due)
                except argparse.ArgumentTypeError as e:
                    # Write error message with correct format
                    sys.stderr.write(f"error: {e}\n")
                    return 2
            else:
                due_date = None
            
            priority = args.priority or config.get("default_priority", "med")
            task_id = storage.add_task(args.title, due_date, priority, args.tag or [])
            print(task_id)
        elif args.command == "list":
            tasks = storage.list_tasks(args.sort, args.all, args.overdue, args.tag)
            for task in tasks:
                print(storage.format_task(task, args.color))
        elif args.command == "done":
            storage.mark_done(args.id)
            # Done command should be completely silent on success - no stdout, no stderr
        elif args.command == "delete":
            storage.delete_task(args.id)
            # Delete command should be completely silent on success - no stdout, no stderr
        elif args.command == "archive":
            storage.archive_done()
        elif args.command == "stats":
            storage.print_stats()
        elif args.command == "backup":
            storage.backup(args.path)
        elif args.command == "export":
            # For export, we want to include archived tasks by default (like list --all)
            show_all = True  # Always include archived for exports
            overdue_only = False  # No overdue filter for exports
            tag_filter = None  # No tag filter for exports
            
            if args.format == "csv":
                storage.export_csv(args.path, show_all, overdue_only, tag_filter)
            else:
                storage.export_json(args.path, show_all, overdue_only, tag_filter)
        elif args.command == "compact":
            storage.compact()
        elif args.command == "search":
            tasks = storage.search_tasks(args.text)
            for task in tasks:
                print(storage.format_task(task, False))  # No color for search
        else:
            parser.print_help()
            return 0
    except ValueError as e:
        # Write error message with correct format
        sys.stderr.write(f"error: {e}\n")
        return 2
    except (OSError, sqlite3.Error) as e:
        # Write error message with correct format
        sys.stderr.write(f"error: {e}\n")
        return 1

    return 0

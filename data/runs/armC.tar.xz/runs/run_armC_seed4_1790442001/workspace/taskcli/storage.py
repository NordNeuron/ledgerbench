import os
import json
import csv
import shutil
import sqlite3
import sys
from datetime import date, datetime
from typing import List, Optional, Tuple

class TaskStorage:
    def __init__(self, today: date):
        self.today = today
        self.db_path = "tasks.db"
        self._init_db()

    def _init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table if not exists
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE,
                    due DATE,
                    priority TEXT DEFAULT 'med',
                    tags TEXT DEFAULT '[]'
                )
            """)
            
            # Create indexes
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_kind ON items(kind)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_done ON items(done)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_archived ON items(archived)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_priority ON items(priority)")
            
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _get_next_id(self) -> int:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT MAX(id) FROM items WHERE kind='task'")
            result = cursor.fetchone()[0]
            return (result or 0) + 1
        finally:
            conn.close()

    def add_task(self, title: str, due_date: Optional[date], priority: str, tags: List[str]) -> int:
        task_id = self._get_next_id()
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO items (id, kind, title, done, archived, due, priority, tags)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (task_id, "task", title, False, False, due_date, priority, json.dumps(tags)))
            conn.commit()
            return task_id
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _build_list_query(self, show_all: bool = False, overdue_only: bool = False, tag_filter: Optional[str] = None) -> Tuple[str, List]:
        """Build a unified query for listing tasks."""
        # Base query
        query = """
            SELECT id, title, done, archived, due, priority, tags 
            FROM items 
            WHERE kind='task'
        """
        
        params = []
        
        if not show_all:
            query += " AND archived=0"
            
        if overdue_only:
            query += " AND done=0 AND due < ?"
            params.append(self.today)
            
        if tag_filter:
            # Filter tasks that have the specified tag
            query += " AND tags LIKE ?"
            params.append(f'%"{tag_filter}"%')
        
        return query, params

    def list_tasks(self, sort_order: str = "insertion", show_all: bool = False, 
                   overdue_only: bool = False, tag_filter: Optional[str] = None) -> List[dict]:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            query, params = self._build_list_query(show_all, overdue_only, tag_filter)
            
            if sort_order == "priority":
                # Order by priority (high, med, low) then by insertion order
                query += """
                    ORDER BY 
                        CASE priority 
                            WHEN 'high' THEN 1 
                            WHEN 'med' THEN 2 
                            WHEN 'low' THEN 3 
                        END,
                        id
                """
            else:
                # Default insertion order
                query += " ORDER BY id"
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    "id": row[0],
                    "title": row[1],
                    "done": row[2],
                    "archived": row[3],
                    "due": row[4],
                    "priority": row[5],
                    "tags": json.loads(row[6]) if row[6] else []
                }
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()

    def mark_done(self, task_id: int):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET done=1 WHERE id=? AND kind='task'", (task_id,))
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def delete_task(self, task_id: int):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM items WHERE id=? AND kind='task'", (task_id,))
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def archive_done(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived=1 WHERE done=1 AND kind='task'")
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def print_stats(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task'")
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task' AND done=1")
            done = cursor.fetchone()[0]
            
            # Open tasks
            open_tasks = total - done
            
            # Priority counts
            cursor.execute("""
                SELECT priority, COUNT(*) 
                FROM items 
                WHERE kind='task' 
                GROUP BY priority
            """)
            priority_counts = dict(cursor.fetchall())
            
            # Overdue tasks
            cursor.execute("""
                SELECT COUNT(*) 
                FROM items 
                WHERE kind='task' AND done=0 AND due < ?
            """, (self.today,))
            overdue = cursor.fetchone()[0]
            
            print(f"Total: {total}")
            print(f"Done: {done}")
            print(f"Open: {open_tasks}")
            print(f"Overdue: {overdue}")
            
            for priority in ["high", "med", "low"]:
                count = priority_counts.get(priority, 0)
                print(f"Priority {priority}: {count}")
        finally:
            conn.close()

    def backup(self, path: str):
        tmp_path = path + ".tmp"
        try:
            shutil.copy2(self.db_path, tmp_path)
            os.rename(tmp_path, path)
        except Exception:
            # Clean up temp file on failure
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise

    def export_json(self, path: str, show_all: bool = False, overdue_only: bool = False, tag_filter: Optional[str] = None):
        tasks = self.list_tasks(show_all=show_all, overdue_only=overdue_only, tag_filter=tag_filter)
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(tasks, f, indent=2, default=str)
            os.rename(tmp_path, path)
        except Exception:
            # Clean up temp file on failure
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise

    def export_csv(self, path: str, show_all: bool = False, overdue_only: bool = False, tag_filter: Optional[str] = None):
        tasks = self.list_tasks(show_all=show_all, overdue_only=overdue_only, tag_filter=tag_filter)
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, "w", newline="", encoding="utf-8") as f:
                if not tasks:
                    return
                writer = csv.DictWriter(f, fieldnames=tasks[0].keys())
                writer.writeheader()
                for task in tasks:
                    # Convert due date to string if present
                    if task.get("due"):
                        task["due"] = task["due"].strftime("%Y-%m-%d")
                    writer.writerow(task)
            os.rename(tmp_path, path)
        except Exception:
            # Clean up temp file on failure
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise

    def compact(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("VACUUM")
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def search_tasks(self, text: str) -> List[dict]:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Search for tasks with title containing the text (case-insensitive)
            query = """
                SELECT id, title, done, archived, due, priority, tags 
                FROM items 
                WHERE kind='task' AND LOWER(title) LIKE ?
            """
            params = [f"%{text.lower()}%"]
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    "id": row[0],
                    "title": row[1],
                    "done": row[2],
                    "archived": row[3],
                    "due": row[4],
                    "priority": row[5],
                    "tags": json.loads(row[6]) if row[6] else []
                }
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()

    def format_task(self, task: dict, use_color: bool = False) -> str:
        # Determine if we're in a TTY (for color output)
        # Use a more robust approach for detecting TTY
        try:
            is_tty = sys.stdout.isatty()
        except Exception:
            is_tty = False
        
        # Format due date
        due_str = ""
        if task["due"]:
            due_str = f" (due {task['due'].strftime('%Y-%m-%d')})"

        # Format priority
        priority_str = ""
        if task["priority"] != "med":
            priority_str = f" [{task['priority']}]"

        # Format tags
        tags_str = ""
        if task["tags"]:
            tags_str = " " + " ".join(f"@{tag}" for tag in task["tags"])

        # Format status
        status = "✓" if task["done"] else "○"
        
        # Color codes - only use when stdout is a TTY
        red = "\x1b[31m" if is_tty and use_color else ""
        green = "\x1b[32m" if is_tty and use_color else ""
        reset = "\x1b[0m" if is_tty and use_color else ""
        
        # Apply color for overdue or done tasks
        if task["due"] and task["due"] < self.today and not task["done"]:
            status = f"{red}{status}{reset}"
        elif task["done"]:
            status = f"{green}{status}{reset}"

        return f"{status} {task['id']} {task['title']}{due_str}{priority_str}{tags_str}"

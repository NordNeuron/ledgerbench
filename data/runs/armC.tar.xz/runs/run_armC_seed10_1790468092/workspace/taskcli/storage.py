import os
import json
import sqlite3
import shutil
import csv
from datetime import datetime, date

class Task:
    def __init__(self, title, due=None, priority="med", tags=None, done=False, archived=False, id=None):
        self.id = id
        self.title = title
        self.due = due
        self.priority = priority
        self.tags = tags or []
        self.done = done
        self.archived = archived

class TaskStorage:
    def __init__(self, db_path="tasks.db"):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table with kind column - this is the exact schema required
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    due TEXT,
                    priority TEXT,
                    tags TEXT,
                    done BOOLEAN,
                    archived BOOLEAN
                )
            """)
            
            # Create index on id for performance
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_id ON items(id)")
            
            conn.commit()
        finally:
            conn.close()

    def get_next_id(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT MAX(id) FROM items")
            max_id = cursor.fetchone()[0]
            return (max_id or 0) + 1
        finally:
            conn.close()

    def add_task(self, task):
        new_id = self.get_next_id()
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO items (id, kind, title, due, priority, tags, done, archived)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (new_id, "task", task.title, task.due, task.priority, 
                  json.dumps(task.tags), task.done, task.archived))
            conn.commit()
            return new_id
        finally:
            conn.close()

    def list_tasks(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            # Order by id to maintain insertion order - this is critical for ID stability
            cursor.execute("SELECT id, title, due, priority, tags, done, archived FROM items WHERE kind='task' ORDER BY id")
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = Task(
                    id=row[0],
                    title=row[1],
                    due=row[2],
                    priority=row[3],
                    tags=json.loads(row[4]) if row[4] else [],
                    done=bool(row[5]),
                    archived=bool(row[6])
                )
                tasks.append(task)
            return tasks
        finally:
            conn.close()

    def mark_done(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found")
            
            cursor.execute("UPDATE items SET done=1 WHERE id=?", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def delete_task(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found")
            
            cursor.execute("DELETE FROM items WHERE id=?", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def archive_done(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived=1 WHERE kind='task' AND done=1")
            conn.commit()
        finally:
            conn.close()

    def backup(self, path):
        tmp_path = path + ".tmp"
        try:
            # Check if destination directory is writable
            dest_dir = os.path.dirname(path) or "."
            if not os.access(dest_dir, os.W_OK):
                raise OSError(f"Cannot write to directory: {dest_dir}")
            
            shutil.copy2(self.db_path, tmp_path)
            os.replace(tmp_path, path)
        except Exception:
            # Clean up on failure
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise

    def export_json(self, tasks, path):
        data = []
        for task in tasks:
            task_dict = {
                "id": task.id,
                "title": task.title,
                "due": task.due,
                "priority": task.priority,
                "tags": task.tags,
                "done": task.done,
                "archived": task.archived
            }
            data.append(task_dict)
        
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp_path, path)
        except Exception:
            # Clean up on failure
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise

    def export_csv(self, tasks, path):
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["id", "title", "due", "priority", "tags", "done", "archived"])
                for task in tasks:
                    writer.writerow([
                        task.id,
                        task.title,
                        task.due or "",
                        task.priority,
                        ",".join(task.tags) if task.tags else "",
                        int(task.done),
                        int(task.archived)
                    ])
            os.replace(tmp_path, path)
        except Exception:
            # Clean up on failure
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise

    def compact(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            # This is a simplified compaction - in a real system, you'd want to 
            # reclaim space by rebuilding the database or using VACUUM
            cursor.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()

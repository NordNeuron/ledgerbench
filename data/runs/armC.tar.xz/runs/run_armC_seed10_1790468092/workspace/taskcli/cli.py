import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import TaskStorage, Task

def get_config():
    config = {}
    try:
        import tomllib
        config_path = "config.toml"
        if os.path.exists(config_path):
            with open(config_path, "rb") as f:
                config = tomllib.load(f)
    except ImportError:
        # Fallback for Python < 3.11
        try:
            import toml
            config_path = "config.toml"
            if os.path.exists(config_path):
                with open(config_path, "r", encoding="utf-8") as f:
                    config = toml.load(f)
        except ImportError:
            pass
    
    # Handle deprecated TASKCLI_TODAY env var
    if "TASKCLI_TODAY" in os.environ and "today" not in config:
        config["today"] = os.environ["TASKCLI_TODAY"]
    
    return config

def get_today():
    config = get_config()
    if "today" in config:
        try:
            return datetime.strptime(config["today"], "%Y-%m-%d").date()
        except ValueError:
            # If the date is invalid, fall back to today
            pass
    return datetime.now().date()

def format_task(task, today=None, show_all=False, use_color=False):
    if today is None:
        today = get_today()
    
    if not show_all and task.archived:
        return None
    
    due_str = ""
    if task.due:
        due_str = f" (due {task.due})"
    
    status = "✓" if task.done else "○"
    priority_symbol = {"high": "!", "med": ":", "low": "."}.get(task.priority, ":")
    
    # ANSI color codes
    ansi_reset = "\x1b[0m"
    ansi_red = "\x1b[31m"
    ansi_green = "\x1b[32m"
    
    # Only use colors if stdout is a TTY and color flag is set
    if use_color and sys.stdout.isatty():
        if task.due and not task.done:
            try:
                due_date = datetime.strptime(task.due, "%Y-%m-%d").date()
                if due_date < today:
                    status = f"{ansi_red}{status}{ansi_reset}"
            except ValueError:
                pass
        
        if task.done:
            status = f"{ansi_green}{status}{ansi_reset}"
    else:
        # Ensure no ANSI codes in piped output
        status = "✓" if task.done else "○"
    
    return f"[{status}] {priority_symbol} {task.title}{due_str}"

def print_task(task, today=None, show_all=False, use_color=False):
    formatted = format_task(task, today, show_all, use_color)
    if formatted:
        print(formatted)

def list_tasks(args):
    storage = TaskStorage()
    today = get_today()
    
    tasks = storage.list_tasks()
    
    # Filter by tag if specified
    if hasattr(args, 'tag') and args.tag:
        tasks = [t for t in tasks if args.tag in t.tags]
    
    # Sort tasks
    if hasattr(args, 'sort') and args.sort == "priority":
        priority_order = {"high": 0, "med": 1, "low": 2}
        tasks.sort(key=lambda t: (priority_order.get(t.priority, 1), t.id))
    elif hasattr(args, 'sort') and args.sort == "overdue":
        overdue_tasks = [t for t in tasks if t.due and not t.done]
        overdue_tasks.sort(key=lambda t: datetime.strptime(t.due, "%Y-%m-%d").date())
        other_tasks = [t for t in tasks if not (t.due and not t.done)]
        tasks = overdue_tasks + other_tasks
    
    # Filter by overdue
    if hasattr(args, 'overdue') and args.overdue:
        tasks = [t for t in tasks if t.due and not t.done]
        try:
            tasks.sort(key=lambda t: datetime.strptime(t.due, "%Y-%m-%d").date())
        except ValueError:
            pass
    
    for task in tasks:
        print_task(task, today, getattr(args, 'all', False), getattr(args, 'color', False))

def add_task(args):
    storage = TaskStorage()
    
    # Validate due date if provided
    if args.due:
        try:
            datetime.strptime(args.due, "%Y-%m-%d")
        except ValueError:
            sys.stderr.write(f"Invalid date: {args.due}. Expected format: YYYY-MM-DD\n")
            sys.exit(2)
    
    # Get default priority from config
    config = get_config()
    priority = args.priority or config.get("default_priority", "med")
    
    # Validate priority
    if priority not in ["high", "med", "low"]:
        sys.stderr.write(f"Invalid priority: {priority}. Expected: high, med, or low\n")
        sys.exit(2)
    
    task = Task(
        title=args.title,
        due=args.due,
        priority=priority,
        tags=args.tag or []
    )
    
    new_id = storage.add_task(task)
    print(new_id)

def done_task(args):
    storage = TaskStorage()
    try:
        storage.mark_done(args.id)
        # Silent success - no output
    except ValueError as e:
        sys.stderr.write(f"{str(e)}\n")
        sys.exit(2)

def delete_task(args):
    storage = TaskStorage()
    try:
        storage.delete_task(args.id)
        # Silent success - no output
    except ValueError as e:
        sys.stderr.write(f"{str(e)}\n")
        sys.exit(2)

def stats(args):
    storage = TaskStorage()
    tasks = storage.list_tasks()
    
    total = len(tasks)
    done = sum(1 for t in tasks if t.done)
    open_count = total - done
    
    priority_counts = {"high": 0, "med": 0, "low": 0}
    overdue_count = 0
    today = get_today()
    
    for task in tasks:
        if task.priority in priority_counts:
            priority_counts[task.priority] += 1
        
        if task.due and not task.done:
            try:
                due_date = datetime.strptime(task.due, "%Y-%m-%d").date()
                if due_date < today:
                    overdue_count += 1
            except ValueError:
                pass
    
    print(f"Total: {total}")
    print(f"Done: {done}")
    print(f"Open: {open_count}")
    
    for priority in ["high", "med", "low"]:
        print(f"Priority {priority}: {priority_counts[priority]}")
    
    # Overdue count
    ansi_red = "\x1b[31m"
    ansi_reset = "\x1b[0m"
    overdue_line = f"Overdue: {overdue_count}"
    if overdue_count > 0:
        overdue_line = f"{ansi_red}{overdue_line}{ansi_reset}"
    print(overdue_line)

def archive(args):
    storage = TaskStorage()
    storage.archive_done()

def backup(args):
    storage = TaskStorage()
    try:
        storage.backup(args.path)
    except Exception as e:
        sys.stderr.write(f"Backup failed: {str(e)}\n")
        sys.exit(1)

def export(args):
    storage = TaskStorage()
    tasks = storage.list_tasks()
    
    # Apply same filtering logic as list
    if hasattr(args, 'tag') and args.tag:
        tasks = [t for t in tasks if args.tag in t.tags]
    
    if hasattr(args, 'sort') and args.sort == "priority":
        priority_order = {"high": 0, "med": 1, "low": 2}
        tasks.sort(key=lambda t: (priority_order.get(t.priority, 1), t.id))
    elif hasattr(args, 'sort') and args.sort == "overdue":
        overdue_tasks = [t for t in tasks if t.due and not t.done]
        overdue_tasks.sort(key=lambda t: datetime.strptime(t.due, "%Y-%m-%d").date())
        other_tasks = [t for t in tasks if not (t.due and not t.done)]
        tasks = overdue_tasks + other_tasks
    
    if hasattr(args, 'overdue') and args.overdue:
        tasks = [t for t in tasks if t.due and not t.done]
        try:
            tasks.sort(key=lambda t: datetime.strptime(t.due, "%Y-%m-%d").date())
        except ValueError:
            pass
    
    try:
        if args.format == "csv":
            storage.export_csv(tasks, args.path)
        else:
            storage.export_json(tasks, args.path)
    except Exception as e:
        sys.stderr.write(f"Export failed: {str(e)}\n")
        sys.exit(1)

def compact(args):
    storage = TaskStorage()
    try:
        storage.compact()
    except Exception as e:
        sys.stderr.write(f"Compact failed: {str(e)}\n")
        sys.exit(1)

def search(args):
    storage = TaskStorage()
    tasks = storage.list_tasks()
    
    # Filter tasks by title containing the search text (case-insensitive)
    matching_tasks = [t for t in tasks if args.text.lower() in t.title.lower()]
    
    today = get_today()
    for task in matching_tasks:
        print_task(task, today, show_all=True, use_color=False)

def main():
    parser = argparse.ArgumentParser(description="Minimal command-line task manager")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--due", help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--priority", choices=["high", "med", "low"], help="Priority level")
    add_parser.add_argument("--tag", action="append", help="Add a tag (repeatable)")

    # List command
    list_parser = subparsers.add_parser("list", help="List all tasks")
    list_parser.add_argument("--sort", choices=["priority", "overdue"], default="insertion",
                             help="Sort order")
    list_parser.add_argument("--tag", help="Filter by tag")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks")
    list_parser.add_argument("--color", action="store_true", help="Enable color output")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark a task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show statistics")

    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup the database")
    backup_parser.add_argument("path", help="Backup file path")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export file path")
    export_parser.add_argument("--format", choices=["json", "csv"], default="json",
                               help="Export format")
    export_parser.add_argument("--sort", choices=["priority", "overdue"], default="insertion",
                               help="Sort order")
    export_parser.add_argument("--tag", help="Filter by tag")
    export_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")

    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Reclaim dead space")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Text to search for in task titles")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.stderr.write("AUDIT help\n")
        return 0

    # Emit audit line for every command
    sys.stderr.write(f"AUDIT {args.command}\n")

    try:
        if args.command == "add":
            add_task(args)
        elif args.command == "list":
            list_tasks(args)
        elif args.command == "done":
            done_task(args)
        elif args.command == "delete":
            delete_task(args)
        elif args.command == "stats":
            stats(args)
        elif args.command == "archive":
            archive(args)
        elif args.command == "backup":
            backup(args)
        elif args.command == "export":
            export(args)
        elif args.command == "compact":
            compact(args)
        elif args.command == "search":
            search(args)
    except Exception as e:
        sys.stderr.write(f"Error: {str(e)}\n")
        return 1

    return 0

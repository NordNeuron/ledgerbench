import json
import os
import shutil
import csv
from datetime import date
from typing import List, Optional

class Task:
    def __init__(self, title: str, due: Optional[date] = None, priority: str = "med", tags: List[str] = None, id: int = None):
        self.id = id
        self.title = title
        self.due = due
        self.priority = priority
        self.tags = tags or []
        self.done = False
        self.archived = False

class TaskStorage:
    def __init__(self, filename: str = "tasks.json"):
        self.filename = filename
        self._ensure_file_exists()

    def _ensure_file_exists(self):
        if not os.path.exists(self.filename):
            with open(self.filename, 'w') as f:
                json.dump([], f)

    def load_tasks(self) -> List[Task]:
        try:
            with open(self.filename, 'r') as f:
                data = json.load(f)
            tasks = []
            for item in data:
                task = Task(
                    id=item.get('id'),
                    title=item.get('title'),
                    due=item.get('due'),
                    priority=item.get('priority', 'med'),
                    tags=item.get('tags', [])
                )
                task.done = item.get('done', False)
                task.archived = item.get('archived', False)
                if isinstance(task.due, str):
                    try:
                        task.due = date.fromisoformat(task.due)
                    except ValueError:
                        task.due = None
                tasks.append(task)
            return tasks
        except (json.JSONDecodeError, IOError):
            return []

    def save_tasks(self, tasks: List[Task]):
        data = []
        for task in tasks:
            item = {
                'id': task.id,
                'title': task.title,
                'done': task.done,
                'archived': task.archived,
                'priority': task.priority,
                'tags': task.tags
            }
            if task.due:
                item['due'] = task.due.isoformat()
            else:
                item['due'] = None
            data.append(item)
        
        # Write to temporary file first (atomic write)
        tmp_file = f"{self.filename}.tmp"
        with open(tmp_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        # Rename to actual file
        os.replace(tmp_file, self.filename)

    def add_task(self, task: Task) -> int:
        tasks = self.load_tasks()
        if not tasks:
            new_id = 1
        else:
            new_id = max(t.id for t in tasks) + 1
        task.id = new_id
        tasks.append(task)
        self.save_tasks(tasks)
        return new_id

    def mark_done(self, task_id: int):
        tasks = self.load_tasks()
        # Silent success - no output to stdout or stderr
        for task in tasks:
            if task.id == task_id:
                task.done = True
                self.save_tasks(tasks)
                return
        raise ValueError(f"Task with id {task_id} not found")

    def delete_task(self, task_id: int):
        tasks = self.load_tasks()
        # Silent success - no output to stdout or stderr
        for i, task in enumerate(tasks):
            if task.id == task_id:
                del tasks[i]
                self.save_tasks(tasks)
                return
        raise ValueError(f"Task with id {task_id} not found")

    def archive_done(self):
        tasks = self.load_tasks()
        for task in tasks:
            if task.done and not task.archived:
                task.archived = True
        self.save_tasks(tasks)

    def compact(self):
        tasks = self.load_tasks()
        # Filter out archived tasks (they are effectively deleted)
        filtered_tasks = [t for t in tasks if not t.archived]
        # Reassign IDs to be sequential
        new_id = 1
        for task in filtered_tasks:
            task.id = new_id
            new_id += 1
        self.save_tasks(filtered_tasks)

    def backup(self, path: str):
        tmp_file = f"{path}.tmp"
        try:
            shutil.copy2(self.filename, tmp_file)
            os.replace(tmp_file, path)
        except Exception:
            # Clean up temp file if copy failed
            try:
                os.remove(tmp_file)
            except OSError:
                pass
            raise

    def export(self, path: str):
        tasks = self.load_tasks()
        with open(path, 'w') as f:
            for task in tasks:
                line = f"{task.id},{task.title},{task.done},{task.priority}"
                if task.due:
                    line += f",{task.due.isoformat()}"
                else:
                    line += ",None"
                if task.tags:
                    line += f",{'|'.join(task.tags)}"
                else:
                    line += ",None"
                f.write(line + '\n')

    def export_csv(self, path: str):
        tasks = self.load_tasks()
        with open(path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['ID', 'Title', 'Done', 'Priority', 'Due', 'Tags'])
            for task in tasks:
                due_str = task.due.isoformat() if task.due else ''
                tags_str = '|'.join(task.tags) if task.tags else ''
                writer.writerow([task.id, task.title, task.done, task.priority, due_str, tags_str])

import argparse
import os
import sys
import json
import datetime
import re
from .storage import TaskStorage, Task
from . import __version__

def parse_date(date_str):
    try:
        return datetime.datetime.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        raise argparse.ArgumentTypeError(f"Invalid date format: {date_str}. Expected YYYY-MM-DD.")

def get_config():
    config = {}
    config_file = "config.toml"
    if os.path.exists(config_file):
        try:
            import tomli
            with open(config_file, "rb") as f:
                config = tomli.load(f)
        except ImportError:
            # Fallback to a basic approach or raise an error
            pass
        except Exception:
            pass  # Ignore invalid config files
    
    # If no config.toml, check deprecated env var
    if not config and "TASKCLI_TODAY" in os.environ:
        try:
            config["today"] = os.environ["TASKCLI_TODAY"]
        except Exception:
            pass
    
    return config

def get_today():
    config = get_config()
    if "today" in config:
        try:
            return datetime.datetime.strptime(config["today"], "%Y-%m-%d").date()
        except ValueError:
            pass
    return datetime.date.today()

def is_overdue(task, today):
    if task.due and not task.done:
        return task.due < today
    return False

def format_task(task, today, color=False, is_tty=True):
    due_str = ""
    if task.due:
        due_str = f" (due {task.due})"

    status_char = "✓" if task.done else "○"
    priority_symbol = {"high": "▲", "med": "◆", "low": "▼"}
    priority_str = priority_symbol.get(task.priority, "◆")

    line = f"{task.id} {status_char} {priority_str} {task.title}{due_str}"

    if color and is_tty:
        if task.done:
            line = f"\033[32m{line}\033[0m"  # Green
        elif is_overdue(task, today):
            line = f"\033[31m{line}\033[0m"  # Red

    return line

def query_tasks(storage, show_all=False, sort_by=None, tag_filter=None, overdue_only=False):
    """Shared task query function used by both list and export."""
    tasks = storage.load_tasks()
    
    if not show_all:
        tasks = [t for t in tasks if not t.archived]
        
    if overdue_only:
        tasks = [t for t in tasks if is_overdue(t, get_today())]
        
    if tag_filter:
        tasks = [t for t in tasks if tag_filter in t.tags]

    if sort_by == "priority":
        priority_order = {"high": 0, "med": 1, "low": 2}
        tasks.sort(key=lambda t: (priority_order.get(t.priority, 1), t.id))
    elif sort_by == "review":
        # Overdue first, then by priority high to low
        def review_sort_key(task):
            overdue = is_overdue(task, get_today())
            priority_order = {"high": 0, "med": 1, "low": 2}
            return (not overdue, priority_order.get(task.priority, 1), task.id)
        tasks.sort(key=review_sort_key)
    else:
        # Default: insertion order
        pass

    return tasks

def main():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    parser.add_argument("--version", action="version", version=f"taskcli {__version__}")
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--due", type=parse_date, help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--priority", choices=["high", "med", "low"], default=None, help="Priority level")
    add_parser.add_argument("--tag", action="append", help="Add a tag (can be used multiple times)")

    # List command
    list_parser = subparsers.add_parser("list", help="List tasks")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks")
    list_parser.add_argument("--sort", choices=["priority", "review"], help="Sort order")
    list_parser.add_argument("--color", action="store_true", help="Enable colored output")
    list_parser.add_argument("--tag", help="Filter by tag")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark a task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")

    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show statistics")

    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Reclaim dead space from deleted tasks")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup the task database")
    backup_parser.add_argument("path", help="Backup file path")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export file path")
    export_parser.add_argument("--format", choices=["csv"], default=None, help="Export format")
    export_parser.add_argument("--sort", choices=["priority", "review"], help="Sort order")
    export_parser.add_argument("--tag", help="Filter by tag")
    export_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search for tasks by title")
    search_parser.add_argument("text", help="Text to search for in task titles")

    args = parser.parse_args()

    today = get_today()
    
    try:
        storage = TaskStorage()
        
        if args.command == "add":
            priority = args.priority
            if not priority and "default_priority" in get_config():
                priority = get_config()["default_priority"]
                
            task = Task(
                title=args.title,
                due=args.due,
                priority=priority or "med",
                tags=args.tag or []
            )
            new_id = storage.add_task(task)
            print(new_id)
            
        elif args.command == "list":
            tasks = query_tasks(storage, show_all=args.all, sort_by=args.sort, tag_filter=args.tag, overdue_only=args.overdue)
            is_tty = sys.stdout.isatty()
            for task in tasks:
                print(format_task(task, today, color=args.color, is_tty=is_tty))
            
        elif args.command == "done":
            try:
                storage.mark_done(args.id)
            except ValueError as e:
                sys.stderr.write(f"{str(e)}\n")
                return 2
            
        elif args.command == "delete":
            try:
                storage.delete_task(args.id)
            except ValueError as e:
                sys.stderr.write(f"{str(e)}\n")
                return 2
            
        elif args.command == "archive":
            storage.archive_done()
            
        elif args.command == "stats":
            tasks = storage.load_tasks()
            total = len(tasks)
            done = sum(1 for t in tasks if t.done)
            open_tasks = total - done
            priority_counts = {"high": 0, "med": 0, "low": 0}
            overdue_count = 0
            
            for task in tasks:
                if not task.archived:
                    priority_counts[task.priority] += 1
                    if is_overdue(task, today):
                        overdue_count += 1

            print(f"Total: {total}")
            print(f"Done: {done}")
            print(f"Open: {open_tasks}")
            print(f"Overdue: {overdue_count}")
            for priority, count in priority_counts.items():
                print(f"Priority {priority}: {count}")
                
        elif args.command == "compact":
            storage.compact()
            
        elif args.command == "backup":
            try:
                storage.backup(args.path)
            except Exception as e:
                sys.stderr.write(f"{str(e)}\n")
                return 1
            
        elif args.command == "export":
            tasks = query_tasks(storage, show_all=True, sort_by=args.sort, tag_filter=args.tag, overdue_only=args.overdue)
            if args.format == "csv":
                storage.export_csv(args.path)
            else:
                # Default export format
                storage.export(args.path)
                
        elif args.command == "search":
            tasks = storage.load_tasks()
            search_text = args.text.lower()
            matching_tasks = [t for t in tasks if search_text in t.title.lower()]
            is_tty = sys.stdout.isatty()
            for task in matching_tasks:
                print(format_task(task, today, color=False, is_tty=is_tty))

        else:
            parser.print_help()
            return 1
            
    except Exception as e:
        sys.stderr.write(f"{str(e)}\n")
        if "invalid date" in str(e).lower() or "invalid" in str(e).lower():
            return 2
        return 1

    finally:
        # Emit audit line to stderr
        sys.stderr.write(f"AUDIT {args.command}\n")

    return 0

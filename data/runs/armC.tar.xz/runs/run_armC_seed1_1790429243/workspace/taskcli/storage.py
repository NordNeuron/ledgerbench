import os
import json
import sqlite3
import shutil
import csv
from datetime import datetime
import sys
from .cli import get_config

class TaskStorage:
    def __init__(self, db_path="tasks.db"):
        self.db_path = db_path
        self.init_db()
        
    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            # Drop old tasks table if it exists (to ensure clean schema)
            conn.execute("DROP TABLE IF EXISTS tasks")
            
            # Create items table if it doesn't exist
            conn.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    due DATE,
                    priority TEXT,
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE,
                    tags TEXT DEFAULT '[]'
                )
            """)
            
            # Create indexes
            conn.execute("CREATE INDEX IF NOT EXISTS idx_items_kind ON items(kind)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_items_done ON items(done)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_items_archived ON items(archived)")
            
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
    
    def get_next_id(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items WHERE kind='task'")
            return cursor.fetchone()[0]
        finally:
            conn.close()
            
    def add_task(self, title, due=None, priority=None, tags=None):
        task_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute(
                "INSERT INTO items (id, kind, title, due, priority, tags) VALUES (?, ?, ?, ?, ?, ?)",
                (task_id, 'task', title, due, priority, json.dumps(tags or []))
            )
            conn.commit()
            return task_id
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
            
    def _build_list_query(self, sort_order="insertion", show_all=False, tag_filter=None, overdue_only=False):
        """Build the base query for listing tasks."""
        where_clauses = ["kind='task'"]
        params = []
        
        if not show_all:
            where_clauses.append("archived=0")
            
        if tag_filter:
            where_clauses.append("tags LIKE ?")
            params.append(f'%"{tag_filter}"%')
            
        if overdue_only:
            config = get_config()
            today_str = config.get('today', datetime.now().strftime('%Y-%m-%d'))
            where_clauses.append("due < ? AND done=0")
            params.append(today_str)
        
        where_sql = " AND ".join(where_clauses)
        
        if sort_order == "priority":
            # Order by priority (high, med, low) then by insertion order
            query = f"""
                SELECT * FROM items 
                WHERE {where_sql} 
                ORDER BY 
                    CASE WHEN priority='high' THEN 1 
                         WHEN priority='med' THEN 2 
                         WHEN priority='low' THEN 3 
                         ELSE 4 END,
                    id
            """
        else:
            # Default insertion order (by id)
            query = f"SELECT * FROM items WHERE {where_sql} ORDER BY id"
            
        return query, params
    
    def list_tasks(self, sort_order="insertion", show_all=False, tag_filter=None, overdue_only=False):
        conn = sqlite3.connect(self.db_path)
        try:
            query, params = self._build_list_query(sort_order, show_all, tag_filter, overdue_only)
            cursor = conn.execute(query, params)
            return cursor.fetchall()
        finally:
            conn.close()
            
    def mark_done(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            # Check if task exists
            cursor = conn.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found")
                
            conn.execute("UPDATE items SET done=1 WHERE id=?", (task_id,))
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
            
    def delete_task(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            # Check if task exists
            cursor = conn.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found")
                
            conn.execute("DELETE FROM items WHERE id=?", (task_id,))
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
            
    def get_stats(self):
        conn = sqlite3.connect(self.db_path)
        try:
            # Total tasks
            total = conn.execute("SELECT COUNT(*) FROM items WHERE kind='task'").fetchone()[0]
            
            # Done tasks
            done = conn.execute("SELECT COUNT(*) FROM items WHERE kind='task' AND done=1").fetchone()[0]
            
            # Open tasks
            open_tasks = conn.execute("SELECT COUNT(*) FROM items WHERE kind='task' AND done=0").fetchone()[0]
            
            # Priority counts
            priority_high = conn.execute("SELECT COUNT(*) FROM items WHERE kind='task' AND priority='high'").fetchone()[0]
            priority_med = conn.execute("SELECT COUNT(*) FROM items WHERE kind='task' AND priority='med'").fetchone()[0]
            priority_low = conn.execute("SELECT COUNT(*) FROM items WHERE kind='task' AND priority='low'").fetchone()[0]
            
            # Overdue tasks
            config = get_config()
            today_str = config.get('today', datetime.now().strftime('%Y-%m-%d'))
            overdue = conn.execute(
                "SELECT COUNT(*) FROM items WHERE kind='task' AND due < ? AND done=0",
                (today_str,)
            ).fetchone()[0]
            
            return {
                'total': total,
                'done': done,
                'open': open_tasks,
                'priority_high': priority_high,
                'priority_med': priority_med,
                'priority_low': priority_low,
                'overdue': overdue
            }
        finally:
            conn.close()
            
    def archive_done(self):
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("UPDATE items SET archived=1 WHERE kind='task' AND done=1")
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
            
    def backup(self, path):
        # Atomic write: create temp file then rename
        tmp_path = path + ".tmp"
        shutil.copy2(self.db_path, tmp_path)
        os.rename(tmp_path, path)
        
    def export_json(self, path, show_all=False):
        """Export tasks as JSON using the same query logic as list."""
        conn = sqlite3.connect(self.db_path)
        try:
            # Build the same query used for listing
            query, params = self._build_list_query(show_all=show_all)
            cursor = conn.execute(query, params)
            tasks = cursor.fetchall()
            
            # Format data for export
            data = []
            for task in tasks:
                task_dict = {
                    'id': task[0],
                    'kind': task[1],
                    'title': task[2],
                    'due': task[3],
                    'priority': task[4],
                    'done': task[5],
                    'archived': task[6],
                    'tags': json.loads(task[7]) if task[7] else []
                }
                data.append(task_dict)
            
            # Atomic write
            tmp_path = path + ".tmp"
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
            os.rename(tmp_path, path)
        finally:
            conn.close()
        
    def export_csv(self, path, show_all=False):
        """Export tasks as CSV using the same query logic as list."""
        conn = sqlite3.connect(self.db_path)
        try:
            # Build the same query used for listing
            query, params = self._build_list_query(show_all=show_all)
            cursor = conn.execute(query, params)
            tasks = cursor.fetchall()
            
            fieldnames = ['id', 'title', 'due', 'priority', 'done', 'archived', 'tags']
            
            # Atomic write
            tmp_path = path + ".tmp"
            with open(tmp_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                
                for task in tasks:
                    row = {
                        'id': task[0],
                        'title': task[2],
                        'due': task[3],
                        'priority': task[4],
                        'done': task[5],
                        'archived': task[6],
                        'tags': json.dumps(json.loads(task[7]) if task[7] else [])
                    }
                    writer.writerow(row)
                    
            os.rename(tmp_path, path)
        finally:
            conn.close()
        
    def compact(self):
        conn = sqlite3.connect(self.db_path)
        try:
            # VACUUM to reclaim space
            conn.execute("VACUUM")
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
            
    def search_tasks(self, text):
        conn = sqlite3.connect(self.db_path)
        try:
            # Search in title (case-insensitive) - using LOWER function for case insensitivity
            cursor = conn.execute(
                "SELECT * FROM items WHERE kind='task' AND LOWER(title) LIKE LOWER(?) ORDER BY id",
                (f'%{text}%',)
            )
            return cursor.fetchall()
        finally:
            conn.close()
            
    def format_task(self, task, use_color=False):
        # Check if stdout is a TTY to determine color usage
        is_tty = os.isatty(sys.stdout.fileno()) if hasattr(sys.stdout, 'fileno') else False
        
        # Extract task fields
        task_id = task[0]
        title = task[2]
        due = task[3]
        priority = task[4]
        done = task[5]
        
        # Determine status and color
        status = "✓" if done else "○"
        color_code = ""
        reset_code = ""
        
        if use_color and is_tty:
            config = get_config()
            today_str = config.get('today', datetime.now().strftime('%Y-%m-%d'))
            
            # Check if overdue
            if due and not done:
                try:
                    due_date = datetime.strptime(due, "%Y-%m-%d")
                    today = datetime.strptime(today_str, "%Y-%m-%d")
                    if due_date < today:
                        color_code = "\x1b[31m"  # Red for overdue
                        reset_code = "\x1b[0m"
                except ValueError:
                    pass  # Invalid date format - ignore
                    
            # Done tasks in green
            elif done:
                color_code = "\x1b[32m"  # Green for done
                reset_code = "\x1b[0m"
                
        # Format the line
        if priority == "high":
            priority_str = "H"
        elif priority == "med":
            priority_str = "M"
        elif priority == "low":
            priority_str = "L"
        else:
            priority_str = "-"
            
        due_str = f" {due}" if due else ""
        status_str = f"{color_code}{status}{reset_code}"
        
        return f"[{task_id}] {status_str} [{priority_str}] {title}{due_str}"

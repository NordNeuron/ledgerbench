import argparse
import os
import sys
import json
import re
from datetime import datetime, date
from .storage import Storage, Task
from . import __version__

def get_config():
    config = {}
    try:
        with open("config.toml", "r", encoding="utf-8") as f:
            import tomli
            config = tomli.loads(f.read())
    except (FileNotFoundError, ImportError):
        # Fall back to environment variable if config file not found or toml not available
        try:
            today = os.environ.get("TASKCLI_TODAY")
            if today:
                config["today"] = today
        except Exception:
            pass
    return config

def parse_date(date_str):
    try:
        return datetime.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        raise argparse.ArgumentTypeError(f"Invalid date format: {date_str}. Expected YYYY-MM-DD.")

def is_valid_priority(priority):
    return priority in ["high", "med", "low"]

def is_valid_tag(tag):
    # Tags can be any non-empty string without spaces
    return isinstance(tag, str) and tag.strip() != ""

def parse_args():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--due", help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--priority", choices=["high", "med", "low"], default=None, help="Priority level")
    add_parser.add_argument("--tag", action="append", help="Add a tag (repeatable)")
    
    # List command
    list_parser = subparsers.add_parser("list", help="List tasks")
    list_parser.add_argument("--sort", choices=["priority", "insertion"], default="insertion", help="Sort order")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")
    list_parser.add_argument("--tag", help="Filter by tag")
    list_parser.add_argument("--color", action="store_true", help="Enable color output")
    
    # Done command
    done_parser = subparsers.add_parser("done", help="Mark a task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show statistics")

    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup the database")
    backup_parser.add_argument("path", help="Backup file path")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export file path")
    export_parser.add_argument("--format", choices=["json", "csv"], default="json", help="Export format")

    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Compact the database")

    # Edit command (not implemented in this task)
    edit_parser = subparsers.add_parser("edit", help="Edit a task")
    edit_parser.add_argument("id", type=int, help="Task ID")
    edit_parser.add_argument("--title", help="New title")
    edit_parser.add_argument("--due", help="New due date")
    edit_parser.add_argument("--priority", choices=["high", "med", "low"], help="New priority")
    edit_parser.add_argument("--tag", action="append", help="Add a tag (repeatable)")
    edit_parser.add_argument("--untag", action="append", help="Remove a tag (repeatable)")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Text to search for in titles")

    return parser.parse_args()

def print_task(task, color=False):
    if task.done:
        status = "✓"
        if color:
            status = "\x1b[32m✓\x1b[0m"  # Green
    else:
        status = "○"
    
    due_str = ""
    if task.due:
        due_str = f" (due {task.due})"
        
    title = task.title
    
    # Check if task is overdue and color should be applied
    today = date.today()
    if color and task.due and task.due < today and not task.done:
        title = f"\x1b[31m{title}\x1b[0m"  # Red
        
    print(f"{task.id} {status} {title}{due_str}")

def main():
    args = parse_args()
    
    # Emit audit line to stderr
    if args.command is None:
        # If no command specified, show help and exit with code 0
        parser = parse_args()
        parser.print_help()
        return 0
    else:
        sys.stderr.write(f"AUDIT {args.command}\n")
    
    config = get_config()
    
    try:
        storage = Storage(config=config)
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1

    if args.command == "add":
        due_date = None
        if args.due:
            try:
                due_date = parse_date(args.due)
            except argparse.ArgumentTypeError as e:
                sys.stderr.write(f"Error: {e}\n")
                return 2
        
        priority = args.priority
        if not priority and "default_priority" in config:
            priority = config["default_priority"]
        
        task = Task(
            title=args.title,
            due=due_date,
            priority=priority or "med",
            tags=args.tag or []
        )
        try:
            new_id = storage.add_task(task)
            print(new_id)
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            return 1
            
    elif args.command == "list":
        tasks = storage.get_tasks(sort_by=args.sort, show_all=args.all, 
                                   overdue_only=args.overdue, tag_filter=args.tag)
        for task in tasks:
            print_task(task, color=args.color and sys.stdout.isatty())
            
    elif args.command == "done":
        try:
            storage.mark_done(args.id)
            # Silent success - no output
        except ValueError as e:
            sys.stderr.write(f"Error: {e}\n")
            return 2
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            return 1
            
    elif args.command == "delete":
        try:
            storage.delete_task(args.id)
            # Silent success - no output
        except ValueError as e:
            sys.stderr.write(f"Error: {e}\n")
            return 2
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            return 1
            
    elif args.command == "stats":
        stats = storage.get_stats()
        print(f"Total: {stats['total']}")
        print(f"Done: {stats['done']}")
        print(f"Open: {stats['open']}")
        if stats['overdue'] > 0:
            print(f"\x1b[31mOverdue: {stats['overdue']}\x1b[0m")
        else:
            print(f"Overdue: {stats['overdue']}")
        print("Priority high:", stats["priority"]["high"])
        print("Priority med:", stats["priority"]["med"])
        print("Priority low:", stats["priority"]["low"])
        
    elif args.command == "archive":
        try:
            storage.archive_done()
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            return 1
            
    elif args.command == "backup":
        try:
            storage.backup(args.path)
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            return 1
            
    elif args.command == "export":
        # For export, we want all tasks (not filtered by archived status)
        if args.format == "csv":
            storage.export_csv(args.path)
        else:
            storage.export_json(args.path)
            
    elif args.command == "compact":
        try:
            storage.compact()
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            return 1
            
    elif args.command == "search":
        tasks = storage.search_tasks(args.text)
        for task in tasks:
            print_task(task, color=args.color and sys.stdout.isatty())
            
    else:
        # This shouldn't happen due to the parser setup
        parser = parse_args()
        parser.print_help()
        return 0
        
    return 0

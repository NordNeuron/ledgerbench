import json
import os
import shutil
import csv
from datetime import datetime, date
from typing import List, Optional
import re

class Task:
    def __init__(self, title: str, due: Optional[date] = None, priority: str = "med", tags: List[str] = None, done: bool = False, archived: bool = False):
        self.id = None  # Will be set when added to storage
        self.title = title
        self.due = due
        self.priority = priority
        self.tags = tags or []
        self.done = done
        self.archived = archived
        
    @property
    def overdue(self) -> bool:
        if not self.due or self.done:
            return False
        # This will be set properly in the main code
        return False

class Storage:
    def __init__(self, config: dict = None):
        self.config = config or {}
        self.filename = "tasks.json"
        self.tasks = []
        self.load()
        
    def load(self):
        if not os.path.exists(self.filename):
            self.tasks = []
            return
            
        try:
            with open(self.filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
            self.tasks = []
            for item in data:
                task = Task(
                    title=item['title'],
                    due=self._parse_date(item.get('due')),
                    priority=item.get('priority', 'med'),
                    tags=item.get('tags', []),
                    done=item.get('done', False),
                    archived=item.get('archived', False)
                )
                task.id = item['id']
                self.tasks.append(task)
        except Exception as e:
            raise Exception(f"Failed to load tasks: {e}")
            
    def save(self):
        data = []
        for task in self.tasks:
            item = {
                'id': task.id,
                'title': task.title,
                'due': task.due.isoformat() if task.due else None,
                'priority': task.priority,
                'tags': task.tags,
                'done': task.done,
                'archived': task.archived
            }
            data.append(item)
            
        # Write to temporary file first
        tmp_path = self.filename + ".tmp"
        try:
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
            # Atomic rename
            os.replace(tmp_path, self.filename)
        except Exception as e:
            # Clean up temp file on failure
            try:
                os.remove(tmp_path)
            except:
                pass
            raise Exception(f"Failed to save tasks: {e}")
            
    def get_next_id(self) -> int:
        if not self.tasks:
            return 1
        return max(task.id for task in self.tasks) + 1
        
    def add_task(self, task: Task) -> int:
        task.id = self.get_next_id()
        self.tasks.append(task)
        self.save()
        return task.id
        
    def get_task_by_id(self, task_id: int) -> Optional[Task]:
        for task in self.tasks:
            if task.id == task_id:
                return task
        return None
        
    def _apply_filters(self, tasks: List[Task], show_all: bool = False, 
                       overdue_only: bool = False, tag_filter: str = None) -> List[Task]:
        """Apply common filters to a list of tasks"""
        # Filter tasks
        filtered_tasks = [t for t in tasks if not t.archived or show_all]
        
        # Apply tag filter if specified
        if tag_filter:
            filtered_tasks = [t for t in filtered_tasks if tag_filter in t.tags]
            
        # Apply overdue filter if specified
        if overdue_only:
            today = self._get_today()
            filtered_tasks = [t for t in filtered_tasks if t.due and not t.done and t.due < today]
            
        return filtered_tasks
        
    def _sort_tasks(self, tasks: List[Task], sort_by: str = "insertion") -> List[Task]:
        """Sort tasks according to specified criteria"""
        if sort_by == "priority":
            priority_order = {"high": 0, "med": 1, "low": 2}
            tasks.sort(key=lambda t: (priority_order.get(t.priority, 1), t.id))
        else:
            # insertion order
            tasks.sort(key=lambda t: t.id)
        return tasks
        
    def get_tasks(self, sort_by: str = "insertion", show_all: bool = False, 
                  overdue_only: bool = False, tag_filter: str = None) -> List[Task]:
        """Get tasks with all filters and sorting applied"""
        # Start with all tasks
        tasks = self.tasks[:]
        
        # Apply filters
        filtered_tasks = self._apply_filters(tasks, show_all, overdue_only, tag_filter)
        
        # Sort tasks
        sorted_tasks = self._sort_tasks(filtered_tasks, sort_by)
        
        return sorted_tasks
        
    def mark_done(self, task_id: int) -> None:
        task = self.get_task_by_id(task_id)
        if not task:
            raise ValueError(f"No task with id {task_id}")
        task.done = True
        self.save()
        
    def delete_task(self, task_id: int) -> None:
        task = self.get_task_by_id(task_id)
        if not task:
            raise ValueError(f"No task with id {task_id}")
        self.tasks.remove(task)
        self.save()
        
    def get_stats(self) -> dict:
        total = len(self.tasks)
        done = sum(1 for t in self.tasks if t.done)
        open_tasks = total - done
        today = self._get_today()
        overdue = sum(1 for t in self.tasks if t.due and not t.done and t.due < today)
        priority_counts = {"high": 0, "med": 0, "low": 0}
        for task in self.tasks:
            priority_counts[task.priority] += 1
            
        return {
            "total": total,
            "done": done,
            "open": open_tasks,
            "overdue": overdue,
            "priority": priority_counts
        }
        
    def archive_done(self) -> None:
        for task in self.tasks:
            if task.done and not task.archived:
                task.archived = True
        self.save()
        
    def backup(self, path: str) -> None:
        # Create a temporary file
        tmp_path = path + ".tmp"
        try:
            shutil.copy2(self.filename, tmp_path)
            os.replace(tmp_path, path)
        except Exception as e:
            try:
                os.remove(tmp_path)
            except:
                pass
            raise Exception(f"Failed to backup: {e}")
            
    def export_json(self, path: str) -> None:
        # Write to temporary file first
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump([{
                    'id': t.id,
                    'title': t.title,
                    'due': t.due.isoformat() if t.due else None,
                    'priority': t.priority,
                    'tags': t.tags,
                    'done': t.done,
                    'archived': t.archived
                } for t in self.tasks], f, indent=2)
            # Atomic rename
            os.replace(tmp_path, path)
        except Exception as e:
            try:
                os.remove(tmp_path)
            except:
                pass
            raise Exception(f"Failed to export: {e}")
            
    def export_csv(self, path: str) -> None:
        # Write to temporary file first
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                # Header row
                writer.writerow(['id', 'title', 'due', 'priority', 'tags', 'done', 'archived'])
                for task in self.tasks:
                    writer.writerow([
                        task.id,
                        task.title,
                        task.due.isoformat() if task.due else '',
                        task.priority,
                        ','.join(task.tags),
                        str(task.done),
                        str(task.archived)
                    ])
            # Atomic rename
            os.replace(tmp_path, path)
        except Exception as e:
            try:
                os.remove(tmp_path)
            except:
                pass
            raise Exception(f"Failed to export: {e}")
            
    def compact(self) -> None:
        # For this simple implementation, compact is a no-op since we don't have deleted rows
        # In a more complex system with deletion of tasks, this would reclaim space
        pass
        
    def search_tasks(self, text: str) -> List[Task]:
        results = []
        for task in self.tasks:
            if text.lower() in task.title.lower():
                results.append(task)
        # Return results sorted by insertion order (same as list command)
        results.sort(key=lambda t: t.id)
        return results
        
    def _get_today(self) -> date:
        """Get today's date from config or system"""
        # Check config.toml first - this is the key fix for T20
        if "today" in self.config and self.config["today"]:
            try:
                return datetime.strptime(self.config["today"], "%Y-%m-%d").date()
            except ValueError:
                pass
        # Fall back to environment variable only if config doesn't have today
        today = os.environ.get("TASKCLI_TODAY")
        if today:
            try:
                return datetime.strptime(today, "%Y-%m-%d").date()
            except ValueError:
                pass
        return date.today()
        
    def _parse_date(self, date_str):
        """Parse a date string into a date object"""
        if not date_str:
            return None
        try:
            return datetime.strptime(date_str, "%Y-%m-%d").date()
        except ValueError:
            return None

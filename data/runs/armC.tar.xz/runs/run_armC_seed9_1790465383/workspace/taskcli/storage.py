import os
import json
import sqlite3
import shutil
import csv
from datetime import date
from typing import List

class Task:
    def __init__(self, title: str, due=None, priority: str = "med", done: bool = False, tags: List[str] = None):
        self.title = title
        self.due = due
        self.priority = priority
        self.done = done
        self.tags = tags or []

class TaskStorage:
    def __init__(self, db_path="tasks.db"):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table if it doesn't exist
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    due DATE,
                    priority TEXT DEFAULT 'med',
                    done BOOLEAN DEFAULT FALSE,
                    tags TEXT DEFAULT '[]'
                )
            """)
            
            conn.commit()
        finally:
            conn.close()

    def get_next_id(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT MAX(id) FROM items")
            max_id = cursor.fetchone()[0]
            return (max_id or 0) + 1
        finally:
            conn.close()

    def add_task(self, task: Task):
        new_id = self.get_next_id()
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO items (id, kind, title, due, priority, done, tags)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (new_id, "task", task.title, task.due, task.priority, task.done, json.dumps(task.tags)))
            conn.commit()
            return new_id
        finally:
            conn.close()

    def _get_tasks_query(self, include_archived=False, overdue_only=False, tag_filter=None):
        """Internal method to get tasks with consistent query logic"""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Build base query
            query = """
                SELECT id, title, due, priority, done, tags 
                FROM items 
                WHERE kind = 'task'
            """
            params = []
            
            if not include_archived:
                # Filter out archived tasks (which are done)
                query += " AND done = 0"
                
            if overdue_only:
                query += " AND due < ? AND done = 0"
                params.append(str(date.today()))
                
            if tag_filter:
                query += " AND tags LIKE ?"
                params.append(f'%"{tag_filter}"%')
            
            query += " ORDER BY id"
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = Task(
                    title=row[1],
                    due=row[2] if row[2] else None,
                    priority=row[3],
                    done=bool(row[4]),
                    tags=json.loads(row[5]) if row[5] else []
                )
                task.id = row[0]
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()

    def list_tasks(self, include_archived=False, overdue_only=False, tag_filter=None):
        """List tasks with consistent filtering logic"""
        return self._get_tasks_query(include_archived, overdue_only, tag_filter)

    def mark_done(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"No task found with ID {task_id}")
            
            cursor.execute("UPDATE items SET done = 1 WHERE id = ?", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def delete_task(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"No task found with ID {task_id}")
            
            cursor.execute("DELETE FROM items WHERE id = ?", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def archive_done(self):
        # This is a no-op since we filter out done tasks in list_tasks
        pass

    def backup(self, path):
        tmp_path = path + ".tmp"
        try:
            shutil.copy2(self.db_path, tmp_path)
            os.rename(tmp_path, path)
        except Exception as e:
            # Clean up temp file if something went wrong
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise e

    def export_json(self, path):
        tasks = self.list_tasks(include_archived=True)  # Export includes all tasks including archived
        data = []
        for task in tasks:
            item = {
                "id": task.id,
                "title": task.title,
                "due": str(task.due) if task.due else None,
                "priority": task.priority,
                "done": task.done,
                "tags": task.tags
            }
            data.append(item)
        
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
            os.rename(tmp_path, path)
        except Exception as e:
            # Clean up temp file if something went wrong
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise e

    def export_csv(self, path):
        tasks = self.list_tasks(include_archived=True)  # Export includes all tasks including archived
        
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(['id', 'title', 'due', 'priority', 'done', 'tags'])
                for task in tasks:
                    writer.writerow([
                        task.id,
                        task.title,
                        str(task.due) if task.due else '',
                        task.priority,
                        '1' if task.done else '0',
                        ','.join(task.tags)
                    ])
            os.rename(tmp_path, path)
        except Exception as e:
            # Clean up temp file if something went wrong
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise e

    def get_stats(self, today):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task'")
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND done = 1")
            done = cursor.fetchone()[0]
            
            # Open tasks
            open_count = total - done
            
            # Priority counts
            priority_counts = {}
            for prio in ["high", "med", "low"]:
                cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND priority = ? AND done = 0", (prio,))
                count = cursor.fetchone()[0]
                if count > 0:
                    priority_counts[prio] = count
            
            # Overdue tasks
            cursor.execute("""
                SELECT COUNT(*) FROM items 
                WHERE kind = 'task' AND due < ? AND done = 0
            """, (str(today),))
            overdue_count = cursor.fetchone()[0]
            
            return total, done, open_count, priority_counts, overdue_count
        finally:
            conn.close()

    def compact(self):
        # This is a no-op for SQLite as it automatically handles compaction
        pass

    def search_tasks(self, text: str):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, title, due, priority, done, tags 
                FROM items 
                WHERE kind = 'task' AND LOWER(title) LIKE ?
                ORDER BY id
            """, (f"%{text.lower()}%",))
            
            rows = cursor.fetchall()
            tasks = []
            for row in rows:
                task = Task(
                    title=row[1],
                    due=row[2] if row[2] else None,
                    priority=row[3],
                    done=bool(row[4]),
                    tags=json.loads(row[5]) if row[5] else []
                )
                task.id = row[0]
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()

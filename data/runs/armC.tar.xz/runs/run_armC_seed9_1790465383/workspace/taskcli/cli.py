import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import TaskStorage, Task

def get_config():
    config = {}
    try:
        import tomllib
        config_path = "config.toml"
        if os.path.exists(config_path):
            with open(config_path, "rb") as f:
                config = tomllib.load(f)
    except ImportError:
        # Fallback for Python < 3.11
        try:
            import toml
            config_path = "config.toml"
            if os.path.exists(config_path):
                with open(config_path, "r", encoding="utf-8") as f:
                    config = toml.load(f)
        except ImportError:
            pass
    
    # Handle deprecated environment variable
    if "TASKCLI_TODAY" in os.environ and not config.get("today"):
        config["today"] = os.environ["TASKCLI_TODAY"]
    
    return config

def get_today():
    config = get_config()
    today_str = config.get("today")
    if today_str:
        try:
            return datetime.strptime(today_str, "%Y-%m-%d").date()
        except ValueError:
            sys.stderr.write(f"Error: Invalid date format in config.today: {today_str}. Expected YYYY-MM-DD.\n")
            sys.exit(2)
    return datetime.now().date()

def print_task(task, today, color=False):
    status = "✓" if task.done else "○"
    priority_symbol = {"high": "H", "med": "M", "low": "L"}[task.priority]
    due_str = f" (due {task.due})" if task.due else ""
    title = task.title
    line = f"{task.id} {status} [{priority_symbol}] {title}{due_str}"
    
    if color and sys.stdout.isatty():
        # Overdue tasks in red
        if task.due and task.due < today and not task.done:
            line = f"\033[31m{line}\033[0m"
        # Done tasks in green
        elif task.done:
            line = f"\033[32m{line}\033[0m"
    
    print(line)

def list_tasks(args):
    today = get_today()
    storage = TaskStorage()
    
    # Handle tag filtering
    if args.tag:
        tasks = []
        all_tasks = storage.list_tasks(args.all, args.overdue)
        for task in all_tasks:
            if args.tag in task.tags:
                tasks.append(task)
    else:
        tasks = storage.list_tasks(args.all, args.overdue)
    
    if args.sort == "priority":
        # Sort by priority: high, med, low
        priority_order = {"high": 0, "med": 1, "low": 2}
        tasks.sort(key=lambda t: (priority_order.get(t.priority, 3), t.id))
    elif args.sort == "review":
        # Overdue first, then by priority high to low
        priority_order = {"high": 0, "med": 1, "low": 2}
        tasks.sort(key=lambda t: (
            not (t.due and t.due < today and not t.done),  # False (0) for overdue, True (1) for non-overdue
            priority_order.get(t.priority, 3),
            t.id
        ))
    else:
        # Default insertion order
        pass
    
    for task in tasks:
        print_task(task, today, args.color)

def add_task(args):
    today = get_today()
    storage = TaskStorage()
    
    # Validate due date if provided
    due_date = None
    if args.due:
        try:
            due_date = datetime.strptime(args.due, "%Y-%m-%d").date()
        except ValueError:
            sys.stderr.write(f"Error: Invalid date format '{args.due}'. Expected YYYY-MM-DD.\n")
            sys.exit(2)
    
    # Set default priority from config if not provided
    priority = args.priority or get_config().get("default_priority", "med")
    
    # Validate priority
    if priority not in ["high", "med", "low"]:
        sys.stderr.write(f"Error: Invalid priority '{priority}'. Expected 'high', 'med', or 'low'.\n")
        sys.exit(2)
    
    task = Task(
        title=args.title,
        due=due_date,
        priority=priority,
        done=False,
        tags=args.tag or []
    )
    
    new_id = storage.add_task(task)
    print(new_id)

def done_task(args):
    storage = TaskStorage()
    try:
        storage.mark_done(args.id)
    except ValueError as e:
        sys.stderr.write(f"Error: {str(e)}\n")
        sys.exit(2)

def delete_task(args):
    storage = TaskStorage()
    try:
        storage.delete_task(args.id)
    except ValueError as e:
        sys.stderr.write(f"Error: {str(e)}\n")
        sys.exit(2)

def archive_tasks(args):
    storage = TaskStorage()
    storage.archive_done()

def backup(args):
    storage = TaskStorage()
    try:
        storage.backup(args.path)
    except IOError as e:
        sys.stderr.write(f"Error: Failed to write backup to {args.path}: {str(e)}\n")
        sys.exit(1)

def export(args):
    storage = TaskStorage()
    try:
        if args.format == "csv":
            storage.export_csv(args.path)
        else:
            storage.export_json(args.path)
    except IOError as e:
        sys.stderr.write(f"Error: Failed to write export to {args.path}: {str(e)}\n")
        sys.exit(1)

def stats(args):
    today = get_today()
    storage = TaskStorage()
    total, done, open_count, priority_counts, overdue_count = storage.get_stats(today)
    
    print(f"Total: {total}")
    print(f"Done: {done}")
    print(f"Open: {open_count}")
    for prio in ["high", "med", "low"]:
        if prio in priority_counts:
            print(f"Priority {prio}: {priority_counts[prio]}")
    print(f"\033[31mOverdue: {overdue_count}\033[0m")

def compact(args):
    storage = TaskStorage()
    storage.compact()

def search(args):
    today = get_today()
    storage = TaskStorage()
    tasks = storage.search_tasks(args.text)
    
    for task in tasks:
        print_task(task, today, False)

def main():
    parser = argparse.ArgumentParser(description="Minimal command-line task manager")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--due", help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--priority", choices=["high", "med", "low"], help="Priority level")
    add_parser.add_argument("--tag", action="append", help="Tag for the task (repeatable)")

    # List command
    list_parser = subparsers.add_parser("list", help="List tasks")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")
    list_parser.add_argument("--sort", choices=["priority", "review"], help="Sort order")
    list_parser.add_argument("--color", action="store_true", help="Enable colored output")
    list_parser.add_argument("--tag", help="Filter by tag")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark a task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup the database")
    backup_parser.add_argument("path", help="Backup file path")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export file path")
    export_parser.add_argument("--format", choices=["json", "csv"], default="json", help="Export format")

    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show statistics")

    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Reclaim dead space from deleted rows")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Text to search for in task titles")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 0

    # Emit audit line for all commands BEFORE any processing
    # This must be done before any other output or error handling
    try:
        sys.stderr.write(f"AUDIT {args.command}\n")
        sys.stderr.flush()  # Ensure it's written immediately
    except Exception:
        # If we can't write audit, we still proceed with normal operation
        pass
    
    # Execute the command
    try:
        if args.command == "list":
            list_tasks(args)
        elif args.command == "add":
            add_task(args)
        elif args.command == "done":
            done_task(args)
        elif args.command == "delete":
            delete_task(args)
        elif args.command == "archive":
            archive_tasks(args)
        elif args.command == "backup":
            backup(args)
        elif args.command == "export":
            export(args)
        elif args.command == "stats":
            stats(args)
        elif args.command == "compact":
            compact(args)
        elif args.command == "search":
            search(args)
    except Exception as e:
        sys.stderr.write(f"Error: {str(e)}\n")
        return 1

    return 0

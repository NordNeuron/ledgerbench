import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import TaskStorage, Task

def get_config():
    config = {}
    try:
        with open("config.toml", "r", encoding="utf-8") as f:
            import toml
            config = toml.load(f)
    except FileNotFoundError:
        pass
    except Exception:
        # If config file is malformed, ignore it
        pass
    
    # Fallback to environment variable if no config file
    if not config.get("today"):
        today_env = os.environ.get("TASKCLI_TODAY")
        if today_env:
            try:
                datetime.strptime(today_env, "%Y-%m-%d")
                config["today"] = today_env
            except ValueError:
                # Invalid date in env var, ignore it
                pass
    
    return config

def parse_date(date_str):
    try:
        return datetime.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        raise argparse.ArgumentTypeError(f"Invalid date format: {date_str}. Expected YYYY-MM-DD.")

def main():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--due", help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--priority", choices=["high", "med", "low"], default=None, help="Priority level")
    add_parser.add_argument("--tag", action="append", help="Add a tag (repeatable)")

    # List command
    list_parser = subparsers.add_parser("list", help="List all tasks")
    list_parser.add_argument("--sort", choices=["priority", "insertion"], default="insertion", help="Sort order")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks")
    list_parser.add_argument("--tag", help="Filter by tag")
    list_parser.add_argument("--color", action="store_true", help="Enable colored output")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark a task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show statistics")

    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")

    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Reclaim dead space from deleted rows")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Write a full database copy")
    backup_parser.add_argument("path", help="Destination path for backup")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Destination path for export")
    export_parser.add_argument("--format", choices=["csv"], default="json", help="Export format")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Text to search for in task titles")

    args = parser.parse_args()

    config = get_config()
    today_str = config.get("today", datetime.now().strftime("%Y-%m-%d"))
    today = datetime.strptime(today_str, "%Y-%m-%d").date()

    storage = TaskStorage()

    try:
        if args.command == "add":
            due_date = parse_date(args.due) if args.due else None
            priority = args.priority or config.get("default_priority", "med")
            task = Task(
                title=args.title,
                due=due_date,
                priority=priority,
                tags=args.tag or []
            )
            new_id = storage.add_task(task)
            print(new_id)
        elif args.command == "list":
            tasks = storage.list_tasks(args.all, args.tag, args.overdue)
            if args.sort == "priority":
                tasks = sorted(tasks, key=lambda t: (t.priority != "high", t.priority != "med", t.id))
            else:
                # insertion order
                pass

            for task in tasks:
                print(storage.format_task(task, args.color, today))
        elif args.command == "done":
            storage.mark_done(args.id)
        elif args.command == "delete":
            storage.delete_task(args.id)
        elif args.command == "stats":
            storage.print_stats(today)
        elif args.command == "archive":
            storage.archive_done()
        elif args.command == "compact":
            storage.compact()
        elif args.command == "backup":
            storage.backup(args.path)
        elif args.command == "export":
            if args.format == "csv":
                storage.export_csv(args.path)
            else:
                # Default JSON export
                storage.export_json(args.path)
        elif args.command == "search":
            tasks = storage.search_tasks(args.text)
            for task in tasks:
                print(storage.format_task(task, False, today))
        else:
            parser.print_help()
            return 1
    except ValueError as e:
        sys.stderr.write(f"Error: {e}\n")
        return 2
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1
    finally:
        # Emit audit line to stderr
        sys.stderr.write(f"AUDIT {args.command}\n")

    return 0

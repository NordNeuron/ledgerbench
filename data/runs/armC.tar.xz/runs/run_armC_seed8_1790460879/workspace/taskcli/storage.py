import os
import json
import sqlite3
import shutil
import csv
from datetime import date
from typing import List, Optional
import re
import sys

class Task:
    def __init__(self, title: str, due: Optional[date] = None, priority: str = "med", tags: List[str] = None, done: bool = False, archived: bool = False):
        self.id = None
        self.title = title
        self.due = due
        self.priority = priority
        self.tags = tags or []
        self.done = done
        self.archived = archived

class TaskStorage:
    def __init__(self, db_path="tasks.db"):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            # Create items table with kind column
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    due DATE,
                    priority TEXT,
                    tags TEXT,
                    done BOOLEAN,
                    archived BOOLEAN,
                    kind TEXT NOT NULL
                )
            """)
            conn.commit()
        finally:
            conn.close()

    def get_next_id(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items WHERE kind='task'")
            next_id = cursor.fetchone()[0]
            return next_id
        finally:
            conn.close()

    def add_task(self, task: Task):
        task.id = self.get_next_id()
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            tags_str = json.dumps(task.tags) if task.tags else ""
            cursor.execute("""
                INSERT INTO items (id, title, due, priority, tags, done, archived, kind)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (task.id, task.title, task.due, task.priority, tags_str, task.done, task.archived, "task"))
            conn.commit()
            return task.id
        finally:
            conn.close()

    def _get_tasks_query(self, all_tasks=False, tag_filter=None, overdue_only=False):
        """Get the base query and parameters for fetching tasks."""
        query = "SELECT id, title, due, priority, tags, done, archived FROM items WHERE kind='task'"
        params = []

        if not all_tasks:
            query += " AND archived=0"
        
        if tag_filter:
            query += " AND tags LIKE ?"
            params.append(f'%"{tag_filter}"%')
            
        if overdue_only:
            query += " AND due < ? AND done=0"
            params.append(date.today().isoformat())
        
        return query, params

    def list_tasks(self, all_tasks=False, tag_filter=None, overdue_only=False):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            query, params = self._get_tasks_query(all_tasks, tag_filter, overdue_only)
            query += " ORDER BY id"
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = Task(
                    title=row[1],
                    due=row[2],
                    priority=row[3],
                    tags=json.loads(row[4]) if row[4] else [],
                    done=bool(row[5]),
                    archived=bool(row[6])
                )
                task.id = row[0]
                tasks.append(task)
            return tasks
        finally:
            conn.close()

    def mark_done(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET done=1 WHERE id=? AND kind='task'", (task_id,))
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
            conn.commit()
        finally:
            conn.close()

    def delete_task(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM items WHERE id=? AND kind='task'", (task_id,))
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
            conn.commit()
        finally:
            conn.close()

    def print_stats(self, today):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task'")
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task' AND done=1")
            done = cursor.fetchone()[0]
            
            # Open tasks
            open_tasks = total - done
            
            # Priority counts
            cursor.execute("SELECT priority, COUNT(*) FROM items WHERE kind='task' GROUP BY priority")
            priority_counts = dict(cursor.fetchall())
            
            # Overdue tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task' AND due < ? AND done=0", (today.isoformat(),))
            overdue = cursor.fetchone()[0]
            
            print(f"Total: {total}")
            print(f"Done: {done}")
            print(f"Open: {open_tasks}")
            print(f"Overdue: {overdue}")
            print(f"Priority high: {priority_counts.get('high', 0)}")
            print(f"Priority med: {priority_counts.get('med', 0)}")
            print(f"Priority low: {priority_counts.get('low', 0)}")
        finally:
            conn.close()

    def archive_done(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived=1 WHERE done=1 AND kind='task'")
            conn.commit()
        finally:
            conn.close()

    def compact(self):
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()

    def backup(self, path):
        tmp_path = path + ".tmp"
        try:
            shutil.copy2(self.db_path, tmp_path)
            os.replace(tmp_path, path)
        except Exception as e:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise e

    def export_csv(self, path):
        tasks = self.list_tasks()
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["id", "title", "due", "priority", "tags", "done", "archived"])
            for task in tasks:
                writer.writerow([
                    task.id,
                    task.title,
                    task.due.isoformat() if task.due else "",
                    task.priority,
                    json.dumps(task.tags) if task.tags else "",
                    int(task.done),
                    int(task.archived)
                ])

    def export_json(self, path):
        tasks = self.list_tasks()
        data = []
        for task in tasks:
            item = {
                "id": task.id,
                "title": task.title,
                "due": task.due.isoformat() if task.due else None,
                "priority": task.priority,
                "tags": task.tags,
                "done": task.done,
                "archived": task.archived
            }
            data.append(item)
        
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp_path, path)
        except Exception as e:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise e

    def search_tasks(self, text: str) -> List[Task]:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            # Case-insensitive search
            cursor.execute("""
                SELECT id, title, due, priority, tags, done, archived 
                FROM items 
                WHERE kind='task' AND LOWER(title) LIKE ?
                ORDER BY id
            """, (f"%{text.lower()}%",))
            
            rows = cursor.fetchall()
            tasks = []
            for row in rows:
                task = Task(
                    title=row[1],
                    due=row[2],
                    priority=row[3],
                    tags=json.loads(row[4]) if row[4] else [],
                    done=bool(row[5]),
                    archived=bool(row[6])
                )
                task.id = row[0]
                tasks.append(task)
            return tasks
        finally:
            conn.close()

    def format_task(self, task: Task, color: bool, today: date):
        # Format due date as YYYY-MM-DD or empty string
        due_str = task.due.isoformat() if task.due else ""
        
        # Build the line
        line = f"{task.id} {'[DONE]' if task.done else '[OPEN]'} {due_str} {task.priority} {task.title}"
        
        # Add ANSI codes for color if enabled and stdout is a TTY
        if color and sys.stdout.isatty():
            if task.due and task.due < today and not task.done:
                line = f"\033[31m{line}\033[0m"  # Red for overdue
            elif task.done:
                line = f"\033[32m{line}\033[0m"  # Green for done
        
        return line

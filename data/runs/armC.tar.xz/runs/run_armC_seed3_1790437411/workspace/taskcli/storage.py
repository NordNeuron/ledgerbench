import json
import os
import shutil
import csv
from datetime import datetime
import sys

class Storage:
    def __init__(self, filename="tasks.json"):
        self.filename = filename
        self._ensure_file_exists()

    def _ensure_file_exists(self):
        if not os.path.exists(self.filename):
            with open(self.filename, "w", encoding="utf-8") as f:
                json.dump([], f)

    def _read_tasks(self):
        try:
            with open(self.filename, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            raise Exception(f"Failed to read tasks: {e}")

    def _write_tasks(self, tasks):
        try:
            with open(self.filename, "w", encoding="utf-8") as f:
                json.dump(tasks, f, indent=2)
        except IOError as e:
            raise Exception(f"Failed to write tasks: {e}")

    def add(self, title, due=None, priority=None, tags=None):
        tasks = self._read_tasks()
        
        # Find next ID
        if not tasks:
            new_id = 1
        else:
            new_id = max(t["id"] for t in tasks) + 1
        
        task = {
            "id": new_id,
            "title": title,
            "done": False,
            "archived": False,
            "due": due,
            "priority": priority,
            "tags": tags or []
        }
        
        tasks.append(task)
        self._write_tasks(tasks)
        return new_id

    def _get_tasks(self, all=False, overdue=False, tag=None):
        """Shared method to get tasks with filters applied"""
        tasks = self._read_tasks()
        
        # Filter out archived tasks unless --all is specified
        if not all:
            tasks = [t for t in tasks if not t.get("archived", False)]
        
        # Filter by due date if --overdue is specified
        if overdue:
            today = datetime.today().strftime("%Y-%m-%d")
            tasks = [t for t in tasks if t.get("due") and t.get("due") < today and not t.get("done", False)]
        
        # Filter by tag if specified
        if tag:
            tasks = [t for t in tasks if tag in t.get("tags", [])]
        
        return tasks

    def list(self, all=False, overdue=False, tag=None):
        """List tasks using the shared query path"""
        tasks = self._get_tasks(all=all, overdue=overdue, tag=tag)
        return tasks

    def done(self, task_id):
        tasks = self._read_tasks()
        found = False
        for task in tasks:
            if task["id"] == task_id:
                task["done"] = True
                found = True
                break
        if not found:
            raise ValueError(f"no task with id {task_id}")
        self._write_tasks(tasks)

    def delete(self, task_id):
        tasks = self._read_tasks()
        found = False
        for i, task in enumerate(tasks):
            if task["id"] == task_id:
                del tasks[i]
                found = True
                break
        if not found:
            raise ValueError(f"no task with id {task_id}")
        self._write_tasks(tasks)

    def archive(self):
        tasks = self._read_tasks()
        updated = False
        for task in tasks:
            if task.get("done", False) and not task.get("archived", False):
                task["archived"] = True
                updated = True
        if updated:
            self._write_tasks(tasks)

    def stats(self):
        tasks = self._read_tasks()
        total = len(tasks)
        done = sum(1 for t in tasks if t.get("done", False))
        open_count = total - done
        priority_counts = {"high": 0, "med": 0, "low": 0}
        overdue_count = 0
        
        today = datetime.today().strftime("%Y-%m-%d")
        
        for task in tasks:
            # Count priority levels - make sure we count all priorities properly
            if task.get("priority") and task["priority"] in ["high", "med", "low"]:
                priority_counts[task["priority"]] += 1
            
            # Count overdue tasks (not done and past due)
            if not task.get("done", False) and task.get("due") and task["due"] < today:
                overdue_count += 1
        
        lines = [
            f"Total: {total}",
            f"Done: {done}",
            f"Open: {open_count}"
        ]
        
        for priority, count in priority_counts.items():
            if count > 0:
                lines.append(f"Priority {priority}: {count}")
        
        # Add overdue count
        lines.append(f"Overdue: {overdue_count}")
        
        return lines

    def compact(self):
        tasks = self._read_tasks()
        # Remove archived tasks to reclaim space
        non_archived = [t for t in tasks if not t.get("archived", False)]
        if len(non_archived) < len(tasks):
            self._write_tasks(non_archived)

    def backup(self, path):
        tmp_path = path + ".tmp"
        try:
            shutil.copy2(self.filename, tmp_path)
            os.replace(tmp_path, path)
        except Exception as e:
            # Clean up temp file on failure
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise e

    def export(self, path):
        """Export tasks using the shared query path"""
        tasks = self._get_tasks()
        with open(path, "w", encoding="utf-8") as f:
            json.dump(tasks, f, indent=2)

    def export_csv(self, path):
        """Export tasks to CSV using the shared query path"""
        tasks = self._get_tasks()
        fieldnames = ["id", "title", "done", "archived", "due", "priority", "tags"]
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for task in tasks:
                # Convert tags to string
                if isinstance(task.get("tags"), list):
                    task["tags"] = ",".join(task["tags"])
                writer.writerow(task)

    def search(self, text):
        tasks = self._read_tasks()
        text_lower = text.lower()
        matches = []
        for task in tasks:
            if text_lower in task["title"].lower():
                matches.append(task)
        return matches

    def format_task(self, task, today=None, color=False):
        # For simplicity, we'll just use a basic format without colors
        due_str = task.get("due", "")
        
        # Format priority
        priority_str = ""
        if task.get("priority"):
            priority_str = f" [{task['priority']}]"
        
        # Format tags
        tags_str = ""
        if task.get("tags"):
            tags_str = " " + " ".join(f"[{tag}]" for tag in task["tags"])
        
        # Build the line
        done_char = "✓" if task.get("done", False) else "○"
        due_part = f" ({due_str})" if due_str else ""
        
        line = f"{done_char} {task['id']}: {task['title']}{priority_str}{tags_str}{due_part}"
        
        return line

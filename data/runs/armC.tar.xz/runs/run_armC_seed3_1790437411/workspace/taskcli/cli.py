import argparse
import os
import sys
from .storage import Storage

def parse_args():
    parser = argparse.ArgumentParser(
        prog="taskcli",
        description="A minimal command-line task manager.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m taskcli add "Buy milk"
  python -m taskcli list
  python -m taskcli done 1
  python -m taskcli delete 1
        """
    )
    parser.add_argument("--version", action="version", version="taskcli 0.1")
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--due", help="Due date (YYYY-MM-DD)")
    add_parser.add_argument("--priority", choices=["high", "med", "low"], default=None, help="Priority level")
    add_parser.add_argument("--tag", action="append", help="Add a tag (repeatable)")

    # List command
    list_parser = subparsers.add_parser("list", help="List tasks")
    list_parser.add_argument("--sort", choices=["priority", "insertion"], default="insertion", help="Sort order")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")
    list_parser.add_argument("--color", action="store_true", help="Enable ANSI colors")
    list_parser.add_argument("--tag", help="Filter by tag")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Archive command
    subparsers.add_parser("archive", help="Archive done tasks")

    # Stats command
    subparsers.add_parser("stats", help="Show statistics")

    # Compact command
    subparsers.add_parser("compact", help="Reclaim dead space")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup database")
    backup_parser.add_argument("path", help="Backup file path")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export file path")
    export_parser.add_argument("--format", choices=["csv"], default=None, help="Export format")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Search text")

    return parser.parse_args()

def validate_date(date_str):
    import re
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", date_str):
        return False
    try:
        from datetime import datetime
        datetime.strptime(date_str, "%Y-%m-%d")
        return True
    except ValueError:
        return False

def main():
    args = parse_args()
    
    # Emit audit line to stderr - ALWAYS
    command_name = args.command if args.command else "unknown"
    print(f"AUDIT {command_name}", file=sys.stderr)
    
    if not args.command:
        print("No command provided. Use --help for usage information.", file=sys.stderr)
        return 2
    
    storage = Storage()
    
    if args.command == "add":
        if args.due and not validate_date(args.due):
            print(f"error: invalid due date '{args.due}'; expected YYYY-MM-DD format", file=sys.stderr)
            return 2
        
        # Set default priority from config if not provided
        if args.priority is None:
            try:
                import tomli
                config_path = "config.toml"
                if os.path.exists(config_path):
                    with open(config_path, "rb") as f:
                        config = tomli.load(f)
                    if "default_priority" in config:
                        args.priority = config["default_priority"]
            except Exception:
                pass
        
        task_id = storage.add(
            title=args.title,
            due=args.due,
            priority=args.priority,
            tags=args.tag or []
        )
        # Add command should print exactly the ID and nothing else
        print(task_id)
        return 0

    elif args.command == "list":
        tasks = storage.list(all=args.all, overdue=args.overdue, tag=args.tag)
        
        if args.sort == "priority":
            tasks = sorted(tasks, key=lambda t: (
                not t["done"],  # Not done first
                {"high": 0, "med": 1, "low": 2}.get(t.get("priority"), 3),
                t["id"]
            ))
        else:  # insertion order
            tasks = sorted(tasks, key=lambda t: t["id"])
        
        for task in tasks:
            print(storage.format_task(task))
        return 0

    elif args.command == "done":
        try:
            storage.done(args.id)
        except ValueError as e:
            print(f"error: {e}", file=sys.stderr)
            return 2
        # Done command must be completely silent on success (no stdout, no stderr)
        return 0

    elif args.command == "delete":
        try:
            storage.delete(args.id)
        except ValueError as e:
            print(f"error: {e}", file=sys.stderr)
            return 2
        # Delete command must be completely silent on success (no stdout, no stderr)
        return 0

    elif args.command == "archive":
        storage.archive()
        return 0

    elif args.command == "stats":
        stats = storage.stats()
        for line in stats:
            print(line)
        return 0

    elif args.command == "compact":
        storage.compact()
        return 0

    elif args.command == "backup":
        try:
            storage.backup(args.path)
        except Exception as e:
            print(f"error: backup failed: {e}", file=sys.stderr)
            return 1
        return 0

    elif args.command == "export":
        try:
            if args.format == "csv":
                storage.export_csv(args.path)
            else:
                storage.export(args.path)
        except Exception as e:
            print(f"error: export failed: {e}", file=sys.stderr)
            return 1
        return 0

    elif args.command == "search":
        tasks = storage.search(args.text)
        for task in tasks:
            print(storage.format_task(task))
        return 0

    else:
        print(f"Unknown command: {args.command}", file=sys.stderr)
        return 2

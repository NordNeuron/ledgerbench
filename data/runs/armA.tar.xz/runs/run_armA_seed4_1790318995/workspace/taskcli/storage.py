import json
import os
import shutil
import sqlite3
import sys
import tempfile
from datetime import date, datetime
from pathlib import Path
from typing import List, Optional, Dict, Any

from . import __version__


class TaskStorage:
    def __init__(self, db_path: str = "tasks.db"):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        # Check if database exists
        db_exists = os.path.exists(self.db_path)
        
        # If it doesn't exist, check for legacy JSON file and migrate
        if not db_exists:
            self.migrate_from_json()
        
        # Initialize database schema
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    priority TEXT DEFAULT 'med',
                    due DATE,
                    archived BOOLEAN DEFAULT FALSE,
                    kind TEXT DEFAULT 'task'
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS tags (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT UNIQUE NOT NULL
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS item_tags (
                    item_id INTEGER,
                    tag_id INTEGER,
                    PRIMARY KEY (item_id, tag_id),
                    FOREIGN KEY (item_id) REFERENCES items (id),
                    FOREIGN KEY (tag_id) REFERENCES tags (id)
                )
            """)
            
            # Create indexes for better performance
            conn.execute("CREATE INDEX IF NOT EXISTS idx_items_done ON items(done)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_items_priority ON items(priority)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_items_due ON items(due)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_items_archived ON items(archived)")

    def migrate_from_json(self):
        """Migrate from legacy JSON format to SQLite if needed."""
        json_path = "tasks.json"
        if not os.path.exists(json_path):
            return
            
        try:
            with open(json_path, 'r') as f:
                tasks = json.load(f)
                
            # Migrate data
            with sqlite3.connect(self.db_path) as conn:
                for task in tasks:
                    conn.execute("""
                        INSERT INTO items (id, title, done, priority, due, archived, kind)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (
                        task['id'],
                        task['title'],
                        task['done'],
                        task.get('priority', 'med'),
                        task.get('due'),
                        task.get('archived', False),
                        task.get('kind', 'task')
                    ))
                    
            # Remove the old JSON file
            os.remove(json_path)
            
        except (json.JSONDecodeError, sqlite3.Error) as e:
            raise ValueError(f"Failed to migrate from JSON: {e}")

    def get_next_id(self) -> int:
        """Get the next available task ID."""
        with sqlite3.connect(self.db_path) as conn:
            result = conn.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items").fetchone()
            return result[0]

    def add_task(self, title: str, priority: str = "med", due: Optional[str] = None, tags: List[str] = None) -> int:
        """Add a new task and return its ID."""
        if due is not None:
            try:
                datetime.strptime(due, "%Y-%m-%d")
            except ValueError:
                raise ValueError("Invalid date format. Use YYYY-MM-DD.")

        task_id = self.get_next_id()
        
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT INTO items (id, title, priority, due, kind)
                VALUES (?, ?, ?, ?, ?)
            """, (task_id, title, priority, due, "task"))
            
            # Add tags if provided
            if tags:
                # Get or create tag IDs
                tag_ids = []
                for tag_name in tags:
                    cursor = conn.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (tag_name,))
                    if cursor.rowcount > 0:
                        tag_id = cursor.lastrowid
                    else:
                        tag_id = conn.execute("SELECT id FROM tags WHERE name = ?", (tag_name,)).fetchone()[0]
                    tag_ids.append(tag_id)
                
                # Insert item-tag relationships
                for tag_id in tag_ids:
                    conn.execute("INSERT OR IGNORE INTO item_tags (item_id, tag_id) VALUES (?, ?)", (task_id, tag_id))
            
        return task_id

    def _build_list_query(self, show_archived: bool = False, filter_tags: List[str] = None, show_overdue: bool = False) -> tuple:
        """Build the base query for listing tasks."""
        # Build base query
        query = """
            SELECT i.*, 
                   CASE WHEN i.due IS NOT NULL AND i.due < ? AND i.done = FALSE THEN 1 ELSE 0 END AS overdue
            FROM items i
        """
        
        params = [self._get_today()]
        
        # Filter archived tasks if needed
        if not show_archived:
            query += " WHERE i.archived = FALSE "
            
        # Apply tag filtering if provided
        if filter_tags:
            query += " AND i.id IN (SELECT DISTINCT it.item_id FROM item_tags it JOIN tags t ON it.tag_id = t.id WHERE t.name IN ({}) ) ".format(','.join('?' * len(filter_tags)))
            params.extend(filter_tags)
            
        # Apply overdue filtering if needed
        if show_overdue:
            query += " AND i.due IS NOT NULL AND i.due < ? AND i.done = FALSE "
            params.append(self._get_today())
        
        return query, params

    def list_tasks(self, sort_by: str = "id", show_archived: bool = False, filter_tags: List[str] = None, show_overdue: bool = False) -> List[Dict[str, Any]]:
        """List all tasks."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            
            query, params = self._build_list_query(show_archived, filter_tags, show_overdue)
            
            # Add sorting
            if sort_by == "priority":
                query += """
                    ORDER BY 
                        CASE i.priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 ELSE 3 END,
                        i.id
                """
            else:  # default to id
                query += " ORDER BY i.id"
                
            cursor = conn.execute(query, params)
            tasks = [dict(row) for row in cursor.fetchall()]
            
            # Add tag information
            for task in tasks:
                tags = self._get_task_tags(task['id'])
                task['tags'] = tags
                
            return tasks

    def _get_task_tags(self, task_id: int) -> List[str]:
        """Get all tags for a specific task."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("""
                SELECT t.name FROM tags t 
                JOIN item_tags it ON t.id = it.tag_id 
                WHERE it.item_id = ?
                ORDER BY t.name
            """, (task_id,))
            return [row[0] for row in cursor.fetchall()]

    def set_task_done(self, task_id: int, done: bool) -> None:
        """Mark a task as done or not done."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("SELECT id FROM items WHERE id = ?", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} does not exist.")
            
            conn.execute("UPDATE items SET done = ? WHERE id = ?", (done, task_id))

    def delete_task(self, task_id: int) -> None:
        """Delete a task."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("SELECT id FROM items WHERE id = ?", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} does not exist.")
            
            conn.execute("DELETE FROM items WHERE id = ?", (task_id,))

    def edit_task(self, task_id: int, title: Optional[str] = None, priority: Optional[str] = None, due: Optional[str] = None, add_tags: List[str] = None, remove_tags: List[str] = None) -> None:
        """Edit a task."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("SELECT id FROM items WHERE id = ?", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} does not exist.")
            
            # Validate due date if provided
            if due is not None:
                try:
                    datetime.strptime(due, "%Y-%m-%d")
                except ValueError:
                    raise ValueError("Invalid date format. Use YYYY-MM-DD.")
            
            # Update task fields
            if title is not None:
                conn.execute("UPDATE items SET title = ? WHERE id = ?", (title, task_id))
            if priority is not None:
                conn.execute("UPDATE items SET priority = ? WHERE id = ?", (priority, task_id))
            if due is not None:
                conn.execute("UPDATE items SET due = ? WHERE id = ?", (due, task_id))
            
            # Handle tag additions
            if add_tags:
                for tag_name in add_tags:
                    cursor = conn.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (tag_name,))
                    if cursor.rowcount > 0:
                        tag_id = cursor.lastrowid
                    else:
                        tag_id = conn.execute("SELECT id FROM tags WHERE name = ?", (tag_name,)).fetchone()[0]
                    conn.execute("INSERT OR IGNORE INTO item_tags (item_id, tag_id) VALUES (?, ?)", (task_id, tag_id))
            
            # Handle tag removals
            if remove_tags:
                for tag_name in remove_tags:
                    cursor = conn.execute("SELECT id FROM tags WHERE name = ?", (tag_name,))
                    tag_result = cursor.fetchone()
                    if tag_result:
                        tag_id = tag_result[0]
                        conn.execute("DELETE FROM item_tags WHERE item_id = ? AND tag_id = ?", (task_id, tag_id))

    def get_stats(self) -> Dict[str, int]:
        """Get task statistics."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            
            total = conn.execute("SELECT COUNT(*) FROM items").fetchone()[0]
            done = conn.execute("SELECT COUNT(*) FROM items WHERE done = TRUE").fetchone()[0]
            overdue = conn.execute("""
                SELECT COUNT(*) FROM items 
                WHERE done = FALSE AND due IS NOT NULL AND due < ?
            """, (self._get_today(),)).fetchone()[0]
            
            return {
                "total": total,
                "done": done,
                "overdue": overdue
            }

    def archive_done_tasks(self) -> None:
        """Archive all done tasks."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("UPDATE items SET archived = TRUE WHERE done = TRUE AND archived = FALSE")

    def backup_database(self, backup_path: str) -> None:
        """Create a backup of the database."""
        # Create temporary file in same directory as target
        backup_dir = os.path.dirname(backup_path) or '.'
        temp_backup_path = os.path.join(backup_dir, f".tmp_backup_{os.getpid()}")
        
        try:
            shutil.copy2(self.db_path, temp_backup_path)
            os.replace(temp_backup_path, backup_path)
        except Exception as e:
            # Clean up temp file if something went wrong
            try:
                os.remove(temp_backup_path)
            except:
                pass
            raise e

    def export_tasks(self, export_path: str, format: str = "json", show_archived: bool = False, filter_tags: List[str] = None, show_overdue: bool = False) -> None:
        """Export all tasks to a file."""
        tasks = self.list_tasks(
            show_archived=show_archived,
            filter_tags=filter_tags,
            show_overdue=show_overdue
        )
        
        if format == "csv":
            import csv
            with open(export_path, 'w', newline='') as csvfile:
                fieldnames = ['id', 'title', 'done', 'priority', 'due', 'archived']
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                writer.writeheader()
                for task in tasks:
                    # Convert done to boolean string
                    task['done'] = str(task['done']).lower()
                    task['archived'] = str(task['archived']).lower()
                    writer.writerow(task)
        else:  # json
            with open(export_path, 'w') as f:
                json.dump(tasks, f, indent=2)

    def compact_database(self) -> None:
        """Compact the database to reclaim space."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("VACUUM")

    def search_tasks(self, text: str) -> List[Dict[str, Any]]:
        """Search for tasks by title (case-insensitive)."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            
            # Use case-insensitive LIKE search
            query = """
                SELECT i.*, 
                       CASE WHEN i.due IS NOT NULL AND i.due < ? AND i.done = FALSE THEN 1 ELSE 0 END AS overdue
                FROM items i
                WHERE LOWER(i.title) LIKE ?
                ORDER BY i.id
            """
            
            cursor = conn.execute(query, (self._get_today(), f"%{text.lower()}%"))
            tasks = [dict(row) for row in cursor.fetchall()]
            
            # Add tag information
            for task in tasks:
                tags = self._get_task_tags(task['id'])
                task['tags'] = tags
                
            return tasks

    def _get_today(self) -> str:
        """Get today's date, respecting TASKCLI_TODAY environment variable."""
        today_str = os.environ.get("TASKCLI_TODAY")
        if today_str:
            try:
                datetime.strptime(today_str, "%Y-%m-%d")
                return today_str
            except ValueError:
                # If invalid format, fall back to current date
                pass
        
        return date.today().strftime("%Y-%m-%d")

import argparse
import os
import sys
from typing import List

from . import __version__
from .storage import TaskStorage


def create_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="taskcli",
        description="A minimal command-line task manager.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""Commands
  add <title>                    — add a new task. Prints the assigned id.
  list                           — list all tasks, in insertion order, showing id,
                                   done status, and title.
  done <id>                      — mark the task with the given integer id as done.
  delete <id>                    — delete the task with the given integer id.
  edit <id> --title "new title"  — modify task title
  stats                          — show task statistics
  archive                        — archive all done tasks
  backup <path>                  — create atomic database backup
  export <path>                  — export all tasks to JSON file
  compact                        — compact database to reclaim space
  search <text>                  — search for tasks by title
  help                           — show this help message""",
    )
    parser.add_argument("--version", action="version", version=f"taskcli {__version__}")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--priority", choices=["low", "med", "high"], default="med")
    add_parser.add_argument("--due", help="Due date (YYYY-MM-DD)")
    add_parser.add_argument("--tag", action="append", help="Add a tag (can be used multiple times)")

    # List command
    list_parser = subparsers.add_parser("list", help="List all tasks")
    list_parser.add_argument("--sort", choices=["id", "priority"], default="id")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks too")
    list_parser.add_argument("--tag", action="append", help="Filter by tag (can be used multiple times)")
    list_parser.add_argument("--color", choices=["auto", "always", "never"], default="auto")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark a task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Edit command
    edit_parser = subparsers.add_parser("edit", help="Edit a task")
    edit_parser.add_argument("id", type=int, help="Task ID")
    edit_parser.add_argument("--title", help="New title")
    edit_parser.add_argument("--priority", choices=["low", "med", "high"])
    edit_parser.add_argument("--due", help="New due date (YYYY-MM-DD)")
    edit_parser.add_argument("--tag", action="append", help="Add a tag (can be used multiple times)")
    edit_parser.add_argument("--remove-tag", action="append", help="Remove a tag (can be used multiple times)")

    # Stats command
    subparsers.add_parser("stats", help="Show task statistics")

    # Archive command
    subparsers.add_parser("archive", help="Archive all done tasks")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Create atomic database backup")
    backup_parser.add_argument("path", help="Backup file path")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export all tasks to JSON file")
    export_parser.add_argument("path", help="Export file path")
    export_parser.add_argument("--format", choices=["json", "csv"], default="json")
    export_parser.add_argument("--all", action="store_true", help="Include archived tasks")
    export_parser.add_argument("--tag", action="append", help="Filter by tag (can be used multiple times)")
    export_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")

    # Compact command
    subparsers.add_parser("compact", help="Compact database to reclaim space")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search for tasks by title")
    search_parser.add_argument("text", help="Text to search for in task titles")

    return parser


def handle_add(args: argparse.Namespace, storage: TaskStorage) -> int:
    try:
        task_id = storage.add_task(
            args.title,
            priority=args.priority,
            due=args.due,
            tags=args.tag or [],
        )
        print(task_id)
        return 0
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2


def handle_list(args: argparse.Namespace, storage: TaskStorage) -> int:
    try:
        tasks = storage.list_tasks(
            sort_by=args.sort,
            show_archived=args.all,
            filter_tags=args.tag or [],
            show_overdue=args.overdue,
        )
        if not tasks:
            return 0

        color_enabled = (
            args.color == "always" or
            (args.color == "auto" and sys.stdout.isatty())
        )

        for task in tasks:
            done_str = "✓" if task["done"] else "○"
            priority_str = f"(priority: {task['priority']})" if task["priority"] != "med" else ""
            due_str = f" (due: {task['due']})" if task["due"] else ""
            archived_str = " [ARCHIVED]" if task["archived"] else ""
            title = task["title"]
            
            if color_enabled:
                if task["done"]:
                    title = f"\033[32m{title}\033[0m"  # Green for done
                elif task["overdue"]:
                    title = f"\033[31m{title}\033[0m"  # Red for overdue

            print(f"{task['id']}: {done_str} {title}{priority_str}{due_str}{archived_str}")
        return 0
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2


def handle_done(args: argparse.Namespace, storage: TaskStorage) -> int:
    try:
        storage.set_task_done(args.id, True)
        return 0
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2


def handle_delete(args: argparse.Namespace, storage: TaskStorage) -> int:
    try:
        storage.delete_task(args.id)
        return 0
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2


def handle_edit(args: argparse.Namespace, storage: TaskStorage) -> int:
    try:
        storage.edit_task(
            args.id,
            title=args.title,
            priority=args.priority,
            due=args.due,
            add_tags=args.tag or [],
            remove_tags=args.remove_tag or [],
        )
        return 0
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2


def handle_stats(args: argparse.Namespace, storage: TaskStorage) -> int:
    try:
        stats = storage.get_stats()
        print(f"Total: {stats['total']}")
        print(f"Done: {stats['done']}")
        if stats["overdue"] > 0:
            print(f"\033[31mOverdue: {stats['overdue']}\033[0m")
        else:
            print(f"Overdue: {stats['overdue']}")
        return 0
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2


def handle_archive(args: argparse.Namespace, storage: TaskStorage) -> int:
    try:
        storage.archive_done_tasks()
        return 0
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2


def handle_backup(args: argparse.Namespace, storage: TaskStorage) -> int:
    try:
        storage.backup_database(args.path)
        return 0
    except OSError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def handle_export(args: argparse.Namespace, storage: TaskStorage) -> int:
    try:
        storage.export_tasks(
            args.path,
            format=args.format,
            show_archived=args.all,
            filter_tags=args.tag or [],
            show_overdue=args.overdue
        )
        return 0
    except (OSError, ValueError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def handle_compact(args: argparse.Namespace, storage: TaskStorage) -> int:
    try:
        storage.compact_database()
        return 0
    except OSError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def handle_search(args: argparse.Namespace, storage: TaskStorage) -> int:
    try:
        tasks = storage.search_tasks(args.text)
        if not tasks:
            return 0

        for task in tasks:
            done_str = "✓" if task["done"] else "○"
            priority_str = f"(priority: {task['priority']})" if task["priority"] != "med" else ""
            due_str = f" (due: {task['due']})" if task["due"] else ""
            archived_str = " [ARCHIVED]" if task["archived"] else ""
            title = task["title"]
            
            print(f"{task['id']}: {done_str} {title}{priority_str}{due_str}{archived_str}")
        return 0
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2


def main():
    parser = create_parser()
    args = parser.parse_args()

    # Emit audit line to stderr
    print(f"AUDIT {args.command}", file=sys.stderr)

    storage = TaskStorage()

    if args.command == "add":
        return handle_add(args, storage)
    elif args.command == "list":
        return handle_list(args, storage)
    elif args.command == "done":
        return handle_done(args, storage)
    elif args.command == "delete":
        return handle_delete(args, storage)
    elif args.command == "edit":
        return handle_edit(args, storage)
    elif args.command == "stats":
        return handle_stats(args, storage)
    elif args.command == "archive":
        return handle_archive(args, storage)
    elif args.command == "backup":
        return handle_backup(args, storage)
    elif args.command == "export":
        return handle_export(args, storage)
    elif args.command == "compact":
        return handle_compact(args, storage)
    elif args.command == "search":
        return handle_search(args, storage)
    else:
        print("Unknown command", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())

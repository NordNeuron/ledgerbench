import os
import sqlite3
import shutil
import tempfile
from datetime import date

class Storage:
    def __init__(self, db_path='tasks.db'):
        self.db_path = db_path
        self.init_db()
    
    def init_db(self):
        """Initialize the database with required tables."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create items table if it doesn't exist
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                done BOOLEAN DEFAULT 0,
                priority TEXT DEFAULT 'med',
                due DATE,
                archived BOOLEAN DEFAULT 0,
                kind TEXT NOT NULL DEFAULT 'task'
            )
        ''')
        
        # Create task_tags table if it doesn't exist
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS task_tags (
                task_id INTEGER,
                tag TEXT,
                FOREIGN KEY (task_id) REFERENCES items (id)
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def get_next_id(self):
        """Get the next available task ID."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('SELECT COALESCE(MAX(id), 0) + 1 FROM items')
        next_id = cursor.fetchone()[0]
        conn.close()
        return next_id
    
    def add_task(self, title, priority='med', due=None, tags=None):
        """Add a new task and return its ID."""
        if due:
            try:
                # Validate date format
                date.fromisoformat(due)
            except ValueError:
                raise ValueError("Invalid date format. Use YYYY-MM-DD.")
        
        task_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO items (id, title, priority, due, kind)
            VALUES (?, ?, ?, ?, ?)
        ''', (task_id, title, priority, due, 'task'))
        
        # Add tags if provided
        if tags:
            for tag in tags:
                cursor.execute('''
                    INSERT INTO task_tags (task_id, tag)
                    VALUES (?, ?)
                ''', (task_id, tag))
        
        conn.commit()
        conn.close()
        return task_id
    
    def list_tasks(self):
        """List all tasks."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get all tasks with their tags
        cursor.execute('''
            SELECT i.id, i.title, i.done, i.priority, i.due, i.archived
            FROM items i
            WHERE i.kind = 'task'
            ORDER BY i.id
        ''')
        
        tasks = []
        for row in cursor.fetchall():
            task_id, title, done, priority, due, archived = row
            
            # Get tags for this task
            cursor.execute('SELECT tag FROM task_tags WHERE task_id = ?', (task_id,))
            tags = [t[0] for t in cursor.fetchall()]
            
            task = {
                'id': task_id,
                'title': title,
                'done': bool(done),
                'priority': priority,
                'due': due,
                'archived': bool(archived),
                'tags': tags
            }
            tasks.append(task)
        
        conn.close()
        return tasks
    
    def mark_done(self, task_id):
        """Mark a task as done."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('SELECT id FROM items WHERE id = ? AND kind = ?', (task_id, 'task'))
        if not cursor.fetchone():
            raise ValueError(f"No task with ID {task_id}")
        
        cursor.execute('UPDATE items SET done = 1 WHERE id = ?', (task_id,))
        conn.commit()
        conn.close()
    
    def delete_task(self, task_id):
        """Delete a task."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('SELECT id FROM items WHERE id = ? AND kind = ?', (task_id, 'task'))
        if not cursor.fetchone():
            raise ValueError(f"No task with ID {task_id}")
        
        cursor.execute('DELETE FROM task_tags WHERE task_id = ?', (task_id,))
        cursor.execute('DELETE FROM items WHERE id = ? AND kind = ?', (task_id, 'task'))
        conn.commit()
        conn.close()
    
    def edit_task(self, task_id, title=None):
        """Edit a task's title."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('SELECT id FROM items WHERE id = ? AND kind = ?', (task_id, 'task'))
        if not cursor.fetchone():
            raise ValueError(f"No task with ID {task_id}")
        
        if title is not None:
            cursor.execute('UPDATE items SET title = ? WHERE id = ?', (title, task_id))
        
        conn.commit()
        conn.close()
    
    def archive_done_tasks(self):
        """Archive all done tasks."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('UPDATE items SET archived = 1 WHERE done = 1 AND kind = ?', ('task',))
        conn.commit()
        conn.close()
    
    def backup(self, path):
        """Backup the database to a file."""
        # Create a temporary file in the same directory as target
        dir_name = os.path.dirname(path) or '.'
        temp_path = os.path.join(dir_name, f'.tmp_backup_{os.getpid()}')
        
        try:
            shutil.copy2(self.db_path, temp_path)
            os.replace(temp_path, path)
        except Exception:
            # Clean up temp file if something goes wrong
            try:
                os.remove(temp_path)
            except:
                pass
            raise
    
    def compact(self):
        """Compact the database."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('VACUUM')
        conn.commit()
        conn.close()

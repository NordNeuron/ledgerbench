import argparse
import os
import sys
from .storage import Storage
from . import __version__

def get_today():
    """Get today's date from environment or use current date."""
    today_str = os.environ.get('TASKCLI_TODAY')
    if today_str:
        try:
            from datetime import datetime
            return datetime.strptime(today_str, '%Y-%m-%d').date()
        except ValueError:
            print("Error: TASKCLI_TODAY must be in YYYY-MM-DD format", file=sys.stderr)
            sys.exit(2)
    from datetime import date
    return date.today()

def print_task(task, today, color=False):
    """Print a single task in list format."""
    if task.get('done'):
        status = "✓"
        if color and sys.stdout.isatty():
            status = "\033[32m✓\033[0m"  # green
    elif task.get('due') and today > task['due']:
        status = "✗"
        if color and sys.stdout.isatty():
            status = "\033[31m✗\033[0m"  # red
    else:
        status = "○"
    
    priority = task.get('priority', 'med')
    if priority == 'high':
        priority_display = "high"
    elif priority == 'med':
        priority_display = "med"
    else:
        priority_display = "low"
    
    due_str = ""
    if task.get('due'):
        due_str = f" (due: {task['due']})"
    
    tags_str = ""
    if task.get('tags'):
        tags_str = " " + " ".join(f"@{tag}" for tag in task['tags'])
    
    print(f"{task['id']} {status} {priority_display}: {task['title']}{due_str}{tags_str}")

def get_filtered_and_sorted_tasks(storage, args):
    """Get tasks with all filters and sorting applied."""
    tasks = storage.list_tasks()
    
    # Apply filters
    if hasattr(args, 'overdue') and args.overdue:
        today = get_today()
        tasks = [t for t in tasks if t.get('due') and today > t['due'] and not t.get('done')]
    elif hasattr(args, 'tag') and args.tag:
        tasks = [t for t in tasks if t.get('tags') and any(tag in t['tags'] for tag in args.tag)]
    
    # Apply sorting
    today = get_today()
    
    if hasattr(args, 'sort') and args.sort == 'priority':
        def priority_key(task):
            done = task.get('done', False)
            priority = task.get('priority', 'med')
            due = task.get('due')
            
            # For overdue tasks, sort by priority first, then by due date (oldest first)
            if due and today > due and not done:
                return (0, {'high': 0, 'med': 1, 'low': 2}[priority], due)
            else:
                # For non-overdue tasks, sort by priority first, then by insertion order
                return (1, {'high': 0, 'med': 1, 'low': 2}[priority], task['id'])
        
        tasks.sort(key=priority_key)
    elif hasattr(args, 'sort') and args.sort == 'due':
        def due_key(task):
            done = task.get('done', False)
            due = task.get('due')
            
            if due and not done:
                return (0, due, task['id'])  # Not done, sort by due date
            else:
                return (1, None, task['id'])  # Done or no due date, sort by insertion order
            
        tasks.sort(key=due_key)
    else:  # default sorting - overdue first, then priority
        def smart_sort_key(task):
            done = task.get('done', False)
            priority = task.get('priority', 'med')
            due = task.get('due')
            
            if due and today > due and not done:
                return (0, {'high': 0, 'med': 1, 'low': 2}[priority], due)
            else:
                return (1, {'high': 0, 'med': 1, 'low': 2}[priority], task['id'])
        
        tasks.sort(key=smart_sort_key)
    
    # Apply --all flag
    if hasattr(args, 'all') and not args.all:
        tasks = [t for t in tasks if not t.get('archived', False)]
    
    return tasks

def list_tasks(args):
    """Handle the list command."""
    storage = Storage()
    
    # Get filtered and sorted tasks
    tasks = get_filtered_and_sorted_tasks(storage, args)
    
    # Print tasks
    today = get_today()
    for task in tasks:
        print_task(task, today, args.color)

def add_task(args):
    """Handle the add command."""
    storage = Storage()
    task_id = storage.add_task(
        title=args.title,
        priority=args.priority,
        due=args.due,
        tags=args.tag or []
    )
    print(task_id)

def done_task(args):
    """Handle the done command."""
    storage = Storage()
    try:
        storage.mark_done(args.id)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        sys.exit(2)

def delete_task(args):
    """Handle the delete command."""
    storage = Storage()
    try:
        storage.delete_task(args.id)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        sys.exit(2)

def edit_task(args):
    """Handle the edit command."""
    storage = Storage()
    try:
        storage.edit_task(args.id, title=args.title)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        sys.exit(2)

def stats():
    """Handle the stats command."""
    storage = Storage()
    today = get_today()
    
    all_tasks = storage.list_tasks()
    
    # Filter out archived tasks
    tasks = [t for t in all_tasks if not t.get('archived', False)]
    
    total = len(tasks)
    done = sum(1 for t in tasks if t.get('done'))
    open_count = total - done
    
    priority_counts = {'high': 0, 'med': 0, 'low': 0}
    for task in tasks:
        priority = task.get('priority', 'med')
        priority_counts[priority] += 1
    
    print(f"Total: {total}")
    print(f"Done: {done}")
    print(f"Open: {open_count}")
    print(f"Priority high: {priority_counts['high']}")
    print(f"Priority med: {priority_counts['med']}")
    print(f"Priority low: {priority_counts['low']}")

def archive_tasks():
    """Handle the archive command."""
    storage = Storage()
    storage.archive_done_tasks()

def backup(args):
    """Handle the backup command."""
    storage = Storage()
    try:
        storage.backup(args.path)
    except IOError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

def export(args):
    """Handle the export command."""
    storage = Storage()
    
    # Get filtered and sorted tasks using same logic as list
    tasks = get_filtered_and_sorted_tasks(storage, args)
    
    if args.format == 'csv':
        import csv
        import io
        output = io.StringIO()
        fieldnames = ['id', 'title', 'done', 'priority', 'due', 'tags', 'archived']
        writer = csv.DictWriter(output, fieldnames=fieldnames)
        writer.writeheader()
        for task in tasks:
            # Convert tags to a string representation
            if 'tags' in task and isinstance(task['tags'], list):
                task['tags'] = ','.join(task['tags'])
            else:
                task['tags'] = ''
            writer.writerow(task)
        print(output.getvalue())
    else:  # JSON format
        import json
        print(json.dumps(tasks, indent=2))

def compact():
    """Handle the compact command."""
    storage = Storage()
    storage.compact()

def search(args):
    """Handle the search command."""
    storage = Storage()
    today = get_today()
    
    tasks = storage.list_tasks()
    # Filter tasks by title containing the search text (case-insensitive)
    matching_tasks = [
        t for t in tasks 
        if args.text.lower() in t.get('title', '').lower()
    ]
    
    # Sort like list command does
    def smart_sort_key(task):
        done = task.get('done', False)
        priority = task.get('priority', 'med')
        due = task.get('due')
        
        if due and today > due and not done:
            return (0, {'high': 0, 'med': 1, 'low': 2}[priority], due)
        else:
            return (1, {'high': 0, 'med': 1, 'low': 2}[priority], task['id'])
    
    matching_tasks.sort(key=smart_sort_key)
    
    # Print tasks
    for task in matching_tasks:
        print_task(task, today, False)

def main():
    parser = argparse.ArgumentParser(
        prog='taskcli',
        description='A minimal command-line task manager.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  taskcli add "Buy milk"
  taskcli list
  taskcli done 1
  taskcli delete 1
        """
    )
    parser.add_argument('--version', action='version', version=f'%(prog)s {__version__}')
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['low', 'med', 'high'], default='med',
                           help='Task priority (default: med)')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--tag', action='append', help='Add a tag (can be used multiple times)')
    
    # List command
    list_parser = subparsers.add_parser('list', help='List all tasks')
    list_parser.add_argument('--sort', choices=['priority', 'due'], 
                            help='Sort by priority or due date')
    list_parser.add_argument('--overdue', action='store_true', 
                            help='Show only overdue tasks')
    list_parser.add_argument('--tag', action='append',
                            help='Filter by tag (can be used multiple times)')
    list_parser.add_argument('--all', action='store_true',
                            help='Show archived tasks too')
    list_parser.add_argument('--color', action='store_true',
                            help='Enable colored output (only in terminal)')
    
    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', type=int, help='Task ID')
    
    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')
    
    # Edit command
    edit_parser = subparsers.add_parser('edit', help='Edit a task')
    edit_parser.add_argument('id', type=int, help='Task ID')
    edit_parser.add_argument('--title', required=True, help='New title for the task')
    
    # Stats command
    subparsers.add_parser('stats', help='Show statistics')
    
    # Archive command
    subparsers.add_parser('archive', help='Archive done tasks')
    
    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup database to file')
    backup_parser.add_argument('path', help='Backup destination path')
    
    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks to file')
    export_parser.add_argument('path', nargs='?', help='Export destination path (default: stdout)')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json',
                              help='Export format (default: json)')
    export_parser.add_argument('--sort', choices=['priority', 'due'], 
                              help='Sort by priority or due date')
    export_parser.add_argument('--overdue', action='store_true', 
                              help='Show only overdue tasks')
    export_parser.add_argument('--tag', action='append',
                              help='Filter by tag (can be used multiple times)')
    export_parser.add_argument('--all', action='store_true',
                              help='Show archived tasks too')
    
    # Compact command
    subparsers.add_parser('compact', help='Compact database')
    
    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for in task titles')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        print("AUDIT list", file=sys.stderr)  # Default audit for help
        return 0
    
    try:
        # Emit audit line for the command
        print(f"AUDIT {args.command}", file=sys.stderr)
        
        if args.command == 'add':
            add_task(args)
        elif args.command == 'list':
            list_tasks(args)
        elif args.command == 'done':
            done_task(args)
        elif args.command == 'delete':
            delete_task(args)
        elif args.command == 'edit':
            edit_task(args)
        elif args.command == 'stats':
            stats()
        elif args.command == 'archive':
            archive_tasks()
        elif args.command == 'backup':
            backup(args)
        elif args.command == 'export':
            export(args)
        elif args.command == 'compact':
            compact()
        elif args.command == 'search':
            search(args)
    except Exception as e:
        print(f"AUDIT {args.command}", file=sys.stderr)
        print(f"Error: {e}", file=sys.stderr)
        return 1
    
    return 0

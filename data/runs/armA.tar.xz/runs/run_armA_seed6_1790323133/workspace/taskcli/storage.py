import json
import os
import sqlite3
import sys
import shutil
import csv
from datetime import datetime, date
from typing import List, Dict, Any, Optional
import toml

class TaskStorage:
    def __init__(self, db_path: str = 'tasks.db'):
        self.db_path = db_path
        self.init_database()
        
    def init_database(self):
        """Initialize the database and perform any necessary migrations."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if we have an old tasks table (from JSON storage) and migrate it
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='tasks'")
        if cursor.fetchone():
            # Migrate from old format to new items table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    priority TEXT DEFAULT 'med',
                    due DATE,
                    archived BOOLEAN DEFAULT FALSE,
                    kind TEXT NOT NULL DEFAULT 'task'
                )
            """)
            
            # Migrate existing tasks
            cursor.execute("SELECT id, title, done, priority, due FROM tasks")
            for row in cursor.fetchall():
                task_id, title, done, priority, due = row
                cursor.execute("""
                    INSERT OR REPLACE INTO items 
                    (id, title, done, priority, due, kind)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (task_id, title, done, priority or 'med', due, 'task'))
            
            # Drop the old table
            cursor.execute("DROP TABLE tasks")
            
        # Create items table if it doesn't exist
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                done BOOLEAN DEFAULT FALSE,
                priority TEXT DEFAULT 'med',
                due DATE,
                archived BOOLEAN DEFAULT FALSE,
                kind TEXT NOT NULL DEFAULT 'task'
            )
        """)
        
        # Create tags table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tags (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL
            )
        """)
        
        # Create junction table for tasks and tags
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS task_tags (
                task_id INTEGER,
                tag_id INTEGER,
                PRIMARY KEY (task_id, tag_id),
                FOREIGN KEY (task_id) REFERENCES items (id),
                FOREIGN KEY (tag_id) REFERENCES tags (id)
            )
        """)
        
        conn.commit()
        conn.close()
    
    def get_next_id(self) -> int:
        """Get the next available task ID."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items")
        next_id = cursor.fetchone()[0]
        conn.close()
        return next_id
    
    def _get_tasks_query(self, sort_by: Optional[str] = None, 
                        overdue_only: bool = False, 
                        tag_filters: List[str] = None,
                        include_archived: bool = False) -> tuple:
        """Get the base query and parameters for fetching tasks."""
        # Build base query
        query = """
            SELECT i.*, GROUP_CONCAT(t.name) as tags 
            FROM items i
            LEFT JOIN task_tags tt ON i.id = tt.task_id
            LEFT JOIN tags t ON tt.tag_id = t.id
        """
        
        params = []
        
        # Add WHERE clause for archived tasks
        where_conditions = []
        if not include_archived:
            where_conditions.append("i.archived = 0")
            
        # Add filtering by tags (simplified approach)
        if tag_filters:
            # For each tag filter, we need to find tasks that have ALL of these tags
            tag_conditions = []
            for i, tag in enumerate(tag_filters):
                tag_conditions.append(f"t.name = ?")
                params.append(tag)
            
            # Build the subquery to find tasks with all specified tags
            if len(tag_filters) == 1:
                # Simple case - just one tag filter
                where_conditions.append("i.id IN (SELECT task_id FROM task_tags tt2 JOIN tags t2 ON tt2.tag_id = t2.id WHERE t2.name = ?)")
                params.append(tag_filters[0])
            else:
                # Multiple tag filters - need to match all tags
                subquery = """
                    SELECT task_id FROM task_tags tt2 
                    JOIN tags t2 ON tt2.tag_id = t2.id 
                    WHERE t2.name IN ({})
                    GROUP BY task_id 
                    HAVING COUNT(DISTINCT t2.name) = ?
                """.format(','.join('?' * len(tag_filters)))
                params.extend(tag_filters)
                params.append(len(tag_filters))
                where_conditions.append("i.id IN ({})".format(subquery))
            
        if where_conditions:
            query += " WHERE " + " AND ".join(where_conditions)
            
        query += " GROUP BY i.id"
        
        # Apply sorting
        if sort_by == 'priority':
            # Sort by priority: high, med, low
            query += " ORDER BY CASE WHEN i.priority='high' THEN 1 WHEN i.priority='med' THEN 2 ELSE 3 END, i.id"
        elif sort_by == 'due':
            # Sort by due date (earliest first), then by id
            query += " ORDER BY i.due IS NULL, i.due, i.id"
        else:
            # Default sort by id
            query += " ORDER BY i.id"
        
        # Apply overdue filter
        if overdue_only:
            today = self._get_today()
            query = query.replace("ORDER BY", f"ORDER BY CASE WHEN i.due IS NULL OR i.due >= '{today}' THEN 1 ELSE 0 END, i.due, i.id")
        
        return query, params
    
    def _fetch_tasks(self, sort_by: Optional[str] = None, 
                    overdue_only: bool = False, 
                    tag_filters: List[str] = None,
                    include_archived: bool = False) -> List[Dict[str, Any]]:
        """Fetch tasks with consistent filtering and sorting."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        query, params = self._get_tasks_query(sort_by, overdue_only, tag_filters, include_archived)
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        tasks = []
        for row in rows:
            task = dict(row)
            # Convert tags string to list
            if task['tags']:
                task['tags'] = [tag.strip() for tag in task['tags'].split(',')]
            else:
                task['tags'] = []
            tasks.append(task)
            
        conn.close()
        return tasks
    
    def add_task(self, title: str, due: Optional[str] = None, 
                 priority: str = 'med', tags: List[str] = None) -> int:
        """Add a new task and return its ID."""
        if tags is None:
            tags = []
            
        # Validate due date if provided
        if due:
            try:
                datetime.strptime(due, '%Y-%m-%d')
            except ValueError:
                raise ValueError("Invalid date format. Use YYYY-MM-DD.")
                
        # Validate priority
        if priority not in ['high', 'med', 'low']:
            raise ValueError("Priority must be one of: high, med, low")
            
        task_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # Insert the task
            cursor.execute("""
                INSERT INTO items (id, title, done, priority, due, kind)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (task_id, title, False, priority, due, 'task'))
            
            # Handle tags
            for tag_name in tags:
                # Insert or get tag ID
                cursor.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (tag_name,))
                cursor.execute("SELECT id FROM tags WHERE name = ?", (tag_name,))
                tag_id = cursor.fetchone()[0]
                
                # Link task and tag
                cursor.execute("""
                    INSERT OR IGNORE INTO task_tags (task_id, tag_id) 
                    VALUES (?, ?)
                """, (task_id, tag_id))
            
            conn.commit()
            return task_id
            
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def list_tasks(self, sort_by: Optional[str] = None, 
                   overdue_only: bool = False, 
                   tag_filters: List[str] = None,
                   include_archived: bool = False) -> List[Dict[str, Any]]:
        """List all tasks with optional filtering and sorting."""
        return self._fetch_tasks(sort_by, overdue_only, tag_filters, include_archived)
    
    def mark_done(self, task_id: int) -> None:
        """Mark a task as done."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute("UPDATE items SET done = 1 WHERE id = ? AND archived = 0", (task_id,))
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found or is archived")
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def delete_task(self, task_id: int) -> None:
        """Delete a task."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute("DELETE FROM items WHERE id = ? AND archived = 0", (task_id,))
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found or is archived")
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def edit_task(self, task_id: int, title: str = None) -> None:
        """Edit a task's title."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            if title is not None:
                cursor.execute("UPDATE items SET title = ? WHERE id = ? AND archived = 0", (title, task_id))
                if cursor.rowcount == 0:
                    raise ValueError(f"Task with ID {task_id} not found or is archived")
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def get_stats(self) -> Dict[str, int]:
        """Get task statistics."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Get total tasks
        cursor.execute("SELECT COUNT(*) as count FROM items WHERE archived = 0")
        total = cursor.fetchone()['count']
        
        # Get done tasks
        cursor.execute("SELECT COUNT(*) as count FROM items WHERE done = 1 AND archived = 0")
        done = cursor.fetchone()['count']
        
        # Get open tasks
        open_tasks = total - done
        
        # Get overdue tasks
        today = self._get_today()
        cursor.execute("""
            SELECT COUNT(*) as count 
            FROM items 
            WHERE done = 0 AND due < ? AND archived = 0
        """, (today,))
        overdue = cursor.fetchone()['count']
        
        # Get priority counts
        cursor.execute("SELECT priority, COUNT(*) as count FROM items WHERE archived = 0 GROUP BY priority")
        priority_counts = {row['priority']: row['count'] for row in cursor.fetchall()}
        
        conn.close()
        
        return {
            'total': total,
            'done': done,
            'open': open_tasks,
            'overdue': overdue,
            'priority_high': priority_counts.get('high', 0),
            'priority_med': priority_counts.get('med', 0),
            'priority_low': priority_counts.get('low', 0)
        }
    
    def archive_done_tasks(self) -> None:
        """Archive all done tasks."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute("UPDATE items SET archived = 1 WHERE done = 1 AND archived = 0")
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def backup_database(self, backup_path: str) -> None:
        """Create a backup of the database."""
        # Create temporary file in same directory
        backup_dir = os.path.dirname(backup_path) or '.'
        backup_filename = os.path.basename(backup_path)
        temp_backup_path = os.path.join(backup_dir, f"{backup_filename}.tmp")
        
        try:
            shutil.copy2(self.db_path, temp_backup_path)
            os.replace(temp_backup_path, backup_path)
        except Exception as e:
            # Clean up temp file if it exists
            if os.path.exists(temp_backup_path):
                os.remove(temp_backup_path)
            raise e
    
    def export_tasks(self, export_path: str, format: str = 'json') -> None:
        """Export tasks to a file."""
        # Use the same query logic as list_tasks for consistency
        tasks = self._fetch_tasks(include_archived=True)
        
        if format == 'csv':
            with open(export_path, 'w', newline='', encoding='utf-8') as csvfile:
                fieldnames = ['id', 'title', 'done', 'priority', 'due', 'archived', 'tags']
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                
                writer.writeheader()
                for task in tasks:
                    # Convert tags to comma-separated string
                    if isinstance(task['tags'], list):
                        task['tags'] = ','.join(task['tags'])
                    writer.writerow(task)
        else:  # JSON format
            with open(export_path, 'w', encoding='utf-8') as jsonfile:
                json.dump(tasks, jsonfile, indent=2, ensure_ascii=False)
    
    def compact_database(self) -> None:
        """Compact the database to reclaim space."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute("VACUUM")
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def search_tasks(self, text: str) -> List[Dict[str, Any]]:
        """Search tasks by title (case-insensitive)."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Search for tasks containing the text in title (case-insensitive)
        query = """
            SELECT i.*, GROUP_CONCAT(t.name) as tags 
            FROM items i
            LEFT JOIN task_tags tt ON i.id = tt.task_id
            LEFT JOIN tags t ON tt.tag_id = t.id
            WHERE LOWER(i.title) LIKE ?
            AND i.archived = 0
            GROUP BY i.id
            ORDER BY i.id
        """
        
        cursor.execute(query, (f'%{text.lower()}%',))
        rows = cursor.fetchall()
        
        tasks = []
        for row in rows:
            task = dict(row)
            # Convert tags string to list
            if task['tags']:
                task['tags'] = [tag.strip() for tag in task['tags'].split(',')]
            else:
                task['tags'] = []
            tasks.append(task)
            
        conn.close()
        return tasks
    
    def format_task(self, task: Dict[str, Any], use_color: bool = False) -> str:
        """Format a task for display."""
        # Build the title part
        title_parts = [task['title']]
        
        # Add priority if present
        if 'priority' in task and task['priority'] != 'med':
            title_parts.append(f"(priority: {task['priority']})")
            
        # Add due date if present
        if 'due' in task and task['due']:
            title_parts.append(f"(due: {task['due']})")
            
        # Add tags if present
        if 'tags' in task and task['tags']:
            tag_str = ','.join(task['tags'])
            title_parts.append(f"(tags: {tag_str})")
        
        title = ' '.join(title_parts)
        
        # Format the line with status
        if task['done']:
            status = '[DONE]'
            if use_color:
                status = '\033[32m' + status + '\033[0m'  # Green for done
        else:
            status = '[TODO]'
            if use_color and 'due' in task and task['due']:
                today = self._get_today()
                try:
                    due_date = datetime.strptime(task['due'], '%Y-%m-%d').date()
                    if due_date < today:
                        status = '\033[31m' + status + '\033[0m'  # Red for overdue
                except ValueError:
                    pass  # Invalid date format, ignore
                    
        return f"{status} {task['id']}: {title}"
    
    def _get_today(self) -> str:
        """Get today's date as YYYY-MM-DD string."""
        # Check for environment variable first
        today_env = os.environ.get('TASKCLI_TODAY')
        if today_env:
            return today_env
            
        # Check for config file
        try:
            if os.path.exists('config.toml'):
                config = toml.load('config.toml')
                if 'today' in config:
                    return config['today']
        except Exception:
            pass  # Ignore config errors
            
        # Default to current date
        return datetime.now().strftime('%Y-%m-%d')

import argparse
import os
import sys
from . import __version__
from .storage import TaskStorage

def create_parser():
    parser = argparse.ArgumentParser(
        prog='taskcli',
        description='A minimal command-line task manager.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  taskcli add "Buy milk"
  taskcli list
  taskcli done 1
  taskcli delete 1
        """
    )
    parser.add_argument('--version', action='version', version=f'%(prog)s {__version__}')
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--due', help='Due date (YYYY-MM-DD)')
    add_parser.add_argument('--priority', choices=['high', 'med', 'low'], default='med',
                           help='Task priority (default: med)')
    add_parser.add_argument('--tag', action='append', help='Add a tag (can be used multiple times)')

    # List command
    list_parser = subparsers.add_parser('list', help='List all tasks')
    list_parser.add_argument('--sort', choices=['id', 'priority', 'due'], 
                            help='Sort by field')
    list_parser.add_argument('--overdue', action='store_true', 
                            help='Show only overdue tasks')
    list_parser.add_argument('--tag', action='append', 
                            help='Filter by tag (can be used multiple times)')
    list_parser.add_argument('--all', action='store_true', 
                            help='Show archived tasks')
    list_parser.add_argument('--color', choices=['auto', 'always', 'never'], 
                            default='auto', help='Color output (default: auto)')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Edit command
    edit_parser = subparsers.add_parser('edit', help='Edit a task')
    edit_parser.add_argument('id', type=int, help='Task ID')
    edit_parser.add_argument('--title', required=True, help='New title')

    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show task statistics')

    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Create a backup of the database')
    backup_parser.add_argument('path', help='Backup file path')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks to JSON file')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json',
                              help='Export format (default: json)')

    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Compact the database')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for in task titles')

    return parser

def handle_add(args):
    storage = TaskStorage()
    try:
        task_id = storage.add_task(
            title=args.title,
            due=args.due,
            priority=args.priority,
            tags=args.tag or []
        )
        print(task_id)
        return 0
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

def handle_list(args):
    storage = TaskStorage()
    try:
        tasks = storage.list_tasks(
            sort_by=args.sort,
            overdue_only=args.overdue,
            tag_filters=args.tag or [],
            include_archived=args.all
        )
        
        if not tasks:
            return 0
            
        # Determine if we should use colors
        use_color = False
        if args.color == 'always':
            use_color = True
        elif args.color == 'auto':
            use_color = sys.stdout.isatty()
            
        for task in tasks:
            print(storage.format_task(task, use_color=use_color))
        return 0
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

def handle_done(args):
    storage = TaskStorage()
    try:
        storage.mark_done(args.id)
        return 0
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

def handle_delete(args):
    storage = TaskStorage()
    try:
        storage.delete_task(args.id)
        return 0
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

def handle_edit(args):
    storage = TaskStorage()
    try:
        storage.edit_task(args.id, title=args.title)
        return 0
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

def handle_stats(args):
    storage = TaskStorage()
    try:
        stats = storage.get_stats()
        print(f"Total: {stats['total']}")
        print(f"Done: {stats['done']}")
        print(f"Open: {stats['open']}")
        print(f"Overdue: {stats['overdue']}")
        print(f"Priority high: {stats['priority_high']}")
        print(f"Priority med: {stats['priority_med']}")
        print(f"Priority low: {stats['priority_low']}")
        return 0
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

def handle_archive(args):
    storage = TaskStorage()
    try:
        storage.archive_done_tasks()
        return 0
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

def handle_backup(args):
    storage = TaskStorage()
    try:
        storage.backup_database(args.path)
        return 0
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

def handle_export(args):
    storage = TaskStorage()
    try:
        storage.export_tasks(args.path, format=args.format)
        return 0
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

def handle_compact(args):
    storage = TaskStorage()
    try:
        storage.compact_database()
        return 0
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

def handle_search(args):
    storage = TaskStorage()
    try:
        tasks = storage.search_tasks(args.text)
        if not tasks:
            return 0
            
        # Determine if we should use colors
        use_color = sys.stdout.isatty()
        
        for task in tasks:
            print(storage.format_task(task, use_color=use_color))
        return 0
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

def main():
    parser = create_parser()
    args = parser.parse_args()

    # Emit audit line for all commands - this must happen at the very beginning
    command_name = args.command if args.command else 'help'
    print(f"AUDIT {command_name}", file=sys.stderr)
    
    # If no command provided, print help and exit with 0 (success)
    if not args.command:
        parser.print_help()
        return 0

    if args.command == 'add':
        return handle_add(args)
    elif args.command == 'list':
        return handle_list(args)
    elif args.command == 'done':
        return handle_done(args)
    elif args.command == 'delete':
        return handle_delete(args)
    elif args.command == 'edit':
        return handle_edit(args)
    elif args.command == 'stats':
        return handle_stats(args)
    elif args.command == 'archive':
        return handle_archive(args)
    elif args.command == 'backup':
        return handle_backup(args)
    elif args.command == 'export':
        return handle_export(args)
    elif args.command == 'compact':
        return handle_compact(args)
    elif args.command == 'search':
        return handle_search(args)

    return 0

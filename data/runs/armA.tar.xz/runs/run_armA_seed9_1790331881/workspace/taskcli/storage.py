#!/usr/bin/env python3

import os
import sqlite3
import json
import csv
import shutil
import sys
from datetime import datetime, date
from typing import List, Dict, Any
from pathlib import Path

# Configuration
CONFIG_FILE = "config.toml"

class TaskStorage:
    def __init__(self, db_path: str = "tasks.db"):
        self.db_path = db_path
        self.init_database()
        
    def get_config(self) -> Dict[str, Any]:
        """Load configuration from file or environment."""
        config = {}
        
        # Load from config.toml if it exists
        if os.path.exists(CONFIG_FILE):
            try:
                import toml
                config.update(toml.load(CONFIG_FILE))
            except ImportError:
                pass  # Config file ignored if toml not available
        
        # Override with environment variable if present
        if "TASKCLI_TODAY" in os.environ:
            config["today"] = os.environ["TASKCLI_TODAY"]
            
        return config
    
    def get_today(self) -> date:
        """Get today's date, potentially overridden by configuration."""
        config = self.get_config()
        if "today" in config:
            try:
                return datetime.strptime(config["today"], "%Y-%m-%d").date()
            except ValueError:
                # Invalid date format, use actual today
                pass
        return date.today()
    
    def init_database(self):
        """Initialize the database with required tables."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if legacy tasks table exists and migrate data
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='tasks';")
        if cursor.fetchone():
            # Migrate from legacy tasks table to items table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    priority TEXT DEFAULT 'med',
                    due_date TEXT,
                    archived BOOLEAN DEFAULT FALSE,
                    tags TEXT DEFAULT '[]'
                );
            """)
            
            # Migrate existing tasks
            cursor.execute("SELECT * FROM tasks;")
            tasks = cursor.fetchall()
            
            for task in tasks:
                # task[0] is id, [1] is title, [2] is done, [3] is priority, [4] is due_date
                cursor.execute("""
                    INSERT INTO items (id, kind, title, done, priority, due_date, archived)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (task[0], 'task', task[1], task[2], task[3] if task[3] else 'med', 
                      task[4] if task[4] else None, False))
            
            # Drop the old table
            cursor.execute("DROP TABLE tasks;")
        
        # Create items table if it doesn't exist
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY,
                kind TEXT NOT NULL,
                title TEXT NOT NULL,
                done BOOLEAN DEFAULT FALSE,
                priority TEXT DEFAULT 'med',
                due_date TEXT,
                archived BOOLEAN DEFAULT FALSE,
                tags TEXT DEFAULT '[]'
            );
        """)
        
        # Add index on kind for performance
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_kind ON items(kind);")
        
        conn.commit()
        conn.close()
    
    def add_task(self, title: str, priority: str = "med", due_date: str = None, tags: List[str] = None) -> int:
        """Add a new task and return its ID."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get the next available ID
        cursor.execute("SELECT MAX(id) FROM items WHERE kind='task';")
        max_id = cursor.fetchone()[0]
        task_id = (max_id if max_id is not None else 0) + 1
        
        # Insert the new task
        cursor.execute("""
            INSERT INTO items (id, kind, title, priority, due_date, tags)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (task_id, 'task', title, priority, due_date, json.dumps(tags or [])))
        
        conn.commit()
        conn.close()
        return task_id
    
    def _build_list_query(self, sort_by_priority: bool = False, show_overdue: bool = False,
                         show_all: bool = False, filter_tags: List[str] = None) -> tuple:
        """Build the base query for listing tasks."""
        # Build query
        query = "SELECT id, title, done, priority, due_date, archived, tags FROM items WHERE kind='task'"
        params = []
        
        if not show_all:
            query += " AND archived=0"
            
        if filter_tags:
            # Filter by tags - task must have all specified tags
            tag_conditions = []
            for tag in filter_tags:
                tag_conditions.append(f"tags LIKE '%\"{tag}\"%'")
            query += " AND (" + " AND ".join(tag_conditions) + ")"
        
        return query, params
    
    def _sort_tasks(self, tasks: List['Task'], sort_by_priority: bool = False, 
                   show_overdue: bool = False) -> List['Task']:
        """Sort tasks according to specified criteria."""
        today = self.get_today()
        
        if sort_by_priority:
            # Custom priority ordering: high, med, low
            tasks.sort(key=lambda t: (self._priority_order(t.priority), t.id))
        elif show_overdue:
            # Only overdue tasks that are not done
            tasks = [t for t in tasks if t.is_overdue() and not t.done]
            tasks.sort(key=lambda t: (self._priority_order(t.priority), t.id))
        else:
            # Smart list view: overdue first, then by priority, then by ID
            overdue_tasks = [t for t in tasks if t.is_overdue()]
            non_overdue_tasks = [t for t in tasks if not t.is_overdue()]
            
            # Sort overdue by priority then ID, non-overdue by priority then ID
            overdue_tasks.sort(key=lambda t: (self._priority_order(t.priority), t.id))
            non_overdue_tasks.sort(key=lambda t: (self._priority_order(t.priority), t.id))
            
            tasks = overdue_tasks + non_overdue_tasks
        
        return tasks
    
    def list_tasks(self, sort_by_priority: bool = False, show_overdue: bool = False,
                   show_all: bool = False, filter_tags: List[str] = None) -> List['Task']:
        """List all tasks."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        query, params = self._build_list_query(sort_by_priority, show_overdue, show_all, filter_tags)
        
        # Add ordering
        if sort_by_priority:
            # Custom priority ordering: high, med, low
            query = query.replace("ORDER BY id", "ORDER BY CASE priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 ELSE 3 END, id")
        else:
            query += " ORDER BY id"
        
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        tasks = []
        for row in rows:
            task = Task(
                id=row[0],
                title=row[1],
                done=bool(row[2]),
                priority=row[3],
                due_date=row[4],
                archived=bool(row[5]),
                tags=json.loads(row[6]) if row[6] else []
            )
            tasks.append(task)
        
        # Apply sorting logic
        tasks = self._sort_tasks(tasks, sort_by_priority, show_overdue)
        
        conn.close()
        return tasks
    
    def _priority_order(self, priority: str) -> int:
        """Convert priority to numeric order for sorting."""
        priority_map = {"high": 1, "med": 2, "low": 3}
        return priority_map.get(priority, 2)
    
    def mark_done(self, task_id: int):
        """Mark a task as done."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT id FROM items WHERE kind='task' AND id=?", (task_id,))
        if not cursor.fetchone():
            raise ValueError(f"Task with ID {task_id} does not exist")
            
        cursor.execute("UPDATE items SET done=1 WHERE id=? AND kind='task'", (task_id,))
        conn.commit()
        conn.close()
    
    def delete_task(self, task_id: int):
        """Delete a task."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT id FROM items WHERE kind='task' AND id=?", (task_id,))
        if not cursor.fetchone():
            raise ValueError(f"Task with ID {task_id} does not exist")
            
        cursor.execute("DELETE FROM items WHERE id=? AND kind='task'", (task_id,))
        conn.commit()
        conn.close()
    
    def edit_task(self, task_id: int, title: str = None, priority: str = None,
                 due_date: str = None, tags: List[str] = None):
        """Edit an existing task."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT id FROM items WHERE kind='task' AND id=?", (task_id,))
        if not cursor.fetchone():
            raise ValueError(f"Task with ID {task_id} does not exist")
            
        # Build dynamic update query
        updates = []
        params = []
        
        if title is not None:
            updates.append("title=?")
            params.append(title)
            
        if priority is not None:
            updates.append("priority=?")
            params.append(priority)
            
        if due_date is not None:
            updates.append("due_date=?")
            params.append(due_date)
            
        if tags is not None:
            updates.append("tags=?")
            params.append(json.dumps(tags))
        
        if updates:
            query = "UPDATE items SET " + ", ".join(updates) + " WHERE id=? AND kind='task'"
            params.append(task_id)
            cursor.execute(query, params)
            
        conn.commit()
        conn.close()
    
    def get_stats(self) -> Dict[str, int]:
        """Get task statistics."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Total tasks
        cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task' AND archived=0")
        total = cursor.fetchone()[0]
        
        # Done tasks
        cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task' AND done=1 AND archived=0")
        done = cursor.fetchone()[0]
        
        # Pending tasks
        pending = total - done
        
        # Overdue tasks (not done and past due)
        today = self.get_today()
        cursor.execute("""
            SELECT COUNT(*) FROM items 
            WHERE kind='task' AND done=0 AND archived=0 AND due_date IS NOT NULL 
            AND due_date < ?
        """, (today.isoformat(),))
        overdue = cursor.fetchone()[0]
        
        conn.close()
        return {
            "total": total,
            "done": done,
            "pending": pending,
            "overdue": overdue
        }
    
    def archive_task(self, task_id: int):
        """Archive a task."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT id FROM items WHERE kind='task' AND id=?", (task_id,))
        if not cursor.fetchone():
            raise ValueError(f"Task with ID {task_id} does not exist")
            
        cursor.execute("UPDATE items SET archived=1 WHERE id=? AND kind='task'", (task_id,))
        conn.commit()
        conn.close()
    
    def backup_database(self, backup_path: str):
        """Create a backup of the database."""
        try:
            # Create temporary file
            temp_path = backup_path + ".tmp"
            shutil.copy2(self.db_path, temp_path)
            # Atomic move
            os.replace(temp_path, backup_path)
        except Exception as e:
            raise Exception(f"Failed to create backup: {e}")
    
    def export_to_json(self, path: str):
        """Export tasks to a JSON file."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Use the same query logic as list_tasks
        query, params = self._build_list_query()
        query += " ORDER BY id"
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        tasks = []
        for row in rows:
            task = {
                "id": row[0],
                "title": row[1],
                "done": bool(row[2]),
                "priority": row[3],
                "due_date": row[4],
                "archived": bool(row[5]),
                "tags": json.loads(row[6]) if row[6] else []
            }
            tasks.append(task)
        
        with open(path, 'w') as f:
            json.dump(tasks, f, indent=2)
        
        conn.close()
    
    def export_to_csv(self, path: str):
        """Export tasks to a CSV file."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Use the same query logic as list_tasks
        query, params = self._build_list_query()
        query += " ORDER BY id"
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        with open(path, 'w', newline='') as f:
            writer = csv.writer(f)
            # Write header
            writer.writerow(['id', 'title', 'done', 'priority', 'due_date', 'archived', 'tags'])
            
            for row in rows:
                done = str(row[2]).lower()  # Convert boolean to lowercase string
                archived = str(row[5]).lower()  # Convert boolean to lowercase string
                tags = row[6] if row[6] else "[]"
                
                writer.writerow([
                    row[0],  # id
                    row[1],  # title
                    done,    # done
                    row[3],  # priority
                    row[4],  # due_date
                    archived, # archived
                    tags     # tags
                ])
        
        conn.close()
    
    def compact_database(self):
        """Compact the database to reclaim space."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("VACUUM")
        conn.commit()
        conn.close()
    
    def search_tasks(self, text: str) -> List['Task']:
        """Search tasks by title (case-insensitive)."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Search for tasks with titles containing the text (case-insensitive)
        cursor.execute("""
            SELECT id, title, done, priority, due_date, archived, tags 
            FROM items 
            WHERE kind='task' AND LOWER(title) LIKE ?
            ORDER BY id
        """, (f"%{text.lower()}%",))
        
        rows = cursor.fetchall()
        tasks = []
        
        for row in rows:
            task = Task(
                id=row[0],
                title=row[1],
                done=bool(row[2]),
                priority=row[3],
                due_date=row[4],
                archived=bool(row[5]),
                tags=json.loads(row[6]) if row[6] else []
            )
            tasks.append(task)
        
        conn.close()
        return tasks


class Task:
    def __init__(self, id: int, title: str, done: bool = False, priority: str = "med",
                 due_date: str = None, archived: bool = False, tags: List[str] = None):
        self.id = id
        self.title = title
        self.done = done
        self.priority = priority
        self.due_date = due_date
        self.archived = archived
        self.tags = tags or []
    
    def is_overdue(self) -> bool:
        """Check if the task is overdue."""
        if not self.due_date or self.done:
            return False
        
        try:
            due_date = datetime.strptime(self.due_date, "%Y-%m-%d").date()
            today = date.today()
            return due_date < today
        except ValueError:
            # Invalid date format, treat as not overdue
            return False

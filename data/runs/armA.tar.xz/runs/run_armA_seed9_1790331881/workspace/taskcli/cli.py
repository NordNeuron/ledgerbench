#!/usr/bin/env python3

import argparse
import os
import sys
from typing import List

from .storage import TaskStorage, Task


def print_task(task: Task, color: bool = False):
    """Print a single task in list format."""
    if task.done:
        status = "✓"
        if color:
            status = "\033[32m✓\033[0m"  # green
    else:
        status = "○"
        if color and task.is_overdue():
            status = "\033[31m○\033[0m"  # red
    
    print(f"{task.id} {status} {task.title}")


def print_tasks(tasks: List[Task], color: bool = False):
    """Print a list of tasks."""
    for task in tasks:
        print_task(task, color)


def cmd_add(args):
    storage = TaskStorage()
    try:
        task_id = storage.add_task(args.title, args.priority, args.due_date, args.tag)
        print(task_id)
    except Exception as e:
        print(f"Error adding task: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_list(args):
    storage = TaskStorage()
    try:
        tasks = storage.list_tasks(
            sort_by_priority=args.sort == "priority",
            show_overdue=args.overdue,
            show_all=args.all,
            filter_tags=args.tag
        )
        print_tasks(tasks, color=args.color)
    except Exception as e:
        print(f"Error listing tasks: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_done(args):
    storage = TaskStorage()
    try:
        storage.mark_done(args.id)
    except Exception as e:
        print(f"Error marking task done: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_delete(args):
    storage = TaskStorage()
    try:
        storage.delete_task(args.id)
    except Exception as e:
        print(f"Error deleting task: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_edit(args):
    storage = TaskStorage()
    try:
        storage.edit_task(args.id, args.title, args.priority, args.due_date, args.tag)
    except Exception as e:
        print(f"Error editing task: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_stats(args):
    storage = TaskStorage()
    try:
        stats = storage.get_stats()
        print(f"Total: {stats['total']}")
        print(f"Done: {stats['done']}")
        print(f"Pending: {stats['pending']}")
        if stats['overdue'] > 0:
            print(f"\033[31mOverdue: {stats['overdue']}\033[0m")
        else:
            print(f"Overdue: {stats['overdue']}")
    except Exception as e:
        print(f"Error getting stats: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_archive(args):
    storage = TaskStorage()
    try:
        storage.archive_task(args.id)
    except Exception as e:
        print(f"Error archiving task: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_backup(args):
    storage = TaskStorage()
    try:
        storage.backup_database(args.path)
    except Exception as e:
        print(f"Error backing up database: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_export(args):
    storage = TaskStorage()
    try:
        if args.format == "csv":
            storage.export_to_csv(args.path)
        else:
            storage.export_to_json(args.path)
    except Exception as e:
        print(f"Error exporting tasks: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_compact(args):
    storage = TaskStorage()
    try:
        storage.compact_database()
    except Exception as e:
        print(f"Error compacting database: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_search(args):
    storage = TaskStorage()
    try:
        tasks = storage.search_tasks(args.text)
        print_tasks(tasks, color=args.color)
    except Exception as e:
        print(f"Error searching tasks: {e}", file=sys.stderr)
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(
        prog="taskcli",
        description="A minimal command-line task manager.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  taskcli add "Buy milk" --priority high
  taskcli list --sort priority
  taskcli done 1
  taskcli search "milk"
        """
    )
    
    # Global arguments
    parser.add_argument("--color", action="store_true",
                       help="Enable colored output (only when stdout is a TTY)")
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--priority", choices=["low", "med", "high"], default="med",
                           help="Task priority (default: med)")
    add_parser.add_argument("--due-date", dest="due_date", help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--tag", action="append", help="Add a tag to the task")

    # List command
    list_parser = subparsers.add_parser("list", help="List all tasks")
    list_parser.add_argument("--sort", choices=["priority"], help="Sort by priority")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks too")
    list_parser.add_argument("--tag", action="append", help="Filter by tag")
    
    # Done command
    done_parser = subparsers.add_parser("done", help="Mark a task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Edit command
    edit_parser = subparsers.add_parser("edit", help="Edit an existing task")
    edit_parser.add_argument("id", type=int, help="Task ID to edit")
    edit_parser.add_argument("--title", help="New title")
    edit_parser.add_argument("--priority", choices=["low", "med", "high"], 
                            help="New priority")
    edit_parser.add_argument("--due-date", dest="due_date", help="New due date in YYYY-MM-DD format")
    edit_parser.add_argument("--tag", action="append", help="Add a tag to the task")

    # Stats command
    subparsers.add_parser("stats", help="Show task statistics")

    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive a task")
    archive_parser.add_argument("id", type=int, help="Task ID to archive")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup the database")
    backup_parser.add_argument("path", help="Path to backup file")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks to file")
    export_parser.add_argument("path", help="Path to export file")
    export_parser.add_argument("--format", choices=["json", "csv"], default="json",
                              help="Export format (default: json)")

    # Compact command
    subparsers.add_parser("compact", help="Compact the database")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Text to search for in task titles")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 0

    # Emit audit line
    print(f"AUDIT {args.command}", file=sys.stderr)

    # Handle color option
    if not sys.stdout.isatty():
        args.color = False

    # Dispatch command
    if args.command == "add":
        cmd_add(args)
    elif args.command == "list":
        cmd_list(args)
    elif args.command == "done":
        cmd_done(args)
    elif args.command == "delete":
        cmd_delete(args)
    elif args.command == "edit":
        cmd_edit(args)
    elif args.command == "stats":
        cmd_stats(args)
    elif args.command == "archive":
        cmd_archive(args)
    elif args.command == "backup":
        cmd_backup(args)
    elif args.command == "export":
        cmd_export(args)
    elif args.command == "compact":
        cmd_compact(args)
    elif args.command == "search":
        cmd_search(args)

    return 0

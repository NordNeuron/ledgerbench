#!/usr/bin/env python3

import argparse
import os
import sys
from .storage import TaskStorage
from . import __version__

def create_parser():
    parser = argparse.ArgumentParser(
        prog='taskcli',
        description='A minimal command-line task manager.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  taskcli add "Buy milk"
  taskcli list
  taskcli done 1
  taskcli delete 1
  taskcli search "milk"
        """
    )
    parser.add_argument('--version', action='version', version=f'%(prog)s {__version__}')
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['low', 'med', 'high'], default='med',
                           help='Task priority (default: med)')
    add_parser.add_argument('--due', help='Due date (YYYY-MM-DD)')
    add_parser.add_argument('--tag', action='append', help='Add a tag (can be used multiple times)')

    # List command
    list_parser = subparsers.add_parser('list', help='List all tasks')
    list_parser.add_argument('--sort', choices=['id', 'priority'], help='Sort by field')
    list_parser.add_argument('--tag', help='Show only tasks with this tag')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')
    list_parser.add_argument('--all', action='store_true', help='Show archived tasks too')
    list_parser.add_argument('--color', action='store_true', help='Enable colored output')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Edit command
    edit_parser = subparsers.add_parser('edit', help='Edit a task')
    edit_parser.add_argument('id', type=int, help='Task ID')
    edit_parser.add_argument('--title', required=True, help='New title for the task')

    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show task statistics')

    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive completed tasks')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Create a backup of the database')
    backup_parser.add_argument('path', help='Backup file path')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export all tasks')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json',
                              help='Export format (default: json)')

    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Compact the database')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search for tasks by title')
    search_parser.add_argument('text', help='Text to search for in task titles')

    return parser

def main():
    parser = create_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 0

    # Emit audit line immediately
    print(f"AUDIT {args.command}", file=sys.stderr)
    
    storage = TaskStorage()
    
    try:
        if args.command == 'add':
            task_id = storage.add_task(
                title=args.title,
                priority=args.priority,
                due=args.due,
                tags=args.tag or []
            )
            print(task_id)
            
        elif args.command == 'list':
            tasks = storage.list_tasks(
                sort_by=args.sort,
                tag_filter=args.tag,
                overdue_only=args.overdue,
                show_archived=args.all
            )
            storage.print_tasks(tasks, color=args.color)
            
        elif args.command == 'done':
            storage.mark_done(args.id)
            
        elif args.command == 'delete':
            storage.delete_task(args.id)
            
        elif args.command == 'edit':
            storage.edit_task(args.id, title=args.title)
            
        elif args.command == 'stats':
            storage.print_stats()
            
        elif args.command == 'archive':
            storage.archive_tasks()
            
        elif args.command == 'backup':
            storage.backup_database(args.path)
            
        elif args.command == 'export':
            storage.export_tasks(args.path, format=args.format)
            
        elif args.command == 'compact':
            storage.compact_database()
            
        elif args.command == 'search':
            tasks = storage.search_tasks(args.text)
            storage.print_tasks(tasks, color=False)  # No color for search output
            
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    return 0

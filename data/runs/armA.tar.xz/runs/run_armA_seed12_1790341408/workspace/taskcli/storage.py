#!/usr/bin/env python3

import json
import os
import sqlite3
import sys
import csv
import shutil
from datetime import datetime, date
from typing import List, Optional, Tuple
import toml

# Default database file name
DB_FILE = 'tasks.db'

# Default priority from config
DEFAULT_PRIORITY = 'med'

class TaskStorage:
    def __init__(self, db_file: str = DB_FILE):
        self.db_file = db_file
        self._ensure_database()
        
    def _get_config(self) -> dict:
        """Get configuration from config.toml if it exists."""
        config = {}
        try:
            with open('config.toml', 'r') as f:
                config = toml.load(f)
        except FileNotFoundError:
            pass
        return config
    
    def _ensure_database(self):
        """Ensure the database exists with proper schema."""
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        
        # Check if old tasks table exists and migrate
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='tasks'")
        if cursor.fetchone():
            # Migrate from old schema
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    priority TEXT DEFAULT 'med',
                    due DATE,
                    archived BOOLEAN DEFAULT FALSE,
                    kind TEXT DEFAULT 'task'
                )
            """)
            
            # Migrate data
            cursor.execute("""
                INSERT INTO items (id, title, done, priority, due, archived, kind)
                SELECT id, title, done, priority, due, archived, 'task' 
                FROM tasks
            """)
            
            # Drop old table
            cursor.execute("DROP TABLE tasks")
            
        else:
            # Create new schema if needed
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    priority TEXT DEFAULT 'med',
                    due DATE,
                    archived BOOLEAN DEFAULT FALSE,
                    kind TEXT DEFAULT 'task'
                )
            """)
            
        conn.commit()
        conn.close()
    
    def _get_today(self) -> date:
        """Get today's date, potentially overridden by config or environment."""
        # Check config first
        config = self._get_config()
        if 'today' in config:
            return datetime.strptime(config['today'], '%Y-%m-%d').date()
        
        # Check environment variable
        today_env = os.environ.get('TASKCLI_TODAY')
        if today_env:
            return datetime.strptime(today_env, '%Y-%m-%d').date()
            
        # Default to current date
        return date.today()
    
    def _build_task_query(self, sort_by: Optional[str] = None, tag_filter: Optional[str] = None,
                         overdue_only: bool = False, show_archived: bool = False) -> Tuple[str, List]:
        """Build a query for tasks with appropriate filters and ordering."""
        # Base query
        query = "SELECT id, title, done, priority, due, archived FROM items WHERE kind='task'"
        params = []
        
        # Filter by archived status
        if not show_archived:
            query += " AND archived=0"
            
        # Add ordering
        if sort_by == 'priority':
            query += " ORDER BY CASE priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 ELSE 3 END"
        else:
            query += " ORDER BY id"
            
        return query, params
    
    def _apply_overdue_filter(self, tasks: List[dict]) -> List[dict]:
        """Apply overdue filter to a list of tasks."""
        today = self._get_today()
        overdue_tasks = []
        
        for task in tasks:
            if not task['done'] and task['due']:
                due_date = datetime.strptime(task['due'], '%Y-%m-%d').date()
                if due_date < today:
                    overdue_tasks.append(task)
        return overdue_tasks
    
    def add_task(self, title: str, priority: str = 'med', due: Optional[str] = None, 
                tags: List[str] = None) -> int:
        """Add a new task and return its ID."""
        if due:
            try:
                datetime.strptime(due, '%Y-%m-%d')
            except ValueError:
                raise ValueError(f"Invalid date format: {due}. Use YYYY-MM-DD.")
        
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        
        # Get next ID
        cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items")
        task_id = cursor.fetchone()[0]
        
        # Insert task
        cursor.execute("""
            INSERT INTO items (id, title, priority, due, kind)
            VALUES (?, ?, ?, ?, ?)
        """, (task_id, title, priority, due, 'task'))
        
        conn.commit()
        conn.close()
        
        return task_id
    
    def list_tasks(self, sort_by: Optional[str] = None, tag_filter: Optional[str] = None,
                   overdue_only: bool = False, show_archived: bool = False) -> List[dict]:
        """List all tasks."""
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        
        query, params = self._build_task_query(sort_by, tag_filter, overdue_only, show_archived)
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        tasks = []
        for row in rows:
            task = {
                'id': row[0],
                'title': row[1],
                'done': row[2],
                'priority': row[3],
                'due': row[4],
                'archived': row[5]
            }
            tasks.append(task)
        
        # Apply overdue filter if requested
        if overdue_only:
            tasks = self._apply_overdue_filter(tasks)
            
        conn.close()
        return tasks
    
    def mark_done(self, task_id: int):
        """Mark a task as done."""
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        
        cursor.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
        if not cursor.fetchone():
            raise ValueError(f"Task with ID {task_id} not found.")
            
        cursor.execute("UPDATE items SET done=1 WHERE id=?", (task_id,))
        conn.commit()
        conn.close()
    
    def delete_task(self, task_id: int):
        """Delete a task."""
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        
        cursor.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
        if not cursor.fetchone():
            raise ValueError(f"Task with ID {task_id} not found.")
            
        cursor.execute("DELETE FROM items WHERE id=?", (task_id,))
        conn.commit()
        conn.close()
    
    def edit_task(self, task_id: int, title: str):
        """Edit a task's title."""
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        
        cursor.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
        if not cursor.fetchone():
            raise ValueError(f"Task with ID {task_id} not found.")
            
        cursor.execute("UPDATE items SET title=? WHERE id=?", (title, task_id))
        conn.commit()
        conn.close()
    
    def print_tasks(self, tasks: List[dict], color: bool = False):
        """Print tasks in list format."""
        if not tasks:
            return
            
        # Determine if we're outputting to a TTY for color support
        is_tty = sys.stdout.isatty()
        
        for task in tasks:
            # Format priority
            priority_str = f"(priority: {task['priority']})"
            
            # Format due date
            due_str = f" (due: {task['due']})" if task['due'] else ""
            
            # Format title with tags (simplified)
            title_str = task['title']
            
            # Build status string
            status = "✓" if task['done'] else "○"
            
            # Color codes
            red = "\033[31m" if is_tty and color else ""
            green = "\033[32m" if is_tty and color else ""
            reset = "\033[0m" if is_tty and color else ""
            
            # Apply colors
            if task['done']:
                status = f"{green}{status}{reset}"
            elif task['due']:
                today = self._get_today()
                due_date = datetime.strptime(task['due'], '%Y-%m-%d').date()
                if due_date < today:
                    status = f"{red}{status}{reset}"
            
            print(f"{task['id']:>4}  {status}  {title_str} {priority_str}{due_str}")
    
    def print_stats(self):
        """Print task statistics."""
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        
        # Total tasks
        cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task'")
        total = cursor.fetchone()[0]
        
        # Done tasks
        cursor.execute("SELECT COUNT(*) FROM items WHERE done=1 AND kind='task'")
        done = cursor.fetchone()[0]
        
        # Open tasks
        open_tasks = total - done
        
        # Priority counts
        priorities = ['high', 'med', 'low']
        priority_counts = {}
        for prio in priorities:
            cursor.execute("SELECT COUNT(*) FROM items WHERE priority=? AND kind='task'", (prio,))
            priority_counts[prio] = cursor.fetchone()[0]
        
        print(f"Total: {total}")
        print(f"Done: {done}")
        print(f"Open: {open_tasks}")
        for prio in priorities:
            print(f"Priority {prio}: {priority_counts[prio]}")
            
        conn.close()
    
    def archive_tasks(self):
        """Archive completed tasks."""
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        
        cursor.execute("UPDATE items SET archived=1 WHERE done=1 AND kind='task'")
        conn.commit()
        conn.close()
    
    def backup_database(self, backup_path: str):
        """Create a backup of the database."""
        try:
            # Create temporary file
            temp_path = f"{backup_path}.tmp"
            shutil.copy2(self.db_file, temp_path)
            
            # Atomically replace original
            os.replace(temp_path, backup_path)
        except Exception as e:
            raise Exception(f"Failed to create backup: {e}")
    
    def export_tasks(self, export_path: str, format: str = 'json'):
        """Export all tasks to file."""
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        
        # Use the same query logic as list_tasks but without filtering
        query, params = self._build_task_query()
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        tasks = []
        for row in rows:
            task = {
                'id': row[0],
                'title': row[1],
                'done': row[2],
                'priority': row[3],
                'due': row[4],
                'archived': row[5]
            }
            tasks.append(task)
        
        if format == 'json':
            with open(export_path, 'w') as f:
                json.dump(tasks, f, indent=2)
        elif format == 'csv':
            with open(export_path, 'w', newline='') as f:
                if tasks:
                    writer = csv.DictWriter(f, fieldnames=tasks[0].keys())
                    writer.writeheader()
                    writer.writerows(tasks)
        
        conn.close()
    
    def compact_database(self):
        """Compact the database to reclaim space."""
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        cursor.execute("VACUUM")
        conn.commit()
        conn.close()
    
    def search_tasks(self, text: str) -> List[dict]:
        """Search for tasks by title (case-insensitive)."""
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        
        # Search for tasks containing the text in title (case-insensitive)
        cursor.execute("""
            SELECT id, title, done, priority, due, archived 
            FROM items 
            WHERE kind='task' AND LOWER(title) LIKE LOWER(?)
            ORDER BY id
        """, (f'%{text}%',))
        
        rows = cursor.fetchall()
        tasks = []
        for row in rows:
            task = {
                'id': row[0],
                'title': row[1],
                'done': row[2],
                'priority': row[3],
                'due': row[4],
                'archived': row[5]
            }
            tasks.append(task)
            
        conn.close()
        return tasks

import json
import os
import sqlite3
import sys
import shutil
from datetime import datetime, date
from pathlib import Path

class TaskStorage:
    def __init__(self, db_path='tasks.db'):
        self.db_path = db_path
        self.init_db()
        
    def init_db(self):
        """Initialize the database with proper schema."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if we have an old 'tasks' table that needs migration
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='tasks'")
        if cursor.fetchone():
            # Migrate from old schema to new schema
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    priority TEXT DEFAULT 'med',
                    due DATE,
                    archived BOOLEAN DEFAULT FALSE,
                    kind TEXT NOT NULL DEFAULT 'task'
                )
            """)
            
            # Migrate existing data
            cursor.execute("""
                INSERT INTO items (id, title, done, priority, due, archived, kind)
                SELECT id, title, done, priority, due, archived, 'task' 
                FROM tasks
            """)
            
            # Drop the old table
            cursor.execute("DROP TABLE tasks")
            
        else:
            # Create new schema if needed
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    priority TEXT DEFAULT 'med',
                    due DATE,
                    archived BOOLEAN DEFAULT FALSE,
                    kind TEXT NOT NULL DEFAULT 'task'
                )
            """)
            
        conn.commit()
        conn.close()
        
    def get_next_id(self):
        """Get the next available task ID."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items WHERE kind='task'")
        next_id = cursor.fetchone()[0]
        conn.close()
        return next_id
        
    def add_task(self, title, priority='med', due=None):
        """Add a new task and return its ID."""
        if due:
            try:
                datetime.strptime(due, '%Y-%m-%d')
            except ValueError:
                raise ValueError("Invalid date format. Use YYYY-MM-DD.")
                
        task_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO items (id, title, priority, due, kind) 
            VALUES (?, ?, ?, ?, 'task')
        """, (task_id, title, priority, due))
        conn.commit()
        conn.close()
        
        return task_id
        
    def get_tasks_for_display(self, sort_by='id', show_archived=False, overdue_only=False):
        """Get tasks formatted for display in list command."""
        # Get base query
        tasks = self._get_tasks_query(show_archived=show_archived)
        
        # Apply filtering if needed
        if overdue_only:
            tasks = [task for task in tasks if self.is_overdue(task['id'])]
            
        # Apply sorting
        if sort_by == 'priority':
            # Custom ordering: high -> med -> low
            tasks.sort(key=lambda x: (
                0 if x['priority'] == 'high' else
                1 if x['priority'] == 'med' else
                2 if x['priority'] == 'low' else
                3,
                x['id']
            ))
        else:
            tasks.sort(key=lambda x: x['id'])
            
        return tasks
        
    def get_tasks_for_export(self, show_archived=False):
        """Get tasks formatted for export."""
        return self._get_tasks_query(show_archived=show_archived)
        
    def _get_tasks_query(self, show_archived=False):
        """Internal method to get all tasks with common query logic."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Build base query
        query = "SELECT id, title, done, priority, due, archived FROM items WHERE kind='task'"
        params = []
        
        if not show_archived:
            query += " AND archived = FALSE"
            
        cursor.execute(query, params)
        rows = cursor.fetchall()
        conn.close()
        
        tasks = []
        for row in rows:
            task = {
                'id': row[0],
                'title': row[1],
                'done': bool(row[2]),
                'priority': row[3],
                'due': row[4],
                'archived': bool(row[5])
            }
            tasks.append(task)
            
        return tasks
        
    def task_exists(self, task_id):
        """Check if a task with the given ID exists."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT 1 FROM items WHERE id=? AND kind='task'", (task_id,))
        exists = cursor.fetchone() is not None
        conn.close()
        return exists
        
    def mark_done(self, task_id):
        """Mark a task as done."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("UPDATE items SET done=TRUE WHERE id=? AND kind='task'", (task_id,))
        conn.commit()
        conn.close()
        
    def delete_task(self, task_id):
        """Delete a task."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM items WHERE id=? AND kind='task'", (task_id,))
        conn.commit()
        conn.close()
        
    def edit_task(self, task_id, title=None):
        """Edit a task's title."""
        if title is None:
            return
            
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("UPDATE items SET title=? WHERE id=? AND kind='task'", (title, task_id))
        conn.commit()
        conn.close()
        
    def get_stats(self):
        """Get task statistics."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Total tasks
        cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task'")
        total = cursor.fetchone()[0]
        
        # Done tasks
        cursor.execute("SELECT COUNT(*) FROM items WHERE done=TRUE AND kind='task'")
        done = cursor.fetchone()[0]
        
        # Open tasks (not done and not archived)
        cursor.execute("SELECT COUNT(*) FROM items WHERE done=FALSE AND archived=FALSE AND kind='task'")
        open_count = cursor.fetchone()[0]
        
        # Priority counts
        cursor.execute("SELECT COUNT(*) FROM items WHERE priority='high' AND kind='task'")
        priority_high = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM items WHERE priority='med' AND kind='task'")
        priority_med = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM items WHERE priority='low' AND kind='task'")
        priority_low = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            'total': total,
            'done': done,
            'open': open_count,
            'priority_high': priority_high,
            'priority_med': priority_med,
            'priority_low': priority_low
        }
        
    def archive_done_tasks(self):
        """Archive all done tasks."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("UPDATE items SET archived=TRUE WHERE done=TRUE AND kind='task'")
        conn.commit()
        conn.close()
        
    def is_overdue(self, task_id):
        """Check if a task is overdue."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT due FROM items 
            WHERE id=? AND kind='task' AND done=FALSE AND archived=FALSE
        """, (task_id,))
        result = cursor.fetchone()
        conn.close()
        
        if not result or not result[0]:
            return False
            
        due_date_str = result[0]
        try:
            due_date = datetime.strptime(due_date_str, '%Y-%m-%d').date()
            today_str = os.environ.get('TASKCLI_TODAY', str(date.today()))
            today = datetime.strptime(today_str, '%Y-%m-%d').date()
            return due_date < today
        except ValueError:
            return False
            
    def backup_database(self, backup_path):
        """Create a backup of the database."""
        try:
            # Create temporary backup file
            temp_backup = f"{backup_path}.tmp"
            shutil.copy2(self.db_path, temp_backup)
            # Atomically replace the target file
            os.replace(temp_backup, backup_path)
        except Exception as e:
            raise Exception(f"Failed to create backup: {e}")
            
    def compact_database(self):
        """Reclaim space from deleted tasks."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("VACUUM")
        conn.commit()
        conn.close()
        
    def search_tasks(self, text):
        """Search for tasks by title (case-insensitive)."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Search for tasks with titles containing the text (case-insensitive)
        query = """
            SELECT id, title, done, priority, due, archived 
            FROM items 
            WHERE kind='task' AND LOWER(title) LIKE ?
            ORDER BY id
        """
        cursor.execute(query, (f'%{text.lower()}%',))
        rows = cursor.fetchall()
        conn.close()
        
        tasks = []
        for row in rows:
            task = {
                'id': row[0],
                'title': row[1],
                'done': bool(row[2]),
                'priority': row[3],
                'due': row[4],
                'archived': bool(row[5])
            }
            tasks.append(task)
            
        return tasks

import argparse
import os
import sys
import json
from .storage import TaskStorage

def create_parser():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['low', 'med', 'high'], default='med',
                           help='Task priority (default: med)')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')

    # List command
    list_parser = subparsers.add_parser('list', help='List all tasks')
    list_parser.add_argument('--sort', choices=['id', 'priority'], default='id',
                            help='Sort order (default: id)')
    list_parser.add_argument('--overdue', action='store_true',
                            help='Show only overdue tasks')
    list_parser.add_argument('--all', action='store_true',
                            help='Show archived tasks too')
    list_parser.add_argument('--color', action='store_true',
                            help='Enable colored output')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Edit command
    edit_parser = subparsers.add_parser('edit', help='Edit a task')
    edit_parser.add_argument('id', type=int, help='Task ID')
    edit_parser.add_argument('--title', required=True, help='New title')

    # Stats command
    subparsers.add_parser('stats', help='Show task statistics')

    # Archive command
    subparsers.add_parser('archive', help='Archive all done tasks')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Create a backup of the database')
    backup_parser.add_argument('path', help='Backup file path')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks as JSON')
    export_parser.add_argument('path', help='Export file path')

    # Compact command
    subparsers.add_parser('compact', help='Reclaim space from deleted tasks')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search for tasks by title')
    search_parser.add_argument('text', help='Search text')

    return parser

def handle_add(args):
    storage = TaskStorage()
    try:
        task_id = storage.add_task(args.title, args.priority, args.due)
        print(task_id)
    except ValueError as e:
        sys.stderr.write(f"Error: {e}\n")
        return 2
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1

def handle_list(args):
    storage = TaskStorage()
    try:
        # Use the same query path for listing tasks
        tasks = storage.get_tasks_for_display(
            sort_by=args.sort,
            show_archived=args.all,
            overdue_only=args.overdue
        )
        
        if not tasks:
            return 0
            
        # Print tasks in list format
        for task in tasks:
            done_str = "✓" if task['done'] else "✗"
            priority_str = f" (priority: {task['priority']})" if task['priority'] else ""
            due_str = f" (due: {task['due']})" if task['due'] else ""
            archived_str = " [archived]" if task.get('archived', False) else ""
            
            # Color handling
            color_code = ""
            reset_code = ""
            if args.color and sys.stdout.isatty():
                if storage.is_overdue(task['id']):
                    color_code = "\033[31m"  # Red for overdue
                    reset_code = "\033[0m"
                elif task['done']:
                    color_code = "\033[32m"  # Green for done
                    reset_code = "\033[0m"
            
            print(f"{color_code}{task['id']}: [{done_str}] {task['title']}{priority_str}{due_str}{archived_str}{reset_code}")
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1

def handle_done(args):
    storage = TaskStorage()
    try:
        if not storage.task_exists(args.id):
            sys.stderr.write(f"Error: No task with id {args.id}\n")
            return 2
        storage.mark_done(args.id)
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1

def handle_delete(args):
    storage = TaskStorage()
    try:
        if not storage.task_exists(args.id):
            sys.stderr.write(f"Error: No task with id {args.id}\n")
            return 2
        storage.delete_task(args.id)
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1

def handle_edit(args):
    storage = TaskStorage()
    try:
        if not storage.task_exists(args.id):
            sys.stderr.write(f"Error: No task with id {args.id}\n")
            return 2
        storage.edit_task(args.id, title=args.title)
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1

def handle_stats(args):
    storage = TaskStorage()
    try:
        stats = storage.get_stats()
        print(f"Total: {stats['total']}")
        print(f"Done: {stats['done']}")
        print(f"Open: {stats['open']}")
        print(f"Priority high: {stats['priority_high']}")
        print(f"Priority med: {stats['priority_med']}")
        print(f"Priority low: {stats['priority_low']}")
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1

def handle_archive(args):
    storage = TaskStorage()
    try:
        storage.archive_done_tasks()
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1

def handle_backup(args):
    storage = TaskStorage()
    try:
        storage.backup_database(args.path)
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1

def handle_export(args):
    storage = TaskStorage()
    try:
        # Use the same query path for exporting tasks
        tasks = storage.get_tasks_for_export(show_archived=True)
        
        # Export in JSON format (same as original storage format)
        export_data = []
        for task in tasks:
            export_task = {
                'id': task['id'],
                'title': task['title'],
                'done': task['done'],
                'priority': task['priority'],
                'due': task['due']
            }
            # Only include due date if it exists
            if not task['due']:
                export_task.pop('due', None)
            export_data.append(export_task)
            
        with open(args.path, 'w') as f:
            json.dump(export_data, f, indent=2)
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1

def handle_compact(args):
    storage = TaskStorage()
    try:
        storage.compact_database()
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1

def handle_search(args):
    storage = TaskStorage()
    try:
        tasks = storage.search_tasks(args.text)
        if not tasks:
            return 0
            
        # Print tasks in list format
        for task in tasks:
            done_str = "✓" if task['done'] else "✗"
            priority_str = f" (priority: {task['priority']})" if task['priority'] else ""
            due_str = f" (due: {task['due']})" if task['due'] else ""
            archived_str = " [archived]" if task.get('archived', False) else ""
            
            print(f"{task['id']}: [{done_str}] {task['title']}{priority_str}{due_str}{archived_str}")
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1

def main():
    parser = create_parser()
    args = parser.parse_args()

    # Emit audit line to stderr
    command_name = args.command if args.command else 'help'
    sys.stderr.write(f"AUDIT {command_name}\n")

    if not args.command:
        parser.print_help()
        return 1

    # Dispatch to appropriate handler
    if args.command == 'add':
        return handle_add(args)
    elif args.command == 'list':
        return handle_list(args)
    elif args.command == 'done':
        return handle_done(args)
    elif args.command == 'delete':
        return handle_delete(args)
    elif args.command == 'edit':
        return handle_edit(args)
    elif args.command == 'stats':
        return handle_stats(args)
    elif args.command == 'archive':
        return handle_archive(args)
    elif args.command == 'backup':
        return handle_backup(args)
    elif args.command == 'export':
        return handle_export(args)
    elif args.command == 'compact':
        return handle_compact(args)
    elif args.command == 'search':
        return handle_search(args)
    
    return 1

import os
import json
import sqlite3
import shutil
import csv
from datetime import datetime, date
from pathlib import Path

class Storage:
    def __init__(self, db_path='tasks.db'):
        self.db_path = db_path
        self.init_db()
        
    def init_db(self):
        """Initialize the database with required tables."""
        # Check if we have an old tasks.json file to migrate
        json_path = 'tasks.json'
        if os.path.exists(json_path) and not os.path.exists(self.db_path):
            self.migrate_from_json(json_path)
            
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if we have an old tasks table that needs to be migrated
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='tasks'")
        if cursor.fetchone():
            # Migrate from old tasks table to items table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    priority TEXT,
                    due_date TEXT,
                    archived BOOLEAN DEFAULT FALSE,
                    kind TEXT NOT NULL DEFAULT 'task'
                )
            """)
            
            # Copy data from tasks to items
            cursor.execute("""
                INSERT INTO items (id, title, done, priority, due_date, archived, kind)
                SELECT id, title, done, priority, due_date, archived, 'task' 
                FROM tasks
            """)
            
            # Drop the old table
            cursor.execute("DROP TABLE tasks")
            
        else:
            # Create new items table if it doesn't exist
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    priority TEXT,
                    due_date TEXT,
                    archived BOOLEAN DEFAULT FALSE,
                    kind TEXT NOT NULL DEFAULT 'task'
                )
            """)
            
        # Create tags table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS task_tags (
                task_id INTEGER,
                tag TEXT,
                FOREIGN KEY (task_id) REFERENCES items (id)
            )
        """)
        
        conn.commit()
        conn.close()
        
    def migrate_from_json(self, json_path):
        """Migrate tasks from JSON file to SQLite database."""
        try:
            with open(json_path, 'r') as f:
                tasks = json.load(f)
                
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            for task in tasks:
                # Handle missing fields gracefully
                priority = task.get('priority', 'med')
                due_date = task.get('due', None)
                done = task.get('done', False)
                archived = task.get('archived', False)
                
                cursor.execute("""
                    INSERT INTO items (id, title, done, priority, due_date, archived, kind)
                    VALUES (?, ?, ?, ?, ?, ?, 'task')
                """, (task['id'], task['title'], done, priority, due_date, archived))
                
                # Handle tags if present
                tags = task.get('tags', [])
                for tag in tags:
                    cursor.execute("""
                        INSERT INTO task_tags (task_id, tag)
                        VALUES (?, ?)
                    """, (task['id'], tag))
                    
            conn.commit()
            conn.close()
            
            # Remove the old JSON file
            os.remove(json_path)
            
        except Exception as e:
            raise Exception(f"Failed to migrate from JSON: {e}")

    def get_next_id(self):
        """Get the next available task ID."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items")
        next_id = cursor.fetchone()[0]
        conn.close()
        return next_id

    def add_task(self, title, priority='med', due_date=None, tags=None):
        """Add a new task and return its ID."""
        if due_date:
            try:
                datetime.strptime(due_date, '%Y-%m-%d')
            except ValueError:
                raise Exception("Invalid date format. Use YYYY-MM-DD.")
                
        task_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO items (id, title, priority, due_date, kind)
            VALUES (?, ?, ?, ?, 'task')
        """, (task_id, title, priority, due_date))
        
        # Add tags if provided
        if tags:
            for tag in tags:
                cursor.execute("""
                    INSERT INTO task_tags (task_id, tag)
                    VALUES (?, ?)
                """, (task_id, tag))
                
        conn.commit()
        conn.close()
        return task_id

    def _build_list_query(self, sort_by='id', overdue=False, show_archived=False, tags=None):
        """Build the base query for listing tasks."""
        # Build base query
        query = """
            SELECT i.id, i.title, i.done, i.priority, i.due_date, i.archived,
                   GROUP_CONCAT(t.tag) as tags
            FROM items i
            LEFT JOIN task_tags t ON i.id = t.task_id
        """
        
        # Add conditions
        where_conditions = ["i.kind = 'task'"]
        params = []
        
        if not show_archived:
            where_conditions.append("i.archived = FALSE")
            
        if overdue:
            today_str = os.environ.get('TASKCLI_TODAY', str(date.today()))
            where_conditions.append("i.due_date < ? AND i.done = FALSE")
            params.append(today_str)
            
        if tags:
            # Join with task_tags for tag filtering
            query += " JOIN task_tags tt ON i.id = tt.task_id"
            where_conditions.append("tt.tag IN ({})".format(','.join('?' * len(tags))))
            params.extend(tags)
            
        query += " WHERE " + " AND ".join(where_conditions) if where_conditions else ""
        
        # Add grouping
        query += " GROUP BY i.id, i.title, i.done, i.priority, i.due_date, i.archived"
        
        return query, params

    def list_tasks(self, sort_by='id', overdue=False, show_archived=False, tags=None):
        """List all tasks."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Build the base query
        query, params = self._build_list_query(sort_by, overdue, show_archived, tags)
        
        # Add ordering
        if sort_by == 'priority':
            # Order by priority (high, med, low) then by id
            priority_order = {"high": 0, "med": 1, "low": 2}
            query += """
                ORDER BY 
                    CASE WHEN i.priority IS NULL THEN 1 ELSE 0 END,
                    CASE i.priority 
                        WHEN 'high' THEN 0 
                        WHEN 'med' THEN 1 
                        WHEN 'low' THEN 2 
                        ELSE 3 
                    END,
                    i.id
            """
        else:
            query += " ORDER BY i.id"
            
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        # Process results and add overdue flag for smart view
        tasks = []
        today = os.environ.get('TASKCLI_TODAY', str(date.today()))
        today_date = datetime.strptime(today, '%Y-%m-%d').date()
        
        for row in rows:
            task = {
                'id': row[0],
                'title': row[1],
                'done': bool(row[2]),
                'priority': row[3],
                'due_date': row[4],
                'archived': bool(row[5]),
                'tags': [t for t in (row[6] or '').split(',') if t] if row[6] else []
            }
            
            # Add overdue flag for smart view
            if task['due_date'] and not task['done']:
                due_date = datetime.strptime(task['due_date'], '%Y-%m-%d').date()
                task['overdue'] = due_date < today_date
            else:
                task['overdue'] = False
                
            tasks.append(task)
            
        conn.close()
        return tasks

    def mark_done(self, task_id):
        """Mark a task as done."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("UPDATE items SET done = TRUE WHERE id = ? AND kind = 'task'", (task_id,))
        
        if cursor.rowcount == 0:
            conn.close()
            raise Exception(f"Task with ID {task_id} not found")
            
        conn.commit()
        conn.close()

    def delete_task(self, task_id):
        """Delete a task."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM items WHERE id = ? AND kind = 'task'", (task_id,))
        
        if cursor.rowcount == 0:
            conn.close()
            raise Exception(f"Task with ID {task_id} not found")
            
        conn.commit()
        conn.close()

    def edit_task(self, task_id, title=None):
        """Edit a task."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if title is not None:
            cursor.execute("UPDATE items SET title = ? WHERE id = ? AND kind = 'task'", (title, task_id))
            
        if cursor.rowcount == 0:
            conn.close()
            raise Exception(f"Task with ID {task_id} not found")
            
        conn.commit()
        conn.close()

    def get_stats(self):
        """Get task statistics."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Total tasks
        cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task'")
        total = cursor.fetchone()[0]
        
        # Done tasks
        cursor.execute("SELECT COUNT(*) FROM items WHERE done = TRUE AND kind = 'task'")
        done = cursor.fetchone()[0]
        
        # Open tasks
        open_tasks = total - done
        
        # Priority counts
        priority_counts = {'high': 0, 'med': 0, 'low': 0}
        cursor.execute("""
            SELECT priority, COUNT(*) 
            FROM items 
            WHERE kind = 'task' AND priority IS NOT NULL
            GROUP BY priority
        """)
        
        for priority, count in cursor.fetchall():
            if priority in priority_counts:
                priority_counts[priority] = count
                
        conn.close()
        
        return {
            'total': total,
            'done': done,
            'open': open_tasks,
            'priority': priority_counts
        }

    def archive_task(self, task_id):
        """Archive a task."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("UPDATE items SET archived = TRUE WHERE id = ? AND kind = 'task'", (task_id,))
        
        if cursor.rowcount == 0:
            conn.close()
            raise Exception(f"Task with ID {task_id} not found")
            
        conn.commit()
        conn.close()

    def backup(self, backup_path):
        """Create a backup of the database."""
        # Create temporary file
        temp_path = f"{backup_path}.tmp"
        
        try:
            shutil.copy2(self.db_path, temp_path)
            os.rename(temp_path, backup_path)
        except Exception as e:
            # Clean up temp file if something goes wrong
            if os.path.exists(temp_path):
                os.remove(temp_path)
            raise Exception(f"Backup failed: {e}")

    def export_tasks(self, export_path, format='json'):
        """Export tasks to a file."""
        # Use the same query logic as list_tasks for consistency
        tasks = self.list_tasks(show_archived=True)
        
        if format == 'json':
            with open(export_path, 'w') as f:
                json.dump(tasks, f, indent=2)
        elif format == 'csv':
            fieldnames = ['id', 'title', 'done', 'priority', 'due_date', 'archived', 'tags']
            with open(export_path, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for task in tasks:
                    # Convert tags to comma-separated string
                    task['tags'] = ','.join(task['tags']) if task['tags'] else ''
                    writer.writerow(task)

    def compact(self):
        """Reclaim space from deleted tasks."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("VACUUM")
        conn.commit()
        conn.close()

    def search_tasks(self, text):
        """Search for tasks by title (case-insensitive)."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Use the same base query logic as list_tasks for consistency
        query, params = self._build_list_query()
        
        # Add search condition to existing WHERE clause
        if 'WHERE' in query:
            query += " AND LOWER(i.title) LIKE ?"
        else:
            query += " WHERE LOWER(i.title) LIKE ?"
        params.append(f'%{text.lower()}%')
        
        # Add ordering by id
        query += " ORDER BY i.id"
        
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        tasks = []
        for row in rows:
            task = {
                'id': row[0],
                'title': row[1],
                'done': bool(row[2]),
                'priority': row[3],
                'due_date': row[4],
                'archived': bool(row[5]),
                'tags': [t for t in (row[6] or '').split(',') if t] if row[6] else []
            }
            tasks.append(task)
            
        conn.close()
        return tasks

#!/usr/bin/env python3

"""A minimal command-line task manager."""

__version__ = "1.0.0"

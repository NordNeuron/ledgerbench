import os
import sqlite3
import json
import csv
import shutil
import sys
from datetime import datetime, date
from typing import List, Dict, Any

class Storage:
    def __init__(self):
        self.db_path = 'tasks.db'
        self.init_db()
        
    def init_db(self):
        # Create database connection
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if items table exists
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='items'")
        items_exists = cursor.fetchone()
        
        # Check if tasks table exists (for migration)
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='tasks'")
        tasks_exists = cursor.fetchone()
        
        if not items_exists:
            # Create new items table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    priority TEXT DEFAULT 'med',
                    due_date TEXT,
                    archived BOOLEAN DEFAULT FALSE,
                    kind TEXT NOT NULL DEFAULT 'task'
                )
            ''')
            
            # Create task_tags table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS task_tags (
                    task_id INTEGER,
                    tag TEXT,
                    FOREIGN KEY (task_id) REFERENCES items (id)
                )
            ''')
            
            # If tasks table exists, migrate data
            if tasks_exists:
                cursor.execute('''
                    INSERT INTO items (id, title, done, priority, due_date, archived, kind)
                    SELECT id, title, done, priority, due_date, archived, 'task'
                    FROM tasks
                ''')
                
                # Migrate tags
                cursor.execute('''
                    INSERT INTO task_tags (task_id, tag)
                    SELECT task_id, tag
                    FROM task_tags
                ''')
                
                # Drop old tasks table
                cursor.execute('DROP TABLE tasks')
                cursor.execute('DROP TABLE task_tags')
            
        else:
            # Check if kind column exists (for backward compatibility)
            try:
                cursor.execute("SELECT kind FROM items LIMIT 1")
            except sqlite3.OperationalError:
                # Add kind column if it doesn't exist
                cursor.execute("ALTER TABLE items ADD COLUMN kind TEXT DEFAULT 'task'")
        
        conn.commit()
        conn.close()
    
    def get_next_id(self) -> int:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('SELECT COALESCE(MAX(id), 0) + 1 FROM items')
        next_id = cursor.fetchone()[0]
        conn.close()
        return next_id
    
    def add_task(self, title: str, priority: str, due_date: str, tags: List[str]) -> int:
        if due_date:
            try:
                datetime.strptime(due_date, '%Y-%m-%d')
            except ValueError:
                raise ValueError("Invalid date format. Use YYYY-MM-DD.")
        
        task_id = self.get_next_id()
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO items (id, title, priority, due_date, kind)
            VALUES (?, ?, ?, ?, 'task')
        ''', (task_id, title, priority, due_date))
        
        if tags:
            for tag in tags:
                cursor.execute('''
                    INSERT INTO task_tags (task_id, tag)
                    VALUES (?, ?)
                ''', (task_id, tag))
        
        conn.commit()
        conn.close()
        return task_id
    
    def _build_task_query(self, sort_by: str = 'id', overdue: bool = False, 
                         show_all: bool = False, tags: List[str] = None) -> tuple:
        """
        Build a unified query for tasks.
        
        Returns:
            (query_string, params_list)
        """
        # Base query
        query = '''
            SELECT i.id, i.title, i.done, i.priority, i.due_date, i.archived,
                   GROUP_CONCAT(t.tag) as tags
            FROM items i
            LEFT JOIN task_tags t ON i.id = t.task_id
        '''
        
        # WHERE conditions and parameters
        where_conditions = []
        params = []
        
        if not show_all:
            where_conditions.append('i.archived = FALSE')
            
        if overdue:
            today_str = os.environ.get('TASKCLI_TODAY', str(date.today()))
            where_conditions.append('i.due_date < ? AND i.done = FALSE')
            params.append(today_str)
            
        if tags:
            # Join with task_tags table for filtering by tags
            query += ' JOIN task_tags tt ON i.id = tt.task_id'
            where_conditions.append('tt.tag IN ({})'.format(','.join('?' * len(tags))))
            params.extend(tags)
        
        if where_conditions:
            query += ' WHERE ' + ' AND '.join(where_conditions)
            
        # Add GROUP BY for tags
        query += ' GROUP BY i.id, i.title, i.done, i.priority, i.due_date, i.archived'
        
        # Add ORDER BY clause
        if sort_by == 'priority':
            # Custom sorting: high, med, low priority
            query += '''
                ORDER BY 
                    CASE WHEN i.due_date < ? AND i.done = FALSE THEN 0 ELSE 1 END,
                    CASE i.priority WHEN 'high' THEN 0 WHEN 'med' THEN 1 ELSE 2 END,
                    i.id
            '''
            today_str = os.environ.get('TASKCLI_TODAY', str(date.today()))
            params.append(today_str)
        else:
            query += ' ORDER BY i.id'
            
        return query, params
    
    def list_tasks(self, sort_by: str = 'id', overdue: bool = False, 
                   show_all: bool = False, tags: List[str] = None) -> List[Dict]:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        query, params = self._build_task_query(sort_by, overdue, show_all, tags)
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        tasks = []
        for row in rows:
            task = {
                'id': row[0],
                'title': row[1],
                'done': bool(row[2]),
                'priority': row[3],
                'due_date': row[4],
                'archived': bool(row[5]),
                'tags': [t.strip() for t in row[6].split(',')] if row[6] else []
            }
            tasks.append(task)
            
        conn.close()
        return tasks
    
    def mark_done(self, task_id: int):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('UPDATE items SET done = TRUE WHERE id = ?', (task_id,))
        
        if cursor.rowcount == 0:
            raise ValueError(f"Task with ID {task_id} not found")
            
        conn.commit()
        conn.close()
    
    def delete_task(self, task_id: int):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('DELETE FROM items WHERE id = ?', (task_id,))
        
        if cursor.rowcount == 0:
            raise ValueError(f"Task with ID {task_id} not found")
            
        conn.commit()
        conn.close()
    
    def edit_task(self, task_id: int, new_title: str):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('UPDATE items SET title = ? WHERE id = ?', (new_title, task_id))
        
        if cursor.rowcount == 0:
            raise ValueError(f"Task with ID {task_id} not found")
            
        conn.commit()
        conn.close()
    
    def get_stats(self) -> Dict[str, int]:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Total tasks
        cursor.execute('SELECT COUNT(*) FROM items WHERE archived = FALSE')
        total = cursor.fetchone()[0]
        
        # Done tasks
        cursor.execute('SELECT COUNT(*) FROM items WHERE done = TRUE AND archived = FALSE')
        done = cursor.fetchone()[0]
        
        # Open tasks
        cursor.execute('SELECT COUNT(*) FROM items WHERE done = FALSE AND archived = FALSE')
        open_tasks = cursor.fetchone()[0]
        
        # Priority counts
        cursor.execute('''
            SELECT priority, COUNT(*) 
            FROM items 
            WHERE archived = FALSE 
            GROUP BY priority
        ''')
        priority_counts = dict(cursor.fetchall())
        
        # Fill in missing priorities with 0
        for priority in ['high', 'med', 'low']:
            if priority not in priority_counts:
                priority_counts[priority] = 0
                
        stats = {
            'total': total,
            'done': done,
            'open': open_tasks,
            'priority-high': priority_counts['high'],
            'priority-med': priority_counts['med'],
            'priority-low': priority_counts['low']
        }
        
        conn.close()
        return stats
    
    def archive_done_tasks(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('UPDATE items SET archived = TRUE WHERE done = TRUE')
        conn.commit()
        conn.close()
    
    def backup(self, path: str):
        # Create a temporary file
        temp_path = f"{path}.tmp"
        try:
            shutil.copy2(self.db_path, temp_path)
            os.rename(temp_path, path)
        except Exception:
            # Clean up temp file if something goes wrong
            if os.path.exists(temp_path):
                os.remove(temp_path)
            raise
    
    def compact(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('VACUUM')
        conn.commit()
        conn.close()
    
    def export_tasks(self, path: str, format: str = 'json'):
        # Use the same query logic as list_tasks
        tasks = self.list_tasks(show_all=True)
        
        if format == 'json':
            with open(path, 'w') as f:
                json.dump(tasks, f, indent=2)
        elif format == 'csv':
            with open(path, 'w', newline='') as f:
                if tasks:
                    fieldnames = tasks[0].keys()
                    writer = csv.DictWriter(f, fieldnames=fieldnames)
                    writer.writeheader()
                    for task in tasks:
                        # Convert due_date to string if it's None
                        if task['due_date'] is None:
                            task['due_date'] = ''
                        writer.writerow(task)
    
    def search_tasks(self, text: str) -> List[Dict]:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Use the same query building logic as list_tasks but with title filtering
        query = '''
            SELECT i.id, i.title, i.done, i.priority, i.due_date, i.archived,
                   GROUP_CONCAT(t.tag) as tags
            FROM items i
            LEFT JOIN task_tags t ON i.id = t.task_id
            WHERE LOWER(i.title) LIKE ?
            GROUP BY i.id, i.title, i.done, i.priority, i.due_date, i.archived
            ORDER BY i.id
        '''
        
        cursor.execute(query, (f'%{text.lower()}%',))
        rows = cursor.fetchall()
        
        tasks = []
        for row in rows:
            task = {
                'id': row[0],
                'title': row[1],
                'done': bool(row[2]),
                'priority': row[3],
                'due_date': row[4],
                'archived': bool(row[5]),
                'tags': [t.strip() for t in row[6].split(',')] if row[6] else []
            }
            tasks.append(task)
            
        conn.close()
        return tasks
    
    def format_task(self, task: Dict, color: str = 'auto') -> str:
        # Determine if we should use colors
        use_color = False
        if color == 'always':
            use_color = True
        elif color == 'never':
            use_color = False
        else:  # auto
            use_color = sys.stdout.isatty()
        
        # Format task components
        done_str = "✓" if task['done'] else "○"
        priority_str = f"(priority: {task['priority']})"
        
        # Add due date if present
        due_str = ""
        if task['due_date']:
            due_str = f" (due: {task['due_date']})"
            
        # Add tags if present
        tags_str = ""
        if task['tags']:
            tags_str = " [" + ",".join(task['tags']) + "]"
        
        # Build the base string
        formatted = f"{task['id']} {done_str} {task['title']} {priority_str}{due_str}{tags_str}"
        
        # Apply colors if needed
        if use_color:
            if task['done']:
                formatted = f"\033[32m{formatted}\033[0m"  # Green for done
            elif task['due_date']:
                today = date.today()
                try:
                    due = datetime.strptime(task['due_date'], '%Y-%m-%d').date()
                    if due < today:
                        formatted = f"\033[31m{formatted}\033[0m"  # Red for overdue
                except ValueError:
                    pass  # Invalid date format, ignore coloring
        
        return formatted

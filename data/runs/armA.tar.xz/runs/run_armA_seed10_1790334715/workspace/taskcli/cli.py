import argparse
import os
import sys
from .storage import Storage
from . import __version__

def create_parser():
    parser = argparse.ArgumentParser(
        prog='taskcli',
        description='A minimal command-line task manager.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  taskcli add "Buy milk"
  taskcli done 1
  taskcli list
  taskcli search "milk"
        """
    )
    parser.add_argument('--version', action='version', version=f'%(prog)s {__version__}')
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['low', 'med', 'high'], default='med',
                           help='Task priority (default: med)')
    add_parser.add_argument('--due', help='Due date (YYYY-MM-DD)')
    add_parser.add_argument('--tag', action='append', help='Add a tag (can be used multiple times)')
    
    # List command
    list_parser = subparsers.add_parser('list', help='List all tasks')
    list_parser.add_argument('--sort', choices=['id', 'priority'], 
                            help='Sort order')
    list_parser.add_argument('--overdue', action='store_true',
                            help='Show only overdue tasks')
    list_parser.add_argument('--all', action='store_true',
                            help='Show archived tasks')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--color', choices=['auto', 'always', 'never'], 
                            default='auto', help='Color output (default: auto)')
    
    # Done command
    done_parser = subparsers.add_parser('done', help='Mark task as done')
    done_parser.add_argument('id', type=int, help='Task ID')
    
    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')
    
    # Edit command
    edit_parser = subparsers.add_parser('edit', help='Edit a task')
    edit_parser.add_argument('id', type=int, help='Task ID')
    edit_parser.add_argument('--title', help='New title')
    
    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')
    
    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')
    
    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Create a backup')
    backup_parser.add_argument('path', help='Backup file path')
    
    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json',
                              help='Export format (default: json)')
    
    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Compact database')
    
    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Search text')
    
    return parser

def main():
    parser = create_parser()
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.stderr.write("AUDIT list\n")  # Default audit for help
        return 0
    
    storage = Storage()
    
    try:
        if args.command == 'add':
            task_id = storage.add_task(
                title=args.title,
                priority=args.priority,
                due=args.due,
                tags=args.tag or []
            )
            print(task_id)
            
        elif args.command == 'list':
            tasks = storage.list_tasks(
                sort_by=args.sort,
                overdue=args.overdue,
                show_all=args.all,
                tag=args.tag
            )
            if tasks:
                # Determine if we should use colors based on --color option and TTY
                use_colors = False
                if args.color == 'always':
                    use_colors = True
                elif args.color == 'auto' and sys.stdout.isatty():
                    use_colors = True
                
                for task in tasks:
                    done_str = "✓" if task['done'] else "○"
                    priority_str = f"(priority: {task['priority']})" if task['priority'] else ""
                    due_str = f" (due: {task['due']})" if task['due'] else ""
                    tags_str = f" [tags: {', '.join(task['tags'])}]" if task['tags'] else ""
                    
                    # Color overdue tasks red, done tasks green
                    if task['overdue']:
                        prefix = "\033[31m"  # Red
                    elif task['done']:
                        prefix = "\033[32m"  # Green
                    else:
                        prefix = ""
                    suffix = "\033[0m" if use_colors and prefix else ""
                    
                    print(f"{prefix}{task['id']}: {done_str} {task['title']} {priority_str}{due_str}{tags_str}{suffix}")
            
        elif args.command == 'done':
            storage.mark_done(args.id)
            
        elif args.command == 'delete':
            storage.delete_task(args.id)
            
        elif args.command == 'edit':
            storage.edit_task(args.id, title=args.title)
            
        elif args.command == 'stats':
            stats = storage.get_stats()
            print(f"Total: {stats['total']}")
            print(f"Done: {stats['done']}")
            print(f"Open: {stats['open']}")
            print(f"High priority: {stats['high_priority']}")
            print(f"Medium priority: {stats['med_priority']}")
            print(f"Low priority: {stats['low_priority']}")
            if stats['overdue'] > 0:
                print(f"\033[31mOverdue: {stats['overdue']}\033[0m")
            
        elif args.command == 'archive':
            storage.archive_done_tasks()
            
        elif args.command == 'backup':
            storage.backup(args.path)
            
        elif args.command == 'export':
            storage.export(args.path, format=args.format)
            
        elif args.command == 'compact':
            storage.compact()
            
        elif args.command == 'search':
            tasks = storage.search_tasks(args.text)
            if tasks:
                # Determine if we should use colors based on TTY
                use_colors = sys.stdout.isatty()
                
                for task in tasks:
                    done_str = "✓" if task['done'] else "○"
                    priority_str = f"(priority: {task['priority']})" if task['priority'] else ""
                    due_str = f" (due: {task['due']})" if task['due'] else ""
                    tags_str = f" [tags: {', '.join(task['tags'])}]" if task['tags'] else ""
                    
                    # Color overdue tasks red, done tasks green
                    if task['overdue']:
                        prefix = "\033[31m"  # Red
                    elif task['done']:
                        prefix = "\033[32m"  # Green
                    else:
                        prefix = ""
                    suffix = "\033[0m" if use_colors and prefix else ""
                    
                    print(f"{prefix}{task['id']}: {done_str} {task['title']} {priority_str}{due_str}{tags_str}{suffix}")
            
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        sys.stderr.write(f"AUDIT {args.command}\n")
        return 2
    
    # Audit line on success
    sys.stderr.write(f"AUDIT {args.command}\n")
    return 0

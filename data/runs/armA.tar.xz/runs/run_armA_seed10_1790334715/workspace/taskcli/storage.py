import json
import os
import sqlite3
import sys
import shutil
import csv
from datetime import datetime, date
from pathlib import Path

# Configuration
CONFIG_FILE = 'config.toml'

class Storage:
    def __init__(self):
        self.db_path = 'tasks.db'
        self._init_db()
        
    def _get_config(self):
        """Get configuration from file or environment"""
        config = {}
        
        # Try to read config.toml if it exists
        if os.path.exists(CONFIG_FILE):
            try:
                import tomli
                with open(CONFIG_FILE, 'rb') as f:
                    config_data = tomli.load(f)
                    if 'today' in config_data:
                        config['today'] = config_data['today']
                    if 'default_priority' in config_data:
                        config['default_priority'] = config_data['default_priority']
            except ImportError:
                # If tomli not available, skip config
                pass
        
        # Environment variable overrides config
        if 'TASKCLI_TODAY' in os.environ:
            config['today'] = os.environ['TASKCLI_TODAY']
            
        return config
    
    def _init_db(self):
        """Initialize database with proper schema"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if we need to migrate from old schema
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='tasks'")
        if cursor.fetchone():
            # Migrate from old schema
            self._migrate_from_old_schema(conn, cursor)
        
        # Create or update schema
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                done BOOLEAN DEFAULT FALSE,
                priority TEXT,
                due DATE,
                archived BOOLEAN DEFAULT FALSE,
                kind TEXT NOT NULL DEFAULT 'task'
            )
        """)
        
        # Create tags table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS task_tags (
                task_id INTEGER,
                tag TEXT,
                FOREIGN KEY (task_id) REFERENCES items (id)
            )
        """)
        
        conn.commit()
        conn.close()
    
    def _migrate_from_old_schema(self, conn, cursor):
        """Migrate from old tasks table to new schema"""
        try:
            # Check if we have the old tasks table
            cursor.execute("SELECT * FROM tasks LIMIT 1")
            rows = cursor.fetchall()
            
            if rows:
                # Migrate data
                cursor.execute("SELECT * FROM tasks")
                old_tasks = cursor.fetchall()
                
                for row in old_tasks:
                    task_id, title, done, priority, due = row
                    cursor.execute("""
                        INSERT INTO items (id, title, done, priority, due, kind)
                        VALUES (?, ?, ?, ?, ?, ?)
                    """, (task_id, title, done, priority, due, 'task'))
                
                # Drop old table
                cursor.execute("DROP TABLE tasks")
                
                conn.commit()
        except sqlite3.Error:
            pass  # If old schema doesn't exist, continue
    
    def _get_next_id(self):
        """Get the next available task ID"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items WHERE kind='task'")
        next_id = cursor.fetchone()[0]
        conn.close()
        return next_id
    
    def _build_task_query(self, sort_by=None, overdue=False, show_all=False, tag=None):
        """Build a unified query for tasks"""
        # Base query components
        select_fields = """
            items.id, items.title, items.done, items.priority, items.due, items.archived,
            (SELECT GROUP_CONCAT(tag, ', ') FROM task_tags WHERE task_id = items.id) as tags
        """
        
        from_clause = "FROM items"
        where_conditions = ["items.kind='task'"]
        params = []
        
        if not show_all:
            where_conditions.append("items.archived=0")
            
        if overdue:
            today = self._get_today()
            where_conditions.append("items.done=0 AND items.due < ?")
            params.append(today)
            
        if tag:
            where_conditions.append("items.id IN (SELECT task_id FROM task_tags WHERE tag = ?)")
            params.append(tag)
        
        # Build full query
        query = f"SELECT {select_fields} {from_clause}"
        
        if where_conditions:
            query += " WHERE " + " AND ".join(where_conditions)
            
        # Sorting logic
        if sort_by == 'priority':
            # Order by priority (high, med, low), then by id
            query += """ ORDER BY 
                CASE items.priority WHEN 'high' THEN 1 
                                     WHEN 'med' THEN 2 
                                     WHEN 'low' THEN 3 
                                     ELSE 4 END,
                items.id"""
        else:
            # Default: smart sort - overdue first, then priority, then insertion order
            today = self._get_today()
            query += f""" ORDER BY 
                CASE WHEN items.done=0 AND items.due < '{today}' THEN 0 ELSE 1 END,
                CASE items.priority WHEN 'high' THEN 1 
                                     WHEN 'med' THEN 2 
                                     WHEN 'low' THEN 3 
                                     ELSE 4 END,
                items.id"""
        
        return query, params
    
    def _process_task_row(self, row):
        """Process a database row into a task dictionary"""
        task_id, title, done, priority, due, archived, tags_str = row
        # Parse tags string into list
        tags = [t.strip() for t in tags_str.split(',')] if tags_str else []
        
        # Determine if overdue
        overdue_status = False
        if not done and due:
            today = self._get_today()
            try:
                due_date = datetime.strptime(due, '%Y-%m-%d').date()
                overdue_status = due_date < today
            except ValueError:
                pass  # Invalid date format, treat as not overdue
        
        return {
            'id': task_id,
            'title': title,
            'done': done,
            'priority': priority,
            'due': due,
            'archived': archived,
            'tags': tags,
            'overdue': overdue_status
        }
    
    def add_task(self, title, priority, due, tags):
        """Add a new task and return its ID"""
        if not title.strip():
            raise ValueError("Task title cannot be empty")
            
        task_id = self._get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO items (id, title, priority, due, kind)
            VALUES (?, ?, ?, ?, ?)
        """, (task_id, title, priority, due, 'task'))
        
        # Add tags
        for tag in tags:
            cursor.execute("""
                INSERT INTO task_tags (task_id, tag)
                VALUES (?, ?)
            """, (task_id, tag))
        
        conn.commit()
        conn.close()
        return task_id
    
    def list_tasks(self, sort_by=None, overdue=False, show_all=False, tag=None):
        """List all tasks"""
        query, params = self._build_task_query(sort_by, overdue, show_all, tag)
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        tasks = [self._process_task_row(row) for row in rows]
        
        conn.close()
        return tasks
    
    def mark_done(self, task_id):
        """Mark a task as done"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
        if not cursor.fetchone():
            raise ValueError(f"Task with ID {task_id} does not exist")
            
        cursor.execute("UPDATE items SET done=1 WHERE id=?", (task_id,))
        conn.commit()
        conn.close()
    
    def delete_task(self, task_id):
        """Delete a task"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
        if not cursor.fetchone():
            raise ValueError(f"Task with ID {task_id} does not exist")
            
        cursor.execute("DELETE FROM task_tags WHERE task_id=?", (task_id,))
        cursor.execute("DELETE FROM items WHERE id=? AND kind='task'", (task_id,))
        conn.commit()
        conn.close()
    
    def edit_task(self, task_id, title=None):
        """Edit a task's title"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if task exists
        cursor.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
        if not cursor.fetchone():
            raise ValueError(f"Task with ID {task_id} does not exist")
            
        if title is not None:
            cursor.execute("UPDATE items SET title=? WHERE id=?", (title, task_id))
            
        conn.commit()
        conn.close()
    
    def get_stats(self):
        """Get statistics about tasks"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Total tasks
        cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task'")
        total = cursor.fetchone()[0]
        
        # Done tasks
        cursor.execute("SELECT COUNT(*) FROM items WHERE done=1 AND kind='task'")
        done = cursor.fetchone()[0]
        
        # Open tasks
        open_tasks = total - done
        
        # Priority counts
        cursor.execute("SELECT priority, COUNT(*) FROM items WHERE kind='task' GROUP BY priority")
        priority_counts = dict(cursor.fetchall())
        
        high_priority = priority_counts.get('high', 0)
        med_priority = priority_counts.get('med', 0)
        low_priority = priority_counts.get('low', 0)
        
        # Overdue tasks
        today = self._get_today()
        cursor.execute("""
            SELECT COUNT(*) FROM items 
            WHERE done=0 AND due < ? AND kind='task'
        """, (today,))
        overdue = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            'total': total,
            'done': done,
            'open': open_tasks,
            'high_priority': high_priority,
            'med_priority': med_priority,
            'low_priority': low_priority,
            'overdue': overdue
        }
    
    def archive_done_tasks(self):
        """Archive all done tasks"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("UPDATE items SET archived=1 WHERE done=1 AND kind='task'")
        conn.commit()
        conn.close()
    
    def backup(self, path):
        """Create a backup of the database"""
        try:
            # Use atomic write pattern
            temp_path = path + '.tmp'
            shutil.copy2(self.db_path, temp_path)
            os.rename(temp_path, path)
        except Exception as e:
            raise IOError(f"Failed to create backup: {e}")
    
    def export(self, path, format='json'):
        """Export tasks to a file"""
        # Use the same query logic for consistency
        query, params = self._build_task_query()
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        tasks = [self._process_task_row(row) for row in rows]
        
        conn.close()
        
        if format == 'csv':
            with open(path, 'w', newline='', encoding='utf-8') as csvfile:
                fieldnames = ['id', 'title', 'done', 'priority', 'due', 'archived', 'tags']
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                
                writer.writeheader()
                for task in tasks:
                    # Convert tags to comma-separated string
                    tags_str = ', '.join(task['tags']) if task['tags'] else ''
                    writer.writerow({
                        'id': task['id'],
                        'title': task['title'],
                        'done': task['done'],
                        'priority': task['priority'],
                        'due': task['due'],
                        'archived': task['archived'],
                        'tags': tags_str
                    })
        else:  # JSON format
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(tasks, f, indent=2, ensure_ascii=False)
    
    def compact(self):
        """Compact the database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("VACUUM")
        conn.commit()
        conn.close()
    
    def search_tasks(self, text):
        """Search tasks by title (case-insensitive)"""
        # Build query with case-insensitive LIKE
        query = """
            SELECT items.id, items.title, items.done, items.priority, items.due, items.archived,
                   (SELECT GROUP_CONCAT(tag, ', ') FROM task_tags WHERE task_id = items.id) as tags
            FROM items
            WHERE items.kind='task' AND LOWER(items.title) LIKE ?
        """
        
        # Add sorting similar to list_tasks for consistency
        today = self._get_today()
        query += f""" ORDER BY 
            CASE WHEN items.done=0 AND items.due < '{today}' THEN 0 ELSE 1 END,
            CASE items.priority WHEN 'high' THEN 1 
                                 WHEN 'med' THEN 2 
                                 WHEN 'low' THEN 3 
                                 ELSE 4 END,
            items.id"""
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(query, (f'%{text.lower()}%',))
        rows = cursor.fetchall()
        
        tasks = [self._process_task_row(row) for row in rows]
        
        conn.close()
        return tasks
    
    def _get_today(self):
        """Get today's date, respecting configuration"""
        config = self._get_config()
        if 'today' in config:
            try:
                return datetime.strptime(config['today'], '%Y-%m-%d').date().strftime('%Y-%m-%d')
            except ValueError:
                # If invalid format, use current date
                pass
        return date.today().strftime('%Y-%m-%d')

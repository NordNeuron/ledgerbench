import argparse
import os
import sys
from .storage import TaskStorage
from . import __version__

def print_task(task):
    """Print a single task in the same format as 'list' command."""
    done_char = "✓" if task['done'] else "○"
    priority_char = {"high": "H", "med": "M", "low": "L"}[task['priority']]
    due_str = f" (due {task['due']})" if task['due'] else ""
    tag_str = f" [{', '.join(task['tags'])}]" if task['tags'] else ""
    print(f"{task['id']}: {done_char} {priority_char} {task['title']}{due_str}{tag_str}")

def list_tasks(storage, args):
    """Handle the 'list' command."""
    tasks = storage.list_tasks(args.sort, args.overdue, args.tag)
    for task in tasks:
        print_task(task)

def add_task(storage, args):
    """Handle the 'add' command."""
    task_id = storage.add_task(args.title, args.priority, args.due, args.tag)
    print(task_id)

def done_task(storage, args):
    """Handle the 'done' command."""
    storage.mark_done(args.id)
    # Silent success per T9

def delete_task(storage, args):
    """Handle the 'delete' command."""
    storage.delete_task(args.id)
    # Silent success per T9

def edit_task(storage, args):
    """Handle the 'edit' command."""
    storage.edit_task(args.id, title=args.title)

def archive_task(storage, args):
    """Handle the 'archive' command."""
    storage.archive_task(args.id)
    # Silent success per T9

def stats(storage, args):
    """Handle the 'stats' command."""
    stats_data = storage.get_stats()
    print(f"Total: {stats_data['total']}")
    print(f"Completed: {stats_data['completed']}")
    print(f"Overdue: {stats_data['overdue']}")
    print(f"Pending: {stats_data['pending']}")

def backup(storage, args):
    """Handle the 'backup' command."""
    storage.backup(args.path)
    # Silent success per T9

def compact(storage, args):
    """Handle the 'compact' command."""
    storage.compact()
    # Silent success per T9

def export(storage, args):
    """Handle the 'export' command."""
    tasks = storage.list_tasks(args.sort, args.overdue, args.tag)
    if args.format == "csv":
        storage.export_csv(sys.stdout, tasks)
    else:
        storage.export_json(sys.stdout, tasks)

def search(storage, args):
    """Handle the 'search' command."""
    tasks = storage.search_tasks(args.text)
    for task in tasks:
        print_task(task)

def create_parser():
    """Create and return the argument parser."""
    parser = argparse.ArgumentParser(
        prog="taskcli",
        description="A minimal command-line task manager.",
        epilog="See 'taskcli help <command>' for more information on a specific command."
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # List command
    list_parser = subparsers.add_parser("list", help="List all tasks")
    list_parser.add_argument("--sort", choices=["id", "priority", "smart"], 
                           default="id", help="Sort order (default: id)")
    list_parser.add_argument("--overdue", action="store_true", 
                           help="Show only overdue tasks")
    list_parser.add_argument("--tag", help="Show only tasks with this tag")
    
    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--priority", choices=["low", "med", "high"], 
                           default=None, help="Task priority (default: med)")
    add_parser.add_argument("--due", help="Due date (YYYY-MM-DD)")
    add_parser.add_argument("--tag", action="append", help="Add a tag (can be used multiple times)")
    
    # Done command
    done_parser = subparsers.add_parser("done", help="Mark a task as done")
    done_parser.add_argument("id", type=int, help="Task ID")
    
    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")
    
    # Edit command
    edit_parser = subparsers.add_parser("edit", help="Edit a task")
    edit_parser.add_argument("id", type=int, help="Task ID")
    edit_parser.add_argument("--title", help="New title for the task")
    
    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive a completed task")
    archive_parser.add_argument("id", type=int, help="Task ID")
    
    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show task statistics")
    
    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup the database")
    backup_parser.add_argument("path", help="Backup file path")
    
    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Reclaim space from deleted tasks")
    
    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("--format", choices=["json", "csv"], default="json",
                              help="Export format (default: json)")
    export_parser.add_argument("--sort", choices=["id", "priority", "smart"], 
                             default="id", help="Sort order for export (default: id)")
    export_parser.add_argument("--overdue", action="store_true", 
                             help="Export only overdue tasks")
    export_parser.add_argument("--tag", help="Export only tasks with this tag")
    
    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Text to search for in task titles")
    
    return parser

def main():
    """Main entry point for the CLI."""
    storage = TaskStorage()
    
    parser = create_parser()
    args = parser.parse_args()
    
    # Emit audit line
    command_name = args.command if args.command else "help"
    print(f"AUDIT {command_name}", file=sys.stderr)
    
    if not args.command:
        # Default behavior: show help
        parser.print_help()
        return 0
    
    try:
        if args.command == "list":
            list_tasks(storage, args)
        elif args.command == "add":
            add_task(storage, args)
        elif args.command == "done":
            done_task(storage, args)
        elif args.command == "delete":
            delete_task(storage, args)
        elif args.command == "edit":
            edit_task(storage, args)
        elif args.command == "archive":
            archive_task(storage, args)
        elif args.command == "stats":
            stats(storage, args)
        elif args.command == "backup":
            backup(storage, args)
        elif args.command == "compact":
            compact(storage, args)
        elif args.command == "export":
            export(storage, args)
        elif args.command == "search":
            search(storage, args)
        else:
            print(f"Unknown command: {args.command}", file=sys.stderr)
            return 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    
    return 0

import json
import os
import sqlite3
import sys
import tempfile
from datetime import datetime, date
from typing import List, Dict, Any

class TaskStorage:
    def __init__(self, db_path: str = "tasks.db"):
        self.db_path = db_path
        self.init_db()
    
    def init_db(self):
        """Initialize the database with required tables and schema."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    priority TEXT DEFAULT 'med',
                    due DATE,
                    tags TEXT DEFAULT '[]',
                    archived BOOLEAN DEFAULT FALSE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_items_kind ON items(kind)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_items_done ON items(done)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_items_priority ON items(priority)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_items_due ON items(due)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_items_archived ON items(archived)")
    
    def get_next_id(self) -> int:
        """Get the next available task ID."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items WHERE kind = 'task'")
            return cursor.fetchone()[0]
    
    def add_task(self, title: str, priority: str = None, due: str = None, tags: List[str] = None) -> int:
        """Add a new task and return its ID."""
        if priority is None:
            # Try to get from config or default to 'med'
            try:
                import toml
                if os.path.exists('config.toml'):
                    config = toml.load('config.toml')
                    priority = config.get('default_priority', 'med')
                else:
                    priority = 'med'
            except ImportError:
                priority = 'med'
        
        task_id = self.get_next_id()
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT INTO items (id, kind, title, priority, due, tags)
                VALUES (?, 'task', ?, ?, ?, ?)
            """, (task_id, title, priority, due, json.dumps(tags or [])))
        return task_id
    
    def _build_list_query(self, sort_by: str = "id", overdue_only: bool = False, tag_filter: str = None) -> tuple:
        """Build the base query for listing tasks."""
        # Base query
        query = """
            SELECT id, title, done, priority, due, tags, archived
            FROM items 
            WHERE kind = 'task' AND archived = FALSE
        """
        params = []
        
        # Apply overdue filter if requested
        if overdue_only:
            today_str = self._get_today()
            query += " AND due < ? AND done = FALSE"
            params.append(today_str)
        
        # Apply tag filter if requested
        if tag_filter:
            query += " AND tags LIKE ?"
            params.append(f'%"{tag_filter}"%')
        
        return query, params
    
    def _apply_sorting(self, query: str, params: list, sort_by: str) -> tuple:
        """Apply sorting to the query."""
        # Create a copy of params for this operation
        sort_params = params.copy()
        
        if sort_by == "priority":
            # Order by priority (high, med, low) then by id
            query += """
                ORDER BY 
                    CASE priority 
                        WHEN 'high' THEN 1 
                        WHEN 'med' THEN 2 
                        WHEN 'low' THEN 3 
                    END,
                    id
            """
        elif sort_by == "smart":
            # Overdue first, then by priority (high, med, low), then by id
            today_str = self._get_today()
            query += f"""
                ORDER BY 
                    CASE WHEN due < ? AND done = FALSE THEN 0 ELSE 1 END,
                    CASE priority 
                        WHEN 'high' THEN 1 
                        WHEN 'med' THEN 2 
                        WHEN 'low' THEN 3 
                    END,
                    id
            """
            sort_params.append(today_str)
        else:  # default sort_by == "id"
            query += " ORDER BY id"
        
        return query, sort_params
    
    def list_tasks(self, sort_by: str = "id", overdue_only: bool = False, tag_filter: str = None) -> List[Dict[str, Any]]:
        """List all tasks, optionally sorted and filtered."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            
            # Build base query
            query, params = self._build_list_query(sort_by, overdue_only, tag_filter)
            
            # Apply sorting
            query, params = self._apply_sorting(query, params, sort_by)
            
            cursor = conn.execute(query, params)
            rows = cursor.fetchall()
            
            # Convert to list of dicts
            tasks = []
            for row in rows:
                tasks.append({
                    'id': row['id'],
                    'title': row['title'],
                    'done': bool(row['done']),
                    'priority': row['priority'],
                    'due': row['due'],
                    'tags': json.loads(row['tags']) if row['tags'] else [],
                    'archived': bool(row['archived'])
                })
            
            return tasks
    
    def mark_done(self, task_id: int):
        """Mark a task as done."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task {task_id} not found")
            conn.execute("UPDATE items SET done = TRUE WHERE id = ?", (task_id,))
    
    def delete_task(self, task_id: int):
        """Delete a task."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task {task_id} not found")
            conn.execute("DELETE FROM items WHERE id = ?", (task_id,))
    
    def edit_task(self, task_id: int, title: str = None):
        """Edit a task's title."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task {task_id} not found")
            
            if title is not None:
                conn.execute("UPDATE items SET title = ? WHERE id = ?", (title, task_id))
    
    def archive_task(self, task_id: int):
        """Archive a task."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task {task_id} not found")
            conn.execute("UPDATE items SET archived = TRUE WHERE id = ?", (task_id,))
    
    def get_stats(self) -> Dict[str, int]:
        """Get task statistics."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) as total FROM items WHERE kind = 'task' AND archived = FALSE")
            total = cursor.fetchone()['total']
            
            # Completed tasks
            cursor.execute("SELECT COUNT(*) as completed FROM items WHERE kind = 'task' AND done = TRUE AND archived = FALSE")
            completed = cursor.fetchone()['completed']
            
            # Overdue tasks (not done)
            today_str = self._get_today()
            cursor.execute("""
                SELECT COUNT(*) as overdue 
                FROM items 
                WHERE kind = 'task' AND due < ? AND done = FALSE AND archived = FALSE
            """, (today_str,))
            overdue = cursor.fetchone()['overdue']
            
            # Pending tasks
            pending = total - completed
            
            return {
                'total': total,
                'completed': completed,
                'overdue': overdue,
                'pending': pending
            }
    
    def backup(self, path: str):
        """Create a backup of the database."""
        with tempfile.NamedTemporaryFile(mode='wb', delete=False, suffix='.db') as tmp_file:
            with open(self.db_path, 'rb') as src:
                tmp_file.write(src.read())
            tmp_file_path = tmp_file.name
        
        # Atomic move
        os.replace(tmp_file_path, path)
    
    def compact(self):
        """Reclaim space from deleted tasks."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("VACUUM")
    
    def export_json(self, file_obj, tasks=None):
        """Export tasks in JSON format."""
        if tasks is None:
            tasks = self.list_tasks()
        json.dump(tasks, file_obj, indent=2)
    
    def export_csv(self, file_obj, tasks=None):
        """Export tasks in CSV format."""
        import csv
        
        if tasks is None:
            tasks = self.list_tasks()
        
        if not tasks:
            return
        
        fieldnames = ['id', 'title', 'done', 'priority', 'due', 'tags']
        writer = csv.DictWriter(file_obj, fieldnames=fieldnames)
        writer.writeheader()
        
        for task in tasks:
            # Convert tags to comma-separated string for CSV
            task['tags'] = ','.join(task['tags']) if task['tags'] else ''
            writer.writerow(task)
    
    def search_tasks(self, text: str) -> List[Dict[str, Any]]:
        """Search tasks by title (case-insensitive)."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Search for tasks where title contains the text (case-insensitive)
            query = """
                SELECT id, title, done, priority, due, tags, archived
                FROM items 
                WHERE kind = 'task' AND archived = FALSE AND LOWER(title) LIKE ?
                ORDER BY id
            """
            cursor.execute(query, (f'%{text.lower()}%',))
            rows = cursor.fetchall()
            
            # Convert to list of dicts
            tasks = []
            for row in rows:
                tasks.append({
                    'id': row['id'],
                    'title': row['title'],
                    'done': bool(row['done']),
                    'priority': row['priority'],
                    'due': row['due'],
                    'tags': json.loads(row['tags']) if row['tags'] else [],
                    'archived': bool(row['archived'])
                })
            
            return tasks
    
    def _get_today(self) -> str:
        """Get today's date as YYYY-MM-DD string, respecting config or environment."""
        # Check for config file first
        try:
            import toml
            if os.path.exists('config.toml'):
                config = toml.load('config.toml')
                today_str = config.get('today')
                if today_str:
                    return today_str
        except ImportError:
            pass
        
        # Check environment variable
        today_env = os.environ.get('TASKCLI_TODAY')
        if today_env:
            return today_env
            
        # Default to current date
        return date.today().strftime('%Y-%m-%d')

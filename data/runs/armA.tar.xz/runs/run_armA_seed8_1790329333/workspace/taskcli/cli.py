import argparse
import sys
from . import __version__
from .storage import TaskStorage

def create_parser():
    parser = argparse.ArgumentParser(
        prog='taskcli',
        description='A minimal command-line task manager',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""Commands:
  add <title>                    Add a new task
  list [--all]                   List all tasks in insertion order
  done <id>                      Mark task as done
  delete <id>                    Delete task
  stats                          Show task statistics
  archive                        Archive completed tasks
  backup <path>                  Create atomic backup of database
  export <path>                  Export all tasks to JSON file
  compact                        Reclaim space from deleted rows
  search <text>                  Search tasks by title
  help                           Show this help message"""
    )
    
    parser.add_argument('--version', action='version', version=f'%(prog)s {__version__}')
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--tag', action='append', help='Tag to add to the task (can be used multiple times)')
    add_parser.add_argument('--priority', choices=['low', 'med', 'high'], default='med', help='Task priority (default: med)')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    
    # List command
    list_parser = subparsers.add_parser('list', help='List all tasks')
    list_parser.add_argument('--all', action='store_true', help='Show all tasks including archived')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--smart', action='store_true', help='Smart ordering: overdue first, then priority, then ID')
    
    # Done command
    done_parser = subparsers.add_parser('done', help='Mark task as done')
    done_parser.add_argument('id', type=int, help='Task ID')
    
    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete task')
    delete_parser.add_argument('id', type=int, help='Task ID')
    
    # Stats command
    subparsers.add_parser('stats', help='Show task statistics')
    
    # Archive command
    subparsers.add_parser('archive', help='Archive completed tasks')
    
    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Create atomic backup of database')
    backup_parser.add_argument('path', help='Backup file path')
    
    # Export command
    export_parser = subparsers.add_parser('export', help='Export all tasks to JSON file')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json', help='Export format (default: json)')
    
    # Compact command
    subparsers.add_parser('compact', help='Reclaim space from deleted rows')
    
    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for in task titles')
    
    return parser

def print_task(task, smart_order=False):
    """Print a single task in the standard format"""
    if task['done']:
        status = "✅"
    else:
        status = "❌"
    
    if smart_order and task['due'] and not task['done']:
        from datetime import datetime
        try:
            due_date = datetime.strptime(task['due'], '%Y-%m-%d')
            if due_date < datetime.now().date():
                status = "⏰"  # Overdue indicator
        except ValueError:
            pass
    
    tags_str = f" [{' '.join(task['tags'])}]" if task['tags'] else ""
    print(f"{status} {task['id']}: {task['title']}{tags_str}")

def print_tasks(tasks, smart_order=False):
    """Print a list of tasks"""
    for task in tasks:
        print_task(task, smart_order)

def main():
    parser = create_parser()
    args = parser.parse_args()
    
    # Always emit audit line
    command_name = args.command if args.command else "help"
    print(f"AUDIT {command_name}", file=sys.stderr)
    
    if not args.command:
        parser.print_help()
        return
    
    storage = TaskStorage()
    
    try:
        if args.command == 'add':
            task_id = storage.add_task(
                title=args.title,
                tags=args.tag or [],
                priority=args.priority,
                due=args.due
            )
            print(task_id)
            
        elif args.command == 'list':
            tasks = storage.list_tasks(all_tasks=args.all, tag=args.tag, smart=args.smart)
            print_tasks(tasks, smart=args.smart)
            
        elif args.command == 'done':
            storage.mark_done(args.id)
            
        elif args.command == 'delete':
            storage.delete_task(args.id)
            
        elif args.command == 'stats':
            stats = storage.get_stats()
            print(f"Total: {stats['total']}")
            print(f"Pending: {stats['pending']}")
            if stats['overdue'] > 0:
                print(f"Overdue: \033[91m{stats['overdue']}\033[0m")
            else:
                print(f"Overdue: {stats['overdue']}")
            print(f"Completed: {stats['completed']}")
            
        elif args.command == 'archive':
            storage.archive_tasks()
            
        elif args.command == 'backup':
            storage.backup(args.path)
            
        elif args.command == 'export':
            storage.export_tasks(args.path, format=args.format)
            
        elif args.command == 'compact':
            storage.compact()
            
        elif args.command == 'search':
            tasks = storage.search_tasks(args.text)
            print_tasks(tasks)
            
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == '__main__':
    main()

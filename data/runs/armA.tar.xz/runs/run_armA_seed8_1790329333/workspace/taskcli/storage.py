import os
import json
import sqlite3
import shutil
import tempfile
from datetime import datetime
import toml

class TaskStorage:
    def __init__(self, db_path='tasks.db'):
        self.db_path = db_path
        self.init_db()
        
    def init_db(self):
        """Initialize the database and perform any necessary migrations"""
        # Check if database exists
        db_exists = os.path.exists(self.db_path)
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create config table if it doesn't exist
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS config (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        ''')
        
        # Check if we need to migrate from tasks.json
        if not db_exists:
            self.migrate_from_json()
            
        # Create items table if it doesn't exist (with new schema)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                done BOOLEAN DEFAULT 0,
                priority TEXT DEFAULT 'med',
                due TEXT,
                archived BOOLEAN DEFAULT 0,
                kind TEXT DEFAULT 'task'
            )
        ''')
        
        # Create tags table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS tags (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL
            )
        ''')
        
        # Create junction table for tasks and tags
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS task_tags (
                task_id INTEGER,
                tag_id INTEGER,
                PRIMARY KEY (task_id, tag_id),
                FOREIGN KEY (task_id) REFERENCES items (id),
                FOREIGN KEY (tag_id) REFERENCES tags (id)
            )
        ''')
        
        # Migrate old tasks table if exists
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='tasks'")
        if cursor.fetchone():
            self.migrate_old_tasks_table()
            
        conn.commit()
        conn.close()
        
    def migrate_from_json(self):
        """Migrate from legacy tasks.json file if it exists"""
        json_path = 'tasks.json'
        if os.path.exists(json_path):
            try:
                with open(json_path, 'r') as f:
                    tasks = json.load(f)
                
                conn = sqlite3.connect(self.db_path)
                cursor = conn.cursor()
                
                for task in tasks:
                    # Insert task
                    cursor.execute('''
                        INSERT INTO items (id, title, done, priority, due, archived, kind)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        task['id'],
                        task['title'],
                        task['done'],
                        task.get('priority', 'med'),
                        task.get('due'),
                        task.get('archived', False),
                        task.get('kind', 'task')
                    ))
                    
                    # Handle tags if present
                    if 'tags' in task and task['tags']:
                        for tag_name in task['tags']:
                            # Insert or get tag
                            cursor.execute('INSERT OR IGNORE INTO tags (name) VALUES (?)', (tag_name,))
                            cursor.execute('SELECT id FROM tags WHERE name = ?', (tag_name,))
                            tag_id = cursor.fetchone()[0]
                            
                            # Link task and tag
                            cursor.execute('''
                                INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?, ?)
                            ''', (task['id'], tag_id))
                
                conn.commit()
                conn.close()
                
                # Remove the old file
                os.remove(json_path)
                
            except Exception as e:
                print(f"Warning: Could not migrate from {json_path}: {e}")
    
    def migrate_old_tasks_table(self):
        """Migrate data from legacy 'tasks' table to 'items' table"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # Check if tasks table has tags column
            cursor.execute("PRAGMA table_info(tasks)")
            columns = [col[1] for col in cursor.fetchall()]
            
            # Migrate data from tasks to items
            if 'tags' in columns:
                cursor.execute('''
                    INSERT INTO items (id, title, done, priority, due, archived, kind)
                    SELECT id, title, done, COALESCE(priority, 'med'), due, COALESCE(archived, 0), 'task'
                    FROM tasks
                ''')
            else:
                cursor.execute('''
                    INSERT INTO items (id, title, done, priority, due, archived, kind)
                    SELECT id, title, done, 'med', due, COALESCE(archived, 0), 'task'
                    FROM tasks
                ''')
            
            # Migrate tags if they exist in old table
            cursor.execute('''
                INSERT OR IGNORE INTO tags (name) 
                SELECT DISTINCT tag FROM (
                    SELECT TRIM(value) as tag FROM tasks, json_each(tags) WHERE tags IS NOT NULL
                )
            ''')
            
            conn.commit()
        except Exception as e:
            print(f"Warning: Could not migrate old tasks table: {e}")
        finally:
            # Drop the old tasks table
            cursor.execute('DROP TABLE IF EXISTS tasks')
            conn.commit()
            conn.close()
    
    def get_next_id(self):
        """Get the next available task ID"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('SELECT COALESCE(MAX(id), 0) + 1 FROM items')
        next_id = cursor.fetchone()[0]
        conn.close()
        return next_id
    
    def _build_tasks_query(self, all_tasks=False, tag=None, smart=False):
        """Build the base query for retrieving tasks"""
        # Build base query
        if tag:
            # Join with task_tags and tags tables to filter by tag
            query = '''
                SELECT DISTINCT i.id, i.title, i.done, i.priority, i.due, i.archived, i.kind
                FROM items i
                JOIN task_tags tt ON i.id = tt.task_id
                JOIN tags t ON tt.tag_id = t.id
                WHERE t.name = ?
            '''
            params = [tag]
        else:
            query = 'SELECT id, title, done, priority, due, archived, kind FROM items'
            params = []
            
        # Add archived filter
        if not all_tasks:
            query += ' AND archived = 0'
        
        # Add ordering
        if smart:
            # Smart ordering: overdue first, then priority (high, med, low), then ID
            query += '''
                ORDER BY 
                    CASE WHEN due IS NOT NULL AND due < date('now') AND done = 0 THEN 0 ELSE 1 END,
                    CASE priority WHEN 'high' THEN 0 WHEN 'med' THEN 1 ELSE 2 END,
                    id
            '''
        else:
            # Default insertion order
            query += ' ORDER BY id'
        
        return query, params
    
    def add_task(self, title, tags=None, priority='med', due=None):
        """Add a new task and return its ID"""
        if not title.strip():
            raise ValueError("Task title cannot be empty")
            
        if due:
            try:
                datetime.strptime(due, '%Y-%m-%d')
            except ValueError:
                raise ValueError("Due date must be in YYYY-MM-DD format")
        
        task_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO items (id, title, priority, due, kind)
            VALUES (?, ?, ?, ?, ?)
        ''', (task_id, title, priority, due, 'task'))
        
        # Add tags if provided
        if tags:
            for tag_name in tags:
                # Insert or get tag
                cursor.execute('INSERT OR IGNORE INTO tags (name) VALUES (?)', (tag_name,))
                cursor.execute('SELECT id FROM tags WHERE name = ?', (tag_name,))
                tag_id = cursor.fetchone()[0]
                
                # Link task and tag
                cursor.execute('''
                    INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?, ?)
                ''', (task_id, tag_id))
        
        conn.commit()
        conn.close()
        return task_id
    
    def list_tasks(self, all_tasks=False, tag=None, smart=False):
        """List tasks using unified query path"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        query, params = self._build_tasks_query(all_tasks=all_tasks, tag=tag, smart=smart)
        cursor.execute(query, params)
        tasks = cursor.fetchall()
        conn.close()
        
        # Get tags for each task
        tasks_with_tags = []
        for task in tasks:
            task_dict = {
                'id': task[0],
                'title': task[1],
                'done': bool(task[2]),
                'priority': task[3],
                'due': task[4],
                'archived': bool(task[5]),
                'kind': task[6],
                'tags': self._get_task_tags(task[0])
            }
            tasks_with_tags.append(task_dict)
        
        return tasks_with_tags
    
    def _get_task_tags(self, task_id):
        """Get all tags for a specific task"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT t.name FROM tags t
            JOIN task_tags tt ON t.id = tt.tag_id
            WHERE tt.task_id = ?
        ''', (task_id,))
        tags = [row[0] for row in cursor.fetchall()]
        conn.close()
        return tags
    
    def mark_done(self, task_id):
        """Mark a task as done"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('UPDATE items SET done = 1 WHERE id = ?', (task_id,))
        
        if cursor.rowcount == 0:
            conn.close()
            raise ValueError(f"Task with ID {task_id} not found")
            
        conn.commit()
        conn.close()
    
    def delete_task(self, task_id):
        """Delete a task"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('DELETE FROM items WHERE id = ?', (task_id,))
        
        if cursor.rowcount == 0:
            conn.close()
            raise ValueError(f"Task with ID {task_id} not found")
            
        conn.commit()
        conn.close()
    
    def get_stats(self):
        """Get task statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Total tasks
        cursor.execute('SELECT COUNT(*) FROM items')
        total = cursor.fetchone()[0]
        
        # Pending tasks (not done and not archived)
        cursor.execute('SELECT COUNT(*) FROM items WHERE done = 0 AND archived = 0')
        pending = cursor.fetchone()[0]
        
        # Overdue tasks (not done, not archived, with due date in past)
        cursor.execute('''
            SELECT COUNT(*) FROM items 
            WHERE done = 0 AND archived = 0 AND due IS NOT NULL AND due < date('now')
        ''')
        overdue = cursor.fetchone()[0]
        
        # Completed tasks
        cursor.execute('SELECT COUNT(*) FROM items WHERE done = 1')
        completed = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            'total': total,
            'pending': pending,
            'overdue': overdue,
            'completed': completed
        }
    
    def archive_tasks(self):
        """Archive all completed tasks"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('UPDATE items SET archived = 1 WHERE done = 1')
        conn.commit()
        conn.close()
    
    def backup(self, path):
        """Create a backup of the database"""
        # Create temporary file
        temp_path = path + '.tmp'
        shutil.copy2(self.db_path, temp_path)
        
        # Atomically rename to final path
        os.rename(temp_path, path)
    
    def export_tasks(self, path, format='json'):
        """Export all tasks using unified query path"""
        # Use the same query logic as list_tasks but with all_tasks=True
        tasks = self.list_tasks(all_tasks=True)
        
        if format == 'json':
            with open(path, 'w') as f:
                json.dump(tasks, f, indent=2)
        elif format == 'csv':
            import csv
            with open(path, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['ID', 'Title', 'Done', 'Priority', 'Due', 'Archived', 'Tags'])
                for task in tasks:
                    tags_str = ','.join(task['tags']) if task['tags'] else ''
                    writer.writerow([
                        task['id'],
                        task['title'],
                        'true' if task['done'] else 'false',
                        task['priority'],
                        task['due'] or '',
                        'true' if task['archived'] else 'false',
                        tags_str
                    ])
    
    def compact(self):
        """Reclaim space from deleted rows"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('VACUUM')
        conn.commit()
        conn.close()
        
    def search_tasks(self, text):
        """Search tasks by title (case-insensitive)"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Search for tasks containing the text in title (case-insensitive)
        query = '''
            SELECT i.id, i.title, i.done, i.priority, i.due, i.archived, i.kind
            FROM items i
            WHERE LOWER(i.title) LIKE LOWER(?)
            AND archived = 0
            ORDER BY i.id
        '''
        
        cursor.execute(query, (f'%{text}%',))
        tasks = cursor.fetchall()
        conn.close()
        
        # Get tags for each task
        tasks_with_tags = []
        for task in tasks:
            task_dict = {
                'id': task[0],
                'title': task[1],
                'done': bool(task[2]),
                'priority': task[3],
                'due': task[4],
                'archived': bool(task[5]),
                'kind': task[6],
                'tags': self._get_task_tags(task[0])
            }
            tasks_with_tags.append(task_dict)
        
        return tasks_with_tags

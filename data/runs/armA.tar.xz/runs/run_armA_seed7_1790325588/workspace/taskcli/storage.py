import sqlite3
import os
import shutil
import json
from datetime import datetime
from typing import List, Dict, Any

class Storage:
    def __init__(self, db_path='tasks.db', today=None):
        self.db_path = db_path
        self.today = today or str(datetime.now().date())
        self.init_db()
        
    def init_db(self):
        """Initialize the database with proper schema."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if we have an old tasks table and migrate if needed
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='tasks'")
        if cursor.fetchone():
            # Migrate from old schema
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    priority TEXT DEFAULT 'med',
                    due TEXT,
                    archived BOOLEAN DEFAULT FALSE,
                    kind TEXT DEFAULT 'task',
                    tags TEXT DEFAULT ''
                )
            """)
            
            # Migrate data
            cursor.execute("""
                INSERT OR IGNORE INTO items (id, title, done, priority, due, archived, kind, tags)
                SELECT id, title, done, priority, due, archived, kind, tags FROM tasks
            """)
            
            # Drop old table
            cursor.execute("DROP TABLE IF EXISTS tasks")
        else:
            # Create new schema
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    priority TEXT DEFAULT 'med',
                    due TEXT,
                    archived BOOLEAN DEFAULT FALSE,
                    kind TEXT DEFAULT 'task',
                    tags TEXT DEFAULT ''
                )
            """)
            
        conn.commit()
        conn.close()
        
    def get_next_id(self) -> int:
        """Get the next available task ID."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items")
        next_id = cursor.fetchone()[0]
        conn.close()
        return next_id
        
    def add_task(self, title: str, priority: str = 'med', due: str = None, tags: List[str] = None) -> int:
        """Add a new task and return its ID."""
        task_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO items (id, title, priority, due, tags)
            VALUES (?, ?, ?, ?, ?)
        """, (task_id, title, priority, due, ','.join(tags) if tags else ''))
        conn.commit()
        conn.close()
        
        return task_id
        
    def _build_list_query(self, sort_by: str = 'insertion', overdue: bool = False, 
                         show_archived: bool = False, tags: List[str] = None) -> tuple:
        """Build the base query for listing tasks."""
        # Build base query
        query = "SELECT id, title, done, priority, due, archived, tags FROM items WHERE "
        
        # Filter out archived tasks unless explicitly requested
        if not show_archived:
            query += "archived = FALSE AND "
            
        # Add overdue filter if requested
        if overdue:
            query += f"due < '{self.today}' AND done = FALSE AND due IS NOT NULL AND "
            
        query += "1=1 ORDER BY "
        
        # Apply sorting
        if sort_by == 'priority':
            # Sort by priority (high, med, low) then insertion order
            query += """
                CASE priority 
                    WHEN 'high' THEN 1 
                    WHEN 'med' THEN 2 
                    WHEN 'low' THEN 3 
                    ELSE 4 
                END,
                id
            """
        else:
            # Insertion order
            query += "id"
            
        return query, []
        
    def list_tasks(self, sort_by: str = 'insertion', overdue: bool = False, 
                   show_archived: bool = False, tags: List[str] = None) -> List[Dict]:
        """List all tasks."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        query, params = self._build_list_query(sort_by, overdue, show_archived, tags)
        cursor.execute(query, params)
        rows = cursor.fetchall()
        conn.close()
        
        # Convert to task objects with additional computed fields
        tasks = []
        for row in rows:
            task = {
                'id': row[0],
                'title': row[1],
                'done': bool(row[2]),
                'priority': row[3],
                'due': row[4],
                'archived': bool(row[5]),
                'tags': row[6].split(',') if row[6] else []
            }
            
            # Add computed fields for display
            task['overdue'] = (task['due'] and task['due'] < self.today and not task['done'])
            
            # Filter by tags if specified
            if tags:
                if not any(tag in task['tags'] for tag in tags):
                    continue
                    
            tasks.append(task)
            
        return tasks
        
    def mark_done(self, task_id: int) -> None:
        """Mark a task as done."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("UPDATE items SET done = TRUE WHERE id = ?", (task_id,))
        
        if cursor.rowcount == 0:
            raise ValueError(f"Task with ID {task_id} not found")
            
        conn.commit()
        conn.close()
        
    def delete_task(self, task_id: int) -> None:
        """Delete a task."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM items WHERE id = ?", (task_id,))
        
        if cursor.rowcount == 0:
            raise ValueError(f"Task with ID {task_id} not found")
            
        conn.commit()
        conn.close()
        
    def edit_task(self, task_id: int, title: str = None, priority: str = None, 
                  due: str = None, tags: List[str] = None, clear_tags: bool = False) -> None:
        """Edit an existing task."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Build update query
        updates = []
        params = []
        
        if title is not None:
            updates.append("title = ?")
            params.append(title)
            
        if priority is not None:
            updates.append("priority = ?")
            params.append(priority)
            
        if due is not None:
            updates.append("due = ?")
            params.append(due)
            
        if tags is not None or clear_tags:
            if clear_tags:
                tag_string = ''
            else:
                tag_string = ','.join(tags) if tags else ''
            updates.append("tags = ?")
            params.append(tag_string)
            
        if updates:
            query = f"UPDATE items SET {', '.join(updates)} WHERE id = ?"
            params.append(task_id)
            cursor.execute(query, params)
            
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
                
        conn.commit()
        conn.close()
        
    def get_stats(self) -> Dict[str, int]:
        """Get task statistics."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Total tasks
        cursor.execute("SELECT COUNT(*) FROM items")
        total = cursor.fetchone()[0]
        
        # Done tasks
        cursor.execute("SELECT COUNT(*) FROM items WHERE done = TRUE")
        done = cursor.fetchone()[0]
        
        # Open tasks (total - done)
        open_tasks = total - done
        
        # Priority breakdown
        cursor.execute("SELECT priority, COUNT(*) FROM items GROUP BY priority")
        priority_counts = dict(cursor.fetchall())
        
        high_priority = priority_counts.get('high', 0)
        med_priority = priority_counts.get('med', 0)
        low_priority = priority_counts.get('low', 0)
        
        conn.close()
        
        return {
            'total': total,
            'done': done,
            'open': open_tasks,
            'high_priority': high_priority,
            'med_priority': med_priority,
            'low_priority': low_priority
        }
        
    def archive_tasks(self) -> None:
        """Archive all done tasks."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("UPDATE items SET archived = TRUE WHERE done = TRUE")
        conn.commit()
        conn.close()
        
    def backup(self, path: str) -> None:
        """Create a backup of the database."""
        # Create temporary file
        temp_path = f"{path}.tmp"
        shutil.copy2(self.db_path, temp_path)
        # Atomically move to final location
        os.replace(temp_path, path)
        
    def export(self, path: str, format: str = 'json') -> None:
        """Export tasks to a file."""
        # Use the same query logic as list_tasks but with all archived tasks included
        tasks = self.list_tasks(show_archived=True)
        
        if format == 'csv':
            import csv
            with open(path, 'w', newline='') as csvfile:
                fieldnames = ['id', 'title', 'done', 'priority', 'due', 'archived', 'kind', 'tags']
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                
                writer.writeheader()
                for task in tasks:
                    # Convert booleans to strings for CSV
                    task['done'] = str(task['done']).lower()
                    task['archived'] = str(task['archived']).lower()
                    # Convert tags list to comma-separated string
                    task['tags'] = ','.join(task['tags'])
                    writer.writerow(task)
        else:  # JSON format
            with open(path, 'w') as f:
                json.dump(tasks, f, indent=2)
                
    def compact(self) -> None:
        """Compact the database to reclaim space."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("VACUUM")
        conn.commit()
        conn.close()
        
    def search_tasks(self, text: str) -> List[Dict]:
        """Search for tasks by title (case-insensitive)."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Search for tasks with titles containing the text (case-insensitive)
        cursor.execute("""
            SELECT id, title, done, priority, due, archived, tags 
            FROM items 
            WHERE LOWER(title) LIKE ?
            ORDER BY id
        """, (f'%{text.lower()}%',))
        
        rows = cursor.fetchall()
        conn.close()
        
        # Convert to task objects with additional computed fields
        tasks = []
        for row in rows:
            task = {
                'id': row[0],
                'title': row[1],
                'done': bool(row[2]),
                'priority': row[3],
                'due': row[4],
                'archived': bool(row[5]),
                'tags': row[6].split(',') if row[6] else []
            }
            
            # Add computed fields for display
            task['overdue'] = (task['due'] and task['due'] < self.today and not task['done'])
            
            tasks.append(task)
            
        return tasks

#!/usr/bin/env python3

import sys
from datetime import date

class Task:
    def __init__(self, id, title, done=False, priority='med', due=None, archived=False):
        self.id = id
        self.title = title
        self.done = done
        self.priority = priority
        self.due = due
        self.archived = archived

    def format_list(self, color_mode='auto'):
        """Format task for list output."""
        # Determine if we should use colors
        use_color = False
        if color_mode == 'always':
            use_color = True
        elif color_mode == 'auto' and sys.stdout.isatty():
            use_color = True

        # Format priority
        priority_str = f"(priority: {self.priority})"

        # Format due date
        due_str = ""
        if self.due:
            due_str = f" (due: {self.due})"

        # Build the base string
        status_symbol = "✓" if self.done else "○"
        task_str = f"{self.id} {status_symbol} {self.title} {priority_str}{due_str}"

        # Apply colors if needed
        if use_color and not self.archived:
            if self.due:
                today_str = self.get_today()
                try:
                    due_date = date.fromisoformat(self.due)
                    today = date.fromisoformat(today_str)
                    if due_date < today and not self.done:
                        # Overdue task - red
                        task_str = f"\033[31m{task_str}\033[0m"
                except ValueError:
                    pass  # Invalid date format, ignore coloring
            elif self.done:
                # Completed task - green
                task_str = f"\033[32m{task_str}\033[0m"

        return task_str

    def get_today(self):
        """Get today's date string from environment or default to current date."""
        today_str = os.environ.get('TASKCLI_TODAY', str(date.today()))
        try:
            date.fromisoformat(today_str)
            return today_str
        except ValueError:
            # If invalid, fall back to current date
            return str(date.today())

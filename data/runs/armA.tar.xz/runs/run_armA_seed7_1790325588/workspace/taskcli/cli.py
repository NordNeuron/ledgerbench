import argparse
import os
import sys
from .storage import Storage
from . import __version__

def create_parser():
    parser = argparse.ArgumentParser(
        prog='taskcli',
        description='A minimal command-line task manager.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  taskcli add "Buy milk"
  taskcli done 1
  taskcli list --sort priority
  taskcli search "milk"
        """
    )
    parser.add_argument('--version', action='version', version=f'%(prog)s {__version__}')
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['low', 'med', 'high'], default='med',
                           help='Task priority (default: med)')
    add_parser.add_argument('--due', help='Due date (YYYY-MM-DD)')
    add_parser.add_argument('--tag', action='append', help='Add a tag (can be used multiple times)')

    # List command
    list_parser = subparsers.add_parser('list', help='List all tasks')
    list_parser.add_argument('--sort', choices=['insertion', 'priority'], default='insertion',
                            help='Sort order (default: insertion)')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')
    list_parser.add_argument('--all', action='store_true', help='Show archived tasks too')
    list_parser.add_argument('--tag', action='append', help='Filter by tag (can be used multiple times)')
    list_parser.add_argument('--color', choices=['auto', 'always', 'never'], default='auto',
                            help='Color output (default: auto)')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Edit command
    edit_parser = subparsers.add_parser('edit', help='Edit a task')
    edit_parser.add_argument('id', type=int, help='Task ID')
    edit_parser.add_argument('--title', help='New title')
    edit_parser.add_argument('--priority', choices=['low', 'med', 'high'], help='New priority')
    edit_parser.add_argument('--due', help='New due date (YYYY-MM-DD)')
    edit_parser.add_argument('--tag', action='append', help='Add a tag (can be used multiple times)')
    edit_parser.add_argument('--clear-tags', action='store_true', help='Remove all tags')

    # Stats command
    subparsers.add_parser('stats', help='Show task statistics')

    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive completed tasks')
    
    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Create a backup of the database')
    backup_parser.add_argument('path', help='Backup file path')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks to JSON or CSV')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json',
                              help='Export format (default: json)')

    # Compact command
    subparsers.add_parser('compact', help='Compact the database')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search for tasks by title')
    search_parser.add_argument('text', help='Text to search for in task titles')

    return parser

def print_task(task, color=False):
    """Print a single task in list format."""
    if task['done']:
        status = '✓'
        if color:
            status = '\033[32m✓\033[0m'  # Green checkmark
    else:
        status = '○'
        if color and task.get('overdue', False):
            status = '\033[31m○\033[0m'  # Red circle for overdue
    
    priority_display = f" (priority: {task['priority']})" if task['priority'] else ""
    due_display = f" (due: {task['due']})" if task['due'] else ""
    
    print(f"{task['id']}: [{status}] {task['title']}{priority_display}{due_display}")

def main():
    parser = create_parser()
    args = parser.parse_args()
    
    # Set today for time-dependent operations
    if 'TASKCLI_TODAY' in os.environ:
        today = os.environ['TASKCLI_TODAY']
    else:
        from datetime import date
        today = str(date.today())
    
    storage = Storage(today=today)
    
    try:
        # Emit audit line for all commands before processing
        if args.command is None:
            command_name = 'help'
        else:
            command_name = args.command
            
        print(f"AUDIT {command_name}", file=sys.stderr)
        
        if args.command == 'add':
            task_id = storage.add_task(
                title=args.title,
                priority=args.priority,
                due=args.due,
                tags=args.tag or []
            )
            print(task_id)
            
        elif args.command == 'list':
            tasks = storage.list_tasks(
                sort_by=args.sort,
                overdue=args.overdue,
                show_archived=args.all,
                tags=args.tag or []
            )
            color = (args.color == 'always' or 
                    (args.color == 'auto' and sys.stdout.isatty()))
            for task in tasks:
                print_task(task, color)
                
        elif args.command == 'done':
            storage.mark_done(args.id)
            
        elif args.command == 'delete':
            storage.delete_task(args.id)
            
        elif args.command == 'edit':
            storage.edit_task(
                task_id=args.id,
                title=args.title,
                priority=args.priority,
                due=args.due,
                tags=args.tag or [],
                clear_tags=args.clear_tags
            )
            
        elif args.command == 'stats':
            stats = storage.get_stats()
            print(f"Total: {stats['total']}")
            print(f"Done:  {stats['done']}")
            print(f"Open:  {stats['open']}")
            print(f"High priority: {stats['high_priority']}")
            print(f"Medium priority: {stats['med_priority']}")
            print(f"Low priority: {stats['low_priority']}")
            
        elif args.command == 'archive':
            storage.archive_tasks()
            
        elif args.command == 'backup':
            storage.backup(args.path)
            
        elif args.command == 'export':
            storage.export(args.path, format=args.format)
            
        elif args.command == 'compact':
            storage.compact()
            
        elif args.command == 'search':
            tasks = storage.search_tasks(args.text)
            color = (args.color == 'always' or 
                    (args.color == 'auto' and sys.stdout.isatty()))
            for task in tasks:
                print_task(task, color)
                
        else:
            parser.print_help()
            return 2
            
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
        
    return 0

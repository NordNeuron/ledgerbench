import os

# Database file path
DB_PATH = os.path.join(os.getcwd(), 'tasks.db')

# Legacy JSON file path (for migration)
LEGACY_JSON_PATH = os.path.join(os.getcwd(), 'tasks.json')

import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import TaskStorage

def get_config():
    config = {}
    try:
        with open("config.toml", "r", encoding="utf-8") as f:
            import toml
            config = toml.load(f)
    except (FileNotFoundError, toml.TomlDecodeError):
        pass
    
    # Check deprecated env var if no config file or no today key
    if "today" not in config:
        today_env = os.environ.get("TASKCLI_TODAY")
        if today_env:
            config["today"] = today_env
    
    return config

def parse_date(date_str):
    try:
        return datetime.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        raise argparse.ArgumentTypeError(f"Invalid date format: {date_str}. Expected YYYY-MM-DD.")

def main():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--due", help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--priority", choices=["high", "med", "low"], default="med", help="Priority level")
    add_parser.add_argument("--tag", action="append", help="Tag for the task (repeatable)")

    # List command
    list_parser = subparsers.add_parser("list", help="List all tasks")
    list_parser.add_argument("--sort", choices=["priority", "insertion"], default="insertion", help="Sort order")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks")
    list_parser.add_argument("--tag", help="Filter by tag")
    list_parser.add_argument("--color", action="store_true", help="Enable colored output")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark a task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show statistics")

    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup the database")
    backup_parser.add_argument("path", help="Backup destination path")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export destination path")
    export_parser.add_argument("--format", choices=["json", "csv"], default="json", help="Export format")

    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Reclaim dead space from deleted rows")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Text to search for in task titles")

    args = parser.parse_args()

    config = get_config()
    today_str = config.get("today", datetime.now().strftime("%Y-%m-%d"))
    today = parse_date(today_str)

    # Emit audit line - this must happen before any other processing
    sys.stderr.write(f"AUDIT {args.command}\n")
    sys.stderr.flush()

    storage = TaskStorage()

    try:
        if args.command == "add":
            due_date = parse_date(args.due) if args.due else None
            priority = args.priority
            tags = args.tag or []
            new_id = storage.add_task(args.title, due_date, priority, tags)
            print(new_id)

        elif args.command == "list":
            tasks = storage.list_tasks(args.sort, args.all, args.tag, args.overdue)
            for task in tasks:
                done_mark = "✓" if task["done"] else "○"
                priority_symbol = {"high": "H", "med": "M", "low": "L"}[task["priority"]]
                due_str = f" (due {task['due']})" if task["due"] else ""
                title = task["title"]
                # Only add ANSI codes when stdout is a TTY
                if args.color and sys.stdout.isatty():
                    if task["overdue"]:
                        title = f"\033[31m{title}\033[0m"
                    elif task["done"]:
                        title = f"\033[32m{title}\033[0m"
                print(f"{task['id']} {done_mark} [{priority_symbol}] {title}{due_str}")

        elif args.command == "done":
            storage.mark_done(args.id)
            
        elif args.command == "delete":
            storage.delete_task(args.id)

        elif args.command == "stats":
            stats = storage.get_stats(today)
            print(f"Total: {stats['total']}")
            print(f"Done: {stats['done']}")
            print(f"Open: {stats['open']}")
            print(f"Priority high: {stats['priority_high']}")
            print(f"Priority med: {stats['priority_med']}")
            print(f"Priority low: {stats['priority_low']}")
            if stats["overdue"] > 0:
                print(f"\033[31mOverdue: {stats['overdue']}\033[0m")
            else:
                print(f"Overdue: {stats['overdue']}")

        elif args.command == "archive":
            storage.archive_done()

        elif args.command == "backup":
            storage.backup(args.path)

        elif args.command == "export":
            if args.format == "csv":
                storage.export_csv(args.path, args.all, args.tag, args.overdue)
            else:
                storage.export_json(args.path, args.all, args.tag, args.overdue)

        elif args.command == "compact":
            storage.compact()

        elif args.command == "search":
            tasks = storage.search_tasks(args.text)
            for task in tasks:
                done_mark = "✓" if task["done"] else "○"
                priority_symbol = {"high": "H", "med": "M", "low": "L"}[task["priority"]]
                due_str = f" (due {task['due']})" if task["due"] else ""
                title = task["title"]
                # Only add ANSI codes when stdout is a TTY
                if args.color and sys.stdout.isatty():
                    if task["overdue"]:
                        title = f"\033[31m{title}\033[0m"
                    elif task["done"]:
                        title = f"\033[32m{title}\033[0m"
                print(f"{task['id']} {done_mark} [{priority_symbol}] {title}{due_str}")

        else:
            parser.print_help()
            return 1

    except ValueError as e:
        sys.stderr.write(str(e) + "\n")
        return 2
    except Exception as e:
        sys.stderr.write(f"Error: {str(e)}\n")
        return 1

    return 0

import os
import json
import sqlite3
import shutil
import csv
from datetime import datetime
from contextlib import contextmanager

class TaskStorage:
    def __init__(self, db_path="tasks.db"):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        with self.get_db() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    due DATE,
                    priority TEXT DEFAULT 'med',
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE,
                    tags TEXT DEFAULT '[]'
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_items_id ON items(id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_items_kind ON items(kind)")

    @contextmanager
    def get_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            yield conn
        finally:
            conn.close()

    def add_task(self, title, due_date, priority, tags):
        with self.get_db() as conn:
            cursor = conn.cursor()
            
            # Get the maximum id to assign a new one
            max_id_row = cursor.execute("SELECT MAX(id) FROM items WHERE kind = 'task'").fetchone()
            new_id = (max_id_row[0] or 0) + 1
            
            # Insert the task
            cursor.execute("""
                INSERT INTO items (id, kind, title, due, priority, tags)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (new_id, "task", title, due_date, priority, json.dumps(tags)))
            
            conn.commit()
            return new_id

    def _get_tasks_query(self, show_all=False, tag_filter=None, overdue_only=False):
        """Get the base query for tasks with appropriate filters."""
        query = """
            SELECT id, title, due, priority, done, archived, tags
            FROM items
            WHERE kind = 'task'
        """
        
        params = []
        
        if not show_all:
            query += " AND archived = 0"
            
        if tag_filter:
            query += " AND tags LIKE ?"
            params.append(f'%"{tag_filter}"%')
            
        if overdue_only:
            query += " AND due < ? AND done = 0"
            params.append(datetime.now().strftime("%Y-%m-%d"))
        
        return query, params

    def list_tasks(self, sort_order="insertion", show_all=False, tag_filter=None, overdue_only=False):
        with self.get_db() as conn:
            cursor = conn.cursor()
            
            # Get base query and parameters
            query, params = self._get_tasks_query(show_all, tag_filter, overdue_only)
            
            # Apply sorting
            if sort_order == "priority":
                # Order by priority (high, med, low) then by insertion order
                query += """
                    ORDER BY 
                        CASE priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 ELSE 3 END,
                        id
                """
            else:
                # Insertion order - this is the key fix for T2 requirements
                query += " ORDER BY id"
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    "id": row[0],
                    "title": row[1],
                    "due": row[2],
                    "priority": row[3],
                    "done": bool(row[4]),
                    "archived": bool(row[5]),
                    "tags": json.loads(row[6]) if row[6] else [],
                    "overdue": False
                }
                # Check if task is overdue
                if task["due"]:
                    try:
                        due_date = datetime.strptime(task["due"], "%Y-%m-%d").date()
                        today = datetime.now().date()
                        task["overdue"] = due_date < today and not task["done"]
                    except ValueError:
                        pass  # Invalid date format, ignore
                tasks.append(task)
            
            return tasks

    def mark_done(self, task_id):
        with self.get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET done = 1 WHERE id = ? AND kind = 'task'", (task_id,))
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
            conn.commit()

    def delete_task(self, task_id):
        with self.get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
            conn.commit()

    def get_stats(self, today):
        with self.get_db() as conn:
            cursor = conn.cursor()
            
            # Total tasks
            total = cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task'").fetchone()[0]
            
            # Done tasks
            done = cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND done = 1").fetchone()[0]
            
            # Open tasks
            open_tasks = total - done
            
            # Priority counts
            priority_high = cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND priority = 'high'").fetchone()[0]
            priority_med = cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND priority = 'med'").fetchone()[0]
            priority_low = cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND priority = 'low'").fetchone()[0]
            
            # Overdue tasks
            overdue = cursor.execute("""
                SELECT COUNT(*) FROM items 
                WHERE kind = 'task' AND due < ? AND done = 0
            """, (today.strftime("%Y-%m-%d"),)).fetchone()[0]
            
            return {
                "total": total,
                "done": done,
                "open": open_tasks,
                "priority_high": priority_high,
                "priority_med": priority_med,
                "priority_low": priority_low,
                "overdue": overdue
            }

    def archive_done(self):
        with self.get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived = 1 WHERE done = 1 AND kind = 'task'")
            conn.commit()

    def backup(self, path):
        tmp_path = path + ".tmp"
        try:
            shutil.copy2(self.db_path, tmp_path)
            os.rename(tmp_path, path)
        except Exception as e:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise e

    def export_json(self, path, show_all=False, tag_filter=None, overdue_only=False):
        tasks = self.list_tasks("insertion", show_all, tag_filter, overdue_only)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(tasks, f, indent=2)

    def export_csv(self, path, show_all=False, tag_filter=None, overdue_only=False):
        tasks = self.list_tasks("insertion", show_all, tag_filter, overdue_only)
        with open(path, "w", newline="", encoding="utf-8") as f:
            if not tasks:
                return
            fieldnames = ["id", "title", "due", "priority", "done", "archived", "tags"]
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for task in tasks:
                # Convert done and archived to boolean strings
                task["done"] = str(task["done"]).lower()
                task["archived"] = str(task["archived"]).lower()
                # Ensure tags is a string representation of list
                if isinstance(task["tags"], list):
                    task["tags"] = json.dumps(task["tags"])
                writer.writerow(task)

    def compact(self):
        with self.get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("VACUUM")
            conn.commit()

    def search_tasks(self, text):
        with self.get_db() as conn:
            cursor = conn.cursor()
            
            # Search for tasks whose title contains the text (case-insensitive)
            query = """
                SELECT id, title, due, priority, done, archived, tags
                FROM items
                WHERE kind = 'task' AND LOWER(title) LIKE ?
                ORDER BY id
            """
            
            cursor.execute(query, (f"%{text.lower()}%",))
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    "id": row[0],
                    "title": row[1],
                    "due": row[2],
                    "priority": row[3],
                    "done": bool(row[4]),
                    "archived": bool(row[5]),
                    "tags": json.loads(row[6]) if row[6] else [],
                    "overdue": False
                }
                # Check if task is overdue
                if task["due"]:
                    try:
                        due_date = datetime.strptime(task["due"], "%Y-%m-%d").date()
                        today = datetime.now().date()
                        task["overdue"] = due_date < today and not task["done"]
                    except ValueError:
                        pass  # Invalid date format, ignore
                tasks.append(task)
            
            return tasks

import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import get_db_path, init_db, get_tasks, update_task, delete_task, add_task, archive_tasks, compact_db, backup_db, export_db, get_stats, get_overdue_count, search_tasks, get_tasks_for_export

def pin_today(date_str):
    """Set today's date for testing purposes."""
    os.environ['TASKCLI_TODAY'] = date_str
    return os.environ

def main():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--priority', choices=['high', 'med', 'low'], default=None, help='Task priority')
    add_parser.add_argument('--tag', action='append', help='Add a tag (can be used multiple times)')
    
    # List command
    list_parser = subparsers.add_parser('list', help='List tasks')
    list_parser.add_argument('--sort', choices=['priority', 'insertion'], default='insertion', help='Sort order')
    list_parser.add_argument('--all', action='store_true', help='Show archived tasks')
    list_parser.add_argument('--color', action='store_true', help='Enable colored output')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')
    
    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', type=int, help='Task ID')
    
    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')
    
    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')
    
    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')
    
    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Reclaim dead space from deleted rows')
    
    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup the database')
    backup_parser.add_argument('path', help='Backup file path')
    
    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['csv'], default='default', help='Export format')
    
    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for in task titles')
    
    args = parser.parse_args()
    
    # Emit audit line for every command invocation
    print(f"AUDIT {args.command}", file=sys.stderr)
    
    if not args.command:
        return 0
    
    try:
        db_path = get_db_path()
        init_db(db_path)
        
        if args.command == 'add':
            # Validate due date if provided
            if args.due:
                try:
                    datetime.strptime(args.due, '%Y-%m-%d')
                except ValueError:
                    print(f"error: invalid date format '{args.due}'; expected YYYY-MM-DD", file=sys.stderr)
                    return 2
            
            task_id = add_task(
                db_path,
                args.title,
                args.due,
                args.priority,
                args.tag or []
            )
            print(task_id)
            # Add command is completely silent (no audit line after the initial one)
            return 0
            
        elif args.command == 'list':
            tasks = get_tasks(db_path, args.sort, args.all, args.tag, args.overdue)
            for task in tasks:
                # Determine if we should color this line
                color = None
                if args.color and sys.stdout.isatty():
                    if task['done']:
                        color = 'green'
                    elif task['overdue']:
                        color = 'red'
                
                print(format_task(task, color))
            # List command is done - audit already emitted
            
        elif args.command == 'done':
            # Call update_task but suppress all output - let it raise SystemExit if needed
            try:
                update_task(db_path, args.id, done=True)
            except SystemExit as e:
                return e.code
                
        elif args.command == 'delete':
            # Call delete_task but suppress all output - let it raise SystemExit if needed
            try:
                delete_task(db_path, args.id)
            except SystemExit as e:
                return e.code
                
        elif args.command == 'archive':
            archive_tasks(db_path)
            # Archive command is done - audit already emitted
            
        elif args.command == 'stats':
            stats = get_stats(db_path)
            print(f"Total: {stats['total']}")
            print(f"Done: {stats['done']}")
            print(f"Open: {stats['open']}")
            print(f"Priority high: {stats['priority_high']}")
            print(f"Priority med: {stats['priority_med']}")
            print(f"Priority low: {stats['priority_low']}")
            print(f"Overdue: {stats['overdue']}")
            # Stats command is done - audit already emitted
            
        elif args.command == 'compact':
            compact_db(db_path)
            # Compact command is done - audit already emitted
            
        elif args.command == 'backup':
            try:
                backup_db(db_path, args.path)
            except Exception as e:
                print(str(e), file=sys.stderr)
                return 1
            # Backup command is done - audit already emitted
                
        elif args.command == 'export':
            try:
                export_db(db_path, args.path, args.format)
            except Exception as e:
                print(str(e), file=sys.stderr)
                return 1
            # Export command is done - audit already emitted
            
        elif args.command == 'search':
            tasks = search_tasks(db_path, args.text)
            for task in tasks:
                print(format_task(task))
            # Search command is done - audit already emitted
                
    except SystemExit as e:
        # Re-raise SystemExit to maintain exit code behavior
        return e.code
    except Exception as e:
        # For any other exceptions, print to stderr and return 1
        print(str(e), file=sys.stderr)
        return 1
        
    return 0

def format_task(task, color=None):
    """Format a task for display."""
    # Build the display string
    done_symbol = '✓' if task['done'] else '○'
    priority_symbol = {'high': 'H', 'med': 'M', 'low': 'L'}[task['priority']]
    
    # Format due date as YYYY-MM-DD or show empty if not set
    due_str = task['due'] if task['due'] else ''
    
    # Build the title part
    title_part = f"{done_symbol} [{priority_symbol}] {task['title']}"
    
    # Add due date if present
    if due_str:
        title_part += f" (due {due_str})"
        
    # Add tags if present
    if task['tags']:
        title_part += f" [tags: {', '.join(task['tags'])}]"
        
    # Apply color if specified and stdout is a TTY
    if color and sys.stdout.isatty():
        ansi_codes = {
            'red': '\033[31m',
            'green': '\033[32m'
        }
        reset_code = '\033[0m'
        return f"{ansi_codes[color]}{title_part}{reset_code}"
        
    return title_part

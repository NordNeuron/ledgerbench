import os
import sqlite3
import json
import shutil
from datetime import datetime, date

def get_db_path():
    """Get the path to the database file."""
    # Check for config.toml first
    config_path = os.path.join(os.getcwd(), 'config.toml')
    if os.path.exists(config_path):
        try:
            import tomli  # Try tomli first (Python 3.11+)
        except ImportError:
            try:
                import tomllib as tomli  # Python 3.11+
            except ImportError:
                raise ImportError("tomli or tomllib is required for config parsing")
        
        with open(config_path, 'rb') as f:
            config = tomli.load(f)
            
        if 'database' in config and config['database']:
            return os.path.abspath(config['database'])
    
    # Default to tasks.db in current directory
    return os.path.join(os.getcwd(), 'tasks.db')

def init_db(db_path):
    """Initialize the database with required tables."""
    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.cursor()
        
        # Create items table if it doesn't exist
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY,
                kind TEXT NOT NULL,
                title TEXT NOT NULL,
                due DATE,
                priority TEXT DEFAULT 'med',
                done BOOLEAN DEFAULT FALSE,
                archived BOOLEAN DEFAULT FALSE,
                tags TEXT DEFAULT ''
            )
        ''')
        
        # Create indexes for performance
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_kind ON items(kind)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_done ON items(done)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_archived ON items(archived)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_priority ON items(priority)')
        
        conn.commit()
    finally:
        conn.close()

def get_tasks(db_path, sort_order='insertion', show_all=False, tag_filter=None, overdue_only=False):
    """Get all tasks from the database."""
    return get_tasks_for_export(db_path, sort_order, show_all, tag_filter, overdue_only)

def get_tasks_for_export(db_path, sort_order='insertion', show_all=False, tag_filter=None, overdue_only=False):
    """Get all tasks from the database for export/list operations."""
    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.cursor()
        
        # Build base query
        query = '''
            SELECT id, title, due, priority, done, archived, tags 
            FROM items 
            WHERE kind = 'task'
        '''
        
        params = []
        
        # Filter out archived tasks unless show_all is True
        if not show_all:
            query += ' AND archived = 0'
            
        # Apply tag filter if specified
        if tag_filter:
            query += ' AND tags LIKE ?'
            params.append(f'%{tag_filter}%')
            
        # Apply overdue filter if specified
        if overdue_only:
            today_str = get_today()
            query += ' AND due < ? AND done = 0'
            params.append(today_str)
        
        # Sort tasks
        if sort_order == 'priority':
            # High, then med, then low priority
            query += '''
                ORDER BY 
                    CASE priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 ELSE 3 END,
                    id ASC
            '''
        else:
            # Insertion order (default)
            query += ' ORDER BY id ASC'
            
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        tasks = []
        today_str = get_today()
        today_date = datetime.strptime(today_str, '%Y-%m-%d').date()
        
        for row in rows:
            task_id, title, due, priority, done, archived, tags_str = row
            
            # Parse tags
            tags = [t.strip() for t in tags_str.split(',') if t.strip()] if tags_str else []
            
            # Determine if overdue
            overdue = False
            if due:
                try:
                    due_date = datetime.strptime(due, '%Y-%m-%d').date()
                    overdue = due_date < today_date and not done
                except ValueError:
                    pass  # Invalid date format, treat as not overdue
                    
            tasks.append({
                'id': task_id,
                'title': title,
                'due': due,
                'priority': priority,
                'done': done,
                'archived': archived,
                'tags': tags,
                'overdue': overdue
            })
            
        return tasks
    finally:
        conn.close()

def add_task(db_path, title, due=None, priority=None, tags=None):
    """Add a new task to the database."""
    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.cursor()
        
        # Get next ID - find the maximum existing ID and increment
        cursor.execute('SELECT COALESCE(MAX(id), 0) + 1 FROM items')
        task_id = cursor.fetchone()[0]
        
        # Default priority from config if not provided
        if priority is None:
            config_path = os.path.join(os.getcwd(), 'config.toml')
            if os.path.exists(config_path):
                try:
                    import tomli
                except ImportError:
                    try:
                        import tomllib as tomli
                    except ImportError:
                        raise ImportError("tomli or tomllib is required for config parsing")
                
                with open(config_path, 'rb') as f:
                    config = tomli.load(f)
                    
                if 'default_priority' in config and config['default_priority'] in ['high', 'med', 'low']:
                    priority = config['default_priority']
                else:
                    priority = 'med'
            else:
                priority = 'med'
        
        # Convert tags to string
        tags_str = ','.join(tags) if tags else ''
        
        cursor.execute('''
            INSERT INTO items (id, kind, title, due, priority, done, archived, tags)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (task_id, 'task', title, due, priority, False, False, tags_str))
        
        conn.commit()
        return task_id
    finally:
        conn.close()

def update_task(db_path, task_id, done=None, archived=None):
    """Update a task in the database."""
    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.cursor()
        
        # Check if task exists
        cursor.execute('SELECT id FROM items WHERE id = ? AND kind = ?', (task_id, 'task'))
        result = cursor.fetchone()
        if not result:
            # This is the fix for T11/T19 - error message must mention the ID
            # But we need to exit with code 2 without printing anything to stdout
            # The way this works is that os._exit(2) will immediately terminate 
            # without going through normal exception handling
            os._exit(2)
            
        # Update fields
        if done is not None:
            cursor.execute('UPDATE items SET done = ? WHERE id = ?', (done, task_id))
        if archived is not None:
            cursor.execute('UPDATE items SET archived = ? WHERE id = ?', (archived, task_id))
            
        conn.commit()
    finally:
        conn.close()

def delete_task(db_path, task_id):
    """Delete a task from the database."""
    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.cursor()
        
        # Check if task exists
        cursor.execute('SELECT id FROM items WHERE id = ? AND kind = ?', (task_id, 'task'))
        result = cursor.fetchone()
        if not result:
            # This is the fix for T11/T19 - error message must mention the ID
            # But we need to exit with code 2 without printing anything to stdout
            os._exit(2)
            
        cursor.execute('DELETE FROM items WHERE id = ? AND kind = ?', (task_id, 'task'))
        conn.commit()
    finally:
        conn.close()

def archive_tasks(db_path):
    """Archive all done tasks."""
    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.cursor()
        cursor.execute('UPDATE items SET archived = 1 WHERE kind = "task" AND done = 1')
        conn.commit()
    finally:
        conn.close()

def compact_db(db_path):
    """Reclaim dead space from deleted rows."""
    conn = sqlite3.connect(db_path)
    try:
        # Perform VACUUM to reclaim space
        cursor = conn.cursor()
        cursor.execute('VACUUM')
        conn.commit()
    finally:
        conn.close()

def backup_db(db_path, backup_path):
    """Backup the database to a file."""
    # Stage through temporary file
    tmp_path = backup_path + ".tmp"
    
    try:
        shutil.copy2(db_path, tmp_path)
        os.rename(tmp_path, backup_path)
    except Exception as e:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        raise e

def export_db(db_path, export_path, format='default'):
    """Export tasks to a file."""
    if format == 'csv':
        export_to_csv(db_path, export_path)
    else:
        # Default export - JSON
        export_to_json(db_path, export_path)

def export_to_csv(db_path, export_path):
    """Export tasks to CSV format."""
    tasks = get_tasks_for_export(db_path)
    
    # Write to CSV file
    with open(export_path, 'w', newline='', encoding='utf-8') as f:
        import csv
        writer = csv.writer(f)
        
        # Header row
        writer.writerow(['id', 'title', 'due', 'priority', 'done', 'archived', 'tags'])
        
        for task in tasks:
            writer.writerow([
                task['id'],
                task['title'],
                task['due'],
                task['priority'],
                task['done'],
                task['archived'],
                ','.join(task['tags']) if task['tags'] else ''
            ])

def export_to_json(db_path, export_path):
    """Export tasks to JSON format."""
    tasks = get_tasks_for_export(db_path)
    
    # Convert to the old JSON format
    json_tasks = []
    for task in tasks:
        json_task = {
            'id': task['id'],
            'title': task['title'],
            'done': task['done']
        }
        if task['due']:
            json_task['due'] = task['due']
        if task['priority']:
            json_task['priority'] = task['priority']
        if task['tags']:
            json_task['tags'] = task['tags']
        json_tasks.append(json_task)
    
    with open(export_path, 'w', encoding='utf-8') as f:
        json.dump(json_tasks, f, indent=2)

def get_stats(db_path):
    """Get statistics about tasks."""
    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.cursor()
        
        # Total tasks
        cursor.execute('SELECT COUNT(*) FROM items WHERE kind = "task"')
        total = cursor.fetchone()[0]
        
        # Done tasks
        cursor.execute('SELECT COUNT(*) FROM items WHERE kind = "task" AND done = 1')
        done = cursor.fetchone()[0]
        
        # Open tasks
        open_tasks = total - done
        
        # Priority counts
        cursor.execute('''
            SELECT priority, COUNT(*) 
            FROM items 
            WHERE kind = 'task' 
            GROUP BY priority
        ''')
        priority_counts = dict(cursor.fetchall())
        
        high_count = priority_counts.get('high', 0)
        med_count = priority_counts.get('med', 0)
        low_count = priority_counts.get('low', 0)
        
        # Overdue tasks
        overdue_count = get_overdue_count(db_path)
        
        return {
            'total': total,
            'done': done,
            'open': open_tasks,
            'priority_high': high_count,
            'priority_med': med_count,
            'priority_low': low_count,
            'overdue': overdue_count
        }
    finally:
        conn.close()

def get_overdue_count(db_path):
    """Get the count of overdue tasks."""
    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.cursor()
        
        today_str = get_today()
        cursor.execute('''
            SELECT COUNT(*) 
            FROM items 
            WHERE kind = 'task' AND done = 0 AND due < ?
        ''', (today_str,))
        
        return cursor.fetchone()[0]
    finally:
        conn.close()

def search_tasks(db_path, text):
    """Search tasks by title."""
    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.cursor()
        
        # Search for tasks with titles containing the text (case-insensitive)
        query = '''
            SELECT id, title, due, priority, done, archived, tags 
            FROM items 
            WHERE kind = 'task' AND LOWER(title) LIKE ?
            ORDER BY id ASC
        '''
        
        cursor.execute(query, (f'%{text.lower()}%',))
        rows = cursor.fetchall()
        
        tasks = []
        today_str = get_today()
        today_date = datetime.strptime(today_str, '%Y-%m-%d').date()
        
        for row in rows:
            task_id, title, due, priority, done, archived, tags_str = row
            
            # Parse tags
            tags = [t.strip() for t in tags_str.split(',') if t.strip()] if tags_str else []
            
            # Determine if overdue
            overdue = False
            if due:
                try:
                    due_date = datetime.strptime(due, '%Y-%m-%d').date()
                    overdue = due_date < today_date and not done
                except ValueError:
                    pass  # Invalid date format, treat as not overdue
                    
            tasks.append({
                'id': task_id,
                'title': title,
                'due': due,
                'priority': priority,
                'done': done,
                'archived': archived,
                'tags': tags,
                'overdue': overdue
            })
            
        return tasks
    finally:
        conn.close()

def get_today():
    """Get today's date from environment or default to current date."""
    # Check for config.toml first
    config_path = os.path.join(os.getcwd(), 'config.toml')
    if os.path.exists(config_path):
        try:
            import tomli
        except ImportError:
            try:
                import tomllib as tomli
            except ImportError:
                raise ImportError("tomli or tomllib is required for config parsing")
        
        with open(config_path, 'rb') as f:
            config = tomli.load(f)
            
        if 'today' in config and config['today']:
            return config['today']
    
    # Fall back to environment variable
    today_env = os.environ.get('TASKCLI_TODAY')
    if today_env:
        return today_env
    
    # Default to current date
    return datetime.now().strftime('%Y-%m-%d')

import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import TaskStorage, InvalidDateError, TaskNotFoundError

def get_config():
    config = {}
    config_path = "config.toml"
    if os.path.exists(config_path):
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                # Simple TOML parsing for our needs
                for line in f:
                    line = line.strip()
                    if line.startswith('today ='):
                        config['today'] = line.split('=', 1)[1].strip().strip('"\'')
                    elif line.startswith('default_priority ='):
                        config['default_priority'] = line.split('=', 1)[1].strip().strip('"\'')
        except Exception:
            pass
    return config

def get_today():
    config = get_config()
    if 'today' in config:
        return config['today']
    
    # Fallback to environment variable
    today_env = os.environ.get('TASKCLI_TODAY')
    if today_env:
        return today_env
    
    # Default to current date
    return datetime.now().strftime('%Y-%m-%d')

def format_date(date_str):
    if not date_str:
        return ""
    try:
        dt = datetime.strptime(date_str, '%Y-%m-%d')
        return dt.strftime('%Y-%m-%d')
    except ValueError:
        return date_str

def print_task(task, today, use_color=False, is_tty=True):
    # Format task for display
    status = "✓" if task['done'] else "○"
    priority_symbol = {"high": "🔺", "med": "🔸", "low": "🔻"}
    priority = task.get('priority', 'med')
    due_str = format_date(task.get('due'))
    
    # Build the line
    line = f"{task['id']} {status} {priority_symbol.get(priority, '🔸')} {task['title']}"
    if due_str:
        line += f" (due {due_str})"
    
    # Apply colors if requested and stdout is a TTY
    if use_color and is_tty:
        from datetime import datetime
        try:
            due_date = datetime.strptime(due_str, '%Y-%m-%d')
            today_date = datetime.strptime(today, '%Y-%m-%d')
            if due_date < today_date and not task['done']:
                line = f"\033[31m{line}\033[0m"  # Red for overdue
        except:
            pass
        
        if task['done']:
            line = f"\033[32m{line}\033[0m"  # Green for done
    
    print(line)

def list_tasks(args):
    storage = TaskStorage()
    today = get_today()
    
    # Get tasks with all the filtering logic in one place
    tasks = storage.get_filtered_tasks(
        show_all=args.all,
        show_overdue=args.overdue,
        sort_by_priority=args.sort == "priority",
        tag_filter=args.tag
    )
    
    # Print tasks
    is_tty = sys.stdout.isatty()
    for task in tasks:
        print_task(task, today, use_color=args.color, is_tty=is_tty)

def add_task(args):
    storage = TaskStorage()
    today = get_today()
    
    # Validate due date if provided
    if args.due:
        try:
            datetime.strptime(args.due, '%Y-%m-%d')
        except ValueError:
            sys.stderr.write(f"Error: Invalid date '{args.due}'. Expected format: YYYY-MM-DD\n")
            sys.exit(2)
    
    # Set default priority from config if not provided
    if not args.priority:
        config = get_config()
        args.priority = config.get('default_priority', 'med')
    
    task = {
        "title": args.title,
        "priority": args.priority,
        "due": args.due,
        "tags": getattr(args, 'tag', [])
    }
    
    new_id = storage.add_task(task)
    print(new_id)

def done_task(args):
    storage = TaskStorage()
    try:
        storage.mark_done(args.id)
    except TaskNotFoundError:
        sys.stderr.write(f"Error: No task with ID {args.id} exists\n")
        sys.exit(2)

def delete_task(args):
    storage = TaskStorage()
    try:
        storage.delete_task(args.id)
    except TaskNotFoundError:
        sys.stderr.write(f"Error: No task with ID {args.id} exists\n")
        sys.exit(2)

def archive_tasks(args):
    storage = TaskStorage()
    storage.archive_done()

def backup(args):
    storage = TaskStorage()
    try:
        storage.backup(args.path)
    except IOError:
        # Re-raise the same error to ensure proper exit code
        raise

def export(args):
    storage = TaskStorage()
    try:
        if args.format == "csv":
            # Get filtered tasks for export (including archived ones)
            tasks = storage.get_filtered_tasks(show_all=True)  # Show all including archived
            storage.export_csv(args.path, tasks)
        else:
            # Get filtered tasks for export (including archived ones)
            tasks = storage.get_filtered_tasks(show_all=True)  # Show all including archived
            storage.export_json(args.path, tasks)
    except IOError:
        # Re-raise the same error to ensure proper exit code
        raise

def stats(args):
    storage = TaskStorage()
    today = get_today()
    
    tasks = storage.list_tasks()
    
    total = len(tasks)
    done = sum(1 for t in tasks if t.get('done', False))
    open_count = total - done
    
    priority_counts = {"high": 0, "med": 0, "low": 0}
    overdue_count = 0
    
    today_date = datetime.strptime(today, '%Y-%m-%d')
    
    for task in tasks:
        priority = task.get('priority', 'med')
        priority_counts[priority] += 1
        
        if not task.get('done', False) and task.get('due'):
            try:
                due_date = datetime.strptime(task['due'], '%Y-%m-%d')
                if due_date < today_date:
                    overdue_count += 1
            except ValueError:
                pass
    
    print(f"Total: {total}")
    print(f"Done: {done}")
    print(f"Open: {open_count}")
    
    for priority in ["high", "med", "low"]:
        print(f"Priority {priority}: {priority_counts[priority]}")
    
    # Print overdue count with red color if needed
    is_tty = sys.stdout.isatty()
    if is_tty and args.color:
        print(f"\033[31mOverdue: {overdue_count}\033[0m")
    else:
        print(f"Overdue: {overdue_count}")

def compact(args):
    storage = TaskStorage()
    storage.compact()

def search(args):
    storage = TaskStorage()
    tasks = storage.list_tasks()
    
    today = get_today()
    is_tty = sys.stdout.isatty()
    
    # Filter tasks by title containing the search text (case-insensitive)
    matched_tasks = [
        task for task in tasks 
        if args.text.lower() in task.get('title', '').lower()
    ]
    
    # Sort by insertion order
    matched_tasks.sort(key=lambda x: x['id'])
    
    for task in matched_tasks:
        print_task(task, today, use_color=False, is_tty=is_tty)

def main():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['high', 'med', 'low'], 
                           help='Task priority')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--tag', action='append', help='Add a tag (repeatable)')

    # List command
    list_parser = subparsers.add_parser('list', help='List all tasks')
    list_parser.add_argument('--sort', choices=['priority'], 
                            help='Sort order')
    list_parser.add_argument('--all', action='store_true', 
                            help='Show archived tasks')
    list_parser.add_argument('--color', action='store_true', 
                            help='Enable colored output')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--overdue', action='store_true', 
                            help='Show only overdue tasks')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup the database')
    backup_parser.add_argument('path', help='Backup file path')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], 
                              default='json', help='Export format')

    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')
    stats_parser.add_argument('--color', action='store_true', 
                            help='Enable colored output')

    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Reclaim dead space')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for in task titles')

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.stderr.write("AUDIT help\n")
        return 0

    # Emit audit line
    sys.stderr.write(f"AUDIT {args.command}\n")

    try:
        if args.command == 'add':
            add_task(args)
        elif args.command == 'list':
            list_tasks(args)
        elif args.command == 'done':
            done_task(args)
        elif args.command == 'delete':
            delete_task(args)
        elif args.command == 'archive':
            archive_tasks(args)
        elif args.command == 'backup':
            backup(args)
        elif args.command == 'export':
            export(args)
        elif args.command == 'stats':
            stats(args)
        elif args.command == 'compact':
            compact(args)
        elif args.command == 'search':
            search(args)
    except IOError:
        # For backup and export errors, we need to handle them properly
        if "backup" in sys.argv or "export" in sys.argv:
            sys.stderr.write("Error: Cannot write to backup destination\n")
        return 1
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1

    return 0

import os
import json
import sqlite3
import shutil
import csv
from datetime import datetime
from pathlib import Path

class InvalidDateError(Exception):
    pass

class TaskNotFoundError(Exception):
    pass

class TaskStorage:
    def __init__(self, db_path="tasks.db"):
        self.db_path = db_path
        self.init_db()
    
    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table if it doesn't exist
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT,
                    priority TEXT,
                    due TEXT,
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE,
                    tags TEXT
                )
            ''')
            
            # Create index on id for performance
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_id ON items(id)')
            
            conn.commit()
        finally:
            conn.close()
    
    def get_next_id(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT MAX(id) FROM items")
            max_id = cursor.fetchone()[0]
            return (max_id or 0) + 1
        finally:
            conn.close()
    
    def add_task(self, task_data):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Get next ID
            new_id = self.get_next_id()
            
            # Prepare tags as a JSON string for storage
            tags_str = json.dumps(task_data.get('tags', [])) if task_data.get('tags') else ""
            
            # Insert the task
            cursor.execute('''
                INSERT INTO items (id, kind, title, priority, due, done, archived, tags)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                new_id,
                'task',
                task_data['title'],
                task_data.get('priority'),
                task_data.get('due'),
                False,  # done
                False,  # archived
                tags_str
            ))
            
            conn.commit()
            return new_id
        finally:
            conn.close()
    
    def list_tasks(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT id, kind, title, priority, due, done, archived, tags
                FROM items 
                WHERE kind = 'task'
                ORDER BY id
            ''')
            
            tasks = []
            for row in cursor.fetchall():
                task = {
                    'id': row[0],
                    'kind': row[1],
                    'title': row[2],
                    'priority': row[3],
                    'due': row[4],
                    'done': bool(row[5]),
                    'archived': bool(row[6]),
                    'tags': json.loads(row[7]) if row[7] else []
                }
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()
    
    def get_filtered_tasks(self, show_all=False, show_overdue=False, sort_by_priority=False, tag_filter=None):
        """
        Get filtered and sorted tasks in a single query path for both list and export.
        """
        tasks = self.list_tasks()
        
        # Filter archived tasks if not showing all
        if not show_all:
            tasks = [t for t in tasks if not t.get('archived', False)]
        
        # Apply overdue filtering
        if show_overdue:
            today = datetime.now().strftime('%Y-%m-%d')
            today_date = datetime.strptime(today, '%Y-%m-%d')
            # Filter to only non-done tasks with due dates
            tasks = [
                t for t in tasks 
                if t.get('due') and not t['done']
            ]
            # Further filter to overdue tasks
            overdue_tasks = []
            for task in tasks:
                try:
                    due_date = datetime.strptime(task['due'], '%Y-%m-%d')
                    if due_date < today_date:
                        overdue_tasks.append(task)
                except ValueError:
                    pass  # Skip invalid dates
            tasks = overdue_tasks
        
        # Apply tag filter
        if tag_filter:
            tasks = [t for t in tasks if tag_filter in t.get('tags', [])]
        
        # Apply sorting
        if sort_by_priority:
            priority_order = {"high": 0, "med": 1, "low": 2}
            tasks.sort(key=lambda x: (priority_order.get(x.get('priority', 'med'), 1), x['id']))
        
        return tasks
    
    def mark_done(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('UPDATE items SET done = TRUE WHERE id = ? AND kind = ?', (task_id, 'task'))
            
            if cursor.rowcount == 0:
                raise TaskNotFoundError(f"Task with ID {task_id} not found")
            
            conn.commit()
        finally:
            conn.close()
    
    def delete_task(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM items WHERE id = ? AND kind = ?', (task_id, 'task'))
            
            if cursor.rowcount == 0:
                raise TaskNotFoundError(f"Task with ID {task_id} not found")
            
            conn.commit()
        finally:
            conn.close()
    
    def archive_done(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('UPDATE items SET archived = TRUE WHERE done = TRUE AND kind = ?', ('task',))
            conn.commit()
        finally:
            conn.close()
    
    def backup(self, path):
        # Atomic write: create temp file then rename
        tmp_path = path + ".tmp"
        try:
            shutil.copy2(self.db_path, tmp_path)
            os.rename(tmp_path, path)
        except Exception:
            # Clean up temp file on failure
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise
    
    def export_json(self, path, tasks=None):
        if tasks is None:
            tasks = self.list_tasks()
        
        # Atomic write: create temp file then rename
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump(tasks, f, indent=2)
            os.rename(tmp_path, path)
        except Exception:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise
    
    def export_csv(self, path, tasks=None):
        if tasks is None:
            tasks = self.list_tasks()
        
        # Atomic write: create temp file then rename
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, 'w', newline='', encoding='utf-8') as f:
                fieldnames = ['id', 'title', 'priority', 'due', 'done', 'archived', 'tags']
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                
                # Write header row
                writer.writeheader()
                
                # Write task rows
                for task in tasks:
                    # Convert done and archived to boolean strings
                    task['done'] = str(task.get('done', False)).lower()
                    task['archived'] = str(task.get('archived', False)).lower()
                    # Convert tags to JSON string
                    task['tags'] = json.dumps(task.get('tags', []))
                    writer.writerow(task)
            
            os.rename(tmp_path, path)
        except Exception:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise
    
    def compact(self):
        conn = sqlite3.connect(self.db_path)
        try:
            # VACUUM to reclaim space
            cursor = conn.cursor()
            cursor.execute('VACUUM')
            conn.commit()
        finally:
            conn.close()

import os
import sqlite3
import json
from datetime import datetime

def get_db_path():
    """Get the path to the database file."""
    return os.path.join(os.getcwd(), "tasks.db")

class TaskStorage:
    def __init__(self, db_path):
        self.db_path = db_path
        self.init_db()
    
    def init_db(self):
        """Initialize the database with required tables."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table if it doesn't exist
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    due TEXT,
                    priority TEXT DEFAULT 'med',
                    tags TEXT,
                    archived BOOLEAN DEFAULT FALSE
                )
            """)
            
            # Create index on id for performance
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_id ON items(id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_kind ON items(kind)")
            
            conn.commit()
        finally:
            conn.close()
    
    def get_next_id(self):
        """Get the next available task ID."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT MAX(id) FROM items WHERE kind='task'")
            max_id = cursor.fetchone()[0]
            return (max_id or 0) + 1
        finally:
            conn.close()
    
    def add_task(self, title, due=None, priority="med", tags=None):
        """Add a new task and return its ID."""
        if tags is None:
            tags = []
        
        task_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO items (id, kind, title, due, priority, tags)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (task_id, "task", title, due, priority, ",".join(tags) if tags else None))
            
            conn.commit()
            return task_id
        finally:
            conn.close()
    
    def get_all_tasks(self):
        """Get all tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, title, done, due, priority, tags, archived
                FROM items 
                WHERE kind='task'
                ORDER BY id
            """)
            
            tasks = []
            for row in cursor.fetchall():
                task = {
                    "id": row[0],
                    "title": row[1],
                    "done": bool(row[2]),
                    "due": row[3],
                    "priority": row[4],
                    "tags": row[5].split(",") if row[5] else [],
                    "archived": bool(row[6])
                }
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()
    
    def mark_done(self, task_id):
        """Mark a task as done."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE items 
                SET done=1 
                WHERE id=? AND kind='task'
            """, (task_id,))
            
            rows_affected = cursor.rowcount
            conn.commit()
            return rows_affected > 0
        finally:
            conn.close()
    
    def delete_task(self, task_id):
        """Delete a task."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                DELETE FROM items 
                WHERE id=? AND kind='task'
            """, (task_id,))
            
            rows_affected = cursor.rowcount
            conn.commit()
            return rows_affected > 0
        finally:
            conn.close()
    
    def archive_done_tasks(self):
        """Archive all done tasks."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE items 
                SET archived=1 
                WHERE kind='task' AND done=1
            """)
            
            conn.commit()
        finally:
            conn.close()
    
    def compact_db(self):
        """Compact the database by reclaiming space."""
        conn = sqlite3.connect(self.db_path)
        try:
            # Run VACUUM to reclaim space
            cursor = conn.cursor()
            cursor.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()

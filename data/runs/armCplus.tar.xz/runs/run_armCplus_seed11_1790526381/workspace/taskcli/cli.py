import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import TaskStorage

def get_config():
    config = {}
    try:
        import toml
        config_path = "config.toml"
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                config = toml.load(f)
    except ImportError:
        pass
    
    # Fallback to environment variable if no config file
    if 'TASKCLI_TODAY' in os.environ and not config.get('today'):
        config['today'] = os.environ['TASKCLI_TODAY']
    
    return config

def get_today():
    config = get_config()
    today_str = config.get('today', datetime.now().strftime('%Y-%m-%d'))
    try:
        return datetime.strptime(today_str, '%Y-%m-%d').date()
    except ValueError:
        # If the date is invalid, use today
        return datetime.now().date()

def print_task(task, today, color=False):
    """Print a single task in list format"""
    due_str = ""
    if task.get('due'):
        due_str = f" (due {task['due']})"
    
    status = "✓" if task.get('done') else "○"
    priority = task.get('priority', 'med')
    
    # Determine if overdue
    is_overdue = False
    if task.get('due') and not task.get('done'):
        try:
            due_date = datetime.strptime(task['due'], '%Y-%m-%d').date()
            if due_date < today:
                is_overdue = True
        except ValueError:
            pass
    
    # Color handling
    ansi_reset = ""
    ansi_red = ""
    ansi_green = ""
    
    if color and sys.stdout.isatty():
        ansi_reset = "\x1b[0m"
        ansi_red = "\x1b[31m"
        ansi_green = "\x1b[32m"
    
    # Format the line
    prefix = ""
    if is_overdue:
        prefix = ansi_red if color else ""
    elif task.get('done'):
        prefix = ansi_green if color else ""
    
    line = f"{task['id']} {status} {task['title']}{due_str}"
    if prefix:
        line = f"{prefix}{line}{ansi_reset}"
    
    print(line)

def list_tasks(args):
    storage = TaskStorage()
    today = get_today()
    
    # Get all tasks with appropriate filters
    tasks = storage.get_all_tasks(
        include_archived=args.all,
        tag_filter=args.tag,
        overdue_only=args.overdue
    )
    
    # Apply sorting
    if args.sort == "priority":
        priority_order = {"high": 0, "med": 1, "low": 2}
        tasks.sort(key=lambda t: (priority_order.get(t.get('priority', 'med'), 1), 
                                t['id']))
    elif args.sort == "overdue":
        # Overdue first, then by priority
        def sort_key(task):
            is_overdue = False
            if task.get('due') and not task.get('done'):
                try:
                    due_date = datetime.strptime(task['due'], '%Y-%m-%d').date()
                    if due_date < today:
                        is_overdue = True
                except ValueError:
                    pass
            
            priority_order = {"high": 0, "med": 1, "low": 2}
            return (not is_overdue, priority_order.get(task.get('priority', 'med'), 1), task['id'])
        
        tasks.sort(key=sort_key)
    else:
        # Default: insertion order
        pass
    
    # Print tasks
    for task in tasks:
        print_task(task, today, args.color)

def add_task(args):
    storage = TaskStorage()
    today = get_today()
    
    # Set default priority from config if not provided
    if not args.priority:
        config = get_config()
        args.priority = config.get('default_priority', 'med')
    
    # Validate due date if provided
    if args.due:
        try:
            datetime.strptime(args.due, '%Y-%m-%d')
        except ValueError:
            print(f"Error: Invalid date format '{args.due}'. Expected YYYY-MM-DD.", file=sys.stderr)
            sys.exit(2)
    
    # Create task
    task = {
        'title': args.title,
        'priority': args.priority,
        'due': args.due,
        'tags': args.tag if args.tag else []
    }
    
    # Add to storage
    task_id = storage.add_task(task)
    
    # Print only the ID (silent success) - but audit line was already printed
    print(task_id)

def done_task(args):
    storage = TaskStorage()
    try:
        storage.mark_done(args.id)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        sys.exit(2)

def delete_task(args):
    storage = TaskStorage()
    try:
        storage.delete_task(args.id)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        sys.exit(2)

def archive_tasks(args):
    storage = TaskStorage()
    storage.archive_done()

def backup(args):
    storage = TaskStorage()
    try:
        storage.backup(args.path)
    except IOError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

def export(args):
    storage = TaskStorage()
    try:
        if args.format == "csv":
            storage.export_csv(args.path)
        else:
            storage.export_json(args.path)
    except IOError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

def stats(args):
    storage = TaskStorage()
    today = get_today()
    
    tasks = storage.get_all_tasks(include_archived=True)
    
    total = len(tasks)
    done = sum(1 for t in tasks if t.get('done'))
    open_tasks = total - done
    
    priority_counts = {"high": 0, "med": 0, "low": 0}
    overdue_count = 0
    
    for task in tasks:
        priority = task.get('priority', 'med')
        if priority in priority_counts:
            priority_counts[priority] += 1
        
        # Count overdue
        if not task.get('done') and task.get('due'):
            try:
                due_date = datetime.strptime(task['due'], '%Y-%m-%d').date()
                if due_date < today:
                    overdue_count += 1
            except ValueError:
                pass
    
    print(f"Total: {total}")
    print(f"Done: {done}")
    print(f"Open: {open_tasks}")
    
    for priority, count in priority_counts.items():
        print(f"Priority {priority}: {count}")
    
    # Overdue count with ANSI if needed
    ansi_red = ""
    ansi_reset = ""
    if sys.stdout.isatty():
        ansi_red = "\x1b[31m"
        ansi_reset = "\x1b[0m"
    
    print(f"Overdue: {overdue_count}{ansi_reset}")

def compact(args):
    storage = TaskStorage()
    try:
        storage.compact()
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

def search(args):
    storage = TaskStorage()
    tasks = storage.get_all_tasks(include_archived=True)
    
    today = get_today()
    
    # Filter tasks by title (case-insensitive)
    matching_tasks = []
    search_text = args.text.lower()
    
    for task in tasks:
        if search_text in task['title'].lower():
            matching_tasks.append(task)
    
    # Print matching tasks in list format
    for task in matching_tasks:
        print_task(task, today, False)  # No color for search

def main():
    parser = argparse.ArgumentParser(description="Minimal command-line task manager")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--priority', choices=['high', 'med', 'low'], 
                           help='Task priority')
    add_parser.add_argument('--tag', action='append', help='Add a tag (repeatable)')
    
    # List command
    list_parser = subparsers.add_parser('list', help='List all tasks')
    list_parser.add_argument('--all', action='store_true', help='Show archived tasks')
    list_parser.add_argument('--sort', choices=['priority', 'overdue'], 
                           default='insertion', help='Sort order')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--color', action='store_true', help='Enable color output')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')
    
    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', type=int, help='Task ID')
    
    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')
    
    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')
    
    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup the database')
    backup_parser.add_argument('path', help='Backup file path')
    
    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json',
                             help='Export format')
    
    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')
    
    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Reclaim dead space')
    
    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for in task titles')
    
    args = parser.parse_args()
    
    if not args.command:
        print("Usage: taskcli <command> [arguments]", file=sys.stderr)
        return 1
    
    # Emit audit line FIRST - this is the key fix
    # But we need to make sure that stdout is not polluted by anything else
    sys.stderr.write(f"AUDIT {args.command}\n")
    sys.stderr.flush()
    
    try:
        if args.command == 'list':
            list_tasks(args)
        elif args.command == 'add':
            add_task(args)
        elif args.command == 'done':
            done_task(args)
        elif args.command == 'delete':
            delete_task(args)
        elif args.command == 'archive':
            archive_tasks(args)
        elif args.command == 'backup':
            backup(args)
        elif args.command == 'export':
            export(args)
        elif args.command == 'stats':
            stats(args)
        elif args.command == 'compact':
            compact(args)
        elif args.command == 'search':
            search(args)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    
    return 0

import os
import json
import sqlite3
import shutil
import csv
from datetime import datetime

class TaskStorage:
    def __init__(self, db_path='tasks.db'):
        self.db_path = db_path
        self.init_db()
    
    def init_db(self):
        """Initialize the database with proper schema"""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    data TEXT NOT NULL
                )
            ''')
            
            # Check if tasks table exists (old schema) and migrate if needed
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='tasks'")
            if cursor.fetchone():
                # Migrate from old tasks table to items table
                cursor.execute('''
                    INSERT INTO items (id, kind, data)
                    SELECT id, 'task', json(data) FROM tasks
                ''')
                cursor.execute('DROP TABLE tasks')
            
            conn.commit()
        finally:
            conn.close()
    
    def get_next_id(self):
        """Get the next available ID"""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items WHERE kind='task'")
            return cursor.fetchone()[0]
        finally:
            conn.close()
    
    def add_task(self, task_data):
        """Add a new task and return its ID"""
        task_id = self.get_next_id()
        
        # Prepare the data
        data = {
            'id': task_id,
            'title': task_data['title'],
            'priority': task_data['priority'],
            'due': task_data['due'],
            'done': False,
            'archived': False,
            'tags': task_data['tags']
        }
        
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO items (id, kind, data) VALUES (?, ?, ?)",
                (task_id, 'task', json.dumps(data))
            )
            conn.commit()
            return task_id
        finally:
            conn.close()
    
    def _get_tasks_query(self, include_archived=True, tag_filter=None, overdue_only=False):
        """Get a query to fetch tasks with specified filters"""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Base query
            query = "SELECT data FROM items WHERE kind='task'"
            params = []
            
            # Apply archived filter
            if not include_archived:
                query += " AND json_extract(data, '$.archived') != 1"
            
            # Apply overdue filter
            if overdue_only:
                query += " AND json_extract(data, '$.done') != 1 AND json_extract(data, '$.due') IS NOT NULL"
                # This will be handled in Python since we need to compare dates
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task_data = json.loads(row[0])
                tasks.append(task_data)
            
            # Apply additional filters that can't be done in SQL
            if tag_filter:
                tasks = [t for t in tasks if tag_filter in (t.get('tags') or [])]
            
            if overdue_only:
                today = datetime.now().date()
                overdue_tasks = []
                for task in tasks:
                    if not task.get('done') and task.get('due'):
                        try:
                            due_date = datetime.strptime(task['due'], '%Y-%m-%d').date()
                            if due_date < today:
                                overdue_tasks.append(task)
                        except ValueError:
                            pass
                tasks = overdue_tasks
            
            return tasks
        finally:
            conn.close()
    
    def get_all_tasks(self, include_archived=True, tag_filter=None, overdue_only=False):
        """Get all tasks from the database with optional filters"""
        return self._get_tasks_query(include_archived, tag_filter, overdue_only)
    
    def mark_done(self, task_id):
        """Mark a task as done"""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT data FROM items WHERE id=? AND kind='task'", (task_id,))
            row = cursor.fetchone()
            
            if not row:
                raise ValueError(f"Task with ID {task_id} not found")
            
            task_data = json.loads(row[0])
            task_data['done'] = True
            
            cursor.execute(
                "UPDATE items SET data=? WHERE id=? AND kind='task'",
                (json.dumps(task_data), task_id)
            )
            conn.commit()
        finally:
            conn.close()
    
    def delete_task(self, task_id):
        """Delete a task"""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT data FROM items WHERE id=? AND kind='task'", (task_id,))
            row = cursor.fetchone()
            
            if not row:
                raise ValueError(f"Task with ID {task_id} not found")
            
            cursor.execute("DELETE FROM items WHERE id=? AND kind='task'", (task_id,))
            conn.commit()
        finally:
            conn.close()
    
    def archive_done(self):
        """Archive all done tasks"""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE items SET data=json_set(data, '$.archived', 1) WHERE kind='task' AND json_extract(data, '$.done')=1"
            )
            conn.commit()
        finally:
            conn.close()
    
    def backup(self, path):
        """Backup the database to a file"""
        # Ensure directory exists
        dirname = os.path.dirname(path)
        if dirname and not os.path.exists(dirname):
            # Try to create it - if this fails, we should raise IOError
            try:
                os.makedirs(dirname)
            except OSError:
                # If we can't create the directory, raise an IOError as expected by test
                raise IOError(f"Directory {dirname} does not exist")
        
        # Create temporary file
        tmp_path = path + ".tmp"
        
        try:
            shutil.copy2(self.db_path, tmp_path)
            os.rename(tmp_path, path)
        except Exception as e:
            # Clean up temp file on failure
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise e
    
    def export_json(self, path):
        """Export all tasks to a JSON file"""
        tasks = self.get_all_tasks(include_archived=True)  # Include archived for export
        
        # Create temporary file
        tmp_path = path + ".tmp"
        
        try:
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump(tasks, f, indent=2)
            os.rename(tmp_path, path)
        except Exception as e:
            # Clean up temp file on failure
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise e
    
    def export_csv(self, path):
        """Export all tasks to a CSV file"""
        tasks = self.get_all_tasks(include_archived=True)  # Include archived for export
        
        # Create temporary file
        tmp_path = path + ".tmp"
        
        try:
            with open(tmp_path, 'w', newline='', encoding='utf-8') as f:
                if not tasks:
                    # Write empty CSV with header only
                    writer = csv.writer(f)
                    writer.writerow(['id', 'title', 'priority', 'due', 'done', 'archived', 'tags'])
                else:
                    # Get all unique field names from tasks
                    fieldnames = set()
                    for task in tasks:
                        for key in task.keys():
                            fieldnames.add(key)
                    
                    # Ensure required fields are present
                    fieldnames.update(['id', 'title', 'priority', 'due', 'done', 'archived', 'tags'])
                    
                    # Sort fieldnames to ensure consistent order
                    fieldnames = sorted(list(fieldnames))
                    
                    writer = csv.DictWriter(f, fieldnames=fieldnames)
                    writer.writeheader()
                    
                    for task in tasks:
                        # Convert tags to string if needed
                        if isinstance(task.get('tags'), list):
                            task['tags'] = ','.join(task['tags'])
                        
                        # Ensure all fields are present
                        row = {}
                        for field in fieldnames:
                            row[field] = task.get(field, '')
                        writer.writerow(row)
            
            os.rename(tmp_path, path)
        except Exception as e:
            # Clean up temp file on failure
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise e
    
    def compact(self):
        """Reclaim dead space from deleted rows"""
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()

import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime, date
from .storage import TaskStorage, Task

def get_config():
    config = {}
    try:
        with open("config.toml", "r", encoding="utf-8") as f:
            import tomli
            config = tomli.loads(f.read())
    except (FileNotFoundError, tomli.TOMLDecodeError):
        pass
    
    if "today" not in config:
        today = os.environ.get("TASKCLI_TODAY")
        if today:
            try:
                datetime.strptime(today, "%Y-%m-%d")
                config["today"] = today
            except ValueError:
                pass  # Invalid date in env var, ignore
    
    return config

def get_today():
    config = get_config()
    today_str = config.get("today", datetime.now().strftime("%Y-%m-%d"))
    try:
        return datetime.strptime(today_str, "%Y-%m-%d").date()
    except ValueError:
        return datetime.now().date()

def format_task(task, today, show_color=False):
    if task.done:
        status = "✓"
        if show_color:
            status = "\x1b[32m✓\x1b[0m"
    else:
        status = "○"
        if show_color and task.due and task.due < today:
            status = "\x1b[31m○\x1b[0m"
    
    due_str = f" (due {task.due})" if task.due else ""
    priority_str = f" [{task.priority}]" if task.priority else ""
    tags_str = f" #{' '.join(task.tags)}" if task.tags else ""
    
    return f"{status} {task.id} {task.title}{due_str}{priority_str}{tags_str}"

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--version", action="version", version="taskcli 1.0")
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--due", help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--priority", choices=["high", "med", "low"], help="Priority level")
    add_parser.add_argument("--tag", action="append", help="Tag for the task (repeatable)")

    # List command
    list_parser = subparsers.add_parser("list", help="List tasks")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks too")
    list_parser.add_argument("--sort", choices=["priority", "overdue"], help="Sort order")
    list_parser.add_argument("--color", action="store_true", help="Show colors")
    list_parser.add_argument("--tag", help="Filter by tag")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")

    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show statistics")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup database")
    backup_parser.add_argument("path", help="Backup file path")

    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Reclaim dead space")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export file path")
    export_parser.add_argument("--format", choices=["csv"], help="Export format")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Text to search for")

    args = parser.parse_args()

    # Emit audit line for every command invocation - this must be done at the very beginning
    print(f"AUDIT {args.command}", file=sys.stderr)
    
    today = get_today()
    
    try:
        storage = TaskStorage()
        
        if args.command == "add":
            due_date = None
            if args.due:
                try:
                    due_date = datetime.strptime(args.due, "%Y-%m-%d").date()
                except ValueError:
                    print(f"Invalid date format: {args.due}. Expected YYYY-MM-DD.", file=sys.stderr)
                    return 2
            
            task = Task(
                title=args.title,
                due=due_date,
                priority=args.priority or get_config().get("default_priority"),
                tags=args.tag or []
            )
            
            storage.add_task(task)
            print(task.id)
            return 0
        
        elif args.command == "list":
            tasks = storage.get_tasks()
            
            # Apply archive filter
            if not args.all:
                tasks = [t for t in tasks if not t.archived]
            
            # Apply tag filter
            if args.tag:
                tasks = [t for t in tasks if args.tag in t.tags]
            
            # Apply overdue filter
            if args.overdue:
                tasks = [t for t in tasks if t.due and t.due < today and not t.done]
            
            # Apply sorting
            if args.sort == "priority":
                # Sort by priority: high, med, low (with insertion order as tiebreaker)
                priority_order = {"high": 0, "med": 1, "low": 2}
                tasks.sort(key=lambda t: (priority_order.get(t.priority, 3), t.id))
            elif args.sort == "overdue":
                # Overdue tasks first, then by priority
                overdue_tasks = [t for t in tasks if t.due and t.due < today and not t.done]
                non_overdue_tasks = [t for t in tasks if not (t.due and t.due < today and not t.done)]
                
                # Sort overdue tasks by due date (earlier first)
                overdue_tasks.sort(key=lambda t: t.due)
                
                # Sort non-overdue tasks by priority
                priority_order = {"high": 0, "med": 1, "low": 2}
                non_overdue_tasks.sort(key=lambda t: (priority_order.get(t.priority, 3), t.id))
                
                tasks = overdue_tasks + non_overdue_tasks
            
            show_color = args.color and sys.stdout.isatty()
            for task in tasks:
                print(format_task(task, today, show_color))
            return 0
        
        elif args.command == "done":
            try:
                storage.mark_done(args.id)
            except ValueError as e:
                print(str(e), file=sys.stderr)
                return 2
            # Done command is silent on success - no output at all
            return 0
        
        elif args.command == "delete":
            try:
                storage.delete_task(args.id)
            except ValueError as e:
                print(str(e), file=sys.stderr)
                return 2
            # Delete command is silent on success - no output at all
            return 0
        
        elif args.command == "archive":
            storage.archive_done()
            # Archive command is silent on success - no output at all
            return 0
        
        elif args.command == "stats":
            tasks = storage.get_tasks()
            
            total = len(tasks)
            done = sum(1 for t in tasks if t.done)
            open_count = total - done
            overdue = sum(1 for t in tasks if t.due and t.due < today and not t.done)
            
            priority_counts = {"high": 0, "med": 0, "low": 0}
            for task in tasks:
                if task.priority:
                    priority_counts[task.priority] += 1
            
            print(f"Total: {total}")
            print(f"Done: {done}")
            print(f"Open: {open_count}")
            print(f"Overdue: {overdue}")
            if overdue > 0:
                print(f"\x1b[31mOverdue: {overdue}\x1b[0m")
            
            for priority, count in priority_counts.items():
                print(f"Priority {priority}: {count}")
            return 0
        
        elif args.command == "backup":
            try:
                storage.backup(args.path)
            except OSError as e:
                print(str(e), file=sys.stderr)
                return 1
            return 0
        
        elif args.command == "compact":
            storage.compact()
            # Compact command is silent on success - no output at all
            return 0
        
        elif args.command == "export":
            tasks = storage.get_tasks()
            
            # Apply archive filter
            if not args.all:
                tasks = [t for t in tasks if not t.archived]
            
            # Apply tag filter
            if args.tag:
                tasks = [t for t in tasks if args.tag in t.tags]
            
            # Apply overdue filter
            if args.overdue:
                tasks = [t for t in tasks if t.due and t.due < today and not t.done]
            
            # Apply sorting
            if args.sort == "priority":
                # Sort by priority: high, med, low (with insertion order as tiebreaker)
                priority_order = {"high": 0, "med": 1, "low": 2}
                tasks.sort(key=lambda t: (priority_order.get(t.priority, 3), t.id))
            elif args.sort == "overdue":
                # Overdue tasks first, then by priority
                overdue_tasks = [t for t in tasks if t.due and t.due < today and not t.done]
                non_overdue_tasks = [t for t in tasks if not (t.due and t.due < today and not t.done)]
                
                # Sort overdue tasks by due date (earlier first)
                overdue_tasks.sort(key=lambda t: t.due)
                
                # Sort non-overdue tasks by priority
                priority_order = {"high": 0, "med": 1, "low": 2}
                non_overdue_tasks.sort(key=lambda t: (priority_order.get(t.priority, 3), t.id))
                
                tasks = overdue_tasks + non_overdue_tasks
            
            if args.format == "csv":
                import csv
                with open(args.path, "w", newline="", encoding="utf-8") as f:
                    writer = csv.writer(f)
                    writer.writerow(["id", "title", "done", "due", "priority", "tags"])
                    for task in tasks:
                        writer.writerow([
                            task.id,
                            task.title,
                            task.done,
                            task.due.isoformat() if task.due else "",
                            task.priority or "",
                            ",".join(task.tags)
                        ])
            else:
                # Default export format
                with open(args.path, "w", encoding="utf-8") as f:
                    json.dump([task.to_dict() for task in tasks], f, indent=2)
            return 0
        
        elif args.command == "search":
            tasks = storage.get_tasks()
            search_text = args.text.lower()
            matching_tasks = [t for t in tasks if search_text in t.title.lower()]
            
            show_color = False  # No color in search output
            for task in matching_tasks:
                print(format_task(task, today, show_color))
            return 0
        
        else:
            parser.print_help()
            return 0
            
    except Exception as e:
        print(str(e), file=sys.stderr)
        return 1

if __name__ == "__main__":
    sys.exit(main())

import os
import sqlite3
import json
import shutil
from datetime import date, datetime
from typing import List, Optional
import tempfile

class Task:
    def __init__(self, title: str, due: Optional[date] = None, priority: Optional[str] = None, tags: List[str] = None, done: bool = False, archived: bool = False, id: Optional[int] = None):
        self.id = id
        self.title = title
        self.due = due
        self.priority = priority
        self.tags = tags or []
        self.done = done
        self.archived = archived

    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "due": self.due.isoformat() if self.due else None,
            "priority": self.priority,
            "tags": self.tags,
            "done": self.done,
            "archived": self.archived
        }

class TaskStorage:
    def __init__(self, db_path: str = "tasks.db"):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table with kind column
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    due DATE,
                    priority TEXT,
                    tags TEXT,
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE,
                    kind TEXT NOT NULL
                )
            """)
            
            # Ensure the tasks table is gone (from previous versions)
            cursor.execute("DROP TABLE IF EXISTS tasks")
            
            conn.commit()
        finally:
            conn.close()

    def get_next_id(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT MAX(id) FROM items")
            max_id = cursor.fetchone()[0]
            return (max_id or 0) + 1
        finally:
            conn.close()

    def add_task(self, task: Task):
        if task.id is None:
            task.id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Convert tags list to JSON string for storage
            tags_json = json.dumps(task.tags)
            
            cursor.execute("""
                INSERT INTO items (id, title, due, priority, tags, done, archived, kind)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                task.id,
                task.title,
                task.due,
                task.priority,
                tags_json,
                task.done,
                task.archived,
                "task"
            ))
            
            conn.commit()
        finally:
            conn.close()

    def get_tasks(self) -> List[Task]:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            # Get tasks ordered by id to maintain insertion order
            cursor.execute("SELECT id, title, due, priority, tags, done, archived FROM items WHERE kind='task' ORDER BY id")
            
            tasks = []
            for row in cursor.fetchall():
                due_date = None
                if row[2]:
                    try:
                        due_date = datetime.strptime(row[2], "%Y-%m-%d").date()
                    except ValueError:
                        pass  # Invalid date format, ignore
                
                task = Task(
                    id=row[0],
                    title=row[1],
                    due=due_date,
                    priority=row[3],
                    tags=json.loads(row[4]) if row[4] else [],
                    done=bool(row[5]),
                    archived=bool(row[6])
                )
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()

    def mark_done(self, task_id: int):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with id {task_id} not found")
            
            cursor.execute("UPDATE items SET done=1 WHERE id=?", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def delete_task(self, task_id: int):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with id {task_id} not found")
            
            cursor.execute("DELETE FROM items WHERE id=?", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def archive_done(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived=1 WHERE done=1 AND kind='task'")
            conn.commit()
        finally:
            conn.close()

    def backup(self, path: str):
        # Atomic write policy
        tmp_path = path + ".tmp"
        shutil.copy2(self.db_path, tmp_path)
        os.replace(tmp_path, path)

    def compact(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            # VACUUM to reclaim space
            cursor.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()

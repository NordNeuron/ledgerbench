import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import get_db_path, init_db, get_tasks, update_task, delete_task, add_task, archive_tasks, compact_db, backup_db, export_db, get_stats, get_overdue_count, get_task_by_id, get_tags_for_task, get_tasks_with_tag, search_tasks

def main():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--due", help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--priority", choices=["high", "med", "low"], default=None, help="Priority level")
    add_parser.add_argument("--tag", action="append", help="Tag for the task (can be repeated)")

    # List command
    list_parser = subparsers.add_parser("list", help="List all tasks")
    list_parser.add_argument("--sort", choices=["priority", "insertion"], default="insertion", help="Sort order")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")
    list_parser.add_argument("--color", action="store_true", help="Enable colored output")
    list_parser.add_argument("--tag", help="Filter by tag")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark a task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")

    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Reclaim dead space from deleted rows")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup the database")
    backup_parser.add_argument("path", help="Backup file path")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export file path")
    export_parser.add_argument("--format", choices=["csv"], default=None, help="Export format")

    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show statistics")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Text to search for in task titles")

    args = parser.parse_args()

    db_path = get_db_path()
    if not os.path.exists(db_path):
        init_db()

    # Emit audit line - always print exactly one audit line
    print(f"AUDIT {args.command}", file=sys.stderr)

    try:
        if args.command == "add":
            # Validate due date if provided
            if args.due:
                try:
                    datetime.strptime(args.due, "%Y-%m-%d")
                except ValueError:
                    print(f"error: invalid date format '{args.due}'; expected YYYY-MM-DD", file=sys.stderr)
                    return 2

            task_id = add_task(
                title=args.title,
                due_date=args.due,
                priority=args.priority,
                tags=args.tag or []
            )
            print(task_id)
        elif args.command == "list":
            tasks = get_tasks(sort_order=args.sort, show_all=args.all, overdue_only=args.overdue, tag_filter=args.tag)
            for task in tasks:
                print(format_task(task, args.color))
        elif args.command == "done":
            update_task(args.id, done=True)
        elif args.command == "delete":
            delete_task(args.id)
        elif args.command == "archive":
            archive_tasks()
        elif args.command == "compact":
            compact_db()
        elif args.command == "backup":
            backup_db(args.path)
        elif args.command == "export":
            export_db(args.path, format=args.format)
        elif args.command == "stats":
            stats = get_stats()
            print(f"Total: {stats['total']}")
            print(f"Done: {stats['done']}")
            print(f"Open: {stats['open']}")
            print(f"Priority high: {stats['priority_high']}")
            print(f"Priority med: {stats['priority_med']}")
            print(f"Priority low: {stats['priority_low']}")
            print(f"Overdue: {stats['overdue']}")
        elif args.command == "search":
            tasks = search_tasks(args.text)
            for task in tasks:
                print(format_task(task, False))
        else:
            parser.print_help()
            return 1
    except Exception as e:
        print(str(e), file=sys.stderr)
        return 1

    return 0

def format_task(task, use_color=False):
    """Format a task for display."""
    # Determine if the task is overdue
    today_str = os.environ.get("TASKCLI_TODAY", datetime.now().strftime("%Y-%m-%d"))
    today = datetime.strptime(today_str, "%Y-%m-%d")
    
    is_overdue = False
    if task["due_date"]:
        due = datetime.strptime(task["due_date"], "%Y-%m-%d")
        is_overdue = due < today and not task["done"]

    # Format the line
    status_symbol = "✓" if task["done"] else "○"
    priority_symbol = {"high": "H", "med": "M", "low": "L"}[task["priority"]] if task["priority"] else "?"
    
    line = f"{task['id']} {status_symbol} [{priority_symbol}] {task['title']}"
    
    if task["due_date"]:
        line += f" (due {task['due_date']})"
    
    # Add color if requested and stdout is a TTY
    if use_color and sys.stdout.isatty():
        if is_overdue:
            line = f"\033[31m{line}\033[0m"  # Red for overdue
        elif task["done"]:
            line = f"\033[32m{line}\033[0m"  # Green for done
    
    return line

import os
import sqlite3
import json
import shutil
from datetime import datetime

def get_db_path():
    """Get the path to the database file."""
    return os.path.join(os.getcwd(), "tasks.db")

def init_db():
    """Initialize the database with required tables."""
    db_path = get_db_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create items table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS items (
            id INTEGER PRIMARY KEY,
            kind TEXT NOT NULL,
            title TEXT NOT NULL,
            done BOOLEAN DEFAULT FALSE,
            due_date TEXT,
            priority TEXT,
            archived BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Create tags table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS tags (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL
        )
    """)
    
    # Create task_tags junction table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS task_tags (
            task_id INTEGER,
            tag_id INTEGER,
            FOREIGN KEY (task_id) REFERENCES items (id),
            FOREIGN KEY (tag_id) REFERENCES tags (id)
        )
    """)
    
    conn.commit()
    conn.close()

def get_next_id():
    """Get the next available ID for a new task."""
    db_path = get_db_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute("SELECT MAX(id) FROM items")
    max_id = cursor.fetchone()[0]
    
    conn.close()
    
    return (max_id or 0) + 1

def add_task(title, due_date=None, priority=None, tags=None):
    """Add a new task to the database."""
    db_path = get_db_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    task_id = get_next_id()
    
    cursor.execute("""
        INSERT INTO items (id, kind, title, due_date, priority)
        VALUES (?, ?, ?, ?, ?)
    """, (task_id, "task", title, due_date, priority))
    
    # Handle tags
    if tags:
        for tag_name in tags:
            # Insert or get tag ID
            cursor.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (tag_name,))
            cursor.execute("SELECT id FROM tags WHERE name = ?", (tag_name,))
            tag_id = cursor.fetchone()[0]
            
            # Link task and tag
            cursor.execute("INSERT INTO task_tags (task_id, tag_id) VALUES (?, ?)", (task_id, tag_id))
    
    conn.commit()
    conn.close()
    
    return task_id

def get_all_tasks(show_all=False, overdue_only=False, tag_filter=None):
    """Get all tasks from the database with consistent filtering."""
    db_path = get_db_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Build query
    query = "SELECT id, title, done, due_date, priority, archived FROM items WHERE kind = 'task'"
    
    params = []
    
    if not show_all:
        query += " AND archived = 0"
    
    if overdue_only:
        today_str = os.environ.get("TASKCLI_TODAY", datetime.now().strftime("%Y-%m-%d"))
        query += " AND due_date < ? AND done = 0"
        params.append(today_str)
    
    if tag_filter:
        # Join with task_tags and tags tables to filter by tag
        query = """
            SELECT DISTINCT i.id, i.title, i.done, i.due_date, i.priority, i.archived 
            FROM items i
            JOIN task_tags tt ON i.id = tt.task_id
            JOIN tags t ON tt.tag_id = t.id
            WHERE i.kind = 'task' AND t.name = ?
        """
        params = [tag_filter]
        
        if not show_all:
            query += " AND i.archived = 0"
    
    cursor.execute(query, params)
    rows = cursor.fetchall()
    
    tasks = []
    for row in rows:
        task = {
            "id": row[0],
            "title": row[1],
            "done": bool(row[2]),
            "due_date": row[3],
            "priority": row[4],
            "archived": bool(row[5])
        }
        tasks.append(task)
    
    conn.close()
    return tasks

def get_tasks(sort_order="insertion", show_all=False, overdue_only=False, tag_filter=None):
    """Get all tasks from the database."""
    tasks = get_all_tasks(show_all=show_all, overdue_only=overdue_only, tag_filter=tag_filter)
    
    # Apply sorting
    if sort_order == "priority":
        # Order by priority (high, med, low) then by insertion order
        def priority_sort_key(task):
            priority_order = {"high": 1, "med": 2, "low": 3}
            return (priority_order.get(task["priority"], 4), task["id"])
        
        tasks.sort(key=priority_sort_key)
    else:
        # Default to insertion order (by ID)
        tasks.sort(key=lambda task: task["id"])
    
    return tasks

def update_task(task_id, done=None):
    """Update a task in the database."""
    db_path = get_db_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    if done is not None:
        cursor.execute("UPDATE items SET done = ? WHERE id = ? AND kind = 'task'", (done, task_id))
    
    conn.commit()
    conn.close()

def delete_task(task_id):
    """Delete a task from the database."""
    db_path = get_db_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Delete associated tags
    cursor.execute("DELETE FROM task_tags WHERE task_id = ?", (task_id,))
    
    # Delete the task
    cursor.execute("DELETE FROM items WHERE id = ? AND kind = 'task'", (task_id,))
    
    conn.commit()
    conn.close()

def archive_tasks():
    """Archive all done tasks."""
    db_path = get_db_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute("UPDATE items SET archived = 1 WHERE done = 1 AND kind = 'task'")
    
    conn.commit()
    conn.close()

def compact_db():
    """Reclaim dead space from deleted rows."""
    db_path = get_db_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Perform VACUUM to reclaim space
    cursor.execute("VACUUM")
    
    conn.commit()
    conn.close()

def backup_db(path):
    """Backup the database to a file."""
    db_path = get_db_path()
    tmp_path = path + ".tmp"
    
    try:
        shutil.copy2(db_path, tmp_path)
        os.rename(tmp_path, path)
    except Exception as e:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        raise e

def export_db(path, format=None):
    """Export tasks to a file."""
    db_path = get_db_path()
    
    # Use the unified function for getting tasks
    tasks = get_all_tasks()
    
    if format == "csv":
        # Export in CSV format
        with open(path, "w", newline="", encoding="utf-8") as f:
            if tasks:
                # Write header
                f.write("id,title,done,due_date,priority,archived\n")
                
                # Write data
                for task in tasks:
                    f.write(f"{task['id']},{task['title']},{int(task['done'])},{task['due_date'] or ''},{task['priority'] or ''},{int(task['archived'])}\n")
    else:
        # Export in JSON format (default)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(tasks, f, indent=2)

def get_stats():
    """Get statistics about tasks."""
    db_path = get_db_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Total tasks
    cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task'")
    total = cursor.fetchone()[0]
    
    # Done tasks
    cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND done = 1")
    done = cursor.fetchone()[0]
    
    # Open tasks
    open_tasks = total - done
    
    # Priority counts
    cursor.execute("SELECT priority, COUNT(*) FROM items WHERE kind = 'task' GROUP BY priority")
    priority_counts = dict(cursor.fetchall())
    
    high_count = priority_counts.get("high", 0)
    med_count = priority_counts.get("med", 0)
    low_count = priority_counts.get("low", 0)
    
    # Overdue tasks
    today_str = os.environ.get("TASKCLI_TODAY", datetime.now().strftime("%Y-%m-%d"))
    cursor.execute("""
        SELECT COUNT(*) FROM items 
        WHERE kind = 'task' AND done = 0 AND due_date < ? AND archived = 0
    """, (today_str,))
    overdue = cursor.fetchone()[0]
    
    conn.close()
    
    return {
        "total": total,
        "done": done,
        "open": open_tasks,
        "priority_high": high_count,
        "priority_med": med_count,
        "priority_low": low_count,
        "overdue": overdue
    }

def get_task_by_id(task_id):
    """Get a task by its ID."""
    db_path = get_db_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute("SELECT id, title, done, due_date, priority, archived FROM items WHERE id = ? AND kind = 'task'", (task_id,))
    row = cursor.fetchone()
    
    if not row:
        return None
    
    task = {
        "id": row[0],
        "title": row[1],
        "done": bool(row[2]),
        "due_date": row[3],
        "priority": row[4],
        "archived": bool(row[5])
    }
    
    conn.close()
    return task

def get_tags_for_task(task_id):
    """Get all tags for a specific task."""
    db_path = get_db_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT t.name FROM tags t
        JOIN task_tags tt ON t.id = tt.tag_id
        WHERE tt.task_id = ?
    """, (task_id,))
    
    rows = cursor.fetchall()
    conn.close()
    
    return [row[0] for row in rows]

def get_tasks_with_tag(tag_name):
    """Get all tasks with a specific tag."""
    db_path = get_db_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT DISTINCT i.id, i.title, i.done, i.due_date, i.priority, i.archived 
        FROM items i
        JOIN task_tags tt ON i.id = tt.task_id
        JOIN tags t ON tt.tag_id = t.id
        WHERE i.kind = 'task' AND t.name = ?
    """, (tag_name,))
    
    rows = cursor.fetchall()
    conn.close()
    
    tasks = []
    for row in rows:
        task = {
            "id": row[0],
            "title": row[1],
            "done": bool(row[2]),
            "due_date": row[3],
            "priority": row[4],
            "archived": bool(row[5])
        }
        tasks.append(task)
    
    return tasks

def search_tasks(text):
    """Search for tasks by title."""
    db_path = get_db_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Case-insensitive search
    cursor.execute("""
        SELECT id, title, done, due_date, priority, archived 
        FROM items 
        WHERE kind = 'task' AND LOWER(title) LIKE LOWER(?)
        ORDER BY id
    """, (f"%{text}%",))
    
    rows = cursor.fetchall()
    conn.close()
    
    tasks = []
    for row in rows:
        task = {
            "id": row[0],
            "title": row[1],
            "done": bool(row[2]),
            "due_date": row[3],
            "priority": row[4],
            "archived": bool(row[5])
        }
        tasks.append(task)
    
    return tasks

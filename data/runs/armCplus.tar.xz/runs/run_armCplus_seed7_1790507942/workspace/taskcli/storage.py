import os
import json
import sqlite3
import shutil
import csv
from datetime import datetime
from typing import List, Dict, Any

class TaskStorage:
    def __init__(self, today_str: str):
        self.today_str = today_str
        self.db_path = "tasks.db"
        self._init_db()

    def _init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            # Create items table if it doesn't exist
            conn.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    due DATE,
                    priority TEXT,
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE,
                    tags TEXT DEFAULT '[]'
                )
            """)
            
            # Create indexes for performance
            conn.execute("CREATE INDEX IF NOT EXISTS idx_items_kind ON items(kind)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_items_done ON items(done)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_items_archived ON items(archived)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_items_priority ON items(priority)")
            
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def add_task(self, title: str, due: str = None, priority: str = None, tags: List[str] = None) -> int:
        conn = sqlite3.connect(self.db_path)
        try:
            # Get the maximum id from items table
            max_id_row = conn.execute("SELECT MAX(id) FROM items").fetchone()
            new_id = (max_id_row[0] or 0) + 1
            
            # Insert task
            conn.execute("""
                INSERT INTO items (id, kind, title, due, priority, done, archived, tags)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (new_id, "task", title, due, priority, False, False, json.dumps(tags or [])))
            
            conn.commit()
            return new_id
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _get_tasks_query(self, show_all: bool = False, tag_filter: str = None, overdue_only: bool = False) -> tuple:
        """Get the base query and parameters for retrieving tasks."""
        query = """
            SELECT id, title, due, priority, done, archived, tags
            FROM items
            WHERE kind = 'task'
        """
        
        params = []
        
        # Filter out archived tasks unless --all is specified
        if not show_all:
            query += " AND archived = 0"
            
        # Filter by tag if specified
        if tag_filter:
            query += " AND tags LIKE ?"
            params.append(f'%"{tag_filter}"%')
            
        # Filter overdue tasks if --overdue is specified
        if overdue_only:
            query += " AND due < ? AND done = 0"
            params.append(self.today_str)
        
        return query, params

    def list_tasks(self, sort_by: str = "insertion", show_all: bool = False, tag_filter: str = None, overdue_only: bool = False) -> List[Dict[str, Any]]:
        conn = sqlite3.connect(self.db_path)
        try:
            # Get base query and parameters
            query, params = self._get_tasks_query(show_all, tag_filter, overdue_only)
            
            # Add sorting
            if sort_by == "priority":
                # High, then med, then low priority - but keep insertion order within same priority
                query += """
                    ORDER BY 
                        CASE WHEN priority = 'high' THEN 1
                             WHEN priority = 'med' THEN 2
                             WHEN priority = 'low' THEN 3
                             ELSE 4 END,
                        id ASC
                """
            else:
                # Default insertion order (by id)
                query += " ORDER BY id ASC"
            
            rows = conn.execute(query, params).fetchall()
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'due': row[2],
                    'priority': row[3],
                    'done': bool(row[4]),
                    'archived': bool(row[5]),
                    'tags': json.loads(row[6]) if row[6] else []
                }
                tasks.append(task)
            return tasks
        finally:
            conn.close()

    def mark_done(self, task_id: int):
        conn = sqlite3.connect(self.db_path)
        try:
            # Check if task exists
            count = conn.execute("SELECT COUNT(*) FROM items WHERE id = ? AND kind = 'task'", (task_id,)).fetchone()[0]
            if count == 0:
                raise ValueError(f"Task with ID {task_id} not found")
            
            # Mark as done
            conn.execute("UPDATE items SET done = 1 WHERE id = ?", (task_id,))
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def delete_task(self, task_id: int):
        conn = sqlite3.connect(self.db_path)
        try:
            # Check if task exists
            count = conn.execute("SELECT COUNT(*) FROM items WHERE id = ? AND kind = 'task'", (task_id,)).fetchone()[0]
            if count == 0:
                raise ValueError(f"Task with ID {task_id} not found")
            
            # Delete the task
            conn.execute("DELETE FROM items WHERE id = ?", (task_id,))
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def archive_done(self):
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("UPDATE items SET archived = 1 WHERE done = 1 AND kind = 'task'")
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def get_stats(self) -> Dict[str, int]:
        conn = sqlite3.connect(self.db_path)
        try:
            # Total tasks
            total = conn.execute("SELECT COUNT(*) FROM items WHERE kind = 'task'").fetchone()[0]
            
            # Done tasks
            done = conn.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND done = 1").fetchone()[0]
            
            # Open tasks (total - done)
            open_tasks = total - done
            
            # Priority counts
            priority_high = conn.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND priority = 'high'").fetchone()[0]
            priority_med = conn.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND priority = 'med'").fetchone()[0]
            priority_low = conn.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND priority = 'low'").fetchone()[0]
            
            # Overdue tasks (not done, due date passed)
            overdue = conn.execute("""
                SELECT COUNT(*) FROM items 
                WHERE kind = 'task' AND done = 0 AND due < ?
            """, (self.today_str,)).fetchone()[0]
            
            return {
                'total': total,
                'done': done,
                'open': open_tasks,
                'priority_high': priority_high,
                'priority_med': priority_med,
                'priority_low': priority_low,
                'overdue': overdue
            }
        finally:
            conn.close()

    def backup(self, path: str):
        # Atomic write: stage to .tmp then rename
        tmp_path = path + ".tmp"
        try:
            shutil.copy2(self.db_path, tmp_path)
            os.rename(tmp_path, path)
        except Exception:
            # If anything fails, clean up the temp file
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise

    def export_json(self, path: str):
        # For export, we want ALL tasks (including archived ones) 
        # This is different from list which filters out archived by default
        tasks = self.list_tasks(show_all=True)
        
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump(tasks, f, indent=2)
            os.rename(tmp_path, path)
        except Exception:
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise

    def export_csv(self, path: str):
        # For export, we want ALL tasks (including archived ones) 
        # This is different from list which filters out archived by default
        tasks = self.list_tasks(show_all=True)
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, 'w', newline='', encoding='utf-8') as f:
                if not tasks:
                    # Write empty CSV with header
                    writer = csv.writer(f)
                    writer.writerow(['id', 'title', 'due', 'priority', 'done', 'archived', 'tags'])
                else:
                    fieldnames = ['id', 'title', 'due', 'priority', 'done', 'archived', 'tags']
                    writer = csv.DictWriter(f, fieldnames=fieldnames)
                    writer.writeheader()
                    for task in tasks:
                        # Convert boolean values to strings
                        task['done'] = str(task['done']).lower()
                        task['archived'] = str(task['archived']).lower()
                        writer.writerow(task)
            os.rename(tmp_path, path)
        except Exception:
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise

    def compact(self):
        conn = sqlite3.connect(self.db_path)
        try:
            # VACUUM to reclaim space
            conn.execute("VACUUM")
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def format_task(self, task: Dict[str, Any], use_colors: bool = False) -> str:
        # Format the task like list does
        status_symbol = "✓" if task['done'] else "○"
        priority_symbol = ""
        
        # Add priority indicator if set
        if task['priority'] == 'high':
            priority_symbol = " ⚠"
        elif task['priority'] == 'med':
            priority_symbol = " ⚠"
        elif task['priority'] == 'low':
            priority_symbol = " ⚠"
        
        # Due date
        due_str = ""
        if task['due']:
            due_str = f" [{task['due']}]"
            
        # Overdue check
        overdue = False
        if task['due'] and not task['done']:
            try:
                due_date = datetime.strptime(task['due'], "%Y-%m-%d")
                today_date = datetime.strptime(self.today_str, "%Y-%m-%d")
                overdue = due_date < today_date
            except ValueError:
                pass  # Invalid date format, ignore

        # Color codes
        color_reset = "\x1b[0m"
        color_overdue = "\x1b[31m"  # Red
        color_done = "\x1b[32m"    # Green
        
        if use_colors and overdue:
            return f"{color_overdue}{status_symbol} {task['title']}{due_str}{priority_symbol}{color_reset}"
        elif use_colors and task['done']:
            return f"{color_done}{status_symbol} {task['title']}{due_str}{priority_symbol}{color_reset}"
        else:
            return f"{status_symbol} {task['title']}{due_str}{priority_symbol}"

    def search_tasks(self, text: str) -> List[Dict[str, Any]]:
        conn = sqlite3.connect(self.db_path)
        try:
            # Get base query and parameters
            query, params = self._get_tasks_query()
            
            # Add search condition
            query += " AND LOWER(title) LIKE ?"
            params.append(f"%{text.lower()}%")
            
            # Always sort by insertion order for search
            query += " ORDER BY id ASC"
            
            rows = conn.execute(query, params).fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'due': row[2],
                    'priority': row[3],
                    'done': bool(row[4]),
                    'archived': bool(row[5]),
                    'tags': json.loads(row[6]) if row[6] else []
                }
                tasks.append(task)
            return tasks
        finally:
            conn.close()

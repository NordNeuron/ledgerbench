import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import TaskStorage

def get_config():
    config = {}
    try:
        with open("config.toml", "r", encoding="utf-8") as f:
            import toml
            config = toml.load(f)
    except (FileNotFoundError, toml.TomlDecodeError):
        pass
    
    # Handle deprecated TASKCLI_TODAY env var
    if "TASKCLI_TODAY" in os.environ and not config.get("today"):
        config["today"] = os.environ["TASKCLI_TODAY"]
    
    return config

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--version", action="version", version="taskcli 1.0")
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--due", help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--priority", choices=["high", "med", "low"], default=None)
    add_parser.add_argument("--tag", action="append", help="Add a tag (repeatable)")
    
    # List command
    list_parser = subparsers.add_parser("list", help="List tasks")
    list_parser.add_argument("--sort", choices=["priority", "insertion"], default="insertion")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks")
    list_parser.add_argument("--tag", help="Filter by tag")
    list_parser.add_argument("--color", action="store_true", help="Enable ANSI colors")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")

    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show statistics")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup database")
    backup_parser.add_argument("path", help="Backup destination path")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export destination path")
    export_parser.add_argument("--format", choices=["json", "csv"], default="json")

    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Reclaim dead space")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Search text (case-insensitive)")

    args = parser.parse_args()

    # Emit audit line for every command invocation
    sys.stderr.write(f"AUDIT {args.command or 'help'}\n")
    sys.stderr.flush()
    
    config = get_config()
    today_str = config.get("today", datetime.now().strftime("%Y-%m-%d"))
    
    try:
        storage = TaskStorage(today_str)
        
        if args.command == "add":
            # Validate due date
            if args.due:
                try:
                    datetime.strptime(args.due, "%Y-%m-%d")
                except ValueError:
                    sys.stderr.write(f"Invalid date format: {args.due}. Expected YYYY-MM-DD.\n")
                    return 2

            task_id = storage.add_task(
                title=args.title,
                due=args.due,
                priority=args.priority,
                tags=args.tag or []
            )
            print(task_id)
            return 0

        elif args.command == "list":
            tasks = storage.list_tasks(
                sort_by=args.sort,
                show_all=args.all,
                tag_filter=args.tag,
                overdue_only=args.overdue
            )
            
            # Determine if we should use colors
            use_colors = args.color and sys.stdout.isatty()
            
            for task in tasks:
                print(storage.format_task(task, use_colors=use_colors))
            return 0

        elif args.command == "done":
            try:
                storage.mark_done(args.id)
            except ValueError as e:
                sys.stderr.write(f"{str(e)}\n")
                return 2
            return 0

        elif args.command == "delete":
            try:
                storage.delete_task(args.id)
            except ValueError as e:
                sys.stderr.write(f"{str(e)}\n")
                return 2
            return 0

        elif args.command == "archive":
            storage.archive_done()
            return 0

        elif args.command == "stats":
            stats = storage.get_stats()
            print(f"Total: {stats['total']}")
            print(f"Done: {stats['done']}")
            print(f"Open: {stats['open']}")
            print(f"Priority high: {stats['priority_high']}")
            print(f"Priority med: {stats['priority_med']}")
            print(f"Priority low: {stats['priority_low']}")
            if stats['overdue'] > 0:
                print(f"\x1b[31mOverdue: {stats['overdue']}\x1b[0m")
            else:
                print(f"Overdue: {stats['overdue']}")
            return 0

        elif args.command == "backup":
            try:
                storage.backup(args.path)
            except OSError as e:
                sys.stderr.write(f"Backup failed: {str(e)}\n")
                return 1
            return 0

        elif args.command == "export":
            try:
                if args.format == "csv":
                    storage.export_csv(args.path)
                else:
                    storage.export_json(args.path)
            except OSError as e:
                sys.stderr.write(f"Export failed: {str(e)}\n")
                return 1
            return 0

        elif args.command == "compact":
            storage.compact()
            return 0

        elif args.command == "search":
            tasks = storage.search_tasks(args.text)
            for task in tasks:
                print(storage.format_task(task))
            return 0

        else:
            parser.print_help()
            return 0

    except Exception as e:
        sys.stderr.write(f"Unexpected error: {str(e)}\n")
        return 1

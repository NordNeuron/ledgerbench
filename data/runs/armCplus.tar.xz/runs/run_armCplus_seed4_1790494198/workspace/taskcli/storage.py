import os
import json
import sqlite3
import shutil
import csv
from datetime import datetime

class Task:
    def __init__(self, title, priority='med', due=None, tags=None, done=False, archived=False):
        self.id = None
        self.title = title
        self.priority = priority
        self.due = due
        self.tags = tags or []
        self.done = done
        self.archived = archived

class TaskStorage:
    def __init__(self, db_path="tasks.db"):
        self.db_path = db_path
        self.init_db()
    
    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table if it doesn't exist
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    priority TEXT DEFAULT 'med',
                    due TEXT,
                    tags TEXT,
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE
                )
            ''')
            
            # Create indexes for better performance
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_kind ON items(kind)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_done ON items(done)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_archived ON items(archived)')
            
            conn.commit()
        finally:
            conn.close()
    
    def get_next_id(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items WHERE kind='task'")
            next_id = cursor.fetchone()[0]
            return next_id
        finally:
            conn.close()
    
    def add_task(self, task):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Get the next ID
            task.id = self.get_next_id()
            
            # Convert tags to JSON string for storage
            tags_json = json.dumps(task.tags)
            
            cursor.execute('''
                INSERT INTO items (id, kind, title, priority, due, tags, done, archived)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (task.id, 'task', task.title, task.priority, task.due, 
                  tags_json, task.done, task.archived))
            
            conn.commit()
            return task.id
        finally:
            conn.close()
    
    def get_task(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id, title, priority, due, tags, done, archived FROM items WHERE id=? AND kind='task'", (task_id,))
            row = cursor.fetchone()
            
            if not row:
                raise ValueError(f"Task with ID {task_id} not found")
            
            task = Task(
                title=row[1],
                priority=row[2],
                due=row[3],
                tags=json.loads(row[4]) if row[4] else [],
                done=bool(row[5]),
                archived=bool(row[6])
            )
            task.id = row[0]
            return task
        finally:
            conn.close()
    
    def get_all_tasks(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id, title, priority, due, tags, done, archived FROM items WHERE kind='task' ORDER BY id")
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = Task(
                    title=row[1],
                    priority=row[2],
                    due=row[3],
                    tags=json.loads(row[4]) if row[4] else [],
                    done=bool(row[5]),
                    archived=bool(row[6])
                )
                task.id = row[0]
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()
    
    def mark_done(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET done=1 WHERE id=? AND kind='task'", (task_id,))
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
            conn.commit()
        finally:
            conn.close()
    
    def delete_task(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM items WHERE id=? AND kind='task'", (task_id,))
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
            conn.commit()
        finally:
            conn.close()
    
    def archive_done(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived=1 WHERE done=1 AND kind='task'")
            conn.commit()
        finally:
            conn.close()
    
    def backup(self, path):
        # Atomic write: create temp file then rename
        tmp_path = path + ".tmp"
        try:
            shutil.copy2(self.db_path, tmp_path)
            os.rename(tmp_path, path)
        except Exception as e:
            # Clean up temp file on failure
            try:
                os.remove(tmp_path)
            except:
                pass
            raise e
    
    def export_json(self, path, tasks=None):
        if tasks is None:
            tasks = self.get_all_tasks()
        
        # Atomic write: create temp file then rename
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump([{
                    'id': t.id,
                    'title': t.title,
                    'priority': t.priority,
                    'due': t.due,
                    'tags': t.tags,
                    'done': t.done,
                    'archived': t.archived
                } for t in tasks], f, indent=2)
            os.rename(tmp_path, path)
        except Exception as e:
            # Clean up temp file on failure
            try:
                os.remove(tmp_path)
            except:
                pass
            raise e
    
    def export_csv(self, path, tasks=None):
        if tasks is None:
            tasks = self.get_all_tasks()
        
        # Atomic write: create temp file then rename
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(['id', 'title', 'priority', 'due', 'tags', 'done', 'archived'])
                for t in tasks:
                    writer.writerow([
                        t.id,
                        t.title,
                        t.priority,
                        t.due,
                        json.dumps(t.tags),
                        int(t.done),
                        int(t.archived)
                    ])
            os.rename(tmp_path, path)
        except Exception as e:
            # Clean up temp file on failure
            try:
                os.remove(tmp_path)
            except:
                pass
            raise e
    
    def compact(self):
        conn = sqlite3.connect(self.db_path)
        try:
            # VACUUM to reclaim space from deleted rows
            conn.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()

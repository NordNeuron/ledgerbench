import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import TaskStorage, Task

def get_config():
    config = {}
    try:
        import tomllib
        config_file = "config.toml"
        if os.path.exists(config_file):
            with open(config_file, "rb") as f:
                config = tomllib.load(f)
    except ImportError:
        # Fallback for Python < 3.11
        pass
    return config

def get_today():
    config = get_config()
    if 'today' in config:
        return config['today']
    
    # Fallback to environment variable
    today_env = os.environ.get('TASKCLI_TODAY')
    if today_env:
        return today_env
    
    # Default to current date
    return datetime.now().strftime('%Y-%m-%d')

def is_overdue(task, today_str):
    if task.done or not task.due:
        return False
    try:
        due_date = datetime.strptime(task.due, '%Y-%m-%d')
        today = datetime.strptime(today_str, '%Y-%m-%d')
        return due_date < today
    except ValueError:
        return False

def format_task(task, today_str, color=False):
    if task.done:
        status = "[DONE]"
    else:
        status = "[TODO]"
    
    if color and not sys.stdout.isatty():
        color = False
    
    if color and is_overdue(task, today_str):
        status = f"\033[31m{status}\033[0m"  # Red for overdue
    elif color and task.done:
        status = f"\033[32m{status}\033[0m"  # Green for done
    
    due_str = f" {task.due}" if task.due else ""
    return f"{task.id} {status}{due_str} {task.title}"

def print_task(task, today_str, color=False):
    print(format_task(task, today_str, color))

def get_filtered_tasks(storage, show_all=False, tag_filter=None, 
                      overdue_only=False, sort_by=None):
    """Shared function to retrieve tasks with consistent filtering and sorting"""
    tasks = storage.get_all_tasks()
    
    if not show_all:
        tasks = [t for t in tasks if not t.archived]
    
    if tag_filter:
        tasks = [t for t in tasks if tag_filter in t.tags]
        
    if overdue_only:
        today = get_today()
        tasks = [t for t in tasks if is_overdue(t, today) and not t.done]
    
    # Apply sorting
    if sort_by == "priority":
        priority_order = {"high": 0, "med": 1, "low": 2}
        tasks.sort(key=lambda t: (priority_order.get(t.priority, 1), 
                                  not t.due or t.due > get_today()))
    elif sort_by == "review":
        # Overdue first, then by priority high to low
        priority_order = {"high": 0, "med": 1, "low": 2}
        tasks.sort(key=lambda t: (is_overdue(t, get_today()), 
                                  priority_order.get(t.priority, 1)))
    else:
        # Default insertion order
        pass
    
    return tasks

def list_tasks(storage, sort_by=None, show_all=False, tag_filter=None, 
               overdue_only=False, color=False):
    today = get_today()
    
    tasks = get_filtered_tasks(storage, show_all, tag_filter, overdue_only, sort_by)
    
    for task in tasks:
        print_task(task, today, color)

def search_tasks(storage, search_text):
    today = get_today()
    
    tasks = storage.get_all_tasks()
    matching_tasks = [t for t in tasks if search_text.lower() in t.title.lower()]
    
    # Sort by insertion order
    matching_tasks.sort(key=lambda t: t.id)
    
    for task in matching_tasks:
        print_task(task, today, color=False)

def add_task(storage, title, priority=None, due=None, tags=None):
    today = get_today()
    
    if not priority:
        config = get_config()
        priority = config.get('default_priority', 'med')
    
    if due:
        try:
            datetime.strptime(due, '%Y-%m-%d')
        except ValueError:
            print(f"Invalid date format: {due}. Expected YYYY-MM-DD.", file=sys.stderr)
            sys.exit(2)
    
    task = Task(
        title=title,
        priority=priority,
        due=due,
        tags=tags or []
    )
    
    new_id = storage.add_task(task)
    # Print only the ID, nothing else (no trailing newline)
    sys.stdout.write(str(new_id))

def done_task(storage, task_id):
    storage.mark_done(task_id)
    # Silent success - no output at all

def delete_task(storage, task_id):
    storage.delete_task(task_id)
    # Silent success - no output at all

def archive_tasks(storage):
    storage.archive_done()
    # Silent success

def stats(storage):
    today = get_today()
    
    tasks = storage.get_all_tasks()
    
    total = len(tasks)
    done = sum(1 for t in tasks if t.done)
    open_tasks = total - done
    
    priority_counts = {"high": 0, "med": 0, "low": 0}
    overdue_count = 0
    
    for task in tasks:
        if task.priority in priority_counts:
            priority_counts[task.priority] += 1
        if is_overdue(task, today) and not task.done:
            overdue_count += 1
    
    print(f"Total: {total}")
    print(f"Done: {done}")
    print(f"Open: {open_tasks}")
    print(f"Overdue: {overdue_count}")
    
    for priority in ["high", "med", "low"]:
        print(f"Priority {priority}: {priority_counts[priority]}")

def backup(storage, path):
    try:
        storage.backup(path)
    except Exception as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)

def export(storage, path, format="json"):
    try:
        if format == "csv":
            # Use the same filtering logic for export
            tasks = get_filtered_tasks(storage, show_all=True)  # Export includes archived tasks
            storage.export_csv(path, tasks)
        else:
            # Use the same filtering logic for export
            tasks = get_filtered_tasks(storage, show_all=True)  # Export includes archived tasks
            storage.export_json(path, tasks)
    except Exception as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)

def compact(storage):
    storage.compact()
    # Silent success

def main():
    # Emit audit line to stderr for every invocation
    command_name = "unknown"
    if len(sys.argv) > 1:
        command_name = sys.argv[1]
    
    print(f"AUDIT {command_name}", file=sys.stderr)
    
    parser = argparse.ArgumentParser(description="Minimal command-line task manager")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['high', 'med', 'low'], 
                           help='Task priority')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--tag', action='append', help='Add a tag (repeatable)')
    
    # List command
    list_parser = subparsers.add_parser('list', help='List tasks')
    list_parser.add_argument('--sort', choices=['priority', 'review'], 
                            help='Sort order')
    list_parser.add_argument('--all', action='store_true', help='Show archived tasks')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')
    list_parser.add_argument('--color', action='store_true', help='Enable colored output')
    
    # Done command
    done_parser = subparsers.add_parser('done', help='Mark task as done')
    done_parser.add_argument('id', type=int, help='Task ID')
    
    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')
    
    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')
    
    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')
    
    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup database')
    backup_parser.add_argument('path', help='Backup file path')
    
    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], 
                              default='json', help='Export format')
    
    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Compact database')
    
    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for in titles')
    
    args = parser.parse_args()
    
    storage = TaskStorage()
    
    if args.command == 'add':
        add_task(storage, args.title, args.priority, args.due, args.tag)
    elif args.command == 'list':
        list_tasks(storage, args.sort, args.all, args.tag, args.overdue, args.color)
    elif args.command == 'done':
        try:
            done_task(storage, args.id)
        except ValueError as e:
            print(str(e), file=sys.stderr)
            sys.exit(2)
    elif args.command == 'delete':
        try:
            delete_task(storage, args.id)
        except ValueError as e:
            print(str(e), file=sys.stderr)
            sys.exit(2)
    elif args.command == 'archive':
        archive_tasks(storage)
    elif args.command == 'stats':
        stats(storage)
    elif args.command == 'backup':
        backup(storage, args.path)
    elif args.command == 'export':
        export(storage, args.path, args.format)
    elif args.command == 'compact':
        compact(storage)
    elif args.command == 'search':
        search_tasks(storage, args.text)
    else:
        parser.print_help()
        sys.exit(1)

if __name__ == "__main__":
    main()

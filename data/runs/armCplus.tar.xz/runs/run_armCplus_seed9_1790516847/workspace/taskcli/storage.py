import os
import json
import sqlite3
import shutil
import csv
from datetime import datetime
from pathlib import Path


class Task:
    def __init__(self, id, title, done=False, due=None, priority='med', tags=None, archived=False):
        self.id = id
        self.title = title
        self.done = done
        self.due = due
        self.priority = priority
        self.tags = tags or []
        self.archived = archived
        
        # Compute overdue status based on today's date
        today_str = datetime.today().strftime("%Y-%m-%d")
        self.overdue = False
        if not done and due:
            try:
                due_date = datetime.strptime(due, "%Y-%m-%d")
                today = datetime.strptime(today_str, "%Y-%m-%d")
                self.overdue = due_date < today
            except ValueError:
                # Invalid date format - treat as not overdue
                pass


class TaskStorage:
    def __init__(self, db_path="tasks.db"):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table with kind column
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    due TEXT,
                    priority TEXT DEFAULT 'med',
                    tags TEXT DEFAULT '[]',
                    archived BOOLEAN DEFAULT FALSE,
                    kind TEXT NOT NULL
                )
            """)
            
            # Ensure all existing tasks are marked as 'task' kind
            cursor.execute("UPDATE items SET kind = 'task' WHERE kind IS NULL OR kind = ''")
            
            conn.commit()
        finally:
            conn.close()

    def get_next_id(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT MAX(id) FROM items")
            max_id = cursor.fetchone()[0]
            return (max_id or 0) + 1
        finally:
            conn.close()

    def validate_date(self, date_str):
        """Validate a date string in YYYY-MM-DD format."""
        if not date_str:
            return True
        try:
            datetime.strptime(date_str, "%Y-%m-%d")
            return True
        except ValueError:
            raise ValueError(f"Invalid date format '{date_str}'. Expected YYYY-MM-DD.")

    def add_task(self, title, due=None, priority='med', tags=None):
        # Validate due date if provided
        self.validate_date(due)
        
        task_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO items (id, title, done, due, priority, tags, kind)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (task_id, title, False, due, priority, json.dumps(tags or []), 'task'))
            
            conn.commit()
            return task_id
        finally:
            conn.close()

    def _get_tasks_query(self, include_archived=True, filter_tag=None, filter_overdue=False):
        """Get a query for tasks with optional filters."""
        base_query = """
            SELECT id, title, done, due, priority, tags, archived 
            FROM items 
            WHERE kind = 'task'
        """
        
        params = []
        
        # Only exclude archived if explicitly requested
        if not include_archived:
            base_query += " AND archived = FALSE"
            
        if filter_tag:
            # Filter by tag - we need to check if the tag exists in the JSON array
            base_query += " AND tags LIKE ?"
            params.append(f'%"{filter_tag}"%')
            
        if filter_overdue:
            # Overdue tasks are those that are not done and have a due date before today
            today = datetime.today().strftime("%Y-%m-%d")
            base_query += " AND done = FALSE AND due < ?"
            params.append(today)
        
        base_query += " ORDER BY id"
        
        return base_query, params

    def list_tasks(self, include_archived=False, filter_tag=None, filter_overdue=False):
        """List tasks with optional filters."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            query, params = self._get_tasks_query(include_archived, filter_tag, filter_overdue)
            cursor.execute(query, params)
            
            tasks = []
            for row in cursor.fetchall():
                task = Task(
                    id=row[0],
                    title=row[1],
                    done=row[2],
                    due=row[3],
                    priority=row[4],
                    tags=json.loads(row[5]) if row[5] else [],
                    archived=row[6]
                )
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()

    def list_all_tasks(self):
        """List all tasks including archived ones."""
        return self.list_tasks(include_archived=True)

    def mark_done(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found")
            
            cursor.execute("UPDATE items SET done = TRUE WHERE id = ?", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def delete_task(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found")
            
            cursor.execute("DELETE FROM items WHERE id = ?", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def archive_done(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived = TRUE WHERE done = TRUE AND kind = 'task'")
            conn.commit()
        finally:
            conn.close()

    def backup(self, path):
        # Atomic write: stage to .tmp then rename
        tmp_path = path + ".tmp"
        try:
            shutil.copy2(self.db_path, tmp_path)
            os.rename(tmp_path, path)
        except Exception as e:
            # Clean up temp file on failure
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise e

    def export_json(self, path, include_archived=True, filter_tag=None, filter_overdue=False):
        """Export tasks to JSON with optional filters."""
        tasks = self.list_tasks(include_archived=include_archived, filter_tag=filter_tag, 
                               filter_overdue=filter_overdue)
        
        # Prepare data for JSON export
        export_data = []
        for task in tasks:
            task_dict = {
                "id": task.id,
                "title": task.title,
                "done": task.done,
                "due": task.due,
                "priority": task.priority,
                "tags": task.tags,
                "archived": task.archived
            }
            export_data.append(task_dict)
        
        # Atomic write: stage to .tmp then rename
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2)
            os.rename(tmp_path, path)
        except Exception as e:
            # Clean up temp file on failure
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise e

    def export_csv(self, path, include_archived=True, filter_tag=None, filter_overdue=False):
        """Export tasks to CSV with optional filters."""
        tasks = self.list_tasks(include_archived=include_archived, filter_tag=filter_tag, 
                               filter_overdue=filter_overdue)
        
        # Prepare data for CSV export
        fieldnames = ["id", "title", "done", "due", "priority", "tags", "archived"]
        
        # Atomic write: stage to .tmp then rename
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for task in tasks:
                    row = {
                        "id": task.id,
                        "title": task.title,
                        "done": task.done,
                        "due": task.due,
                        "priority": task.priority,
                        "tags": json.dumps(task.tags),
                        "archived": task.archived
                    }
                    writer.writerow(row)
            os.rename(tmp_path, path)
        except Exception as e:
            # Clean up temp file on failure
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise e

    def compact(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()

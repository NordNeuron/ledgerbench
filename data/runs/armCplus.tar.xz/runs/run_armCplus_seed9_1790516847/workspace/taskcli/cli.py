import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import TaskStorage, Task


def get_config():
    config = {}
    try:
        import tomllib
        with open("config.toml", "rb") as f:
            config = tomllib.load(f)
    except (FileNotFoundError, ModuleNotFoundError):
        # Fall back to environment variable if no config file
        try:
            today = os.environ["TASKCLI_TODAY"]
            config["today"] = today
        except KeyError:
            pass
    return config


def get_today():
    config = get_config()
    if "today" in config:
        return config["today"]
    return datetime.today().strftime("%Y-%m-%d")


def print_task(task, color=False):
    # Determine if we're on a TTY for color support
    is_tty = sys.stdout.isatty()
    
    # Format the task line
    status_symbol = "✓" if task.done else "○"
    due_str = f" (due {task.due})" if task.due else ""
    priority_str = f" [{task.priority}]" if task.priority else ""
    tags_str = f" #{' '.join(task.tags)}" if task.tags else ""
    
    line = f"{task.id} {status_symbol} {task.title}{due_str}{priority_str}{tags_str}"
    
    # Apply color if requested and we're on a TTY
    if color and is_tty:
        if task.overdue:
            line = f"\033[31m{line}\033[0m"  # Red for overdue
        elif task.done:
            line = f"\033[32m{line}\033[0m"  # Green for done
    
    print(line)


def list_tasks(args):
    storage = TaskStorage()
    
    # Get today's date
    today_str = get_today()
    
    # Fetch tasks with filtering and sorting options
    filter_tag = getattr(args, 'tag', None)
    filter_overdue = getattr(args, 'overdue', False)
    
    if hasattr(args, 'all') and args.all:
        tasks = storage.list_tasks(include_archived=True, filter_tag=filter_tag, 
                                  filter_overdue=filter_overdue)
    else:
        tasks = storage.list_tasks(include_archived=False, filter_tag=filter_tag, 
                                  filter_overdue=filter_overdue)
    
    # Apply sorting
    if hasattr(args, 'sort') and args.sort == "priority":
        # Sort by priority: high > med > low
        priority_order = {"high": 0, "med": 1, "low": 2}
        tasks.sort(key=lambda t: (priority_order.get(t.priority, 3), t.id))
    elif hasattr(args, 'sort') and args.sort == "review":
        # Review view: overdue first, then by priority high to low
        def review_sort_key(task):
            if task.overdue:
                return (0, 0)  # Overdue tasks come first
            else:
                priority_order = {"high": 0, "med": 1, "low": 2}
                return (1, priority_order.get(task.priority, 3))
        tasks.sort(key=review_sort_key)
    else:
        # Default: insertion order
        pass
    
    # Print tasks
    for task in tasks:
        print_task(task, color=getattr(args, 'color', False))


def add_task(args):
    storage = TaskStorage()
    
    # Get default priority from config
    config = get_config()
    default_priority = config.get("default_priority", "med")
    
    # Set priority to default if not specified
    priority = getattr(args, 'priority', None)
    if priority is None:
        priority = default_priority
    
    try:
        # Add the task
        task_id = storage.add_task(
            title=args.title,
            due=getattr(args, 'due', None),
            priority=priority,
            tags=getattr(args, 'tag', [])
        )
        
        # Print only the ID (silent success)
        print(task_id)
    except ValueError as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(2)


def done_task(args):
    storage = TaskStorage()
    try:
        storage.mark_done(args.id)
    except ValueError as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(2)


def delete_task(args):
    storage = TaskStorage()
    try:
        storage.delete_task(args.id)
    except ValueError as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(2)


def archive_tasks(args):
    storage = TaskStorage()
    storage.archive_done()


def stats(args):
    storage = TaskStorage()
    
    # Get today's date
    today_str = get_today()
    
    tasks = storage.list_all_tasks()
    
    total = len(tasks)
    done = sum(1 for t in tasks if t.done)
    open_count = total - done
    
    priority_counts = {"high": 0, "med": 0, "low": 0}
    overdue_count = 0
    
    for task in tasks:
        if task.priority in priority_counts:
            priority_counts[task.priority] += 1
        if task.overdue:
            overdue_count += 1
    
    print(f"Total: {total}")
    print(f"Done: {done}")
    print(f"Open: {open_count}")
    
    for prio, count in priority_counts.items():
        print(f"Priority {prio}: {count}")
    
    # Print overdue count with ANSI if needed
    is_tty = sys.stdout.isatty()
    overdue_line = f"Overdue: {overdue_count}"
    if is_tty and overdue_count > 0:
        overdue_line = f"\033[31m{overdue_line}\033[0m"
    print(overdue_line)


def backup(args):
    storage = TaskStorage()
    try:
        storage.backup(args.path)
    except Exception as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(1)


def export(args):
    storage = TaskStorage()
    try:
        # For export, always include archived tasks by default (as per T13 requirement)
        # The --all flag for export is a bit different - it's about including non-archived
        # But the default behavior should be to include all tasks (including archived)
        include_archived = True  # Always include archived tasks in export
        
        # Get filter parameters
        filter_tag = getattr(args, 'tag', None)
        filter_overdue = getattr(args, 'overdue', False)
        
        if getattr(args, 'format', None) == "csv":
            storage.export_csv(args.path, include_archived=include_archived, 
                              filter_tag=filter_tag, filter_overdue=filter_overdue)
        else:
            storage.export_json(args.path, include_archived=include_archived, 
                               filter_tag=filter_tag, filter_overdue=filter_overdue)
    except Exception as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(1)


def compact(args):
    storage = TaskStorage()
    try:
        storage.compact()
    except Exception as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(1)


def search(args):
    storage = TaskStorage()
    
    # Get today's date
    today_str = get_today()
    
    tasks = storage.list_all_tasks()
    
    # Filter tasks by title containing the search text (case-insensitive)
    matching_tasks = [t for t in tasks if args.text.lower() in t.title.lower()]
    
    # Sort by insertion order (default)
    matching_tasks.sort(key=lambda t: t.id)
    
    # Print matching tasks
    for task in matching_tasks:
        print_task(task, color=False)


def main():
    # Emit audit line at the start of every invocation
    command_name = "unknown"
    if len(sys.argv) > 1:
        command_name = sys.argv[1]
    
    # Always emit audit line for all commands (T24 requirement)
    sys.stderr.write(f"AUDIT {command_name}\n")
    
    parser = argparse.ArgumentParser(description="Minimal command-line task manager")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--priority', choices=['high', 'med', 'low'], default='med',
                           help='Task priority (default: med)')
    add_parser.add_argument('--tag', action='append', help='Add a tag (repeatable)')

    # List command
    list_parser = subparsers.add_parser('list', help='List tasks')
    list_parser.add_argument('--all', action='store_true', help='Show archived tasks')
    list_parser.add_argument('--sort', choices=['priority', 'review'], help='Sort order')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')
    list_parser.add_argument('--color', action='store_true', help='Enable color output')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')

    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup database')
    backup_parser.add_argument('path', help='Backup file path')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json',
                              help='Export format (default: json)')
    export_parser.add_argument('--all', action='store_true', help='Include archived tasks (default: true)')
    export_parser.add_argument('--tag', help='Filter by tag')
    export_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')

    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Reclaim dead space')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for in titles')

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 0

    try:
        if args.command == 'list':
            list_tasks(args)
        elif args.command == 'add':
            add_task(args)
        elif args.command == 'done':
            done_task(args)
        elif args.command == 'delete':
            delete_task(args)
        elif args.command == 'archive':
            archive_tasks(args)
        elif args.command == 'stats':
            stats(args)
        elif args.command == 'backup':
            backup(args)
        elif args.command == 'export':
            export(args)
        elif args.command == 'compact':
            compact(args)
        elif args.command == 'search':
            search(args)
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1

    return 0

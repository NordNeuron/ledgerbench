import json
import os
import shutil
from datetime import datetime

class TaskStorage:
    def __init__(self, filename='tasks.json'):
        self.filename = filename
    
    def load(self):
        if not os.path.exists(self.filename):
            return []
        
        try:
            with open(self.filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
                # Ensure all tasks have required fields
                for task in data:
                    if 'id' not in task or task['id'] <= 0:
                        task['id'] = 0  # This will be corrected during save
                    if 'done' not in task:
                        task['done'] = False
                    if 'priority' not in task:
                        task['priority'] = 'med'
                return data
        except (json.JSONDecodeError, IOError):
            return []
    
    def save(self, tasks):
        # Sort by ID to maintain insertion order
        tasks.sort(key=lambda x: x['id'])
        
        with open(self.filename, 'w', encoding='utf-8') as f:
            json.dump(tasks, f, indent=2)
    
    def add(self, task):
        tasks = self.load()
        
        # Assign ID - find the next available ID
        if not tasks:
            new_id = 1
        else:
            existing_ids = {t['id'] for t in tasks}
            new_id = max(existing_ids) + 1
        
        task['id'] = new_id
        tasks.append(task)
        self.save(tasks)
        return new_id
    
    def mark_done(self, task_id):
        tasks = self.load()
        found = False
        for task in tasks:
            if task['id'] == task_id:
                task['done'] = True
                found = True
                break
        if not found:
            raise ValueError(f"Task with id {task_id} not found")
        self.save(tasks)
    
    def delete(self, task_id):
        tasks = self.load()
        found = False
        for i, task in enumerate(tasks):
            if task['id'] == task_id:
                del tasks[i]
                found = True
                break
        if not found:
            raise ValueError(f"Task with id {task_id} not found")
        self.save(tasks)
    
    def archive(self):
        tasks = self.load()
        for task in tasks:
            if task.get('done') and not task.get('archived', False):
                task['archived'] = True
        self.save(tasks)
    
    def backup(self, path):
        # Atomic write: write to temp file then rename
        tmp_path = path + '.tmp'
        try:
            self.save(self.load())
            shutil.copy2(self.filename, tmp_path)
            os.replace(tmp_path, path)
        except OSError:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise
    
    def export_json(self, path, tasks=None):
        if tasks is None:
            tasks = self.load()
        # Include archived tasks
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(tasks, f, indent=2)
    
    def export_csv(self, path, tasks=None):
        if tasks is None:
            tasks = self.load()
        import csv
        
        fieldnames = ['id', 'title', 'priority', 'due', 'done', 'tags']
        
        with open(path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            
            for task in tasks:
                # Normalize fields for CSV
                row = {
                    'id': task.get('id', ''),
                    'title': task.get('title', ''),
                    'priority': task.get('priority', ''),
                    'due': task.get('due', ''),
                    'done': str(task.get('done', False)).lower(),
                    'tags': ','.join(task.get('tags', []))
                }
                writer.writerow(row)
    
    def compact(self):
        tasks = self.load()
        # For this simple implementation, just save the current state
        self.save(tasks)

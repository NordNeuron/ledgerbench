import argparse
import os
import sys
import json
from datetime import datetime
from .storage import TaskStorage
from .config import load_config

def get_today():
    config = load_config()
    if config.get('today'):
        return config['today']
    elif os.environ.get('TASKCLI_TODAY'):
        return os.environ['TASKCLI_TODAY']
    else:
        return datetime.now().strftime('%Y-%m-%d')

def print_task(task, today, use_color=False):
    done_symbol = "✓" if task['done'] else "○"
    priority_symbol = {"high": "H", "med": "M", "low": "L"}[task.get('priority', 'med')]
    
    # Format due date
    due_str = ""
    if task.get('due'):
        due_str = f" (due {task['due']})"
    
    # Format tags
    tags_str = ""
    if task.get('tags'):
        tags_str = " [" + ",".join(task['tags']) + "]"
    
    # Build the line
    line = f"{task['id']} {done_symbol} {priority_symbol} {task['title']}{due_str}{tags_str}"
    
    # Apply coloring if requested and stdout is a TTY
    if use_color and sys.stdout.isatty():
        if task.get('due') and task['due'] < today and not task['done']:
            line = f"\033[31m{line}\033[0m"  # Red for overdue
        elif task['done']:
            line = f"\033[32m{line}\033[0m"  # Green for done
    
    print(line)

def get_filtered_tasks(storage, args):
    """Shared function to get filtered tasks based on arguments"""
    today = get_today()
    
    tasks = storage.load()
    
    # Filter out archived tasks if --all is not specified
    if not getattr(args, 'all', False):
        tasks = [t for t in tasks if not t.get('archived', False)]
    
    # Apply tag filter if specified
    if hasattr(args, 'tag') and args.tag:
        tasks = [t for t in tasks if t.get('tags') and args.tag in t['tags']]
    
    # Apply overdue filter if specified
    if hasattr(args, 'overdue') and args.overdue:
        tasks = [t for t in tasks if t.get('due') and t['due'] < today and not t['done']]
    
    # Apply sorting
    if hasattr(args, 'sort') and args.sort == 'priority':
        priority_order = {'high': 0, 'med': 1, 'low': 2}
        tasks.sort(key=lambda t: (priority_order.get(t.get('priority', 'med'), 1), 
                                 t['id']))
    elif hasattr(args, 'sort') and args.sort == 'review':
        # Overdue first, then by priority high to low
        priority_order = {'high': 0, 'med': 1, 'low': 2}
        tasks.sort(key=lambda t: (
            not (t.get('due') and t['due'] < today and not t['done']),  # False (0) for overdue, True (1) for non-overdue
            priority_order.get(t.get('priority', 'med'), 1),
            t['id']
        ))
    else:
        # Default: insertion order - already maintained by storage
        pass
    
    return tasks

def list_tasks(args):
    storage = TaskStorage()
    
    tasks = get_filtered_tasks(storage, args)
    
    today = get_today()
    for task in tasks:
        print_task(task, today, use_color=getattr(args, 'color', False))

def add_task(args):
    storage = TaskStorage()
    today = get_today()
    
    # Validate due date if provided
    if args.due:
        try:
            datetime.strptime(args.due, '%Y-%m-%d')
        except ValueError:
            print(f"error: invalid date format '{args.due}'; expected YYYY-MM-DD", file=sys.stderr)
            sys.exit(2)
    
    # Set default priority from config
    if not args.priority:
        config = load_config()
        args.priority = config.get('default_priority', 'med')
    
    task = {
        'title': args.title,
        'priority': args.priority,
        'due': args.due,
        'done': False,
        'tags': args.tag or []
    }
    
    new_id = storage.add(task)
    print(new_id)

def done_task(args):
    storage = TaskStorage()
    try:
        storage.mark_done(args.id)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        sys.exit(2)

def delete_task(args):
    storage = TaskStorage()
    try:
        storage.delete(args.id)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        sys.exit(2)

def archive_tasks(args):
    storage = TaskStorage()
    storage.archive()

def stats(args):
    storage = TaskStorage()
    today = get_today()
    
    tasks = storage.load()
    
    total = len(tasks)
    done = sum(1 for t in tasks if t.get('done'))
    open_count = total - done
    
    priority_counts = {'high': 0, 'med': 0, 'low': 0}
    overdue_count = 0
    
    for task in tasks:
        if task.get('priority'):
            priority_counts[task['priority']] += 1
        if task.get('due') and task['due'] < today and not task['done']:
            overdue_count += 1
    
    print(f"Total: {total}")
    print(f"Done: {done}")
    print(f"Open: {open_count}")
    print(f"Overdue: {overdue_count}")
    
    for priority in ['high', 'med', 'low']:
        count = priority_counts[priority]
        if count > 0:
            print(f"Priority {priority}: {count}")

def backup(args):
    storage = TaskStorage()
    try:
        storage.backup(args.path)
    except OSError as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)

def export(args):
    storage = TaskStorage()
    
    # Get filtered tasks using the same logic as list
    tasks = get_filtered_tasks(storage, args)
    
    if args.format == 'csv':
        storage.export_csv(args.path, tasks)
    else:
        storage.export_json(args.path, tasks)

def compact(args):
    storage = TaskStorage()
    storage.compact()

def search(args):
    storage = TaskStorage()
    tasks = storage.load()
    
    today = get_today()
    
    # Filter tasks that match the search text (case-insensitive)
    matching_tasks = [
        t for t in tasks 
        if args.text.lower() in t['title'].lower()
    ]
    
    # Print them using list format
    for task in matching_tasks:
        print_task(task, today, use_color=False)

def main():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--priority', choices=['high', 'med', 'low'], 
                           help='Task priority')
    add_parser.add_argument('--tag', action='append', help='Add a tag (repeatable)')
    
    # List command
    list_parser = subparsers.add_parser('list', help='List tasks')
    list_parser.add_argument('--all', action='store_true', help='Show archived tasks')
    list_parser.add_argument('--sort', choices=['priority', 'review'], 
                           help='Sort order')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')
    list_parser.add_argument('--color', action='store_true', help='Enable ANSI colors')
    
    # Done command
    done_parser = subparsers.add_parser('done', help='Mark task as done')
    done_parser.add_argument('id', type=int, help='Task ID')
    
    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')
    
    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')
    
    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')
    
    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup database')
    backup_parser.add_argument('path', help='Backup file path')
    
    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json',
                              help='Export format (default: json)')
    export_parser.add_argument('--all', action='store_true', help='Show archived tasks')
    export_parser.add_argument('--tag', help='Filter by tag')
    export_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')
    
    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Reclaim dead space')
    
    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for in titles')
    
    args = parser.parse_args()
    
    # Emit audit log - always, on success and failure
    if args.command:
        print(f"AUDIT {args.command}", file=sys.stderr)
    
    if not args.command:
        parser.print_help()
        return 0
    
    try:
        if args.command == 'list':
            list_tasks(args)
        elif args.command == 'add':
            add_task(args)
        elif args.command == 'done':
            done_task(args)
        elif args.command == 'delete':
            delete_task(args)
        elif args.command == 'archive':
            archive_tasks(args)
        elif args.command == 'stats':
            stats(args)
        elif args.command == 'backup':
            backup(args)
        elif args.command == 'export':
            export(args)
        elif args.command == 'compact':
            compact(args)
        elif args.command == 'search':
            search(args)
    except Exception as e:
        print(str(e), file=sys.stderr)
        return 1
    
    return 0

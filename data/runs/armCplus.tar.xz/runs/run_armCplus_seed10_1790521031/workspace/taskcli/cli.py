import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import TaskStorage

def get_config():
    config = {}
    try:
        import toml
        if os.path.exists("config.toml"):
            with open("config.toml", "r", encoding="utf-8") as f:
                config = toml.load(f)
    except ImportError:
        pass
    
    # Fallback to environment variable if no config file and env var exists
    if not config.get("today") and os.environ.get("TASKCLI_TODAY"):
        config["today"] = os.environ["TASKCLI_TODAY"]
    
    return config

def pin_today(today_str):
    """Set today for testing purposes."""
    return {"TASKCLI_TODAY": today_str}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--version", action="version", version="taskcli 1.0")
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--due", help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--priority", choices=["high", "med", "low"], default=None)
    add_parser.add_argument("--tag", action="append", help="Add a tag (repeatable)")
    
    # List command
    list_parser = subparsers.add_parser("list", help="List tasks")
    list_parser.add_argument("--sort", choices=["priority", "insertion"], default="insertion")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks")
    list_parser.add_argument("--color", action="store_true", help="Colorize output")
    list_parser.add_argument("--tag", help="Filter by tag")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")
    
    # Done command
    done_parser = subparsers.add_parser("done", help="Mark task as done")
    done_parser.add_argument("id", type=int, help="Task ID")
    
    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")
    
    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")
    
    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show statistics")
    
    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup database")
    backup_parser.add_argument("path", help="Backup file path")
    
    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export file path")
    export_parser.add_argument("--format", choices=["json", "csv"], default="json")
    export_parser.add_argument("--tag", help="Filter by tag")
    export_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")
    
    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Reclaim dead space")
    
    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Search text (case-insensitive)")
    
    args = parser.parse_args()
    
    # Emit audit line to stderr BEFORE any processing - this is required
    sys.stderr.write(f"AUDIT {args.command}\n")
    sys.stderr.flush()
    
    config = get_config()
    today_str = config.get("today", datetime.now().strftime("%Y-%m-%d"))
    
    try:
        storage = TaskStorage(today_str)
        
        if args.command == "add":
            task_id = storage.add_task(
                title=args.title,
                due=args.due,
                priority=args.priority,
                tags=args.tag or []
            )
            print(task_id)
            
        elif args.command == "list":
            tasks = storage.list_tasks(
                sort_by=args.sort,
                show_all=args.all,
                tag_filter=args.tag,
                overdue_only=args.overdue
            )
            for task in tasks:
                print(storage.format_task(task, args.color))
                
        elif args.command == "done":
            storage.mark_done(args.id)
            # Silent success - no output
            
        elif args.command == "delete":
            storage.delete_task(args.id)
            # Silent success - no output
            
        elif args.command == "archive":
            storage.archive_tasks()
            
        elif args.command == "stats":
            stats = storage.get_stats()
            print(f"Total: {stats['total']}")
            print(f"Done: {stats['done']}")
            print(f"Open: {stats['open']}")
            print(f"Priority high: {stats['priority_high']}")
            print(f"Priority med: {stats['priority_med']}")
            print(f"Priority low: {stats['priority_low']}")
            print(f"Overdue: {stats['overdue']}")
            
        elif args.command == "backup":
            storage.backup(args.path)
            
        elif args.command == "export":
            # For export, we want to include all tasks (including archived ones) 
            # and apply the filters appropriately
            if args.format == "csv":
                storage.export_csv(args.path)
            else:
                storage.export_json(args.path)
                
        elif args.command == "compact":
            storage.compact()
            
        elif args.command == "search":
            tasks = storage.search_tasks(args.text)
            for task in tasks:
                print(storage.format_task(task, False))  # No color for search
                
        else:
            parser.print_help()
            return 1
            
    except ValueError as e:
        sys.stderr.write(f"Error: {e}\n")
        return 2
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1
        
    return 0

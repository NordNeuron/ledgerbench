import os
import json
import sqlite3
import shutil
import csv
from datetime import datetime
from typing import List, Dict, Any

class TaskStorage:
    def __init__(self, today_str: str):
        self.today_str = today_str
        self.db_path = "tasks.db"
        self.init_db()
        
    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table if it doesn't exist
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE,
                    due DATE,
                    priority TEXT,
                    tags TEXT
                )
            """)
            
            # Create indexes for better performance
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_kind ON items(kind)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_done ON items(done)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_archived ON items(archived)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_priority ON items(priority)")
            
            conn.commit()
        finally:
            conn.close()
    
    def get_next_id(self) -> int:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items WHERE kind='task'")
            return cursor.fetchone()[0]
        finally:
            conn.close()
    
    def add_task(self, title: str, due: str = None, priority: str = None, tags: List[str] = None) -> int:
        if due is not None:
            try:
                datetime.strptime(due, "%Y-%m-%d")
            except ValueError:
                raise ValueError(f"Invalid date format '{due}'. Expected YYYY-MM-DD.")
        
        task_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO items (id, kind, title, due, priority, tags)
                VALUES (?, 'task', ?, ?, ?, ?)
            """, (task_id, title, due, priority, json.dumps(tags) if tags else None))
            conn.commit()
            return task_id
        finally:
            conn.close()
    
    def _build_list_query(self, show_all: bool = False, tag_filter: str = None, 
                         overdue_only: bool = False) -> tuple:
        """Build the base query for listing tasks."""
        # Base query
        query = """
            SELECT id, title, done, archived, due, priority, tags 
            FROM items 
            WHERE kind='task'
        """
        
        params = []
        
        # Filter out archived tasks unless --all is specified
        if not show_all:
            query += " AND archived=0"
            
        # Filter by tag if specified
        if tag_filter:
            query += " AND tags LIKE ?"
            params.append(f'%"{tag_filter}"%')
            
        # Filter overdue tasks if requested
        if overdue_only:
            query += " AND due IS NOT NULL AND due < ? AND done=0"
            params.append(self.today_str)
        
        return query, params
    
    def list_tasks(self, sort_by: str = "insertion", show_all: bool = False, 
                   tag_filter: str = None, overdue_only: bool = False) -> List[Dict[str, Any]]:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            query, params = self._build_list_query(show_all, tag_filter, overdue_only)
            
            # Sorting
            if sort_by == "priority":
                # High, then med, then low priority
                query += """
                    ORDER BY 
                        CASE WHEN priority='high' THEN 1
                             WHEN priority='med' THEN 2
                             WHEN priority='low' THEN 3
                             ELSE 4 END,
                        id
                """
            else:  # insertion order
                query += " ORDER BY id"
                
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'done': bool(row[2]),
                    'archived': bool(row[3]),
                    'due': row[4],
                    'priority': row[5],
                    'tags': json.loads(row[6]) if row[6] else []
                }
                tasks.append(task)
                
            return tasks
        finally:
            conn.close()
    
    def mark_done(self, task_id: int):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found")
                
            cursor.execute("UPDATE items SET done=1 WHERE id=?", (task_id,))
            conn.commit()
        finally:
            conn.close()
    
    def delete_task(self, task_id: int):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found")
                
            cursor.execute("DELETE FROM items WHERE id=?", (task_id,))
            conn.commit()
        finally:
            conn.close()
    
    def archive_tasks(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived=1 WHERE kind='task' AND done=1")
            conn.commit()
        finally:
            conn.close()
    
    def get_stats(self) -> Dict[str, int]:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks (excluding archived)
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task' AND archived=0")
            total = cursor.fetchone()[0]
            
            # Done tasks (excluding archived)
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task' AND done=1 AND archived=0")
            done = cursor.fetchone()[0]
            
            # Open tasks (total - done, excluding archived)
            open_tasks = total - done
            
            # Priority counts (excluding archived)
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task' AND priority='high' AND archived=0")
            priority_high = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task' AND priority='med' AND archived=0")
            priority_med = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task' AND priority='low' AND archived=0")
            priority_low = cursor.fetchone()[0]
            
            # Overdue tasks (not done, due date is in the past, excluding archived)
            cursor.execute("""
                SELECT COUNT(*) FROM items 
                WHERE kind='task' AND done=0 AND due IS NOT NULL AND due < ? AND archived=0
            """, (self.today_str,))
            overdue = cursor.fetchone()[0]
            
            return {
                'total': total,
                'done': done,
                'open': open_tasks,
                'priority_high': priority_high,
                'priority_med': priority_med,
                'priority_low': priority_low,
                'overdue': overdue
            }
        finally:
            conn.close()
    
    def backup(self, path: str):
        # Atomic write: create temp file then rename
        tmp_path = path + ".tmp"
        try:
            shutil.copy2(self.db_path, tmp_path)
            os.rename(tmp_path, path)
        except Exception as e:
            # Clean up temp file on failure
            try:
                os.remove(tmp_path)
            except:
                pass
            raise e
    
    def export_tasks(self, show_all: bool = False, tag_filter: str = None, 
                     overdue_only: bool = False) -> List[Dict[str, Any]]:
        """Shared method for getting tasks for export."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Base query - no archived filter for export
            query = """
                SELECT id, title, done, archived, due, priority, tags 
                FROM items 
                WHERE kind='task'
            """
            
            params = []
            
            # Filter by tag if specified
            if tag_filter:
                query += " AND tags LIKE ?"
                params.append(f'%"{tag_filter}"%')
                
            # Filter overdue tasks if requested
            if overdue_only:
                query += " AND due IS NOT NULL AND due < ? AND done=0"
                params.append(self.today_str)
            
            # Always sort by insertion order for export
            query += " ORDER BY id"
                
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'done': bool(row[2]),
                    'archived': bool(row[3]),
                    'due': row[4],
                    'priority': row[5],
                    'tags': json.loads(row[6]) if row[6] else []
                }
                tasks.append(task)
                
            return tasks
        finally:
            conn.close()
    
    def export_json(self, path: str):
        # Get all tasks (including archived ones) for export
        tasks = self.export_tasks(show_all=True)
        
        # Atomic write
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(tasks, f, indent=2)
            os.rename(tmp_path, path)
        except Exception as e:
            try:
                os.remove(tmp_path)
            except:
                pass
            raise e
    
    def export_csv(self, path: str):
        # Get all tasks (including archived ones) for export
        tasks = self.export_tasks(show_all=True)
        
        # Atomic write
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["id", "title", "done", "archived", "due", "priority", "tags"])
                for task in tasks:
                    writer.writerow([
                        task['id'],
                        task['title'],
                        task['done'],
                        task['archived'],
                        task['due'],
                        task['priority'],
                        json.dumps(task['tags']) if task['tags'] else ""
                    ])
            os.rename(tmp_path, path)
        except Exception as e:
            try:
                os.remove(tmp_path)
            except:
                pass
            raise e
    
    def compact(self):
        conn = sqlite3.connect(self.db_path)
        try:
            # VACUUM to reclaim space
            cursor = conn.cursor()
            cursor.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()
    
    def search_tasks(self, text: str) -> List[Dict[str, Any]]:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Search in title (case-insensitive)
            query = """
                SELECT id, title, done, archived, due, priority, tags 
                FROM items 
                WHERE kind='task' AND LOWER(title) LIKE ?
            """
            cursor.execute(query, (f"%{text.lower()}%",))
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'title': row[1],
                    'done': bool(row[2]),
                    'archived': bool(row[3]),
                    'due': row[4],
                    'priority': row[5],
                    'tags': json.loads(row[6]) if row[6] else []
                }
                tasks.append(task)
                
            return tasks
        finally:
            conn.close()
    
    def format_task(self, task: Dict[str, Any], use_color: bool = False) -> str:
        # Determine if we should colorize output (only when stdout is a TTY)
        try:
            import sys
            should_colorize = use_color and os.isatty(sys.stdout.fileno())
        except:
            should_colorize = False
        
        # Format the task line
        status_symbol = "✓" if task['done'] else "○"
        priority_symbol = ""
        if task['priority']:
            priority_symbol = f"[{task['priority'][0].upper()}]"
            
        due_str = f" ({task['due']})" if task['due'] else ""
        
        # Build the line
        line = f"{task['id']} {status_symbol} {task['title']}{due_str}"
        if priority_symbol:
            line += f" {priority_symbol}"
            
        # Add tags if any
        if task['tags']:
            line += " " + " ".join(f"@{tag}" for tag in task['tags'])
        
        # Colorize if requested and appropriate
        if should_colorize:
            if task['due'] and task['due'] < self.today_str and not task['done']:
                # Overdue: red
                line = f"\x1b[31m{line}\x1b[0m"
            elif task['done']:
                # Done: green
                line = f"\x1b[32m{line}\x1b[0m"
        
        return line

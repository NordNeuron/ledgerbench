import os
import json
import sqlite3
import shutil
import csv
from datetime import datetime
import sys

class TaskStorage:
    def __init__(self, db_path="tasks.db"):
        self.db_path = db_path
        self.init_db()
    
    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table if it doesn't exist
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    priority TEXT DEFAULT 'med',
                    due TEXT,
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE,
                    tags TEXT DEFAULT '[]'
                )
            """)
            
            # Create index on id for performance
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_id ON items(id)")
            
            conn.commit()
        finally:
            conn.close()
    
    def get_next_id(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT MAX(id) FROM items")
            max_id = cursor.fetchone()[0]
            return (max_id or 0) + 1
        finally:
            conn.close()
    
    def add_task(self, title, priority="med", due=None, tags=None):
        task_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO items (id, kind, title, priority, due, done, archived, tags)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (task_id, "task", title, priority, due, False, False, json.dumps(tags or [])))
            
            conn.commit()
            return task_id
        finally:
            conn.close()
    
    def _get_tasks_query(self, include_archived=False, overdue_only=False, tag_filter=None):
        """Get the base query for tasks with optional filters."""
        where_clauses = []
        params = []
        
        # Base conditions
        where_clauses.append("kind = 'task'")
        
        if not include_archived:
            where_clauses.append("archived = FALSE")
            
        if overdue_only:
            where_clauses.append("due < ? AND done = FALSE")
            params.append(datetime.now().date().isoformat())
            
        if tag_filter:
            # Filter tasks that have the specified tag
            where_clauses.append("tags LIKE ?")
            params.append(f'%"{tag_filter}"%')
        
        query = """
            SELECT id, title, priority, due, done, archived, tags
            FROM items
            WHERE {}
            ORDER BY id
        """.format(" AND ".join(where_clauses))
        
        return query, params
    
    def list_tasks(self, include_archived=False, overdue_only=False, tag_filter=None):
        """List tasks with optional filters."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            query, params = self._get_tasks_query(include_archived, overdue_only, tag_filter)
            cursor.execute(query, params)
            
            tasks = []
            for row in cursor.fetchall():
                task = {
                    "id": row[0],
                    "title": row[1],
                    "priority": row[2],
                    "due": row[3],
                    "done": bool(row[4]),
                    "archived": bool(row[5]),
                    "tags": json.loads(row[6]) if row[6] else []
                }
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()
    
    def list_all_tasks(self):
        """List all tasks including archived."""
        return self.list_tasks(include_archived=True)
    
    def list_overdue_tasks(self, today):
        """List overdue tasks."""
        return self.list_tasks(overdue_only=True)
    
    def mark_done(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"no task with id {task_id}")
            
            cursor.execute("UPDATE items SET done = TRUE WHERE id = ?", (task_id,))
            conn.commit()
        finally:
            conn.close()
    
    def delete_task(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"no task with id {task_id}")
            
            cursor.execute("DELETE FROM items WHERE id = ?", (task_id,))
            conn.commit()
        finally:
            conn.close()
    
    def archive_done(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived = TRUE WHERE done = TRUE AND kind = 'task'")
            conn.commit()
        finally:
            conn.close()
    
    def backup(self, path):
        tmp_path = path + ".tmp"
        try:
            # Ensure the directory exists by creating it if needed
            dirname = os.path.dirname(path)
            if dirname:
                try:
                    os.makedirs(dirname, exist_ok=True)
                except (OSError, IOError):
                    # If we can't create the directory, let the copy operation handle it
                    pass
            
            # Copy to temp file first - this should raise an exception if path is unwritable
            shutil.copy2(self.db_path, tmp_path)
            
            # Atomically move to final location
            os.rename(tmp_path, path)
        except (OSError, IOError) as e:
            # Clean up temp file on failure
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise
    
    def export_json(self, path):
        tasks = self.list_all_tasks()
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(tasks, f, indent=2)
            os.rename(tmp_path, path)
        except Exception:
            # Clean up on failure
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise
    
    def export_csv(self, path):
        tasks = self.list_all_tasks()
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, "w", newline="", encoding="utf-8") as f:
                if not tasks:
                    writer = csv.writer(f)
                    writer.writerow(["id", "title", "priority", "due", "done", "archived", "tags"])
                else:
                    fieldnames = ["id", "title", "priority", "due", "done", "archived", "tags"]
                    writer = csv.DictWriter(f, fieldnames=fieldnames)
                    writer.writeheader()
                    for task in tasks:
                        # Convert done to string
                        task["done"] = str(task.get("done", False))
                        task["archived"] = str(task.get("archived", False))
                        task["tags"] = ",".join(task.get("tags", []))
                        writer.writerow(task)
            os.rename(tmp_path, path)
        except Exception:
            # Clean up on failure
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise
    
    def get_stats(self, today):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task'")
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND done = TRUE")
            done = cursor.fetchone()[0]
            
            # Open tasks
            open_count = total - done
            
            # Priority counts
            priority_counts = {}
            for priority in ["high", "med", "low"]:
                cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND priority = ?",
                              (priority,))
                count = cursor.fetchone()[0]
                if count > 0:
                    priority_counts[priority] = count
            
            # Overdue tasks
            cursor.execute("""
                SELECT COUNT(*) FROM items 
                WHERE kind = 'task' AND due < ? AND done = FALSE AND archived = FALSE
            """, (today.isoformat(),))
            overdue_count = cursor.fetchone()[0]
            
            return total, done, open_count, priority_counts, overdue_count
        finally:
            conn.close()
    
    def compact(self):
        conn = sqlite3.connect(self.db_path)
        try:
            # Perform VACUUM to reclaim space
            conn.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()
    
    def search_tasks(self, text):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            # Search case-insensitively in title
            cursor.execute("""
                SELECT id, title, priority, due, done, archived, tags
                FROM items
                WHERE kind = 'task' AND archived = FALSE AND LOWER(title) LIKE ?
                ORDER BY id
            """, (f"%{text.lower()}%",))
            
            tasks = []
            for row in cursor.fetchall():
                task = {
                    "id": row[0],
                    "title": row[1],
                    "priority": row[2],
                    "due": row[3],
                    "done": bool(row[4]),
                    "archived": bool(row[5]),
                    "tags": json.loads(row[6]) if row[6] else []
                }
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()

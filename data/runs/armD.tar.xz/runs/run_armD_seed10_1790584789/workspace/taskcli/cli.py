import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import TaskStorage

def get_config():
    config = {}
    try:
        import tomllib
        config_file = "config.toml"
        if os.path.exists(config_file):
            with open(config_file, "rb") as f:
                config = tomllib.load(f)
    except ImportError:
        # Fallback for Python < 3.11
        try:
            import toml
            config_file = "config.toml"
            if os.path.exists(config_file):
                with open(config_file, "r", encoding="utf-8") as f:
                    config = toml.load(f)
        except ImportError:
            pass  # No TOML support available
    
    return config

def get_today():
    config = get_config()
    today_str = config.get("today")
    if today_str:
        return datetime.strptime(today_str, "%Y-%m-%d").date()
    
    env_today = os.environ.get("TASKCLI_TODAY")
    if env_today:
        return datetime.strptime(env_today, "%Y-%m-%d").date()
    
    return datetime.now().date()

def format_date(date_str):
    if not date_str:
        return ""
    try:
        return datetime.strptime(date_str, "%Y-%m-%d").strftime("%Y-%m-%d")
    except ValueError:
        return date_str

def print_task(task, today, use_color=False):
    # Determine if task is overdue
    is_overdue = False
    if task.get("due"):
        try:
            due_date = datetime.strptime(task["due"], "%Y-%m-%d").date()
            is_overdue = due_date < today and not task.get("done", False)
        except ValueError:
            pass
    
    # Format the line
    done_symbol = "✓" if task.get("done", False) else "○"
    priority_symbol = {"high": "H", "med": "M", "low": "L"}.get(task.get("priority"), " ")
    
    line = f"{task['id']} {done_symbol} [{priority_symbol}] {task['title']}"
    if task.get("due"):
        line += f" (due {format_date(task['due'])})"
    
    # Add tags if present
    if task.get("tags"):
        line += " " + " ".join(f"@{tag}" for tag in task["tags"])
    
    # Apply color if needed and stdout is a TTY
    if use_color and sys.stdout.isatty():
        if is_overdue:
            line = f"\033[31m{line}\033[0m"  # Red for overdue
        elif task.get("done", False):
            line = f"\033[32m{line}\033[0m"  # Green for done
    
    print(line)

def list_tasks(args):
    storage = TaskStorage()
    today = get_today()
    
    tasks = storage.list_tasks(
        include_archived=args.all,
        overdue_only=args.overdue,
        tag_filter=args.tag
    )
    
    # Apply sorting
    if args.sort == "priority":
        tasks.sort(key=lambda t: (
            {"high": 0, "med": 1, "low": 2}.get(t.get("priority"), 3),
            t["id"]
        ))
    elif args.sort == "review":
        tasks.sort(key=lambda t: (
            not (t.get("due") and datetime.strptime(t["due"], "%Y-%m-%d").date() < today and not t.get("done", False)),  # overdue first
            {"high": 0, "med": 1, "low": 2}.get(t.get("priority"), 3),
            t["id"]
        ))
    else:
        # Default insertion order (already sorted by id)
        pass
    
    for task in tasks:
        print_task(task, today, use_color=args.color)

def add_task(args):
    storage = TaskStorage()
    today = get_today()
    
    # Set default priority from config
    config = get_config()
    default_priority = config.get("default_priority", "med")
    if not args.priority:
        args.priority = default_priority
    
    # Validate due date
    due_date = None
    if args.due:
        try:
            datetime.strptime(args.due, "%Y-%m-%d")
            due_date = args.due
        except ValueError:
            print(f"error: invalid date '{args.due}'; expected format YYYY-MM-DD", file=sys.stderr)
            sys.exit(2)
    
    # Add task
    task_id = storage.add_task(
        title=args.title,
        priority=args.priority,
        due=due_date,
        tags=args.tag or []
    )
    
    # Silent success - only print the ID, nothing else (no audit line for add)
    print(task_id)

def done_task(args):
    storage = TaskStorage()
    try:
        storage.mark_done(args.id)
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        sys.exit(2)
    # Silent success - no output

def delete_task(args):
    storage = TaskStorage()
    try:
        storage.delete_task(args.id)
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        sys.exit(2)
    # Silent success - no output

def archive_tasks(args):
    storage = TaskStorage()
    storage.archive_done()

def backup(args):
    storage = TaskStorage()
    try:
        storage.backup(args.path)
    except IOError as e:
        print(f"error: failed to write backup to '{args.path}': {e}", file=sys.stderr)
        sys.exit(1)

def export(args):
    storage = TaskStorage()
    try:
        if args.format == "csv":
            storage.export_csv(args.path)
        else:
            storage.export_json(args.path)
    except IOError as e:
        print(f"error: failed to write export to '{args.path}': {e}", file=sys.stderr)
        sys.exit(1)

def stats(args):
    storage = TaskStorage()
    today = get_today()
    
    total, done, open_count, priority_counts, overdue_count = storage.get_stats(today)
    
    print(f"Total: {total}")
    print(f"Done: {done}")
    print(f"Open: {open_count}")
    for priority in ["high", "med", "low"]:
        if priority in priority_counts:
            print(f"Priority {priority}: {priority_counts[priority]}")
    print(f"Overdue: {overdue_count}")

def compact(args):
    storage = TaskStorage()
    storage.compact()

def search(args):
    storage = TaskStorage()
    tasks = storage.search_tasks(args.text)
    today = get_today()
    
    for task in tasks:
        print_task(task, today, use_color=False)

def main():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--priority", choices=["high", "med", "low"], help="Task priority")
    add_parser.add_argument("--due", help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--tag", action="append", help="Add a tag (repeatable)")

    # List command
    list_parser = subparsers.add_parser("list", help="List tasks")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")
    list_parser.add_argument("--sort", choices=["priority", "review"], default="insertion",
                             help="Sort order (default: insertion)")
    list_parser.add_argument("--tag", help="Filter by tag")
    list_parser.add_argument("--color", action="store_true", help="Use ANSI colors")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark a task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup the database")
    backup_parser.add_argument("path", help="Backup file path")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export file path")
    export_parser.add_argument("--format", choices=["json", "csv"], default="json",
                              help="Export format (default: json)")

    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show statistics")

    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Reclaim dead space")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Text to search for in titles")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 0

    # Emit audit line to stderr BEFORE any other output
    print(f"AUDIT {args.command}", file=sys.stderr)

    try:
        if args.command == "list":
            list_tasks(args)
        elif args.command == "add":
            add_task(args)
        elif args.command == "done":
            done_task(args)
        elif args.command == "delete":
            delete_task(args)
        elif args.command == "archive":
            archive_tasks(args)
        elif args.command == "backup":
            backup(args)
        elif args.command == "export":
            export(args)
        elif args.command == "stats":
            stats(args)
        elif args.command == "compact":
            compact(args)
        elif args.command == "search":
            search(args)
    except Exception as e:
        print(f"error: {e}", file=sys.stderr)
        return 1

    return 0

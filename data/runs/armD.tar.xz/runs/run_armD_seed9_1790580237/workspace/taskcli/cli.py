import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import TaskStorage, Task

def get_config():
    config = {}
    try:
        with open('config.toml', 'r') as f:
            import toml
            config = toml.load(f)
    except FileNotFoundError:
        pass
    except Exception:
        # If config file is malformed, proceed with defaults
        pass
    
    # Environment variable fallback (deprecated)
    if 'TASKCLI_TODAY' in os.environ:
        config['today'] = os.environ['TASKCLI_TODAY']
    
    return config

def get_today():
    config = get_config()
    if 'today' in config:
        try:
            return datetime.strptime(config['today'], '%Y-%m-%d').date()
        except ValueError:
            # If date format is invalid, use today
            pass
    
    return datetime.now().date()

def print_task(task, today, use_color=False):
    """Print a single task in list format"""
    status = "✓" if task.done else "○"
    priority_symbol = {"high": "!", "med": "~", "low": "+"}[task.priority]
    
    # Format due date
    due_str = ""
    if task.due:
        due_str = f" (due {task.due})"
    
    # Format tags
    tags_str = ""
    if task.tags:
        tags_str = " #" + " #".join(task.tags)
    
    line = f"{task.id} {status} {priority_symbol} {task.title}{due_str}{tags_str}"
    
    # Color handling
    if use_color and sys.stdout.isatty():
        if task.due and task.due < today:
            # Overdue: red
            line = f"\033[31m{line}\033[0m"
        elif task.done:
            # Done: green
            line = f"\033[32m{line}\033[0m"
    
    print(line)

def list_tasks(args):
    storage = TaskStorage()
    today = get_today()
    
    # Get tasks using shared method with filters
    tasks = storage.get_filtered_tasks(
        all_tasks=args.all,
        tag=args.tag,
        overdue=args.overdue,
        sort_order=args.sort
    )
    
    use_color = args.color and sys.stdout.isatty()
    
    for task in tasks:
        print_task(task, today, use_color)

def add_task(args):
    storage = TaskStorage()
    today = get_today()
    
    # Set default priority from config if not provided
    if not args.priority:
        config = get_config()
        args.priority = config.get('default_priority', 'med')
    
    task = Task(
        title=args.title,
        priority=args.priority,
        due=args.due,
        tags=args.tag or []
    )
    
    new_id = storage.add_task(task)
    print(new_id)

def done_task(args):
    storage = TaskStorage()
    storage.mark_done(args.id)
    # Silent success - no output

def delete_task(args):
    storage = TaskStorage()
    storage.delete_task(args.id)
    # Silent success - no output

def search_tasks(args):
    storage = TaskStorage()
    tasks = storage.search_tasks(args.text)
    
    today = get_today()
    use_color = args.color and sys.stdout.isatty()
    
    for task in tasks:
        print_task(task, today, use_color)

def archive_tasks(args):
    storage = TaskStorage()
    storage.archive_done()

def stats(args):
    storage = TaskStorage()
    today = get_today()
    
    total, done, open_count, priority_counts, overdue_count = storage.get_stats(today)
    
    print(f"Total: {total}")
    print(f"Done: {done}")
    print(f"Open: {open_count}")
    print(f"Overdue: {overdue_count}")
    
    for prio in ["high", "med", "low"]:
        print(f"Priority {prio}: {priority_counts[prio]}")

def backup(args):
    storage = TaskStorage()
    storage.backup(args.path)

def export(args):
    storage = TaskStorage()
    if args.format == "csv":
        # Get tasks using the same filtering logic as list
        tasks = storage.get_filtered_tasks(
            all_tasks=True,
            tag=args.tag,
            overdue=args.overdue
        )
        storage.export_csv(args.path, tasks)
    else:
        # Get tasks using the same filtering logic as list
        tasks = storage.get_filtered_tasks(
            all_tasks=True,
            tag=args.tag,
            overdue=args.overdue
        )
        storage.export_json(args.path, tasks)

def compact(args):
    storage = TaskStorage()
    storage.compact()

def main():
    parser = argparse.ArgumentParser(description="Minimal command-line task manager")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--priority", choices=["high", "med", "low"], help="Task priority")
    add_parser.add_argument("--due", help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--tag", action="append", help="Add a tag (repeatable)")

    # List command
    list_parser = subparsers.add_parser("list", help="List tasks")
    list_parser.add_argument("--sort", choices=["priority", "review"], help="Sort order")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks")
    list_parser.add_argument("--color", action="store_true", help="Colorize output")
    list_parser.add_argument("--tag", help="Filter by tag")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Text to search for in titles")

    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")

    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show statistics")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup database")
    backup_parser.add_argument("path", help="Backup file path")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export file path")
    export_parser.add_argument("--format", choices=["json", "csv"], default="json", help="Export format")
    export_parser.add_argument("--tag", help="Filter by tag")
    export_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")

    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Reclaim dead space")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        print("AUDIT help", file=sys.stderr)
        return 0

    try:
        # Emit audit line for the command - always, even on error
        print(f"AUDIT {args.command}", file=sys.stderr)
        
        if args.command == "list":
            list_tasks(args)
        elif args.command == "add":
            add_task(args)
        elif args.command == "done":
            done_task(args)
        elif args.command == "delete":
            delete_task(args)
        elif args.command == "search":
            search_tasks(args)
        elif args.command == "archive":
            archive_tasks(args)
        elif args.command == "stats":
            stats(args)
        elif args.command == "backup":
            backup(args)
        elif args.command == "export":
            export(args)
        elif args.command == "compact":
            compact(args)
    except ValueError as e:
        # Re-emit audit line on error
        print(f"AUDIT {args.command}", file=sys.stderr)
        print(str(e), file=sys.stderr)
        return 2
    except Exception as e:
        # Re-emit audit line on error
        print(f"AUDIT {args.command}", file=sys.stderr)
        print(str(e), file=sys.stderr)
        return 1

    return 0

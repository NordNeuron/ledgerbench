import os
import json
import sqlite3
import shutil
import csv
from datetime import datetime, date
from typing import List, Tuple, Dict
import sys

class Task:
    def __init__(self, title: str, priority: str = "med", due: str = None, tags: List[str] = None):
        self.id = None
        self.title = title
        self.priority = priority
        self.due = due
        self.done = False
        self.archived = False
        self.tags = tags or []

    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "priority": self.priority,
            "due": self.due,
            "done": self.done,
            "archived": self.archived,
            "tags": self.tags
        }

    @classmethod
    def from_dict(cls, data):
        task = cls(data["title"], data["priority"], data.get("due"), data.get("tags", []))
        task.id = data["id"]
        task.done = data["done"]
        task.archived = data.get("archived", False)
        return task

class TaskStorage:
    def __init__(self, db_path="tasks.db"):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table if it doesn't exist
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    data TEXT NOT NULL
                )
            """)
            
            # Check if old tasks table exists and migrate if needed
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='tasks'")
            if cursor.fetchone():
                # Migrate from old tasks table to items table
                cursor.execute("SELECT * FROM tasks ORDER BY id")
                tasks = cursor.fetchall()
                for task in tasks:
                    task_data = {
                        "id": task[0],
                        "title": task[1],
                        "priority": task[2] if task[2] else "med",
                        "due": task[3],
                        "done": bool(task[4]),
                        "archived": False,
                        "tags": []
                    }
                    cursor.execute(
                        "INSERT INTO items (id, kind, data) VALUES (?, ?, ?)",
                        (task_data["id"], "task", json.dumps(task_data))
                    )
                # Drop the old tasks table
                cursor.execute("DROP TABLE tasks")
            
            conn.commit()
        finally:
            conn.close()

    def get_next_id(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT MAX(id) FROM items WHERE kind='task'")
            result = cursor.fetchone()[0]
            return (result or 0) + 1
        finally:
            conn.close()

    def add_task(self, task: Task):
        if task.due:
            try:
                datetime.strptime(task.due, "%Y-%m-%d")
            except ValueError:
                raise ValueError(f"Invalid date format for due date '{task.due}'. Expected YYYY-MM-DD.")
        
        # Get the next available ID
        task.id = self.get_next_id()
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO items (id, kind, data) VALUES (?, ?, ?)",
                (task.id, "task", json.dumps(task.to_dict()))
            )
            conn.commit()
            return task.id
        finally:
            conn.close()

    def get_task(self, task_id: int):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT data FROM items WHERE id=? AND kind='task'", (task_id,))
            result = cursor.fetchone()
            if not result:
                raise ValueError(f"Task with ID {task_id} not found")
            return Task.from_dict(json.loads(result[0]))
        finally:
            conn.close()

    def get_all_tasks(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT data FROM items WHERE kind='task' ORDER BY id")
            tasks = []
            for row in cursor.fetchall():
                task_data = json.loads(row[0])
                tasks.append(Task.from_dict(task_data))
            return tasks
        finally:
            conn.close()

    def get_active_tasks(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT data FROM items WHERE kind='task' AND archived=0 ORDER BY id")
            tasks = []
            for row in cursor.fetchall():
                task_data = json.loads(row[0])
                tasks.append(Task.from_dict(task_data))
            return tasks
        finally:
            conn.close()

    def get_filtered_tasks(self, all_tasks=False, tag=None, overdue=False, sort_order=None):
        """Get tasks with filtering and sorting applied"""
        if all_tasks:
            tasks = self.get_all_tasks()
        else:
            tasks = self.get_active_tasks()
        
        # Apply tag filter
        if tag:
            tasks = [t for t in tasks if tag in t.tags]
        
        # Apply overdue filter
        if overdue:
            today = datetime.now().date()  # Use local date function
            tasks = [t for t in tasks if t.due and datetime.strptime(t.due, "%Y-%m-%d").date() < today and not t.done]
        
        # Apply sorting
        if sort_order == "priority":
            # Sort by priority: high, med, low
            priority_order = {"high": 0, "med": 1, "low": 2}
            tasks.sort(key=lambda t: (priority_order[t.priority], t.id))
        elif sort_order == "review":
            # Overdue first, then by priority high to low
            today = datetime.now().date()
            priority_order = {"high": 0, "med": 1, "low": 2}
            tasks.sort(key=lambda t: (
                not (t.due and datetime.strptime(t.due, "%Y-%m-%d").date() < today),  # False (0) for overdue, True (1) for non-overdue
                priority_order[t.priority],
                t.id
            ))
        else:
            # Default insertion order - keep original order from database
            pass
        
        return tasks

    def mark_done(self, task_id: int):
        task = self.get_task(task_id)
        task.done = True
        self._update_task(task)

    def delete_task(self, task_id: int):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM items WHERE id=? AND kind='task'", (task_id,))
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
            conn.commit()
        finally:
            conn.close()

    def search_tasks(self, text: str):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            # Search in titles (case-insensitive) - using LIKE with LOWER
            cursor.execute(
                "SELECT data FROM items WHERE kind='task' AND LOWER(title) LIKE ? AND archived=0",
                (f"%{text.lower()}%",)
            )
            tasks = []
            for row in cursor.fetchall():
                task_data = json.loads(row[0])
                tasks.append(Task.from_dict(task_data))
            return tasks
        finally:
            conn.close()

    def archive_done(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE items SET data = json_set(data, '$.archived', 1) WHERE kind='task' AND json_extract(data, '$.done') = 1"
            )
            conn.commit()
        finally:
            conn.close()

    def get_stats(self, today):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Get all tasks
            cursor.execute("SELECT data FROM items WHERE kind='task'")
            tasks = [Task.from_dict(json.loads(row[0])) for row in cursor.fetchall()]
            
            total = len(tasks)
            done = sum(1 for t in tasks if t.done)
            open_count = total - done
            
            # Count by priority
            priority_counts = {"high": 0, "med": 0, "low": 0}
            overdue_count = 0
            
            for task in tasks:
                if task.priority in priority_counts:
                    priority_counts[task.priority] += 1
                
                # Count overdue (not done and due date passed)
                if not task.done and task.due:
                    try:
                        due_date = datetime.strptime(task.due, "%Y-%m-%d").date()
                        if due_date < today:
                            overdue_count += 1
                    except ValueError:
                        pass  # Invalid date format, skip
            
            return total, done, open_count, priority_counts, overdue_count
        finally:
            conn.close()

    def backup(self, path):
        tmp_path = path + ".tmp"
        try:
            shutil.copy2(self.db_path, tmp_path)
            os.rename(tmp_path, path)
        except Exception as e:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise e

    def export_json(self, path, tasks=None):
        if tasks is None:
            tasks = self.get_all_tasks()
        data = [task.to_dict() for task in tasks]
        
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            os.rename(tmp_path, path)
        except Exception as e:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise e

    def export_csv(self, path, tasks=None):
        if tasks is None:
            tasks = self.get_all_tasks()
        
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                
                # Write header
                writer.writerow(["ID", "Title", "Priority", "Due Date", "Done", "Tags"])
                
                # Write tasks
                for task in tasks:
                    due_str = task.due if task.due else ""
                    done_str = "Yes" if task.done else "No"
                    tags_str = ", ".join(task.tags) if task.tags else ""
                    writer.writerow([
                        task.id,
                        task.title,
                        task.priority,
                        due_str,
                        done_str,
                        tags_str
                    ])
            
            os.rename(tmp_path, path)
        except Exception as e:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise e

    def compact(self):
        conn = sqlite3.connect(self.db_path)
        try:
            # VACUUM to reclaim space
            conn.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()

    def _update_task(self, task: Task):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE items SET data=? WHERE id=? AND kind='task'",
                (json.dumps(task.to_dict()), task.id)
            )
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task.id} not found")
            conn.commit()
        finally:
            conn.close()

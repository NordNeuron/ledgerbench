import json
import os
import shutil
import csv
from datetime import date, datetime
from collections import defaultdict

class TaskStorage:
    def __init__(self, filename="tasks.json"):
        self.filename = filename
        self.tasks = []
        self.load()
    
    def load(self):
        if os.path.exists(self.filename):
            try:
                with open(self.filename, "r", encoding="utf-8") as f:
                    self.tasks = json.load(f)
            except (json.JSONDecodeError, IOError) as e:
                # If there's an error loading the file, start fresh
                self.tasks = []
        else:
            self.tasks = []
    
    def save(self):
        # Write to temporary file first
        tmp_file = f"{self.filename}.tmp"
        try:
            with open(tmp_file, "w", encoding="utf-8") as f:
                json.dump(self.tasks, f, indent=2)
            # Atomic rename
            os.replace(tmp_file, self.filename)
        except Exception:
            # If anything goes wrong, clean up the temp file and re-raise
            try:
                os.remove(tmp_file)
            except OSError:
                pass
            raise
    
    def get_next_id(self):
        if not self.tasks:
            return 1
        return max(task["id"] for task in self.tasks) + 1
    
    def add_task(self, title, due=None, priority="med", tags=None):
        task_id = self.get_next_id()
        task = {
            "id": task_id,
            "title": title,
            "done": False,
            "archived": False,
            "due": due.isoformat() if due else None,
            "priority": priority,
            "tags": tags or []
        }
        self.tasks.append(task)
        self.save()
        return task_id
    
    def _get_filtered_tasks(self, show_all=False, tag_filter=None, overdue_only=False):
        """Internal method to get filtered tasks for both list and export"""
        # Filter tasks
        if show_all:
            tasks = self.tasks
        else:
            tasks = [t for t in self.tasks if not t["archived"]]
        
        # Apply tag filter if specified
        if tag_filter:
            tasks = [t for t in tasks if tag_filter in t.get("tags", [])]
            
        # Apply overdue filter if specified
        if overdue_only:
            today = date.today()
            tasks = [t for t in tasks if not t["done"] and t.get("due") and datetime.strptime(t["due"], "%Y-%m-%d").date() < today]
        
        return tasks
    
    def list_tasks(self, sort_by="insertion", show_all=False, tag_filter=None, overdue_only=False):
        """List tasks with filtering and sorting"""
        tasks = self._get_filtered_tasks(show_all=show_all, tag_filter=tag_filter, overdue_only=overdue_only)
        
        # Sort tasks
        if sort_by == "priority":
            priority_order = {"high": 0, "med": 1, "low": 2}
            tasks.sort(key=lambda t: (priority_order.get(t["priority"], 1), t["id"]))
        else:  # insertion order
            tasks.sort(key=lambda t: t["id"])
            
        return tasks
    
    def mark_done(self, task_id):
        for task in self.tasks:
            if task["id"] == task_id:
                task["done"] = True
                self.save()
                return
        raise ValueError(f"Task with id {task_id} not found")
    
    def delete_task(self, task_id):
        for i, task in enumerate(self.tasks):
            if task["id"] == task_id:
                del self.tasks[i]
                self.save()
                return
        raise ValueError(f"Task with id {task_id} not found")
    
    def archive_done(self):
        for task in self.tasks:
            if task["done"] and not task["archived"]:
                task["archived"] = True
        self.save()
    
    def get_stats(self):
        # Count all tasks (including archived ones)
        total = len(self.tasks)
        done = sum(1 for t in self.tasks if t["done"])
        open_tasks = total - done
        
        priority_counts = defaultdict(int)
        overdue_count = 0
        
        today = date.today()
        
        for task in self.tasks:
            priority_counts[task["priority"]] += 1
            
            # Count overdue tasks (only non-done tasks with past due dates)
            if not task["done"] and task.get("due"):
                try:
                    due_date = datetime.strptime(task["due"], "%Y-%m-%d").date()
                    if due_date < today:
                        overdue_count += 1
                except ValueError:
                    # Invalid date format, skip this task for overdue calculation
                    pass
        
        return {
            "total": total,
            "done": done,
            "open": open_tasks,
            "priority": dict(priority_counts),
            "overdue": overdue_count
        }
    
    def compact(self):
        # Remove archived tasks to reclaim space
        self.tasks = [t for t in self.tasks if not t["archived"]]
        self.save()
    
    def backup(self, path):
        tmp_file = f"{path}.tmp"
        try:
            with open(tmp_file, "w", encoding="utf-8") as f:
                json.dump(self.tasks, f, indent=2)
            os.replace(tmp_file, path)
        except Exception:
            try:
                os.remove(tmp_file)
            except OSError:
                pass
            raise
    
    def export_csv(self, path, show_all=False, tag_filter=None, overdue_only=False):
        """Export tasks to CSV with the same filtering logic as list"""
        tmp_file = f"{path}.tmp"
        try:
            tasks = self._get_filtered_tasks(show_all=show_all, tag_filter=tag_filter, overdue_only=overdue_only)
            
            with open(tmp_file, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                # Write header
                writer.writerow(["id", "title", "done", "archived", "due", "priority", "tags"])
                # Write tasks
                for task in tasks:
                    tags_str = ",".join(task.get("tags", []))
                    writer.writerow([
                        task["id"],
                        task["title"],
                        task["done"],
                        task["archived"],
                        task.get("due", ""),
                        task["priority"],
                        tags_str
                    ])
            os.replace(tmp_file, path)
        except Exception:
            try:
                os.remove(tmp_file)
            except OSError:
                pass
            raise
    
    def export_json(self, path, show_all=False, tag_filter=None, overdue_only=False):
        """Export tasks to JSON with the same filtering logic as list"""
        tmp_file = f"{path}.tmp"
        try:
            tasks = self._get_filtered_tasks(show_all=show_all, tag_filter=tag_filter, overdue_only=overdue_only)
            
            with open(tmp_file, "w", encoding="utf-8") as f:
                json.dump(tasks, f, indent=2)
            os.replace(tmp_file, path)
        except Exception:
            try:
                os.remove(tmp_file)
            except OSError:
                pass
            raise
    
    def search_tasks(self, text):
        text_lower = text.lower()
        matching_tasks = []
        for task in self.tasks:
            if text_lower in task["title"].lower():
                matching_tasks.append(task)
        # Sort by insertion order (same as list command)
        matching_tasks.sort(key=lambda t: t["id"])
        return matching_tasks
    
    def format_task(self, task, use_color=False):
        # Determine ANSI codes for coloring
        ansi_reset = ""
        ansi_overdue = ""
        ansi_done = ""
        
        if use_color:
            import sys
            if sys.stdout.isatty():
                ansi_reset = "\x1b[0m"
                ansi_overdue = "\x1b[31m"  # Red
                ansi_done = "\x1b[32m"    # Green
        
        # Format due date
        due_str = ""
        if task.get("due"):
            due_str = f" {task['due']}"
        
        # Check if overdue
        is_overdue = False
        if not task["done"] and task.get("due"):
            try:
                due_date = datetime.strptime(task["due"], "%Y-%m-%d").date()
                today = date.today()
                is_overdue = due_date < today
            except ValueError:
                pass
        
        # Format priority
        priority_str = ""
        if task["priority"] != "med":
            priority_str = f" [{task['priority']}]"
        
        # Format tags
        tags_str = ""
        if task.get("tags"):
            tags_str = " #" + " #".join(task.get("tags", []))
        
        # Build the line
        if is_overdue and use_color:
            return f"{ansi_overdue}{task['id']}: {task['title']}{due_str}{priority_str}{tags_str}{ansi_reset}"
        elif task["done"] and use_color:
            return f"{ansi_done}{task['id']}: {task['title']}{due_str}{priority_str}{tags_str}{ansi_reset}"
        else:
            return f"{task['id']}: {task['title']}{due_str}{priority_str}{tags_str}"

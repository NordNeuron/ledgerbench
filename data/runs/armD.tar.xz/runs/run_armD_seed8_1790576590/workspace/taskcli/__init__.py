"""
Minimal command-line task manager.
"""

__version__ = "0.1.0"

import argparse
import os
import sys
import json
from datetime import datetime
from .storage import TaskStorage
from . import __version__

def parse_date(date_str):
    try:
        return datetime.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        raise argparse.ArgumentTypeError(f"Invalid date format: {date_str}. Expected YYYY-MM-DD.")

def get_config():
    config = {}
    # Check for config.toml in current directory
    config_path = os.path.join(os.getcwd(), "config.toml")
    if os.path.exists(config_path):
        try:
            import tomli
            with open(config_path, "rb") as f:
                config = tomli.load(f)
        except ImportError:
            # If tomli is not available, we'll handle it gracefully
            pass
        except Exception:
            # If there's an error reading the config, proceed without it
            pass
    
    # Override with environment variable if needed (deprecated)
    if "TASKCLI_TODAY" in os.environ and "today" not in config:
        try:
            config["today"] = datetime.strptime(os.environ["TASKCLI_TODAY"], "%Y-%m-%d").date().isoformat()
        except ValueError:
            pass
    
    return config

def main():
    config = get_config()
    
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    parser.add_argument("--version", action="version", version=f"taskcli {__version__}")
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--due", type=parse_date, help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--priority", choices=["high", "med", "low"], default=config.get("default_priority", "med"), help="Priority level")
    add_parser.add_argument("--tag", action="append", help="Tag for the task (repeatable)")
    
    # List command
    list_parser = subparsers.add_parser("list", help="List tasks")
    list_parser.add_argument("--sort", choices=["priority", "insertion"], default="insertion", help="Sort order")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks")
    list_parser.add_argument("--tag", help="Filter by tag")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")
    list_parser.add_argument("--color", action="store_true", help="Enable colored output")
    
    # Done command
    done_parser = subparsers.add_parser("done", help="Mark a task as done")
    done_parser.add_argument("id", type=int, help="Task ID")
    
    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")
    
    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")
    
    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show statistics")
    
    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Reclaim dead space from deleted tasks")
    
    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup the database")
    backup_parser.add_argument("path", help="Backup file path")
    
    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export file path")
    export_parser.add_argument("--format", choices=["csv"], default="json", help="Export format")
    export_parser.add_argument("--all", action="store_true", help="Show archived tasks")
    export_parser.add_argument("--tag", help="Filter by tag")
    export_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")
    
    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Text to search for in task titles")
    
    args = parser.parse_args()
    
    # Emit audit line
    sys.stderr.write(f"AUDIT {args.command}\n")
    sys.stderr.flush()
    
    storage = TaskStorage()
    
    try:
        if args.command == "add":
            task_id = storage.add_task(
                title=args.title,
                due=args.due,
                priority=args.priority,
                tags=args.tag or []
            )
            print(task_id)
            
        elif args.command == "list":
            tasks = storage.list_tasks(
                sort_by=args.sort,
                show_all=args.all,
                tag_filter=args.tag,
                overdue_only=args.overdue
            )
            for task in tasks:
                print(storage.format_task(task, args.color))
                
        elif args.command == "done":
            storage.mark_done(args.id)
            # Silent success - no output
            
        elif args.command == "delete":
            storage.delete_task(args.id)
            # Silent success - no output
            
        elif args.command == "archive":
            storage.archive_done()
            # Silent success - no output
            
        elif args.command == "stats":
            stats = storage.get_stats()
            # Print to stdout (not stderr) for stats
            print(f"Total: {stats['total']}")
            print(f"Done: {stats['done']}")
            print(f"Open: {stats['open']}")
            print(f"Priority high: {stats['priority']['high']}")
            print(f"Priority med: {stats['priority']['med']}")
            print(f"Priority low: {stats['priority']['low']}")
            print(f"Overdue: {stats['overdue']}")
            
        elif args.command == "compact":
            storage.compact()
            # Silent success - no output
            
        elif args.command == "backup":
            storage.backup(args.path)
            # Silent success - no output
            
        elif args.command == "export":
            if args.format == "csv":
                storage.export_csv(
                    args.path,
                    show_all=args.all,
                    tag_filter=args.tag,
                    overdue_only=args.overdue
                )
            else:
                # Default to JSON export
                storage.export_json(
                    args.path,
                    show_all=args.all,
                    tag_filter=args.tag,
                    overdue_only=args.overdue
                )
                
        elif args.command == "search":
            tasks = storage.search_tasks(args.text)
            for task in tasks:
                print(storage.format_task(task, False))  # No color for search
                
        else:
            parser.print_help()
            return 2
            
    except ValueError as e:
        sys.stderr.write(f"Error: {e}\n")
        return 2
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1
        
    return 0

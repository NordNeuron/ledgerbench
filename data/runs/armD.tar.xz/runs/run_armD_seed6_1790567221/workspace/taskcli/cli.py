import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import TaskStorage, Task

def get_config():
    config = {}
    try:
        import tomllib
        config_file = "config.toml"
        if os.path.exists(config_file):
            with open(config_file, "rb") as f:
                config = tomllib.load(f)
    except ImportError:
        # Fallback for Python < 3.11
        try:
            import toml
            config_file = "config.toml"
            if os.path.exists(config_file):
                with open(config_file, "r", encoding="utf-8") as f:
                    config = toml.load(f)
        except ImportError:
            pass
    return config

def get_today():
    config = get_config()
    today_str = config.get("today")
    if today_str:
        return datetime.strptime(today_str, "%Y-%m-%d").date()
    env_today = os.environ.get("TASKCLI_TODAY")
    if env_today:
        return datetime.strptime(env_today, "%Y-%m-%d").date()
    return datetime.now().date()

def print_task(task, today, use_color=False):
    status = "✓" if task.done else "○"
    priority_symbol = {"high": "!", "med": ":", "low": "."}.get(task.priority, ".")
    due_str = f" {task.due}" if task.due else ""
    title = task.title
    if use_color:
        if task.due and task.due < today:
            title = f"\033[31m{title}\033[0m"
        elif task.done:
            title = f"\033[32m{title}\033[0m"
    print(f"{task.id} {status} {priority_symbol} {title}{due_str}")

def list_tasks(args):
    today = get_today()
    storage = TaskStorage()
    
    # Use the shared method with appropriate filters
    tasks = storage.list_tasks(
        all_tasks=args.all,
        overdue_only=args.overdue,
        tag_filter=args.tag,
        sort_order=args.sort
    )
    
    use_color = args.color and sys.stdout.isatty()
    for task in tasks:
        print_task(task, today, use_color)

def add_task(args):
    today = get_today()
    config = get_config()
    default_priority = config.get("default_priority", "med")
    
    priority = args.priority or default_priority
    if priority not in ["high", "med", "low"]:
        sys.stderr.write(f"error: invalid priority '{priority}' (must be 'high', 'med', or 'low')\n")
        sys.exit(2)
        
    due_date = None
    if args.due:
        try:
            due_date = datetime.strptime(args.due, "%Y-%m-%d").date()
        except ValueError:
            sys.stderr.write(f"error: invalid date '{args.due}' (expected YYYY-MM-DD)\n")
            sys.exit(2)
    
    storage = TaskStorage()
    task = Task(
        title=args.title,
        priority=priority,
        due=due_date,
        tags=args.tag or [],
        done=False,
        archived=False
    )
    new_id = storage.add_task(task)
    print(new_id)

def done_task(args):
    storage = TaskStorage()
    try:
        storage.mark_done(args.id)
    except ValueError as e:
        sys.stderr.write(f"error: {str(e)}\n")
        sys.exit(2)

def delete_task(args):
    storage = TaskStorage()
    try:
        storage.delete_task(args.id)
    except ValueError as e:
        sys.stderr.write(f"error: {str(e)}\n")
        sys.exit(2)

def archive_tasks(args):
    storage = TaskStorage()
    storage.archive_done()

def stats(args):
    today = get_today()
    storage = TaskStorage()
    
    # Get all tasks including archived ones for stats
    all_tasks = storage.list_tasks(all_tasks=True)
    
    # Count all tasks (including archived ones) for total
    total = len(all_tasks)
    done = sum(1 for t in all_tasks if t.done)
    # Only non-archived tasks count as open
    open_count = sum(1 for t in all_tasks if not t.done and not t.archived)
    priority_counts = {"high": 0, "med": 0, "low": 0}
    overdue_count = 0
    
    for task in all_tasks:
        if task.priority in priority_counts:
            priority_counts[task.priority] += 1
        if task.due and task.due < today and not task.done:
            overdue_count += 1
    
    print(f"Total: {total}")
    print(f"Done: {done}")
    print(f"Open: {open_count}")
    for prio, count in priority_counts.items():
        print(f"Priority {prio}: {count}")
    if overdue_count > 0:
        print(f"\033[31mOverdue: {overdue_count}\033[0m")
    else:
        print(f"Overdue: {overdue_count}")

def backup(args):
    storage = TaskStorage()
    try:
        storage.backup(args.path)
    except Exception as e:
        sys.stderr.write(f"error: failed to write backup: {str(e)}\n")
        sys.exit(1)

def export(args):
    storage = TaskStorage()
    if args.format == "csv":
        storage.export_csv(args.path)
    else:
        storage.export_json(args.path)

def compact(args):
    storage = TaskStorage()
    storage.compact()

def search(args):
    today = get_today()
    storage = TaskStorage()
    
    # Get all tasks for search
    all_tasks = storage.list_tasks(all_tasks=True)
    
    # Filter tasks by title containing the search text (case-insensitive)
    search_text = args.text.lower()
    matching_tasks = [t for t in all_tasks if search_text in t.title.lower()]
    
    use_color = args.color and sys.stdout.isatty()
    for task in matching_tasks:
        print_task(task, today, use_color)

def main():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--priority", choices=["high", "med", "low"], help="Task priority")
    add_parser.add_argument("--due", help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--tag", action="append", help="Add a tag (repeatable)")

    # List command
    list_parser = subparsers.add_parser("list", help="List tasks")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks")
    list_parser.add_argument("--sort", choices=["priority", "review"], help="Sort order")
    list_parser.add_argument("--tag", help="Filter by tag")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")
    list_parser.add_argument("--color", action="store_true", help="Enable color output")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")

    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show statistics")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup database")
    backup_parser.add_argument("path", help="Backup file path")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export file path")
    export_parser.add_argument("--format", choices=["json", "csv"], default="json", help="Export format")

    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Reclaim dead space")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Text to search for in task titles")
    search_parser.add_argument("--color", action="store_true", help="Enable color output")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 0

    # Emit audit line - this is required by T24
    # But we need to be careful about when to emit it for success vs error cases
    # For now, always emit it for every command execution
    sys.stderr.write(f"AUDIT {args.command}\n")

    try:
        if args.command == "add":
            add_task(args)
        elif args.command == "list":
            list_tasks(args)
        elif args.command == "done":
            done_task(args)
        elif args.command == "delete":
            delete_task(args)
        elif args.command == "archive":
            archive_tasks(args)
        elif args.command == "stats":
            stats(args)
        elif args.command == "backup":
            backup(args)
        elif args.command == "export":
            export(args)
        elif args.command == "compact":
            compact(args)
        elif args.command == "search":
            search(args)
    except Exception as e:
        sys.stderr.write(f"error: {str(e)}\n")
        return 1

    return 0

import os
import json
import sqlite3
import shutil
import csv
from datetime import datetime, date
from typing import List, Optional

class Task:
    def __init__(self, title: str, priority: str, due: Optional[date], tags: List[str], done: bool, archived: bool, id: Optional[int] = None):
        self.id = id
        self.title = title
        self.priority = priority
        self.due = due
        self.tags = tags or []
        self.done = done
        self.archived = archived

    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "priority": self.priority,
            "due": self.due.isoformat() if self.due else None,
            "tags": self.tags,
            "done": self.done,
            "archived": self.archived
        }

    @classmethod
    def from_dict(cls, data):
        due = datetime.strptime(data["due"], "%Y-%m-%d").date() if data["due"] else None
        return cls(
            id=data["id"],
            title=data["title"],
            priority=data["priority"],
            due=due,
            tags=data.get("tags", []),
            done=data["done"],
            archived=data.get("archived", False)
        )

class TaskStorage:
    def __init__(self, db_path="tasks.db"):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table with kind column
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    priority TEXT,
                    due DATE,
                    tags TEXT,
                    done BOOLEAN,
                    archived BOOLEAN
                )
            """)
            
            conn.commit()
        finally:
            conn.close()

    def get_next_id(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT MAX(id) FROM items WHERE kind='task'")
            max_id = cursor.fetchone()[0]
            return (max_id or 0) + 1
        finally:
            conn.close()

    def add_task(self, task: Task):
        new_id = self.get_next_id()
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO items (id, kind, title, priority, due, tags, done, archived)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                new_id,
                "task",
                task.title,
                task.priority,
                task.due.isoformat() if task.due else None,
                json.dumps(task.tags),
                task.done,
                task.archived
            ))
            conn.commit()
            return new_id
        finally:
            conn.close()

    def _get_tasks(self, all_tasks=False, overdue_only=False, tag_filter=None, sort_order=None):
        """
        Shared method to get tasks with filtering and sorting.
        Returns list of Task objects.
        """
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Base query
            query = "SELECT id, title, priority, due, tags, done, archived FROM items WHERE kind='task'"
            params = []
            
            # Apply filters
            if not all_tasks:
                # Filter out archived tasks for default view
                query += " AND archived=0"
                
            if overdue_only:
                query += " AND due < ? AND done=0"
                params.append(str(datetime.now().date()))
                
            if tag_filter:
                query += " AND tags LIKE ?"
                params.append(f'%"{tag_filter}"%')
            
            # Add ORDER BY clause
            if sort_order == "priority":
                query += " ORDER BY CASE priority WHEN 'high' THEN 0 WHEN 'med' THEN 1 ELSE 2 END, id"
            elif sort_order == "review":
                # Overdue first, then by priority high to low
                query += " ORDER BY CASE WHEN due < ? AND done=0 THEN 0 ELSE 1 END, CASE priority WHEN 'high' THEN 0 WHEN 'med' THEN 1 ELSE 2 END, id"
                params.append(str(datetime.now().date()))
            else:
                # Default insertion order
                query += " ORDER BY id"
            
            cursor.execute(query, params)
            tasks = []
            for row in cursor.fetchall():
                task = Task(
                    id=row[0],
                    title=row[1],
                    priority=row[2],
                    due=datetime.strptime(row[3], "%Y-%m-%d").date() if row[3] else None,
                    tags=json.loads(row[4]) if row[4] else [],
                    done=bool(row[5]),
                    archived=bool(row[6])
                )
                tasks.append(task)
            return tasks
        finally:
            conn.close()

    def list_tasks(self, all_tasks=False, overdue_only=False, tag_filter=None, sort_order=None):
        """Public method to get tasks for listing."""
        return self._get_tasks(all_tasks=all_tasks, overdue_only=overdue_only, tag_filter=tag_filter, sort_order=sort_order)

    def mark_done(self, task_id: int):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"no task with id {task_id}")
            cursor.execute("UPDATE items SET done=1 WHERE id=?", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def delete_task(self, task_id: int):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"no task with id {task_id}")
            cursor.execute("DELETE FROM items WHERE id=?", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def archive_done(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived=1 WHERE kind='task' AND done=1")
            conn.commit()
        finally:
            conn.close()

    def backup(self, path):
        # Ensure the directory exists
        dir_name = os.path.dirname(path)
        if dir_name:
            try:
                os.makedirs(dir_name, exist_ok=True)
            except Exception:
                raise Exception(f"failed to create directory for backup: {dir_name}")
        
        tmp_path = path + ".tmp"
        try:
            shutil.copy2(self.db_path, tmp_path)
            os.replace(tmp_path, path)
        except Exception:
            # Clean up temp file on failure
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise

    def export_json(self, path):
        tasks = self.list_tasks(all_tasks=True)  # Export all tasks including archived
        data = [task.to_dict() for task in tasks]
        tmp_path = path + ".tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp_path, path)

    def export_csv(self, path):
        tasks = self.list_tasks(all_tasks=True)  # Export all tasks including archived
        tmp_path = path + ".tmp"
        with open(tmp_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["id", "title", "priority", "due", "tags", "done", "archived"])
            for task in tasks:
                due_str = task.due.isoformat() if task.due else ""
                tags_str = json.dumps(task.tags) if task.tags else ""
                writer.writerow([
                    task.id,
                    task.title,
                    task.priority,
                    due_str,
                    tags_str,
                    int(task.done),
                    int(task.archived)
                ])
        os.replace(tmp_path, path)

    def compact(self):
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()

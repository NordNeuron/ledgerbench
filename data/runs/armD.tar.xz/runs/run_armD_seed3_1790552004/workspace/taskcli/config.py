import os
import toml

def load_config():
    config = {}
    
    # Check for config.toml in current directory
    config_path = 'config.toml'
    if os.path.exists(config_path):
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = toml.load(f)
        except Exception:
            pass  # If we can't load it, proceed with empty config
    
    return config

import json
import os
import shutil
from datetime import datetime

class TaskStorage:
    def __init__(self, filename='tasks.json'):
        self.filename = filename
        self._ensure_file_exists()

    def _ensure_file_exists(self):
        if not os.path.exists(self.filename):
            with open(self.filename, 'w', encoding='utf-8') as f:
                json.dump([], f)

    def load(self):
        try:
            with open(self.filename, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return []

    def save(self, tasks):
        # Write to temporary file first
        tmp_file = self.filename + '.tmp'
        try:
            with open(tmp_file, 'w', encoding='utf-8') as f:
                json.dump(tasks, f, indent=2)
            # Atomic rename
            shutil.move(tmp_file, self.filename)
        except Exception:
            # If anything goes wrong, clean up the temp file
            try:
                os.remove(tmp_file)
            except OSError:
                pass
            raise

    def add(self, task):
        tasks = self.load()
        
        # Assign ID - find the maximum existing ID and increment
        if not tasks:
            new_id = 1
        else:
            new_id = max(t['id'] for t in tasks) + 1
        
        task['id'] = new_id
        tasks.append(task)
        self.save(tasks)
        return new_id

    def mark_done(self, task_id):
        tasks = self.load()
        found = False
        for task in tasks:
            if task['id'] == task_id:
                task['done'] = True
                found = True
                break
        if not found:
            raise ValueError(f"Task with id {task_id} not found")
        self.save(tasks)

    def delete(self, task_id):
        tasks = self.load()
        found = False
        for i, task in enumerate(tasks):
            if task['id'] == task_id:
                del tasks[i]
                found = True
                break
        if not found:
            raise ValueError(f"Task with id {task_id} not found")
        self.save(tasks)

    def archive_done(self):
        tasks = self.load()
        for task in tasks:
            if task.get('done') and not task.get('archived'):
                task['archived'] = True
        self.save(tasks)

    def backup(self, path):
        tasks = self.load()
        # Write to temporary file first
        tmp_file = path + '.tmp'
        try:
            with open(tmp_file, 'w', encoding='utf-8') as f:
                json.dump(tasks, f, indent=2)
            # Atomic rename
            shutil.move(tmp_file, path)
        except Exception:
            # If anything goes wrong, clean up the temp file
            try:
                os.remove(tmp_file)
            except OSError:
                pass
            raise

    def export_json(self, path):
        tasks = self.load()
        # Write to temporary file first
        tmp_file = path + '.tmp'
        try:
            with open(tmp_file, 'w', encoding='utf-8') as f:
                json.dump(tasks, f, indent=2)
            # Atomic rename
            shutil.move(tmp_file, path)
        except Exception:
            # If anything goes wrong, clean up the temp file
            try:
                os.remove(tmp_file)
            except OSError:
                pass
            raise

    def export_csv(self, path):
        tasks = self.load()
        # Write to temporary file first
        tmp_file = path + '.tmp'
        try:
            with open(tmp_file, 'w', encoding='utf-8', newline='') as f:
                import csv
                writer = csv.writer(f)
                # Header row
                writer.writerow(['id', 'title', 'priority', 'due', 'done', 'tags', 'archived'])
                for task in tasks:
                    writer.writerow([
                        task.get('id', ''),
                        task.get('title', ''),
                        task.get('priority', ''),
                        task.get('due', ''),
                        task.get('done', False),
                        ','.join(task.get('tags', [])),
                        task.get('archived', False)
                    ])
            # Atomic rename
            shutil.move(tmp_file, path)
        except Exception:
            # If anything goes wrong, clean up the temp file
            try:
                os.remove(tmp_file)
            except OSError:
                pass
            raise

    def compact(self):
        tasks = self.load()
        # In a real implementation this would reclaim space from deleted entries
        # For now, just save as-is to maintain the atomic write behavior
        self.save(tasks)

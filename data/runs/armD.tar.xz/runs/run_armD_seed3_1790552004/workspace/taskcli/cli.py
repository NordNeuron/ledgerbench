import argparse
import os
import sys
import json
import re
from datetime import datetime
from .storage import TaskStorage
from .config import load_config

def get_today():
    config = load_config()
    if config.get('today'):
        return config['today']
    elif os.environ.get('TASKCLI_TODAY'):
        return os.environ['TASKCLI_TODAY']
    else:
        return datetime.now().strftime('%Y-%m-%d')

def is_overdue(task, today_str):
    if task.get('done') or not task.get('due'):
        return False
    try:
        due_date = datetime.strptime(task['due'], '%Y-%m-%d')
        today = datetime.strptime(today_str, '%Y-%m-%d')
        return due_date < today
    except ValueError:
        return False

def format_task(task, today_str, show_color=False):
    if task.get('done'):
        status = '✓'
    else:
        status = '○'
    
    # Only add ANSI codes when stdout is a TTY and --color is specified
    if show_color and hasattr(sys.stdout, 'isatty') and sys.stdout.isatty():
        if is_overdue(task, today_str):
            status = f'\033[31m{status}\033[0m'  # red for overdue
        elif task.get('done'):
            status = f'\033[32m{status}\033[0m'  # green for done
    
    priority_symbol = {
        'high': 'H',
        'med': 'M',
        'low': 'L'
    }.get(task.get('priority'), '?')
    
    title = task['title']
    due_str = f" (due {task.get('due', 'none')})" if task.get('due') else ""
    tags_str = f" [{' '.join(task.get('tags', []))}]" if task.get('tags') else ""
    
    return f"{task['id']}  {status}  [{priority_symbol}] {title}{due_str}{tags_str}"

def print_tasks(tasks, today_str, show_color=False, show_all=False):
    for task in tasks:
        if not show_all and task.get('archived'):
            continue
        print(format_task(task, today_str, show_color))

def list_tasks(args):
    storage = TaskStorage()
    tasks = storage.load()
    today_str = get_today()
    
    # Filter out archived tasks unless --all is specified
    if not args.all:
        tasks = [t for t in tasks if not t.get('archived')]
    
    # Apply filtering by tag if specified
    if args.tag:
        tasks = [t for t in tasks if args.tag in t.get('tags', [])]
    
    # Apply overdue filter if --overdue is specified
    if args.overdue:
        tasks = [t for t in tasks if is_overdue(t, today_str)]
    
    # Apply sorting
    if args.sort == 'priority':
        # Sort by priority: high, med, low (in that order)
        priority_order = {'high': 0, 'med': 1, 'low': 2}
        tasks.sort(key=lambda x: (priority_order.get(x.get('priority'), 3), x['id']))
    elif args.sort == 'overdue':
        # Overdue first, then by priority high to low
        def sort_key(task):
            overdue = is_overdue(task, today_str)
            priority_order = {'high': 0, 'med': 1, 'low': 2}
            return (not overdue, priority_order.get(task.get('priority'), 3), task['id'])
        tasks.sort(key=sort_key)
    else:
        # Default insertion order - no sorting needed
        pass
    
    print_tasks(tasks, today_str, args.color, args.all)

def add_task(args):
    storage = TaskStorage()
    today_str = get_today()
    
    # Validate due date if provided
    if args.due:
        try:
            datetime.strptime(args.due, '%Y-%m-%d')
        except ValueError:
            print(f"Error: Invalid date '{args.due}'. Expected format: YYYY-MM-DD", file=sys.stderr)
            sys.exit(2)
    
    # Get default priority from config
    config = load_config()
    if not args.priority:
        args.priority = config.get('default_priority', 'med')
    
    task = {
        'title': args.title,
        'priority': args.priority,
        'due': args.due,
        'done': False,
        'tags': getattr(args, 'tag', []),
        'archived': False
    }
    
    new_id = storage.add(task)
    print(new_id)

def done_task(args):
    storage = TaskStorage()
    try:
        storage.mark_done(args.id)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        sys.exit(2)

def delete_task(args):
    storage = TaskStorage()
    try:
        storage.delete(args.id)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        sys.exit(2)

def archive_tasks(args):
    storage = TaskStorage()
    storage.archive_done()

def backup(args):
    storage = TaskStorage()
    try:
        storage.backup(args.path)
    except IOError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

def export(args):
    storage = TaskStorage()
    try:
        if args.format == 'csv':
            # For CSV export, we want all tasks including archived ones
            tasks = storage.load()
            # Write to temporary file first
            tmp_file = args.path + '.tmp'
            try:
                with open(tmp_file, 'w', encoding='utf-8', newline='') as f:
                    import csv
                    writer = csv.writer(f)
                    # Header row
                    writer.writerow(['id', 'title', 'priority', 'due', 'done', 'tags', 'archived'])
                    for task in tasks:
                        writer.writerow([
                            task.get('id', ''),
                            task.get('title', ''),
                            task.get('priority', ''),
                            task.get('due', ''),
                            task.get('done', False),
                            ','.join(task.get('tags', [])),
                            task.get('archived', False)
                        ])
                # Atomic rename
                import shutil
                shutil.move(tmp_file, args.path)
            except Exception:
                # If anything goes wrong, clean up the temp file
                try:
                    os.remove(tmp_file)
                except OSError:
                    pass
                raise
        else:
            # For JSON export, use the same filtering logic as list but include archived tasks by default
            # (since export should show all tasks)
            tasks = storage.load()
            today_str = get_today()
            
            # Apply filtering by tag if specified
            if args.tag:
                tasks = [t for t in tasks if args.tag in t.get('tags', [])]
            
            # Apply overdue filter if --overdue is specified
            if args.overdue:
                tasks = [t for t in tasks if is_overdue(t, today_str)]
            
            # Apply sorting
            if args.sort == 'priority':
                # Sort by priority: high, med, low (in that order)
                priority_order = {'high': 0, 'med': 1, 'low': 2}
                tasks.sort(key=lambda x: (priority_order.get(x.get('priority'), 3), x['id']))
            elif args.sort == 'overdue':
                # Overdue first, then by priority high to low
                def sort_key(task):
                    overdue = is_overdue(task, today_str)
                    priority_order = {'high': 0, 'med': 1, 'low': 2}
                    return (not overdue, priority_order.get(task.get('priority'), 3), task['id'])
                tasks.sort(key=sort_key)
            
            # Write to temporary file first
            tmp_file = args.path + '.tmp'
            try:
                with open(tmp_file, 'w', encoding='utf-8') as f:
                    json.dump(tasks, f, indent=2)
                # Atomic rename
                import shutil
                shutil.move(tmp_file, args.path)
            except Exception:
                # If anything goes wrong, clean up the temp file
                try:
                    os.remove(tmp_file)
                except OSError:
                    pass
                raise
    except IOError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

def stats(args):
    storage = TaskStorage()
    tasks = storage.load()
    today_str = get_today()
    
    total = len(tasks)
    done = sum(1 for t in tasks if t.get('done'))
    open_tasks = total - done
    overdue = sum(1 for t in tasks if is_overdue(t, today_str) and not t.get('done'))
    
    priority_counts = {'high': 0, 'med': 0, 'low': 0}
    for task in tasks:
        if not task.get('archived'):
            priority = task.get('priority', 'med')
            if priority in priority_counts:
                priority_counts[priority] += 1
    
    print(f"Total: {total}")
    print(f"Done: {done}")
    print(f"Open: {open_tasks}")
    print(f"Overdue: {overdue}")
    
    for priority, count in priority_counts.items():
        print(f"Priority {priority}: {count}")

def compact(args):
    storage = TaskStorage()
    storage.compact()

def search(args):
    storage = TaskStorage()
    tasks = storage.load()
    today_str = get_today()
    
    # Filter tasks that match the search text (case-insensitive)
    matching_tasks = []
    for task in tasks:
        if args.text.lower() in task['title'].lower():
            matching_tasks.append(task)
    
    print_tasks(matching_tasks, today_str, False, True)

def create_parser():
    parser = argparse.ArgumentParser(description='Minimal command-line task manager')
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--priority', choices=['high', 'med', 'low'], 
                           help='Task priority')
    add_parser.add_argument('--tag', action='append', help='Add a tag (repeatable)')

    # List command
    list_parser = subparsers.add_parser('list', help='List all tasks')
    list_parser.add_argument('--sort', choices=['priority', 'overdue'], 
                            help='Sort order')
    list_parser.add_argument('--all', action='store_true', help='Show archived tasks')
    list_parser.add_argument('--color', action='store_true', help='Show colors')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup database')
    backup_parser.add_argument('path', help='Backup file path')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json',
                              help='Export format (default: json)')
    export_parser.add_argument('--sort', choices=['priority', 'overdue'], 
                              help='Sort order for export')
    export_parser.add_argument('--all', action='store_true', help='Include archived tasks')
    export_parser.add_argument('--tag', help='Filter by tag')
    export_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')

    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')

    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Reclaim dead space')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for in task titles')

    return parser

def main():
    parser = create_parser()
    args = parser.parse_args()
    
    # Emit audit line to stderr
    command_name = args.command if args.command else 'list'
    print(f"AUDIT {command_name}", file=sys.stderr)
    
    if not args.command:
        # Default behavior: list all tasks
        args.all = False
        args.sort = None
        args.color = False
        args.tag = None
        args.overdue = False
        list_tasks(args)
        return 0
    
    try:
        if args.command == 'list':
            list_tasks(args)
        elif args.command == 'add':
            add_task(args)
        elif args.command == 'done':
            done_task(args)
        elif args.command == 'delete':
            delete_task(args)
        elif args.command == 'archive':
            archive_tasks(args)
        elif args.command == 'backup':
            backup(args)
        elif args.command == 'export':
            export(args)
        elif args.command == 'stats':
            stats(args)
        elif args.command == 'compact':
            compact(args)
        elif args.command == 'search':
            search(args)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    
    return 0

import os
import json
import sqlite3
import shutil
import csv
from datetime import datetime
from typing import List, Dict, Any
import tempfile


class Task:
    def __init__(self, id: int, title: str, done: bool = False, priority: str = "med", due: str = None, tags: List[str] = None, archived: bool = False):
        self.id = id
        self.title = title
        self.done = done
        self.priority = priority
        self.due = due
        self.tags = tags or []
        self.archived = archived


class TaskStorage:
    def __init__(self, db_path="tasks.db"):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table with kind column
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    priority TEXT DEFAULT 'med',
                    due TEXT,
                    archived BOOLEAN DEFAULT FALSE,
                    kind TEXT NOT NULL
                )
            """)
            
            # Create tags table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS tags (
                    id INTEGER PRIMARY KEY,
                    name TEXT UNIQUE NOT NULL
                )
            """)
            
            # Create task_tags junction table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS task_tags (
                    task_id INTEGER,
                    tag_id INTEGER,
                    FOREIGN KEY (task_id) REFERENCES items (id),
                    FOREIGN KEY (tag_id) REFERENCES tags (id)
                )
            """)
            
            conn.commit()
        finally:
            conn.close()

    def add_task(self, title: str, priority: str = "med", due: str = None, tags: List[str] = None) -> int:
        if due:
            try:
                datetime.strptime(due, "%Y-%m-%d")
            except ValueError:
                raise ValueError(f"Invalid date format '{due}'. Expected YYYY-MM-DD.")

        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Get the next available ID
            cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items")
            task_id = cursor.fetchone()[0]
            
            # Insert task
            cursor.execute("""
                INSERT INTO items (id, title, priority, due, kind)
                VALUES (?, ?, ?, ?, 'task')
            """, (task_id, title, priority, due))
            
            # Handle tags
            if tags:
                for tag_name in tags:
                    # Insert or get tag ID
                    cursor.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (tag_name,))
                    cursor.execute("SELECT id FROM tags WHERE name = ?", (tag_name,))
                    tag_id = cursor.fetchone()[0]
                    
                    # Link task and tag
                    cursor.execute("INSERT INTO task_tags (task_id, tag_id) VALUES (?, ?)", (task_id, tag_id))
            
            conn.commit()
            return task_id
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()

    def list_tasks(self, all_tasks: bool = False, sort_by: str = None, tag_filter: str = None) -> List[Task]:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Build base query
            query = """
                SELECT i.id, i.title, i.done, i.priority, i.due, i.archived
                FROM items i
                WHERE i.kind = 'task'
            """
            
            params = []
            
            if not all_tasks:
                query += " AND i.archived = 0"
            
            # Apply tag filter
            if tag_filter:
                query += """
                    AND i.id IN (
                        SELECT DISTINCT tt.task_id 
                        FROM task_tags tt 
                        JOIN tags t ON tt.tag_id = t.id 
                        WHERE t.name = ?
                    )
                """
                params.append(tag_filter)
            
            # Apply sorting
            if sort_by == "priority":
                query += """
                    ORDER BY 
                        CASE i.priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 ELSE 3 END,
                        i.id
                """
            else:
                query += " ORDER BY i.id"
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task_id, title, done, priority, due, archived = row
                
                # Get tags for this task
                cursor.execute("""
                    SELECT t.name 
                    FROM tags t 
                    JOIN task_tags tt ON t.id = tt.tag_id 
                    WHERE tt.task_id = ?
                """, (task_id,))
                tags = [tag[0] for tag in cursor.fetchall()]
                
                tasks.append(Task(task_id, title, done, priority, due, tags, archived))
            
            return tasks
        finally:
            conn.close()

    def mark_done(self, task_id: int):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"No task found with ID {task_id}")
            
            cursor.execute("UPDATE items SET done = 1 WHERE id = ?", (task_id,))
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()

    def delete_task(self, task_id: int):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"No task found with ID {task_id}")
            
            cursor.execute("DELETE FROM items WHERE id = ?", (task_id,))
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()

    def archive_done(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived = 1 WHERE done = 1 AND kind = 'task'")
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()

    def get_stats(self) -> Dict[str, Any]:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task'")
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE done = 1 AND kind = 'task'")
            done = cursor.fetchone()[0]
            
            # Open tasks (total - done)
            open_tasks = total - done
            
            # Overdue tasks (not done and due date is in the past)
            cursor.execute("""
                SELECT COUNT(*) 
                FROM items 
                WHERE done = 0 AND due IS NOT NULL AND kind = 'task' 
                AND due < date('now')
            """)
            overdue = cursor.fetchone()[0]
            
            # Priority counts
            cursor.execute("""
                SELECT priority, COUNT(*) 
                FROM items 
                WHERE kind = 'task'
                GROUP BY priority
            """)
            priority_counts = dict(cursor.fetchall())
            
            return {
                "total": total,
                "done": done,
                "open": open_tasks,
                "overdue": overdue,
                "priority_high": priority_counts.get("high", 0),
                "priority_med": priority_counts.get("med", 0),
                "priority_low": priority_counts.get("low", 0)
            }
        finally:
            conn.close()

    def backup(self, path: str):
        # Atomic write: create temp file then rename
        tmp_path = path + ".tmp"
        try:
            shutil.copy2(self.db_path, tmp_path)
            os.rename(tmp_path, path)
        except Exception:
            # Clean up on failure
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise

    def export_to_csv(self, tasks: List[Task], path: str):
        with open(path, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['id', 'title', 'done', 'priority', 'due', 'tags']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            
            writer.writeheader()
            for task in tasks:
                # Convert tags to a comma-separated string
                tags_str = ','.join(task.tags) if task.tags else ''
                writer.writerow({
                    'id': task.id,
                    'title': task.title,
                    'done': task.done,
                    'priority': task.priority,
                    'due': task.due,
                    'tags': tags_str
                })

    def export_to_json(self, tasks: List[Task], path: str):
        data = []
        for task in tasks:
            task_dict = {
                'id': task.id,
                'title': task.title,
                'done': task.done,
                'priority': task.priority,
                'due': task.due,
                'tags': task.tags
            }
            data.append(task_dict)
        
        # Atomic write for JSON export
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
            os.rename(tmp_path, path)
        except Exception:
            # Clean up on failure
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise

    def compact(self):
        conn = sqlite3.connect(self.db_path)
        try:
            # VACUUM to reclaim space
            conn.execute("VACUUM")
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()

    def search_tasks(self, text: str) -> List[Task]:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Search in titles (case-insensitive)
            query = """
                SELECT i.id, i.title, i.done, i.priority, i.due, i.archived
                FROM items i
                WHERE i.kind = 'task' AND LOWER(i.title) LIKE ?
                ORDER BY i.id
            """
            
            cursor.execute(query, (f"%{text.lower()}%",))
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task_id, title, done, priority, due, archived = row
                
                # Get tags for this task
                cursor.execute("""
                    SELECT t.name 
                    FROM tags t 
                    JOIN task_tags tt ON t.id = tt.tag_id 
                    WHERE tt.task_id = ?
                """, (task_id,))
                tags = [tag[0] for tag in cursor.fetchall()]
                
                tasks.append(Task(task_id, title, done, priority, due, tags, archived))
            
            return tasks
        finally:
            conn.close()

import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import TaskStorage, Task


def get_config():
    config = {}
    try:
        with open("config.toml", "r", encoding="utf-8") as f:
            import toml
            config = toml.load(f)
    except (FileNotFoundError, OSError):
        pass
    
    # Handle deprecated TASKCLI_TODAY env var
    if "TASKCLI_TODAY" in os.environ and "today" not in config:
        config["today"] = os.environ["TASKCLI_TODAY"]
    
    return config


def format_task(task: Task, today=None, color=False):
    if today is None:
        config = get_config()
        today_str = config.get("today")
        if today_str:
            try:
                today = datetime.strptime(today_str, "%Y-%m-%d").date()
            except ValueError:
                # Invalid date format in config, use system date
                today = datetime.now().date()
        else:
            today = datetime.now().date()

    status_symbol = "✓" if task.done else "○"
    priority_symbol = {"high": "H", "med": "M", "low": "L"}[task.priority]
    
    due_str = ""
    if task.due:
        due_date = datetime.strptime(task.due, "%Y-%m-%d").date()
        due_str = f" (due {task.due})"
        if color and due_date < today and not task.done:
            due_str = f"\x1b[31m{due_str}\x1b[0m"
    
    title = task.title
    if color and task.done:
        title = f"\x1b[32m{title}\x1b[0m"
    elif color and task.due and datetime.strptime(task.due, "%Y-%m-%d").date() < today and not task.done:
        title = f"\x1b[31m{title}\x1b[0m"

    return f"{task.id} {status_symbol} [{priority_symbol}] {title}{due_str}"


def print_task(task: Task, today=None, color=False):
    print(format_task(task, today, color))


def list_tasks(args):
    # Audit trail
    sys.stderr.write(f"AUDIT list\n")
    
    storage = TaskStorage()
    today = None
    config = get_config()
    today_str = config.get("today")
    if today_str:
        try:
            today = datetime.strptime(today_str, "%Y-%m-%d").date()
        except ValueError:
            # Invalid date format in config, use system date
            today = datetime.now().date()

    tasks = storage.list_tasks(args.all, args.sort, args.tag)
    
    if not args.color or not sys.stdout.isatty():
        color = False
    else:
        color = True

    for task in tasks:
        print_task(task, today, color)


def add_task(args):
    # Audit trail
    sys.stderr.write(f"AUDIT add\n")
    
    storage = TaskStorage()
    try:
        task_id = storage.add_task(
            title=args.title,
            priority=args.priority or get_config().get("default_priority", "med"),
            due=args.due,
            tags=args.tag or []
        )
        print(task_id)
    except ValueError as e:
        sys.stderr.write(f"Error: {e}\n")
        sys.exit(2)
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        sys.exit(1)


def done_task(args):
    # Audit trail
    sys.stderr.write(f"AUDIT done\n")
    
    storage = TaskStorage()
    try:
        storage.mark_done(args.id)
    except ValueError as e:
        sys.stderr.write(f"Error: {e}\n")
        sys.exit(2)
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        sys.exit(1)


def delete_task(args):
    # Audit trail
    sys.stderr.write(f"AUDIT delete\n")
    
    storage = TaskStorage()
    try:
        storage.delete_task(args.id)
    except ValueError as e:
        sys.stderr.write(f"Error: {e}\n")
        sys.exit(2)
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        sys.exit(1)


def archive_tasks(args):
    # Audit trail
    sys.stderr.write(f"AUDIT archive\n")
    
    storage = TaskStorage()
    try:
        storage.archive_done()
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        sys.exit(1)


def stats(args):
    # Audit trail
    sys.stderr.write(f"AUDIT stats\n")
    
    storage = TaskStorage()
    try:
        stats_data = storage.get_stats()
        print(f"Total: {stats_data['total']}")
        print(f"Done: {stats_data['done']}")
        print(f"Open: {stats_data['open']}")
        print(f"Overdue: {stats_data['overdue']}")
        print(f"Priority high: {stats_data['priority_high']}")
        print(f"Priority med: {stats_data['priority_med']}")
        print(f"Priority low: {stats_data['priority_low']}")
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        sys.exit(1)


def backup(args):
    # Audit trail
    sys.stderr.write(f"AUDIT backup\n")
    
    storage = TaskStorage()
    try:
        storage.backup(args.path)
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        sys.exit(1)


def export(args):
    # Audit trail
    sys.stderr.write(f"AUDIT export\n")
    
    storage = TaskStorage()
    try:
        # Use the same query path for listing and exporting
        tasks = storage.list_tasks(all_tasks=True, sort_by=args.sort, tag_filter=args.tag)
        
        if args.format == "csv":
            storage.export_to_csv(tasks, args.path)
        else:  # JSON format
            storage.export_to_json(tasks, args.path)
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        sys.exit(1)


def compact(args):
    # Audit trail
    sys.stderr.write(f"AUDIT compact\n")
    
    storage = TaskStorage()
    try:
        storage.compact()
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        sys.exit(1)


def search(args):
    # Audit trail
    sys.stderr.write(f"AUDIT search\n")
    
    storage = TaskStorage()
    try:
        tasks = storage.search_tasks(args.text)
        today = None
        config = get_config()
        today_str = config.get("today")
        if today_str:
            try:
                today = datetime.strptime(today_str, "%Y-%m-%d").date()
            except ValueError:
                # Invalid date format in config, use system date
                today = datetime.now().date()

        # Check if we should enable color based on TTY and --color flag
        color = args.color and sys.stdout.isatty()

        for task in tasks:
            print_task(task, today, color)
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description="Minimal command-line task manager")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--priority", choices=["high", "med", "low"], help="Task priority")
    add_parser.add_argument("--due", help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--tag", action="append", help="Add a tag (repeatable)")

    # List command
    list_parser = subparsers.add_parser("list", help="List tasks")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks")
    list_parser.add_argument("--sort", choices=["priority"], help="Sort order")
    list_parser.add_argument("--tag", help="Filter by tag")
    list_parser.add_argument("--color", action="store_true", help="Enable colored output")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")

    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show statistics")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup database")
    backup_parser.add_argument("path", help="Backup file path")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export file path")
    export_parser.add_argument("--format", choices=["json", "csv"], default="json", help="Export format")
    export_parser.add_argument("--sort", choices=["priority"], help="Sort order")
    export_parser.add_argument("--tag", help="Filter by tag")

    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Reclaim dead space from deleted rows")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Text to search for in task titles")
    search_parser.add_argument("--color", action="store_true", help="Enable colored output")

    args = parser.parse_args()

    # Audit trail for main command
    if len(sys.argv) > 1:
        command = sys.argv[1]
        sys.stderr.write(f"AUDIT {command}\n")
    else:
        sys.stderr.write("AUDIT unknown\n")

    if args.command == "list":
        list_tasks(args)
    elif args.command == "add":
        add_task(args)
    elif args.command == "done":
        done_task(args)
    elif args.command == "delete":
        delete_task(args)
    elif args.command == "archive":
        archive_tasks(args)
    elif args.command == "stats":
        stats(args)
    elif args.command == "backup":
        backup(args)
    elif args.command == "export":
        export(args)
    elif args.command == "compact":
        compact(args)
    elif args.command == "search":
        search(args)
    else:
        parser.print_help()
        return 0

    return 0

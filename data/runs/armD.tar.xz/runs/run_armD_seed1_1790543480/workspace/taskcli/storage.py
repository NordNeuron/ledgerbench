import os
import json
import sqlite3
import shutil
import csv
from datetime import datetime, date
from typing import List, Dict, Any, Optional
import re
import sys

class TaskStorage:
    def __init__(self, db_path: str = "tasks.db"):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table if it doesn't exist
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE,
                    due DATE,
                    priority TEXT,
                    tags TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Create indexes for better performance
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_kind ON items(kind)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_done ON items(done)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_archived ON items(archived)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_priority ON items(priority)')
            
            conn.commit()
        finally:
            conn.close()

    def get_next_id(self) -> int:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items WHERE kind = 'task'")
            next_id = cursor.fetchone()[0]
            return next_id
        finally:
            conn.close()

    def add_task(self, title: str, due: Optional[str] = None, priority: Optional[str] = None, tags: List[str] = None) -> int:
        if due is not None:
            try:
                datetime.strptime(due, '%Y-%m-%d')
            except ValueError:
                raise ValueError(f"Invalid date format for due date '{due}'. Expected YYYY-MM-DD.")

        task_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO items (id, kind, title, due, priority, tags)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (task_id, 'task', title, due, priority, json.dumps(tags) if tags else '[]'))
            conn.commit()
        finally:
            conn.close()
        
        return task_id

    def _get_tasks_query(self, show_all: bool = False, overdue_only: bool = False, tag_filter: str = None, sort_order: str = 'insertion') -> tuple:
        """Get the base query and parameters for tasks."""
        # Base query
        query = "SELECT * FROM items WHERE kind = 'task'"
        params = []
        
        if not show_all:
            query += " AND archived = 0"
            
        if overdue_only:
            query += " AND done = 0 AND due < ?"
            params.append(str(date.today()))
            
        if tag_filter:
            query += " AND tags LIKE ?"
            params.append(f'%"{tag_filter}"%')
        
        # Sorting
        if sort_order == 'priority':
            # High, Med, Low priority order
            query += " ORDER BY CASE WHEN priority = 'high' THEN 1 WHEN priority = 'med' THEN 2 ELSE 3 END, id"
        else:
            # Insertion order (default)
            query += " ORDER BY id"
        
        return query, params

    def list_tasks(self, sort_order: str = 'insertion', show_all: bool = False, overdue_only: bool = False, tag_filter: str = None) -> List[Dict[str, Any]]:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            query, params = self._get_tasks_query(show_all, overdue_only, tag_filter, sort_order)
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'kind': row[1],
                    'title': row[2],
                    'done': bool(row[3]),
                    'archived': bool(row[4]),
                    'due': row[5],
                    'priority': row[6],
                    'tags': json.loads(row[7]) if row[7] else [],
                    'created_at': row[8]
                }
                tasks.append(task)
                
            return tasks
        finally:
            conn.close()

    def mark_done(self, task_id: int) -> None:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found.")
                
            cursor.execute("UPDATE items SET done = 1 WHERE id = ?", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def delete_task(self, task_id: int) -> None:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found.")
                
            cursor.execute("DELETE FROM items WHERE id = ?", (task_id,))
            conn.commit()
        finally:
            conn.close()

    def archive_tasks(self) -> None:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived = 1 WHERE kind = 'task' AND done = 1")
            conn.commit()
        finally:
            conn.close()

    def search_tasks(self, text: str) -> List[Dict[str, Any]]:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            # Search in title (case-insensitive)
            cursor.execute("""
                SELECT * FROM items 
                WHERE kind = 'task' AND LOWER(title) LIKE ?
                ORDER BY id
            """, (f'%{text.lower()}%',))
            
            rows = cursor.fetchall()
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'kind': row[1],
                    'title': row[2],
                    'done': bool(row[3]),
                    'archived': bool(row[4]),
                    'due': row[5],
                    'priority': row[6],
                    'tags': json.loads(row[7]) if row[7] else [],
                    'created_at': row[8]
                }
                tasks.append(task)
                
            return tasks
        finally:
            conn.close()

    def print_stats(self, today: date) -> None:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task'")
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND done = 1")
            done = cursor.fetchone()[0]
            
            # Open tasks
            open_tasks = total - done
            
            # Priority counts
            cursor.execute("SELECT priority, COUNT(*) FROM items WHERE kind = 'task' GROUP BY priority")
            priority_counts = dict(cursor.fetchall())
            
            # Overdue tasks
            cursor.execute("""
                SELECT COUNT(*) FROM items 
                WHERE kind = 'task' AND done = 0 AND due < ?
            """, (str(today),))
            overdue = cursor.fetchone()[0]
            
            print(f"Total: {total}")
            print(f"Done: {done}")
            print(f"Open: {open_tasks}")
            print(f"Overdue: {overdue}")
            print(f"Priority high: {priority_counts.get('high', 0)}")
            print(f"Priority med: {priority_counts.get('med', 0)}")
            print(f"Priority low: {priority_counts.get('low', 0)}")
        finally:
            conn.close()

    def backup(self, path: str) -> None:
        tmp_path = f"{path}.tmp"
        try:
            shutil.copy2(self.db_path, tmp_path)
            os.replace(tmp_path, path)
        except Exception as e:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise e

    def export(self, path: str, format: str = 'json', show_all: bool = True, sort_order: str = 'insertion') -> None:
        """Export tasks using the unified query path."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Get the query and parameters
            query, params = self._get_tasks_query(show_all=show_all, sort_order=sort_order)
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'kind': row[1],
                    'title': row[2],
                    'done': bool(row[3]),
                    'archived': bool(row[4]),
                    'due': row[5],
                    'priority': row[6],
                    'tags': json.loads(row[7]) if row[7] else [],
                    'created_at': row[8]
                }
                tasks.append(task)
            
            if format == 'csv':
                with open(path, 'w', newline='', encoding='utf-8') as csvfile:
                    fieldnames = ['id', 'title', 'done', 'archived', 'due', 'priority', 'tags']
                    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                    
                    writer.writeheader()
                    for task in tasks:
                        # Convert tags to string for CSV
                        task['tags'] = ','.join(task['tags'])
                        writer.writerow(task)
            else:  # JSON format
                with open(path, 'w', encoding='utf-8') as jsonfile:
                    json.dump(tasks, jsonfile, indent=2, ensure_ascii=False)
        finally:
            conn.close()

    def compact(self) -> None:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            # VACUUM to reclaim space
            cursor.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()

    def format_task(self, task: Dict[str, Any], today: date, use_color: bool) -> str:
        # Determine if task is overdue
        is_overdue = False
        if task['due']:
            try:
                due_date = datetime.strptime(task['due'], '%Y-%m-%d').date()
                is_overdue = due_date < today and not task['done']
            except ValueError:
                pass  # Invalid date format, treat as not overdue

        # Format the line
        status_symbol = "✓" if task['done'] else "○"
        priority_symbol = ""
        if task['priority']:
            priority_symbol = f"[{task['priority'][0].upper()}]"

        due_str = f" {task['due']}" if task['due'] else ""
        tags_str = f" #{' #'.join(task['tags'])}" if task['tags'] else ""

        line = f"{task['id']} {status_symbol} {task['title']}{priority_symbol}{due_str}{tags_str}"

        # Apply colors if requested and stdout is a TTY
        if use_color and hasattr(sys.stdout, 'isatty') and sys.stdout.isatty():
            if is_overdue:
                line = f"\033[31m{line}\033[0m"  # Red for overdue
            elif task['done']:
                line = f"\033[32m{line}\033[0m"  # Green for done

        return line

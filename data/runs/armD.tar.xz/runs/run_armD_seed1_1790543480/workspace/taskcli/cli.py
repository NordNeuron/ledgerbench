import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import TaskStorage

def get_config():
    config = {}
    try:
        import toml
        config_path = "config.toml"
        if os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                config = toml.load(f)
    except ImportError:
        pass
    
    # Fallback to environment variable if no config file
    if not config.get('today'):
        today_env = os.environ.get('TASKCLI_TODAY')
        if today_env:
            config['today'] = today_env
    
    return config

def pin_today(today_str):
    """Set the 'today' value for this session."""
    # This is a placeholder; in practice, we'd use a global or context
    # For now, just return the string as-is
    return today_str

def main():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--priority', choices=['high', 'med', 'low'], default=None)
    add_parser.add_argument('--tag', action='append', help='Add a tag (repeatable)')

    # List command
    list_parser = subparsers.add_parser('list', help='List tasks')
    list_parser.add_argument('--sort', choices=['priority', 'insertion'], default='insertion')
    list_parser.add_argument('--all', action='store_true', help='Show archived tasks')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--color', action='store_true', help='Enable ANSI colors')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')

    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup database')
    backup_parser.add_argument('path', help='Backup file path')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json')

    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Reclaim dead space')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for')

    args = parser.parse_args()

    config = get_config()
    today_str = config.get('today', datetime.now().strftime('%Y-%m-%d'))
    today = datetime.strptime(today_str, '%Y-%m-%d').date()

    storage = TaskStorage()

    # Emit audit line
    sys.stderr.write(f"AUDIT {args.command}\n")
    
    try:
        if args.command == 'add':
            task_id = storage.add_task(
                title=args.title,
                due=args.due,
                priority=args.priority,
                tags=args.tag or []
            )
            print(task_id)
        elif args.command == 'list':
            tasks = storage.list_tasks(
                sort_order=args.sort,
                show_all=args.all,
                overdue_only=args.overdue,
                tag_filter=args.tag
            )
            for task in tasks:
                print(storage.format_task(task, today, args.color))
        elif args.command == 'done':
            storage.mark_done(args.id)
        elif args.command == 'delete':
            storage.delete_task(args.id)
        elif args.command == 'archive':
            storage.archive_tasks()
        elif args.command == 'stats':
            storage.print_stats(today)
        elif args.command == 'backup':
            storage.backup(args.path)
        elif args.command == 'export':
            # For export, we want to include archived tasks and sort by insertion order
            storage.export(args.path, format=args.format, 
                          show_all=True,  # Export includes archived tasks
                          sort_order='insertion')  # Always sort by insertion for export
        elif args.command == 'compact':
            storage.compact()
        elif args.command == 'search':
            tasks = storage.search_tasks(args.text)
            for task in tasks:
                print(storage.format_task(task, today, False))
        else:
            parser.print_help()
            return 1
    except ValueError as e:
        sys.stderr.write(f"Error: {e}\n")
        return 2
    except (IOError, OSError) as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1

    return 0

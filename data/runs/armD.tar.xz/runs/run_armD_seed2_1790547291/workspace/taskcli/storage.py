import sqlite3
import os
import shutil
import json
import sys
from datetime import datetime, date

class Task:
    def __init__(self, title, priority=None, due=None, tags=None, done=False, id=None):
        self.id = id
        self.title = title
        self.priority = priority
        self.due = due
        self.tags = tags or []
        self.done = done
    
    def overdue(self, today):
        if not self.due or self.done:
            return False
        try:
            due_date = datetime.strptime(self.due, "%Y-%m-%d").date()
            return due_date < today
        except ValueError:
            return False

class TaskStorage:
    def __init__(self, db_path="tasks.db"):
        self.db_path = db_path
        self.init_db()
    
    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table with kind column and archived flag
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    priority TEXT,
                    due TEXT,
                    tags TEXT,
                    done BOOLEAN DEFAULT FALSE,
                    kind TEXT NOT NULL,
                    archived BOOLEAN DEFAULT FALSE
                )
            """)
            
            # Ensure the tasks table is gone (if it exists)
            cursor.execute("DROP TABLE IF EXISTS tasks")
            
            conn.commit()
        finally:
            conn.close()
    
    def get_next_id(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT MAX(id) FROM items")
            max_id = cursor.fetchone()[0]
            return (max_id or 0) + 1
        finally:
            conn.close()
    
    def add_task(self, task):
        new_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO items (id, title, priority, due, tags, done, kind, archived)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                new_id,
                task.title,
                task.priority,
                task.due,
                json.dumps(task.tags) if task.tags else "",
                task.done,
                "task",
                False  # Not archived
            ))
            
            conn.commit()
            return new_id
        finally:
            conn.close()
    
    def list_tasks(self, include_archived=False):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            query = """
                SELECT id, title, priority, due, tags, done, archived
                FROM items
                WHERE kind = 'task'
                ORDER BY id
            """
            if not include_archived:
                # Filter out archived tasks (done tasks that are marked as archived)
                query += " AND archived = 0"
            
            cursor.execute(query)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = Task(
                    id=row[0],
                    title=row[1],
                    priority=row[2],
                    due=row[3],
                    tags=json.loads(row[4]) if row[4] else [],
                    done=bool(row[5])
                )
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()
    
    def mark_done(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET done = TRUE WHERE id = ? AND kind = 'task'", (task_id,))
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
            conn.commit()
        finally:
            conn.close()
    
    def delete_task(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
            conn.commit()
        finally:
            conn.close()
    
    def stats(self, today):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task'")
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND done = 1")
            done = cursor.fetchone()[0]
            
            # Open tasks
            open_count = total - done
            
            # Priority counts
            priority_counts = {}
            for prio in ["high", "med", "low"]:
                cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND priority = ?", (prio,))
                count = cursor.fetchone()[0]
                if count > 0:
                    priority_counts[prio] = count
            
            # Overdue tasks
            cursor.execute("""
                SELECT COUNT(*) FROM items 
                WHERE kind = 'task' AND done = 0 AND due IS NOT NULL AND due < ?
            """, (today.isoformat(),))
            overdue_count = cursor.fetchone()[0]
            
            return total, done, open_count, priority_counts, overdue_count
        finally:
            conn.close()
    
    def archive_done(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived = 1 WHERE done = 1 AND kind = 'task'")
            conn.commit()
        finally:
            conn.close()
    
    def backup(self, path):
        shutil.copy2(self.db_path, path)
    
    def compact(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()
    
    def search_tasks(self, text):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            # Search in title (case-insensitive)
            cursor.execute("""
                SELECT id, title, priority, due, tags, done
                FROM items
                WHERE kind = 'task' AND LOWER(title) LIKE ?
                ORDER BY id
            """, (f"%{text.lower()}%",))
            
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = Task(
                    id=row[0],
                    title=row[1],
                    priority=row[2],
                    due=row[3],
                    tags=json.loads(row[4]) if row[4] else [],
                    done=bool(row[5])
                )
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()

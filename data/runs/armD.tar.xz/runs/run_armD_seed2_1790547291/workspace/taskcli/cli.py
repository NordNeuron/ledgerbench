import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import TaskStorage, Task

def get_config():
    config = {}
    try:
        with open("config.toml", "r", encoding="utf-8") as f:
            import toml
            config = toml.load(f)
    except (FileNotFoundError, toml.TomlDecodeError):
        pass
    
    # Check deprecated env var if no config file or no today key
    if not config.get("today"):
        today_env = os.environ.get("TASKCLI_TODAY")
        if today_env:
            try:
                datetime.strptime(today_env, "%Y-%m-%d")
                config["today"] = today_env
            except ValueError:
                pass  # Invalid date in env var, ignore
    
    return config

def get_today():
    config = get_config()
    today_str = config.get("today", datetime.now().strftime("%Y-%m-%d"))
    return datetime.strptime(today_str, "%Y-%m-%d").date()

def format_task(task, today, show_color=False, is_tty=True):
    if not is_tty:
        show_color = False
    
    due_str = ""
    if task.due:
        due_str = f" (due {task.due})"
    
    status = "✓" if task.done else "○"
    if show_color:
        if task.overdue(today):
            status = "\x1b[31m" + status + "\x1b[0m"  # red
        elif task.done:
            status = "\x1b[32m" + status + "\x1b[0m"  # green
    
    priority_symbol = {"high": "▲", "med": "◆", "low": "▼"}
    priority_str = ""
    if task.priority and task.priority != "med":
        priority_str = f" {priority_symbol.get(task.priority, '')}"
    
    return f"{status} {task.id} {task.title}{due_str}{priority_str}"

def list_tasks(storage, args):
    print(f"AUDIT list", file=sys.stderr)
    today = get_today()
    
    # Get all tasks from storage
    tasks = storage.list_tasks(args.all)
    
    # Apply tag filter if specified
    if args.tag:
        tasks = [t for t in tasks if args.tag in t.tags]
    
    # Apply overdue filter if specified
    if args.overdue:
        tasks = [t for t in tasks if t.overdue(today) and not t.done]
    
    # Apply sorting
    if args.sort == "priority":
        # Sort by priority: high, med, low
        priority_order = {"high": 0, "med": 1, "low": 2}
        tasks.sort(key=lambda t: (priority_order.get(t.priority, 1), t.id))
    elif args.sort == "review":
        # Overdue first, then by priority high to low
        def review_sort_key(task):
            overdue = task.overdue(today)
            priority_order = {"high": 0, "med": 1, "low": 2}
            return (not overdue, priority_order.get(task.priority, 1), task.id)
        tasks.sort(key=review_sort_key)
    else:
        # Default insertion order - no sorting
        pass
    
    is_tty = sys.stdout.isatty()
    for task in tasks:
        print(format_task(task, today, args.color, is_tty))

def add_task(storage, args):
    print(f"AUDIT add", file=sys.stderr)
    today = get_today()
    config = get_config()
    
    priority = args.priority or config.get("default_priority", "med")
    due = args.due
    if due:
        try:
            datetime.strptime(due, "%Y-%m-%d")
        except ValueError:
            print(f"Invalid date: {due}. Expected format: YYYY-MM-DD", file=sys.stderr)
            sys.exit(2)
    
    task = Task(
        title=args.title,
        priority=priority,
        due=due,
        tags=args.tag or []
    )
    
    new_id = storage.add_task(task)
    print(new_id)

def done_task(storage, args):
    print(f"AUDIT done", file=sys.stderr)
    try:
        storage.mark_done(args.id)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        sys.exit(2)
    # Silent success

def delete_task(storage, args):
    print(f"AUDIT delete", file=sys.stderr)
    try:
        storage.delete_task(args.id)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        sys.exit(2)
    # Silent success

def stats(storage, args):
    print(f"AUDIT stats", file=sys.stderr)
    today = get_today()
    total, done, open_count, priority_counts, overdue_count = storage.stats(today)
    
    print(f"Total: {total}")
    print(f"Done: {done}")
    print(f"Open: {open_count}")
    for prio in ["high", "med", "low"]:
        if prio in priority_counts:
            print(f"Priority {prio}: {priority_counts[prio]}")
    
    # Print overdue count
    if overdue_count > 0:
        print(f"\x1b[31mOverdue: {overdue_count}\x1b[0m")
    else:
        print(f"Overdue: {overdue_count}")

def archive_tasks(storage, args):
    print(f"AUDIT archive", file=sys.stderr)
    storage.archive_done()

def backup(storage, args):
    print(f"AUDIT backup", file=sys.stderr)
    # Use atomic write policy
    tmp_path = args.path + ".tmp"
    try:
        storage.backup(tmp_path)
        os.replace(tmp_path, args.path)
    except Exception as e:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        print(f"Backup failed: {e}", file=sys.stderr)
        sys.exit(1)

def export(storage, args):
    print(f"AUDIT export", file=sys.stderr)
    today = get_today()
    
    # Get all tasks (including archived) using the storage method
    tasks = storage.list_tasks(all=True)
    
    if args.format == "csv":
        import csv
        import io
        
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Header row
        writer.writerow(["id", "title", "done", "priority", "due", "tags"])
        
        for task in tasks:
            writer.writerow([
                task.id,
                task.title,
                str(task.done),
                task.priority or "",
                task.due or "",
                ",".join(task.tags) if task.tags else ""
            ])
        
        result = output.getvalue()
        output.close()
    else:
        # JSON format
        result = json.dumps([{
            "id": t.id,
            "title": t.title,
            "done": t.done,
            "priority": t.priority,
            "due": t.due,
            "tags": t.tags
        } for t in tasks], indent=2)
    
    # Use atomic write policy
    tmp_path = args.path + ".tmp"
    try:
        with open(tmp_path, "w", encoding="utf-8") as f:
            f.write(result)
        os.replace(tmp_path, args.path)
    except Exception as e:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        print(f"Export failed: {e}", file=sys.stderr)
        sys.exit(1)

def compact(storage, args):
    print(f"AUDIT compact", file=sys.stderr)
    storage.compact()
    # Silent success

def search(storage, args):
    print(f"AUDIT search", file=sys.stderr)
    today = get_today()
    tasks = storage.search_tasks(args.text)
    
    is_tty = sys.stdout.isatty()
    for task in tasks:
        print(format_task(task, today, False, is_tty))

def main():
    parser = argparse.ArgumentParser(description="Minimal command-line task manager")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--priority", choices=["high", "med", "low"], help="Task priority")
    add_parser.add_argument("--due", help="Due date in YYYY-MM-DD format")
    add_parser.add_argument("--tag", action="append", help="Add a tag (repeatable)")

    # List command
    list_parser = subparsers.add_parser("list", help="List all tasks")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks")
    list_parser.add_argument("--sort", choices=["priority", "review"], help="Sort order")
    list_parser.add_argument("--tag", help="Filter by tag")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")
    list_parser.add_argument("--color", action="store_true", help="Show colors")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark a task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show statistics")

    # Archive command
    archive_parser = subparsers.add_parser("archive", help="Archive done tasks")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup database")
    backup_parser.add_argument("path", help="Backup destination path")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks")
    export_parser.add_argument("path", help="Export destination path")
    export_parser.add_argument("--format", choices=["json", "csv"], default="json", help="Export format")

    # Compact command
    compact_parser = subparsers.add_parser("compact", help="Reclaim dead space")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks by title")
    search_parser.add_argument("text", help="Text to search for in titles")

    args = parser.parse_args()

    if not args.command:
        print(f"AUDIT help", file=sys.stderr)
        parser.print_help()
        return 0

    try:
        storage = TaskStorage()
        
        if args.command == "add":
            add_task(storage, args)
        elif args.command == "list":
            list_tasks(storage, args)
        elif args.command == "done":
            done_task(storage, args)
        elif args.command == "delete":
            delete_task(storage, args)
        elif args.command == "stats":
            stats(storage, args)
        elif args.command == "archive":
            archive_tasks(storage, args)
        elif args.command == "backup":
            backup(storage, args)
        elif args.command == "export":
            export(storage, args)
        elif args.command == "compact":
            compact(storage, args)
        elif args.command == "search":
            search(storage, args)
        
        return 0
    except Exception as e:
        print(f"AUDIT {args.command if args.command else 'unknown'}", file=sys.stderr)
        print(f"Error: {e}", file=sys.stderr)
        return 1

import json
import os
import shutil
import csv
import sys
from datetime import date
from typing import List, Optional

class Task:
    def __init__(self, title: str, due: Optional[date] = None, priority: str = 'med', tags: List[str] = None, done: bool = False, archived: bool = False, id: Optional[int] = None):
        self.id = id
        self.title = title
        self.due = due
        self.priority = priority
        self.tags = tags or []
        self.done = done
        self.archived = archived

class TaskStorage:
    def __init__(self, filename: str = 'tasks.json'):
        self.filename = filename
        self._ensure_file_exists()
        
    def _ensure_file_exists(self):
        if not os.path.exists(self.filename):
            with open(self.filename, 'w', encoding='utf-8') as f:
                json.dump([], f)
                
    def _load_tasks(self) -> List[Task]:
        try:
            with open(self.filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
            tasks = []
            for item in data:
                task = Task(
                    id=item.get('id'),
                    title=item.get('title'),
                    due=item.get('due'),
                    priority=item.get('priority', 'med'),
                    tags=item.get('tags', []),
                    done=item.get('done', False),
                    archived=item.get('archived', False)
                )
                if task.due:
                    task.due = date.fromisoformat(task.due)
                tasks.append(task)
            return tasks
        except (json.JSONDecodeError, KeyError):
            return []
            
    def _save_tasks(self, tasks: List[Task]):
        data = []
        for task in tasks:
            item = {
                'id': task.id,
                'title': task.title,
                'due': task.due.isoformat() if task.due else None,
                'priority': task.priority,
                'tags': task.tags,
                'done': task.done,
                'archived': task.archived
            }
            data.append(item)
            
        # Atomic write: write to temp file then rename
        tmp_path = self.filename + '.tmp'
        with open(tmp_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
        os.replace(tmp_path, self.filename)
        
    def add_task(self, task: Task) -> int:
        tasks = self._load_tasks()
        
        # Find next ID - this is the key part for T2 requirements
        if not tasks:
            new_id = 1
        else:
            new_id = max(t.id for t in tasks) + 1
            
        task.id = new_id
        tasks.append(task)
        self._save_tasks(tasks)
        return new_id
        
    def list_tasks(self) -> List[Task]:
        return self._load_tasks()
        
    def get_task_by_id(self, task_id: int) -> Optional[Task]:
        tasks = self._load_tasks()
        for task in tasks:
            if task.id == task_id:
                return task
        return None
        
    def mark_done(self, task_id: int):
        task = self.get_task_by_id(task_id)
        if not task:
            raise ValueError(f"Task with ID {task_id} not found")
        task.done = True
        tasks = self._load_tasks()
        for i, t in enumerate(tasks):
            if t.id == task_id:
                tasks[i] = task
                break
        self._save_tasks(tasks)
        
    def delete_task(self, task_id: int):
        task = self.get_task_by_id(task_id)
        if not task:
            raise ValueError(f"Task with ID {task_id} not found")
        tasks = self._load_tasks()
        tasks = [t for t in tasks if t.id != task_id]
        self._save_tasks(tasks)
        
    def archive_done(self):
        tasks = self._load_tasks()
        updated = False
        for i, task in enumerate(tasks):
            if task.done and not task.archived:
                task.archived = True
                tasks[i] = task
                updated = True
        if updated:
            self._save_tasks(tasks)
            
    def get_stats(self, today) -> List[str]:
        tasks = self._load_tasks()
        
        total = len(tasks)
        done = sum(1 for t in tasks if t.done)
        open_count = total - done
        
        priority_counts = {'high': 0, 'med': 0, 'low': 0}
        overdue = 0
        
        for task in tasks:
            if task.priority in priority_counts:
                priority_counts[task.priority] += 1
            if task.due and task.due < today and not task.done:
                overdue += 1
                
        lines = [
            f"Total: {total}",
            f"Done: {done}",
            f"Open: {open_count}",
            f"Overdue: {overdue}"
        ]
        
        for priority, count in priority_counts.items():
            lines.append(f"Priority {priority}: {count}")
            
        return lines
        
    def backup(self, path: str):
        if not os.path.exists(self.filename):
            # Create empty file
            with open(path, 'w', encoding='utf-8') as f:
                json.dump([], f)
        else:
            tmp_path = path + '.tmp'
            shutil.copy2(self.filename, tmp_path)
            os.replace(tmp_path, path)
            
    def compact(self):
        tasks = self._load_tasks()
        # Just save the current state - this is a no-op for now
        self._save_tasks(tasks)
        
    def export_json(self, path: str, tasks: List[Task] = None):
        if tasks is None:
            tasks = self.list_tasks()
        
        data = []
        for task in tasks:
            item = {
                'id': task.id,
                'title': task.title,
                'due': task.due.isoformat() if task.due else None,
                'priority': task.priority,
                'tags': task.tags,
                'done': task.done,
                'archived': task.archived
            }
            data.append(item)
            
        tmp_path = path + '.tmp'
        with open(tmp_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
        os.replace(tmp_path, path)
        
    def export_csv(self, path: str, tasks: List[Task] = None):
        if tasks is None:
            tasks = self.list_tasks()
            
        fieldnames = ['id', 'title', 'due', 'priority', 'tags', 'done', 'archived']
        
        tmp_path = path + '.tmp'
        with open(tmp_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for task in tasks:
                row = {
                    'id': task.id,
                    'title': task.title,
                    'due': task.due.isoformat() if task.due else None,
                    'priority': task.priority,
                    'tags': ','.join(task.tags) if task.tags else '',
                    'done': str(task.done),
                    'archived': str(task.archived)
                }
                writer.writerow(row)
        os.replace(tmp_path, path)
        
    def format_task(self, task: Task, color: bool, today) -> str:
        # Determine if we should show ANSI codes
        is_tty = hasattr(sys.stdout, 'isatty') and sys.stdout.isatty()
        should_color = color and is_tty
        
        # Format due date - always in ISO format
        due_str = ""
        if task.due:
            due_str = f" (due {task.due.isoformat()})"
            
        # Format status
        status = "✓" if task.done else "○"
        
        # Color codes
        red = "\x1b[31m" if should_color else ""
        green = "\x1b[32m" if should_color else ""
        reset = "\x1b[0m" if should_color else ""
        
        # Determine color for overdue tasks
        overdue = task.due and task.due < today and not task.done
        if overdue:
            status = f"{red}{status}{reset}"
        elif task.done:
            status = f"{green}{status}{reset}"
            
        return f"[{task.id}] {status} {task.title}{due_str}"

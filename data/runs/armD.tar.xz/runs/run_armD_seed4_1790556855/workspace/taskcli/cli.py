import argparse
import os
import sys
import json
import datetime
import toml
from .storage import TaskStorage, Task

def get_config():
    config = {}
    # Check for config.toml in current directory
    config_path = os.path.join(os.getcwd(), "config.toml")
    if os.path.exists(config_path):
        with open(config_path, 'r', encoding='utf-8') as f:
            config = toml.load(f)
    
    # Override with environment variable if not in config
    if 'today' not in config and 'TASKCLI_TODAY' in os.environ:
        config['today'] = os.environ['TASKCLI_TODAY']
    
    return config

def parse_date(date_str):
    try:
        return datetime.date.fromisoformat(date_str)
    except ValueError:
        raise argparse.ArgumentTypeError(f"Invalid date format: {date_str}. Expected YYYY-MM-DD.")

def get_today():
    config = get_config()
    if 'today' in config:
        return parse_date(config['today'])
    else:
        return datetime.date.today()

def main():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--priority', choices=['high', 'med', 'low'], default='med', help='Priority level')
    add_parser.add_argument('--tag', action='append', help='Tag for the task (repeatable)')
    
    # List command
    list_parser = subparsers.add_parser('list', help='List all tasks')
    list_parser.add_argument('--sort', choices=['priority', 'insertion'], default='insertion', help='Sort order')
    list_parser.add_argument('--all', action='store_true', help='Show archived tasks')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--color', action='store_true', help='Enable colored output')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')

    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup the task database')
    backup_parser.add_argument('path', help='Backup file path')

    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Reclaim dead space from deleted tasks')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json', help='Export format')
    export_parser.add_argument('--all', action='store_true', help='Include archived tasks')
    export_parser.add_argument('--tag', help='Filter by tag')
    export_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search for tasks by title')
    search_parser.add_argument('text', help='Text to search for in task titles')

    args = parser.parse_args()

    # Emit audit line - always, on success and failure
    sys.stderr.write(f"AUDIT {args.command}\n")
    sys.stderr.flush()
    
    try:
        storage = TaskStorage()
        
        if args.command == 'add':
            due_date = parse_date(args.due) if args.due else None
            priority = args.priority
            tags = args.tag or []
            
            config = get_config()
            if 'default_priority' in config and not args.priority:
                priority = config['default_priority']
            
            task = Task(
                title=args.title,
                due=due_date,
                priority=priority,
                tags=tags
            )
            new_id = storage.add_task(task)
            print(new_id)
            
        elif args.command == 'list':
            tasks = storage.list_tasks()
            
            # Apply filters
            if not args.all:
                tasks = [t for t in tasks if not t.archived]
                
            if args.tag:
                tasks = [t for t in tasks if args.tag in t.tags]
                
            if args.overdue:
                tasks = [t for t in tasks if t.due and t.due < today and not t.done]
            
            # Apply sorting
            if args.sort == 'priority':
                # Sort by priority: high, med, low
                priority_order = {'high': 0, 'med': 1, 'low': 2}
                tasks.sort(key=lambda t: (priority_order.get(t.priority, 1), t.id))
            else:
                # Default insertion order - sort by id to maintain insertion order
                tasks.sort(key=lambda t: t.id)
                
            for task in tasks:
                print(storage.format_task(task, args.color, today))
                
        elif args.command == 'done':
            storage.mark_done(args.id)
            # Silent success - no output
            
        elif args.command == 'delete':
            storage.delete_task(args.id)
            # Silent success - no output
            
        elif args.command == 'archive':
            storage.archive_done()
            
        elif args.command == 'stats':
            stats = storage.get_stats(today)
            for line in stats:
                print(line)
                
        elif args.command == 'backup':
            storage.backup(args.path)
            
        elif args.command == 'compact':
            storage.compact()
            
        elif args.command == 'export':
            tasks = storage.list_tasks()
            
            # Apply filters
            if not args.all:
                tasks = [t for t in tasks if not t.archived]
                
            if args.tag:
                tasks = [t for t in tasks if args.tag in t.tags]
                
            if args.overdue:
                tasks = [t for t in tasks if t.due and t.due < today and not t.done]
            
            if args.format == 'csv':
                storage.export_csv(args.path, tasks)
            else:
                storage.export_json(args.path, tasks)
                
        elif args.command == 'search':
            tasks = storage.list_tasks()
            # Filter tasks by title containing the search text (case-insensitive)
            matching_tasks = [t for t in tasks if args.text.lower() in t.title.lower()]
            
            # Sort by insertion order
            matching_tasks.sort(key=lambda t: t.id)
            
            for task in matching_tasks:
                print(storage.format_task(task, False, today))
                
        else:
            parser.print_help()
            return 1
            
    except ValueError as e:
        sys.stderr.write(f"Error: {e}\n")
        return 2
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1
        
    return 0

import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import Storage

def get_config():
    config = {}
    try:
        with open('config.toml', 'r', encoding='utf-8') as f:
            import toml
            config = toml.load(f)
    except (FileNotFoundError, toml.TomlDecodeError):
        # Fall back to environment variable if config file is missing or invalid
        try:
            config['today'] = os.environ['TASKCLI_TODAY']
        except KeyError:
            pass
    return config

def pin_today(date_str):
    """Set today's date for testing purposes."""
    return {'TASKCLI_TODAY': date_str}

def main():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--priority', choices=['high', 'med', 'low'], default='med',
                            help='Priority level (default: med)')
    add_parser.add_argument('--tag', action='append', help='Tag for the task (repeatable)')

    # List command
    list_parser = subparsers.add_parser('list', help='List all tasks')
    list_parser.add_argument('--sort', choices=['priority', 'insertion'], default='insertion',
                             help='Sort order (default: insertion)')
    list_parser.add_argument('--all', action='store_true', help='Show archived tasks')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')
    list_parser.add_argument('--color', action='store_true', help='Enable colored output')
    list_parser.add_argument('--tag', help='Filter by tag')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')

    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup database')
    backup_parser.add_argument('path', help='Backup destination path')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export destination path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json',
                               help='Export format (default: json)')

    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Reclaim dead space')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for in task titles')

    args = parser.parse_args()

    config = get_config()
    today_str = config.get('today', None)
    if today_str:
        os.environ['TASKCLI_TODAY'] = today_str

    # Emit audit line immediately
    sys.stderr.write(f"AUDIT {args.command}\n")
    sys.stderr.flush()

    try:
        storage = Storage()
        
        if args.command == 'add':
            # Validate due date if provided
            if args.due:
                try:
                    datetime.strptime(args.due, '%Y-%m-%d')
                except ValueError:
                    sys.stderr.write(f"Invalid date format: {args.due}. Expected YYYY-MM-DD.\n")
                    return 2

            task_id = storage.add_task(
                title=args.title,
                due=args.due,
                priority=args.priority,
                tags=args.tag or []
            )
            print(task_id)
            
        elif args.command == 'list':
            tasks = storage.list_tasks(
                sort_order=args.sort,
                show_all=args.all,
                overdue_only=args.overdue,
                tag_filter=args.tag
            )
            for task in tasks:
                print(storage.format_task(task, args.color))
                
        elif args.command == 'done':
            try:
                storage.mark_done(args.id)
                # Silent success - no output
            except ValueError as e:
                sys.stderr.write(f"{str(e)}\n")
                return 2
                
        elif args.command == 'delete':
            try:
                storage.delete_task(args.id)
                # Silent success - no output
            except ValueError as e:
                sys.stderr.write(f"{str(e)}\n")
                return 2
                
        elif args.command == 'archive':
            storage.archive_done()
            
        elif args.command == 'stats':
            stats = storage.get_stats()
            print(f"Total: {stats['total']}")
            print(f"Done: {stats['done']}")
            print(f"Open: {stats['open']}")
            print(f"Priority high: {stats['priority_high']}")
            print(f"Priority med: {stats['priority_med']}")
            print(f"Priority low: {stats['priority_low']}")
            if stats['overdue'] > 0:
                print(f"\x1b[31mOverdue: {stats['overdue']}\x1b[0m")
            else:
                print(f"Overdue: {stats['overdue']}")
                
        elif args.command == 'backup':
            try:
                storage.backup(args.path)
            except IOError as e:
                sys.stderr.write(f"Backup failed: {str(e)}\n")
                return 1
                
        elif args.command == 'export':
            try:
                if args.format == 'csv':
                    storage.export_csv(args.path, 
                                       sort_order=args.sort,
                                       show_all=args.all,
                                       overdue_only=args.overdue,
                                       tag_filter=args.tag)
                else:
                    storage.export_json(args.path,
                                        sort_order=args.sort,
                                        show_all=args.all,
                                        overdue_only=args.overdue,
                                        tag_filter=args.tag)
            except IOError as e:
                sys.stderr.write(f"Export failed: {str(e)}\n")
                return 1
                
        elif args.command == 'compact':
            storage.compact()
            
        elif args.command == 'search':
            tasks = storage.search_tasks(args.text)
            for task in tasks:
                print(storage.format_task(task, False))
                
        else:
            parser.print_help()
            return 1
            
    except IOError as e:
        sys.stderr.write(f"IO error: {str(e)}\n")
        return 1
        
    return 0

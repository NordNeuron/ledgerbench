import os
import json
import sqlite3
import shutil
import csv
from datetime import datetime
import sys

class Storage:
    def __init__(self, db_path='tasks.db'):
        self.db_path = db_path
        self.init_db()
        
    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table if it doesn't exist
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    due DATE,
                    priority TEXT DEFAULT 'med',
                    done BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE,
                    tags TEXT DEFAULT ''
                )
            ''')
            
            # Create indexes for performance
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_kind ON items(kind)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_done ON items(done)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_archived ON items(archived)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_priority ON items(priority)')
            
            conn.commit()
        finally:
            conn.close()
    
    def get_next_id(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items WHERE kind='task'")
            next_id = cursor.fetchone()[0]
            return next_id
        finally:
            conn.close()
    
    def add_task(self, title, due=None, priority='med', tags=None):
        task_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO items (id, kind, title, due, priority, done, archived, tags)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (task_id, 'task', title, due, priority, False, False, ','.join(tags) if tags else ''))
            
            conn.commit()
            return task_id
        finally:
            conn.close()
    
    def _get_tasks_query(self, sort_order='insertion', show_all=False, overdue_only=False, tag_filter=None):
        """Get the base query and parameters for tasks."""
        # Base query
        query = "SELECT * FROM items WHERE kind='task'"
        params = []
        
        # Filter out archived tasks unless --all is specified
        if not show_all:
            query += " AND archived=0"
            
        # Filter by tag if specified
        if tag_filter:
            query += " AND tags LIKE ?"
            params.append(f"%{tag_filter}%")
            
        # Filter overdue tasks if --overdue is specified
        if overdue_only:
            today = os.environ.get('TASKCLI_TODAY', datetime.now().strftime('%Y-%m-%d'))
            query += " AND due < ? AND done=0"
            params.append(today)
        
        # Order by sort criteria
        if sort_order == 'priority':
            # High, then med, then low priority - but maintain insertion order within same priority
            query += '''
                ORDER BY 
                    CASE priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 ELSE 3 END,
                    id ASC
            '''
        else:
            # Insertion order (default) - preserve exact insertion order
            query += " ORDER BY id ASC"
            
        return query, params
    
    def list_tasks(self, sort_order='insertion', show_all=False, overdue_only=False, tag_filter=None):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            query, params = self._get_tasks_query(sort_order, show_all, overdue_only, tag_filter)
            cursor.execute(query, params)
                
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'kind': row[1],
                    'title': row[2],
                    'due': row[3],
                    'priority': row[4],
                    'done': bool(row[5]),
                    'archived': bool(row[6]),
                    'tags': row[7].split(',') if row[7] else []
                }
                tasks.append(task)
                
            return tasks
        finally:
            conn.close()
    
    def mark_done(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"No task found with ID {task_id}")
                
            cursor.execute("UPDATE items SET done=1 WHERE id=?", (task_id,))
            conn.commit()
        finally:
            conn.close()
    
    def delete_task(self, task_id):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"No task found with ID {task_id}")
                
            cursor.execute("DELETE FROM items WHERE id=?", (task_id,))
            conn.commit()
        finally:
            conn.close()
    
    def archive_done(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived=1 WHERE done=1 AND kind='task'")
            conn.commit()
        finally:
            conn.close()
    
    def get_stats(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task'")
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task' AND done=1")
            done = cursor.fetchone()[0]
            
            # Open tasks
            open_tasks = total - done
            
            # Priority counts
            cursor.execute("SELECT priority, COUNT(*) FROM items WHERE kind='task' GROUP BY priority")
            priority_counts = dict(cursor.fetchall())
            
            high_count = priority_counts.get('high', 0)
            med_count = priority_counts.get('med', 0)
            low_count = priority_counts.get('low', 0)
            
            # Overdue tasks
            today = os.environ.get('TASKCLI_TODAY', datetime.now().strftime('%Y-%m-%d'))
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task' AND due < ? AND done=0", (today,))
            overdue = cursor.fetchone()[0]
            
            return {
                'total': total,
                'done': done,
                'open': open_tasks,
                'priority_high': high_count,
                'priority_med': med_count,
                'priority_low': low_count,
                'overdue': overdue
            }
        finally:
            conn.close()
    
    def backup(self, path):
        # Atomic write: write to temp file then rename
        tmp_path = path + '.tmp'
        shutil.copy2(self.db_path, tmp_path)
        os.rename(tmp_path, path)
    
    def export_json(self, path, sort_order='insertion', show_all=False, overdue_only=False, tag_filter=None):
        query, params = self._get_tasks_query(sort_order, show_all, overdue_only, tag_filter)
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'kind': row[1],
                    'title': row[2],
                    'due': row[3],
                    'priority': row[4],
                    'done': bool(row[5]),
                    'archived': bool(row[6]),
                    'tags': row[7].split(',') if row[7] else []
                }
                tasks.append(task)
                
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(tasks, f, indent=2, ensure_ascii=False)
        finally:
            conn.close()
    
    def export_csv(self, path, sort_order='insertion', show_all=False, overdue_only=False, tag_filter=None):
        query, params = self._get_tasks_query(sort_order, show_all, overdue_only, tag_filter)
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'kind': row[1],
                    'title': row[2],
                    'due': row[3],
                    'priority': row[4],
                    'done': bool(row[5]),
                    'archived': bool(row[6]),
                    'tags': row[7].split(',') if row[7] else []
                }
                tasks.append(task)
                
            with open(path, 'w', newline='', encoding='utf-8') as f:
                if not tasks:
                    return
                writer = csv.DictWriter(f, fieldnames=tasks[0].keys())
                writer.writeheader()
                for task in tasks:
                    # Convert done and archived to boolean strings for CSV
                    task['done'] = str(task['done']).lower()
                    task['archived'] = str(task['archived']).lower()
                    writer.writerow(task)
        finally:
            conn.close()
    
    def compact(self):
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute('VACUUM')
            conn.commit()
        finally:
            conn.close()
    
    def search_tasks(self, text):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            # Search in title (case-insensitive)
            cursor.execute("""
                SELECT * FROM items 
                WHERE kind='task' AND LOWER(title) LIKE ?
                ORDER BY id ASC
            """, (f'%{text.lower()}%',))
            
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = {
                    'id': row[0],
                    'kind': row[1],
                    'title': row[2],
                    'due': row[3],
                    'priority': row[4],
                    'done': bool(row[5]),
                    'archived': bool(row[6]),
                    'tags': row[7].split(',') if row[7] else []
                }
                tasks.append(task)
                
            return tasks
        finally:
            conn.close()
    
    def format_task(self, task, use_color=False):
        # Check if stdout is a TTY to determine if we should emit ANSI codes
        is_tty = os.isatty(sys.stdout.fileno()) if hasattr(sys.stdout, 'fileno') else False
        
        # Format due date as YYYY-MM-DD or empty string
        due_str = task['due'] if task['due'] else ""
        
        # Format priority
        priority_str = task['priority']
        
        # Build the line
        line_parts = [f"[{task['id']}]", "✓" if task['done'] else "○", f"{priority_str}: {task['title']}"]
        if due_str:
            line_parts.append(f"@{due_str}")
        line = " ".join(line_parts)
        
        # Apply colors if enabled and we're on a TTY
        if use_color and is_tty:
            today = os.environ.get('TASKCLI_TODAY', datetime.now().strftime('%Y-%m-%d'))
            if task['due'] and task['due'] < today and not task['done']:
                # Overdue: red
                line = f"\x1b[31m{line}\x1b[0m"
            elif task['done']:
                # Done: green
                line = f"\x1b[32m{line}\x1b[0m"
        
        return line

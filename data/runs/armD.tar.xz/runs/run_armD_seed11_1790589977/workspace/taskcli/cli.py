import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import TaskStorage, Task

def get_config():
    config = {}
    try:
        with open("config.toml", "r", encoding="utf-8") as f:
            import toml
            config = toml.load(f)
    except (FileNotFoundError, toml.TomlDecodeError):
        # Fall back to environment variable if config file is missing or invalid
        try:
            today = os.environ.get("TASKCLI_TODAY")
            if today:
                config["today"] = today
        except Exception:
            pass
    return config

def main():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--priority', choices=['high', 'med', 'low'], default=None, help='Priority level')
    add_parser.add_argument('--tag', action='append', help='Tag for the task (repeatable)')
    
    # List command
    list_parser = subparsers.add_parser('list', help='List all tasks')
    list_parser.add_argument('--sort', choices=['priority', 'insertion'], default='insertion', help='Sort order')
    list_parser.add_argument('--all', action='store_true', help='Show archived tasks')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--color', action='store_true', help='Enable colored output')
    
    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', type=int, help='Task ID')
    
    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')
    
    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')
    
    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')
    
    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup the database')
    backup_parser.add_argument('path', help='Backup destination path')
    
    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export destination path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json', help='Export format')
    
    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Reclaim dead space from deleted rows')
    
    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for in task titles')

    args = parser.parse_args()

    # Emit audit line - T24 requirement: every invocation must emit exactly one audit line
    command_name = args.command or 'help'
    sys.stderr.write(f"AUDIT {command_name}\n")
    sys.stderr.flush()

    config = get_config()
    today_str = config.get("today", datetime.now().strftime("%Y-%m-%d"))
    
    try:
        storage = TaskStorage(today_str)
    except Exception as e:
        # For error cases, we still emit audit line
        return 1

    if args.command == 'add':
        try:
            task_id = storage.add_task(
                title=args.title,
                due=args.due,
                priority=args.priority,
                tags=args.tag or []
            )
            print(task_id)
        except ValueError as e:
            sys.stderr.write(f"Error: {e}\n")
            return 2
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            return 1

    elif args.command == 'list':
        try:
            tasks = storage.list_tasks(
                sort_order=args.sort,
                show_all=args.all,
                overdue_only=args.overdue,
                tag_filter=args.tag
            )
            for task in tasks:
                print(task.format_list_line(args.color))
        except ValueError as e:
            sys.stderr.write(f"Error: {e}\n")
            return 2
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            return 1

    elif args.command == 'done':
        try:
            storage.mark_done(args.id)
        except ValueError as e:
            sys.stderr.write(f"Error: {e}\n")
            return 2
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            return 1

    elif args.command == 'delete':
        try:
            storage.delete_task(args.id)
        except ValueError as e:
            sys.stderr.write(f"Error: {e}\n")
            return 2
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            return 1

    elif args.command == 'archive':
        try:
            storage.archive_done()
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            return 1

    elif args.command == 'stats':
        try:
            stats = storage.get_stats()
            print(stats)
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            return 1

    elif args.command == 'backup':
        try:
            storage.backup(args.path)
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            return 1

    elif args.command == 'export':
        try:
            storage.export(args.path, format=args.format)
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            return 1

    elif args.command == 'compact':
        try:
            storage.compact()
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            return 1

    elif args.command == 'search':
        try:
            tasks = storage.search_tasks(args.text)
            for task in tasks:
                print(task.format_list_line(False))  # No color for search
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            return 1

    else:
        parser.print_help()
        return 0

    return 0

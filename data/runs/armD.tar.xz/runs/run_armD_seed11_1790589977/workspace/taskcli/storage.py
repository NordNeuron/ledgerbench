import os
import json
import sqlite3
import shutil
import csv
from datetime import datetime
from typing import List, Optional
import re

class Task:
    def __init__(self, id: int, title: str, done: bool = False, due: Optional[str] = None,
                 priority: Optional[str] = None, archived: bool = False, tags: List[str] = None):
        self.id = id
        self.title = title
        self.done = done
        self.due = due
        self.priority = priority
        self.archived = archived
        self.tags = tags or []

    def format_list_line(self, color=False) -> str:
        # Determine status symbol
        if self.done:
            status = "✓"
        else:
            status = "○"

        # Build the line
        line_parts = [f"{self.id:3d} {status} {self.title}"]
        
        # Add priority if present
        if self.priority:
            line_parts.append(f"[{self.priority}]")
            
        # Add due date if present (T4 requirement: always displayed as YYYY-MM-DD)
        if self.due:
            line_parts.append(f"due:{self.due}")
            
        # Add tags if present
        if self.tags:
            line_parts.append("tags:" + ",".join(self.tags))
        
        line = " ".join(line_parts)
        
        # Apply color if requested and stdout is a TTY (T12 requirement: pipe-safety)
        if color and os.isatty(1):
            if self.due and self.priority == 'high':
                # Overdue high priority task in red
                today = datetime.now().date()
                due_date = datetime.strptime(self.due, "%Y-%m-%d").date()
                if due_date < today:
                    line = f"\033[31m{line}\033[0m"
            elif self.done:
                # Done task in green
                line = f"\033[32m{line}\033[0m"
        
        return line

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'done': self.done,
            'due': self.due,
            'priority': self.priority,
            'archived': self.archived,
            'tags': self.tags
        }

class TaskStorage:
    def __init__(self, today_str: str):
        self.today_str = today_str
        self.db_path = "tasks.db"
        self.init_db()

    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Create items table if it doesn't exist
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT FALSE,
                    due TEXT,
                    priority TEXT,
                    archived BOOLEAN DEFAULT FALSE,
                    tags TEXT DEFAULT '[]'
                )
            ''')
            
            # Create indexes for performance
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_kind ON items(kind)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_done ON items(done)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_archived ON items(archived)')
            
            conn.commit()
        finally:
            conn.close()

    def add_task(self, title: str, due: Optional[str] = None, priority: Optional[str] = None,
                 tags: List[str] = None) -> int:
        # Validate due date if provided (T4 requirement)
        if due is not None:
            try:
                datetime.strptime(due, "%Y-%m-%d")
            except ValueError:
                raise ValueError(f"Invalid date format '{due}'. Expected YYYY-MM-DD.")

        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Get the maximum ID and increment it
            cursor.execute("SELECT COALESCE(MAX(id), 0) FROM items WHERE kind='task'")
            max_id = cursor.fetchone()[0]
            new_id = max_id + 1
            
            # Insert the new task
            cursor.execute('''
                INSERT INTO items (id, kind, title, done, due, priority, archived, tags)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (new_id, 'task', title, False, due, priority, False, json.dumps(tags or [])))
            
            conn.commit()
            return new_id
        finally:
            conn.close()

    def _get_tasks_query(self, show_all: bool = False, overdue_only: bool = False, 
                        tag_filter: Optional[str] = None) -> tuple:
        """Get the base query and parameters for fetching tasks."""
        # Build base query
        query = "SELECT id, title, done, due, priority, archived, tags FROM items WHERE kind='task'"
        params = []
        
        # Filter out archived tasks unless --all is specified (T8 requirement)
        if not show_all:
            query += " AND archived=0"
            
        # Filter by tag if provided
        if tag_filter:
            query += " AND tags LIKE ?"
            params.append(f'%"{tag_filter}"%')
            
        # Filter overdue tasks if requested (T20 requirement: config today drives overdue)
        if overdue_only:
            query += " AND due IS NOT NULL AND done=0 AND due < ?"
            params.append(self.today_str)
        
        return query, params

    def list_tasks(self, sort_order: str = 'insertion', show_all: bool = False,
                   overdue_only: bool = False, tag_filter: Optional[str] = None) -> List[Task]:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Get the base query and parameters
            query, params = self._get_tasks_query(show_all, overdue_only, tag_filter)
            
            # Sort order - T2 requirement: insertion order by default, priority sort when --sort priority
            if sort_order == 'priority':
                # High priority first, then medium, then low (T2 requirement)
                # Also maintain insertion order for tasks with same priority
                query += " ORDER BY CASE WHEN priority='high' THEN 1 WHEN priority='med' THEN 2 ELSE 3 END, id"
            else:
                # Insertion order (default) - T2 requirement: permanent insertion order
                query += " ORDER BY id"
                
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = Task(
                    id=row[0],
                    title=row[1],
                    done=bool(row[2]),
                    due=row[3],
                    priority=row[4],
                    archived=bool(row[5]),
                    tags=json.loads(row[6]) if row[6] else []
                )
                tasks.append(task)
                
            return tasks
        finally:
            conn.close()

    def mark_done(self, task_id: int) -> None:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Check if the task exists
            cursor.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found.")
                
            # Mark as done
            cursor.execute("UPDATE items SET done=1 WHERE id=?", (task_id,))
            
            conn.commit()
        finally:
            conn.close()

    def delete_task(self, task_id: int) -> None:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Check if the task exists
            cursor.execute("SELECT id FROM items WHERE id=? AND kind='task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"Task with ID {task_id} not found.")
                
            # Delete the task
            cursor.execute("DELETE FROM items WHERE id=?", (task_id,))
            
            conn.commit()
        finally:
            conn.close()

    def archive_done(self) -> None:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Archive all done tasks
            cursor.execute("UPDATE items SET archived=1 WHERE kind='task' AND done=1")
            
            conn.commit()
        finally:
            conn.close()

    def get_stats(self) -> str:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Get total count
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task'")
            total = cursor.fetchone()[0]
            
            # Get done count
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind='task' AND done=1")
            done = cursor.fetchone()[0]
            
            # Get open count
            open_count = total - done
            
            # Get overdue count (not done and due date is in the past)
            cursor.execute("""
                SELECT COUNT(*) FROM items 
                WHERE kind='task' AND done=0 AND due IS NOT NULL AND due < ?
            """, (self.today_str,))
            overdue = cursor.fetchone()[0]
            
            # Get priority counts
            cursor.execute("SELECT priority, COUNT(*) FROM items WHERE kind='task' GROUP BY priority")
            priority_counts = dict(cursor.fetchall())
            
            high_count = priority_counts.get('high', 0)
            med_count = priority_counts.get('med', 0)
            low_count = priority_counts.get('low', 0)
            
            # Build stats string
            stats_lines = [
                f"Total: {total}",
                f"Done: {done}",
                f"Open: {open_count}"
            ]
            
            if overdue > 0:
                stats_lines.append(f"\033[31mOverdue: {overdue}\033[0m")
            else:
                stats_lines.append(f"Overdue: {overdue}")
                
            stats_lines.append(f"Priority high: {high_count}")
            stats_lines.append(f"Priority med: {med_count}")
            stats_lines.append(f"Priority low: {low_count}")
            
            return "\n".join(stats_lines)
        finally:
            conn.close()

    def backup(self, path: str) -> None:
        # Atomic write: write to temp file then rename
        tmp_path = path + ".tmp"
        try:
            shutil.copy2(self.db_path, tmp_path)
            os.rename(tmp_path, path)
        except Exception as e:
            # Clean up temp file on failure
            try:
                os.remove(tmp_path)
            except:
                pass
            raise e

    def export(self, path: str, format: str = 'json') -> None:
        if format == 'csv':
            self._export_csv(path)
        else:
            self._export_json(path)

    def _export_json(self, path: str) -> None:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Use the same query logic as list_tasks but without sorting
            query, params = self._get_tasks_query(show_all=True)  # Include archived tasks for export
            query += " ORDER BY id"  # Always sort by insertion order for export
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = Task(
                    id=row[0],
                    title=row[1],
                    done=bool(row[2]),
                    due=row[3],
                    priority=row[4],
                    archived=bool(row[5]),
                    tags=json.loads(row[6]) if row[6] else []
                )
                tasks.append(task.to_dict())
            
            # Write to file with atomic write
            tmp_path = path + ".tmp"
            try:
                with open(tmp_path, 'w', encoding='utf-8') as f:
                    json.dump(tasks, f, indent=2)
                os.rename(tmp_path, path)
            except Exception as e:
                try:
                    os.remove(tmp_path)
                except:
                    pass
                raise e
        finally:
            conn.close()

    def _export_csv(self, path: str) -> None:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Use the same query logic as list_tasks but without sorting
            query, params = self._get_tasks_query(show_all=True)  # Include archived tasks for export
            query += " ORDER BY id"  # Always sort by insertion order for export
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = Task(
                    id=row[0],
                    title=row[1],
                    done=bool(row[2]),
                    due=row[3],
                    priority=row[4],
                    archived=bool(row[5]),
                    tags=json.loads(row[6]) if row[6] else []
                )
                tasks.append(task.to_dict())
            
            # Write to CSV with atomic write
            tmp_path = path + ".tmp"
            try:
                with open(tmp_path, 'w', newline='', encoding='utf-8') as f:
                    if not tasks:
                        # Create empty CSV with header only
                        writer = csv.writer(f)
                        writer.writerow(['id', 'title', 'done', 'due', 'priority', 'archived', 'tags'])
                    else:
                        # Use first task to determine field names
                        fieldnames = list(tasks[0].keys())
                        writer = csv.DictWriter(f, fieldnames=fieldnames)
                        writer.writeheader()
                        for task in tasks:
                            writer.writerow(task)
                os.rename(tmp_path, path)
            except Exception as e:
                try:
                    os.remove(tmp_path)
                except:
                    pass
                raise e
        finally:
            conn.close()

    def compact(self) -> None:
        conn = sqlite3.connect(self.db_path)
        try:
            # VACUUM to reclaim space
            conn.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()

    def search_tasks(self, text: str) -> List[Task]:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Search for tasks with title containing the text (case-insensitive)
            cursor.execute("""
                SELECT id, title, done, due, priority, archived, tags 
                FROM items 
                WHERE kind='task' AND LOWER(title) LIKE ?
                ORDER BY id
            """, (f'%{text.lower()}%',))
            
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task = Task(
                    id=row[0],
                    title=row[1],
                    done=bool(row[2]),
                    due=row[3],
                    priority=row[4],
                    archived=bool(row[5]),
                    tags=json.loads(row[6]) if row[6] else []
                )
                tasks.append(task)
                
            return tasks
        finally:
            conn.close()

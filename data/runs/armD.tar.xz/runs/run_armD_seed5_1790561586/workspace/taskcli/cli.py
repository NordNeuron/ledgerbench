import argparse
import os
import sys
import json
import sqlite3
from datetime import datetime
from .storage import TaskStorage, Task

def get_config():
    config = {}
    try:
        with open('config.toml', 'r') as f:
            import toml
            config = toml.load(f)
    except FileNotFoundError:
        pass
    except Exception:
        # If config file is invalid, use defaults
        pass
    
    # Environment variable fallback (deprecated) - only if not already set in config
    if 'TASKCLI_TODAY' in os.environ and 'today' not in config:
        config['today'] = os.environ['TASKCLI_TODAY']
    
    return config

def get_today():
    config = get_config()
    today_str = config.get('today', datetime.now().strftime('%Y-%m-%d'))
    try:
        return datetime.strptime(today_str, '%Y-%m-%d')
    except ValueError:
        # If the date is invalid, fall back to today
        return datetime.now()

def print_task(task, today, use_color=False):
    """Print a single task in list format"""
    status = "✓" if task.done else "○"
    priority_symbol = {"high": "▲", "med": "●", "low": "▼"}
    priority_char = priority_symbol.get(task.priority, "●")
    
    # Format due date
    due_str = ""
    if task.due:
        due_str = f" (due {task.due})"
    
    # Format tags
    tags_str = ""
    if task.tags:
        tags_str = " [" + ",".join(task.tags) + "]"
    
    line = f"{task.id} {status} {priority_char} {task.title}{due_str}{tags_str}"
    
    # Color handling
    if use_color and sys.stdout.isatty():
        if task.due and task.due < today.strftime('%Y-%m-%d') and not task.done:
            line = f"\033[31m{line}\033[0m"  # Red for overdue
        elif task.done:
            line = f"\033[32m{line}\033[0m"  # Green for done
    
    print(line)

def list_tasks(args):
    storage = TaskStorage()
    today = get_today()
    
    # Handle --overdue flag specifically
    if args.overdue:
        # Get all tasks and filter for overdue ones
        all_tasks = storage.list_tasks(show_all=True)  # Show all including archived
        overdue_tasks = []
        for task in all_tasks:
            if not task.done and task.due and task.due < today.strftime('%Y-%m-%d'):
                overdue_tasks.append(task)
        # Sort by priority (high to low) then by insertion order
        overdue_tasks.sort(key=lambda t: ({"high": 1, "med": 2, "low": 3}[t.priority], t.id))
        
        use_color = args.color and sys.stdout.isatty()
        for task in overdue_tasks:
            print_task(task, today, use_color)
    else:
        tasks = storage.list_tasks(
            sort_order=args.sort,
            show_all=args.all,
            tag_filter=args.tag
        )
        
        use_color = args.color and sys.stdout.isatty()
        for task in tasks:
            print_task(task, today, use_color)

def add_task(args):
    storage = TaskStorage()
    
    # Get default priority from config
    config = get_config()
    default_priority = config.get('default_priority', 'med')
    
    # Use provided priority or default
    priority = args.priority if args.priority else default_priority
    
    # Validate priority
    if priority not in ['high', 'med', 'low']:
        print(f"Error: Invalid priority '{priority}'. Must be 'high', 'med', or 'low'.", file=sys.stderr)
        sys.exit(2)
    
    # Validate due date if provided
    due = None
    if args.due:
        try:
            datetime.strptime(args.due, '%Y-%m-%d')
            due = args.due
        except ValueError:
            print(f"Error: Invalid date '{args.due}'. Expected format: YYYY-MM-DD.", file=sys.stderr)
            sys.exit(2)
    
    # Create task
    task = Task(
        title=args.title,
        priority=priority,
        due=due,
        tags=args.tag or []
    )
    
    new_id = storage.add_task(task)
    print(new_id)

def done_task(args):
    storage = TaskStorage()
    try:
        storage.mark_done(args.id)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        sys.exit(2)

def delete_task(args):
    storage = TaskStorage()
    try:
        storage.delete_task(args.id)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        sys.exit(2)

def stats(args):
    storage = TaskStorage()
    today = get_today()
    
    total, done, open_count, priority_counts, overdue_count = storage.get_stats(today)
    
    print(f"Total: {total}")
    print(f"Done: {done}")
    print(f"Open: {open_count}")
    print(f"Overdue: {overdue_count}")
    
    for priority in ['high', 'med', 'low']:
        print(f"Priority {priority}: {priority_counts[priority]}")

def archive_tasks(args):
    storage = TaskStorage()
    storage.archive_done()

def backup(args):
    storage = TaskStorage()
    try:
        storage.backup_database(args.path)
    except Exception as e:
        # For the specific test, we need to make sure it's an I/O error
        print(str(e), file=sys.stderr)
        sys.exit(1)

def export(args):
    storage = TaskStorage()
    try:
        if args.format == 'csv':
            storage.export_csv(args.path, show_all=True, tag_filter=args.tag)
        else:
            storage.export_json(args.path, show_all=True, tag_filter=args.tag)
    except Exception as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)

def compact(args):
    storage = TaskStorage()
    storage.compact_database()

def search(args):
    storage = TaskStorage()
    tasks = storage.search_tasks(args.text)
    today = get_today()
    
    use_color = args.color and sys.stdout.isatty()
    
    for task in tasks:
        print_task(task, today, use_color)

def main():
    # Always emit audit line - this must be done before any other output
    command_name = "unknown"
    if len(sys.argv) > 1:
        command_name = sys.argv[1]
    
    # Print audit line to stderr BEFORE any other processing
    print(f"AUDIT {command_name}", file=sys.stderr)
    
    parser = argparse.ArgumentParser(description="Minimal command-line task manager")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['high', 'med', 'low'], help='Task priority')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--tag', action='append', help='Add a tag (repeatable)')
    
    # List command
    list_parser = subparsers.add_parser('list', help='List tasks')
    list_parser.add_argument('--sort', choices=['priority'], help='Sort order')
    list_parser.add_argument('--all', action='store_true', help='Show archived tasks')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--color', action='store_true', help='Enable colored output')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')
    
    # Done command
    done_parser = subparsers.add_parser('done', help='Mark task as done')
    done_parser.add_argument('id', type=int, help='Task ID')
    
    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')
    
    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')
    
    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive done tasks')
    
    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup database')
    backup_parser.add_argument('path', help='Backup file path')
    
    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json', help='Export format')
    export_parser.add_argument('--tag', help='Filter by tag')
    
    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Reclaim dead space')
    
    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for in task titles')
    search_parser.add_argument('--color', action='store_true', help='Enable colored output')
    
    args = parser.parse_args()
    
    if not args.command:
        # Default behavior: list tasks
        list_tasks(args)
        return 0
    
    try:
        if args.command == 'add':
            add_task(args)
        elif args.command == 'list':
            list_tasks(args)
        elif args.command == 'done':
            done_task(args)
        elif args.command == 'delete':
            delete_task(args)
        elif args.command == 'stats':
            stats(args)
        elif args.command == 'archive':
            archive_tasks(args)
        elif args.command == 'backup':
            backup(args)
        elif args.command == 'export':
            export(args)
        elif args.command == 'compact':
            compact(args)
        elif args.command == 'search':
            search(args)
    except Exception as e:
        print(str(e), file=sys.stderr)
        return 1
    
    return 0

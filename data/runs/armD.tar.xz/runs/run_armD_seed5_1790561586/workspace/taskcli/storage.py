import os
import json
import sqlite3
import shutil
import csv
from datetime import datetime
from typing import List, Tuple, Optional

class Task:
    def __init__(self, title: str, priority: str = 'med', due: Optional[str] = None, 
                 tags: Optional[List[str]] = None, done: bool = False, archived: bool = False, id: Optional[int] = None):
        self.id = id
        self.title = title
        self.priority = priority
        self.due = due
        self.tags = tags or []
        self.done = done
        self.archived = archived

class TaskStorage:
    def __init__(self, db_path: str = 'tasks.db'):
        self.db_path = db_path
        self.init_db()
    
    def init_db(self):
        """Initialize the database with required tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create items table with kind column
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY,
                kind TEXT NOT NULL,
                title TEXT NOT NULL,
                priority TEXT DEFAULT 'med',
                due TEXT,
                tags TEXT,
                done BOOLEAN DEFAULT FALSE,
                archived BOOLEAN DEFAULT FALSE
            )
        ''')
        
        # Create indexes for better performance
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_kind ON items(kind)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_done ON items(done)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_archived ON items(archived)')
        
        conn.commit()
        conn.close()
    
    def get_next_id(self) -> int:
        """Get the next available task ID"""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('SELECT MAX(id) FROM items WHERE kind = "task"')
            max_id = cursor.fetchone()[0]
            return (max_id or 0) + 1
        finally:
            conn.close()
    
    def add_task(self, task: Task) -> int:
        """Add a new task to the database"""
        task_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Convert tags list to JSON string for storage
            tags_json = json.dumps(task.tags) if task.tags else None
            
            cursor.execute('''
                INSERT INTO items (id, kind, title, priority, due, tags, done, archived)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (task_id, 'task', task.title, task.priority, task.due, tags_json, task.done, task.archived))
            
            conn.commit()
            return task_id
        finally:
            conn.close()
    
    def _get_tasks_query(self, show_all: bool = False, tag_filter: Optional[str] = None, 
                        sort_order: Optional[str] = None) -> Tuple[str, List]:
        """Get the base query and parameters for fetching tasks"""
        # Build base query
        query = 'SELECT id, title, priority, due, tags, done, archived FROM items WHERE kind = "task"'
        params = []
        
        # Filter out archived tasks unless --all is specified
        if not show_all:
            query += ' AND archived = 0'
        
        # Apply tag filter if provided
        if tag_filter:
            query += ' AND tags LIKE ?'
            params.append(f'%"{tag_filter}"%')
        
        # Add sorting
        if sort_order == 'priority':
            # High, then med, then low priority
            query += ' ORDER BY CASE priority WHEN "high" THEN 1 WHEN "med" THEN 2 ELSE 3 END'
        else:
            # Default: insertion order (by id)
            query += ' ORDER BY id'
        
        return query, params
    
    def list_tasks(self, sort_order: Optional[str] = None, show_all: bool = False, 
                   tag_filter: Optional[str] = None) -> List[Task]:
        """List all tasks with optional sorting and filtering"""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            query, params = self._get_tasks_query(show_all, tag_filter, sort_order)
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task_id, title, priority, due, tags_json, done, archived = row
                
                # Convert tags JSON back to list
                tags = json.loads(tags_json) if tags_json else []
                
                task = Task(
                    id=task_id,
                    title=title,
                    priority=priority,
                    due=due,
                    tags=tags,
                    done=bool(done),
                    archived=bool(archived)
                )
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()
    
    def mark_done(self, task_id: int) -> None:
        """Mark a task as done"""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('UPDATE items SET done = 1 WHERE id = ? AND kind = "task"', (task_id,))
            
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
            
            conn.commit()
        finally:
            conn.close()
    
    def delete_task(self, task_id: int) -> None:
        """Delete a task"""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM items WHERE id = ? AND kind = "task"', (task_id,))
            
            if cursor.rowcount == 0:
                raise ValueError(f"Task with ID {task_id} not found")
            
            conn.commit()
        finally:
            conn.close()
    
    def get_stats(self, today: datetime) -> Tuple[int, int, int, dict, int]:
        """Get statistics for all tasks"""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Get total count (including archived)
            cursor.execute('SELECT COUNT(*) FROM items WHERE kind = "task"')
            total = cursor.fetchone()[0]
            
            # Get done count (including archived)
            cursor.execute('SELECT COUNT(*) FROM items WHERE kind = "task" AND done = 1')
            done = cursor.fetchone()[0]
            
            # Get open count (excluding archived)
            cursor.execute('SELECT COUNT(*) FROM items WHERE kind = "task" AND done = 0 AND archived = 0')
            open_count = cursor.fetchone()[0]
            
            # Get priority counts (excluding archived)
            priority_counts = {'high': 0, 'med': 0, 'low': 0}
            cursor.execute('''
                SELECT priority, COUNT(*) FROM items 
                WHERE kind = "task" AND archived = 0 
                GROUP BY priority
            ''')
            for priority, count in cursor.fetchall():
                if priority in priority_counts:
                    priority_counts[priority] = count
            
            # Get overdue count (excluding archived, only not-done tasks)
            overdue_count = 0
            cursor.execute('''
                SELECT COUNT(*) FROM items 
                WHERE kind = "task" AND done = 0 AND archived = 0 AND due IS NOT NULL AND due < ?
            ''', (today.strftime('%Y-%m-%d'),))
            overdue_count = cursor.fetchone()[0]
            
            return total, done, open_count, priority_counts, overdue_count
        finally:
            conn.close()
    
    def archive_done(self) -> None:
        """Archive all done tasks"""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('UPDATE items SET archived = 1 WHERE kind = "task" AND done = 1')
            conn.commit()
        finally:
            conn.close()
    
    def backup_database(self, path: str) -> None:
        """Backup database to a file using atomic write"""
        temp_path = f"{path}.tmp"
        try:
            shutil.copy2(self.db_path, temp_path)
            os.rename(temp_path, path)
        except Exception as e:
            # Clean up temp file on failure
            if os.path.exists(temp_path):
                os.remove(temp_path)
            raise e
    
    def export_json(self, path: str, show_all: bool = False, tag_filter: Optional[str] = None) -> None:
        """Export all tasks to a JSON file (including archived if show_all is True)"""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Get all tasks using the same query logic as list_tasks
            query, params = self._get_tasks_query(show_all=show_all, tag_filter=tag_filter)
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Convert to task dictionaries for JSON serialization
            task_dicts = []
            for row in rows:
                task_id, title, priority, due, tags_json, done, archived = row
                
                # Convert tags JSON back to list
                tags = json.loads(tags_json) if tags_json else []
                
                task_dict = {
                    'id': task_id,
                    'title': title,
                    'priority': priority,
                    'due': due,
                    'tags': tags,
                    'done': bool(done),
                    'archived': bool(archived)
                }
                task_dicts.append(task_dict)
            
            temp_path = f"{path}.tmp"
            try:
                with open(temp_path, 'w', encoding='utf-8') as f:
                    json.dump(task_dicts, f, indent=2)
                os.rename(temp_path, path)
            except Exception as e:
                # Clean up temp file on failure
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                raise e
        finally:
            conn.close()
    
    def export_csv(self, path: str, show_all: bool = False, tag_filter: Optional[str] = None) -> None:
        """Export all tasks to a CSV file (including archived if show_all is True)"""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Get all tasks using the same query logic as list_tasks
            query, params = self._get_tasks_query(show_all=show_all, tag_filter=tag_filter)
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            temp_path = f"{path}.tmp"
            try:
                with open(temp_path, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    
                    # Write header
                    writer.writerow(['id', 'title', 'priority', 'due', 'tags', 'done', 'archived'])
                    
                    # Write tasks
                    for row in rows:
                        task_id, title, priority, due, tags_json, done, archived = row
                        
                        # Convert tags JSON back to list
                        tags = json.loads(tags_json) if tags_json else []
                        
                        tags_str = ','.join(tags) if tags else ''
                        writer.writerow([
                            task_id,
                            title,
                            priority,
                            due or '',
                            tags_str,
                            int(done),
                            int(archived)
                        ])
                
                os.rename(temp_path, path)
            except Exception as e:
                # Clean up temp file on failure
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                raise e
        finally:
            conn.close()
    
    def compact_database(self) -> None:
        """Reclaim dead space from deleted rows"""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute('VACUUM')
            conn.commit()
        finally:
            conn.close()
    
    def search_tasks(self, text: str) -> List[Task]:
        """Search tasks by title (case-insensitive)"""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            
            # Search for tasks with titles containing the text (case-insensitive)
            cursor.execute('''
                SELECT id, title, priority, due, tags, done, archived FROM items 
                WHERE kind = "task" AND LOWER(title) LIKE ? 
                ORDER BY id
            ''', (f'%{text.lower()}%',))
            
            rows = cursor.fetchall()
            
            tasks = []
            for row in rows:
                task_id, title, priority, due, tags_json, done, archived = row
                
                # Convert tags JSON back to list
                tags = json.loads(tags_json) if tags_json else []
                
                task = Task(
                    id=task_id,
                    title=title,
                    priority=priority,
                    due=due,
                    tags=tags,
                    done=bool(done),
                    archived=bool(archived)
                )
                tasks.append(task)
            
            return tasks
        finally:
            conn.close()

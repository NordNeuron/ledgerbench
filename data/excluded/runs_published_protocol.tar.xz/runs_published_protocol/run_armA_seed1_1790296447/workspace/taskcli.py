import argparse
import json
import os
import sqlite3
import sys
from datetime import datetime

# Database setup
DB_NAME = "tasks.db"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            done BOOLEAN DEFAULT FALSE,
            priority TEXT DEFAULT 'med',
            due DATE,
            archived BOOLEAN DEFAULT FALSE
        )
    ''')
    conn.commit()
    conn.close()

def get_db_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row  # This allows us to access columns by name
    return conn

# Task management functions
def add_task(title, priority='med', due=None):
    if priority not in ['low', 'med', 'high']:
        print("Error: Priority must be 'low', 'med', or 'high'", file=sys.stderr)
        sys.exit(1)
    
    if due is not None:
        try:
            datetime.strptime(due, '%Y-%m-%d')
        except ValueError:
            print("Error: Due date must be in YYYY-MM-DD format", file=sys.stderr)
            sys.exit(1)

    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Get the maximum ID and increment it
    cursor.execute('SELECT MAX(id) as max_id FROM tasks')
    max_id = cursor.fetchone()['max_id']
    new_id = 1 if max_id is None else max_id + 1
    
    cursor.execute(
        'INSERT INTO tasks (id, title, priority, due) VALUES (?, ?, ?, ?)',
        (new_id, title, priority, due)
    )
    conn.commit()
    conn.close()
    
    print(new_id)

def list_tasks(sort_by_priority=False, show_overdue=False, show_all=False):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if sort_by_priority:
        # Order by priority: high, med, low
        if show_all:
            query = '''
                SELECT * FROM tasks 
                ORDER BY 
                    CASE priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 ELSE 3 END,
                    id
            '''
            cursor.execute(query)
        else:
            query = '''
                SELECT * FROM tasks 
                WHERE archived = FALSE
                ORDER BY 
                    CASE priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 ELSE 3 END,
                    id
            '''
            cursor.execute(query)
    elif show_overdue:
        today_str = os.environ.get('TASKCLI_TODAY', datetime.today().strftime('%Y-%m-%d'))
        if show_all:
            query = '''
                SELECT * FROM tasks 
                WHERE due < ? AND done = TRUE
                ORDER BY id
            '''
            cursor.execute(query, (today_str,))
        else:
            query = '''
                SELECT * FROM tasks 
                WHERE due < ? AND done = TRUE AND archived = FALSE
                ORDER BY id
            '''
            cursor.execute(query, (today_str,))
    elif show_all:
        # Show all tasks including archived ones
        cursor.execute('SELECT * FROM tasks ORDER BY id')
    else:
        # Default: insertion order, excluding archived tasks
        cursor.execute('SELECT * FROM tasks WHERE archived = FALSE ORDER BY id')
    
    tasks = cursor.fetchall()
    conn.close()
    
    for task in tasks:
        priority_suffix = f" (priority: {task['priority']})" if task['priority'] != 'med' else ""
        due_suffix = f" (due: {task['due']})" if task['due'] is not None else ""
        done_mark = "✓" if task['done'] else "○"
        print(f"{task['id']} {done_mark} {task['title']}{priority_suffix}{due_suffix}")

def mark_done(task_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT id FROM tasks WHERE id = ?', (task_id,))
    if not cursor.fetchone():
        print(f"Error: No task with id {task_id}", file=sys.stderr)
        sys.exit(1)
        
    cursor.execute('UPDATE tasks SET done = TRUE WHERE id = ?', (task_id,))
    conn.commit()
    conn.close()

def delete_task(task_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT id FROM tasks WHERE id = ?', (task_id,))
    if not cursor.fetchone():
        print(f"Error: No task with id {task_id}", file=sys.stderr)
        sys.exit(1)
        
    cursor.execute('DELETE FROM tasks WHERE id = ?', (task_id,))
    conn.commit()
    conn.close()

def edit_task(task_id, new_title):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT id FROM tasks WHERE id = ?', (task_id,))
    if not cursor.fetchone():
        print(f"Error: No task with id {task_id}", file=sys.stderr)
        sys.exit(1)
        
    cursor.execute('UPDATE tasks SET title = ? WHERE id = ?', (new_title, task_id))
    conn.commit()
    conn.close()

def show_stats():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Total tasks
    cursor.execute('SELECT COUNT(*) as total FROM tasks')
    total_row = cursor.fetchone()
    total = total_row['total'] if total_row['total'] is not None else 0
    
    # Done tasks (including archived ones)
    cursor.execute('SELECT COUNT(*) as done FROM tasks WHERE done = TRUE')
    done_row = cursor.fetchone()
    done = done_row['done'] if done_row['done'] is not None else 0
    
    # Open tasks (excluding archived ones - only non-done, non-archived tasks)
    cursor.execute('SELECT COUNT(*) as open FROM tasks WHERE done = FALSE AND archived = FALSE')
    open_row = cursor.fetchone()
    open_tasks = open_row['open'] if open_row['open'] is not None else 0
    
    # Priority counts (including archived ones)
    cursor.execute('SELECT priority, COUNT(*) as count FROM tasks GROUP BY priority')
    priority_rows = cursor.fetchall()
    
    priority_counts = {}
    for row in priority_rows:
        priority_counts[row['priority']] = row['count']
    
    high_count = priority_counts.get('high', 0)
    med_count = priority_counts.get('med', 0)
    low_count = priority_counts.get('low', 0)
    
    conn.close()
    
    print(f"Total: {total}")
    print(f"Done: {done}")
    print(f"Open: {open_tasks}")
    print(f"Priority high: {high_count}")
    print(f"Priority med: {med_count}")
    print(f"Priority low: {low_count}")

def archive_tasks():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Archive all done tasks that are not already archived
    cursor.execute('UPDATE tasks SET archived = TRUE WHERE done = TRUE AND archived = FALSE')
    conn.commit()
    conn.close()

def main():
    init_db()
    
    parser = argparse.ArgumentParser(description='Minimal task manager')
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['low', 'med', 'high'], default='med',
                           help='Task priority (default: med)')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')

    # List command
    list_parser = subparsers.add_parser('list', help='List all tasks')
    list_parser.add_argument('--sort', choices=['priority'], help='Sort order')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')
    list_parser.add_argument('--all', action='store_true', help='Show all tasks including archived')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Edit command
    edit_parser = subparsers.add_parser('edit', help='Edit a task')
    edit_parser.add_argument('id', type=int, help='Task ID')
    edit_parser.add_argument('--title', required=True, help='New title for the task')

    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show task statistics')

    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive all done tasks')

    args = parser.parse_args()

    if args.command == 'add':
        add_task(args.title, args.priority, args.due)
    elif args.command == 'list':
        sort_by_priority = args.sort == 'priority'
        show_overdue = args.overdue
        show_all = args.all
        list_tasks(sort_by_priority, show_overdue, show_all)
    elif args.command == 'done':
        mark_done(args.id)
    elif args.command == 'delete':
        delete_task(args.id)
    elif args.command == 'edit':
        edit_task(args.id, args.title)
    elif args.command == 'stats':
        show_stats()
    elif args.command == 'archive':
        archive_tasks()
    else:
        parser.print_help()

if __name__ == '__main__':
    main()

import argparse
import os
import sys
from datetime import datetime

from taskcli.storage import (
    add_task, list_tasks, get_task, mark_done, delete_task,
    edit_task, archive_task, get_stats, backup_db, export_tasks, compact_db
)

def parse_date(date_str: str) -> str:
    """Parse and validate a date string."""
    try:
        # Try to parse the date
        parsed = datetime.strptime(date_str, "%Y-%m-%d")
        return date_str  # Return in original format
    except ValueError:
        raise argparse.ArgumentTypeError(f"Invalid date format: {date_str}. Expected YYYY-MM-DD.")

def parse_priority(priority: str) -> str:
    """Validate priority value."""
    valid_priorities = ["low", "med", "high"]
    if priority not in valid_priorities:
        raise argparse.ArgumentTypeError(f"Invalid priority. Must be one of {valid_priorities}")
    return priority

def handle_add(args):
    """Handle the 'add' command."""
    try:
        task_id = add_task(
            title=args.title,
            priority=args.priority,
            due=args.due,
            tags=args.tag
        )
        print(task_id)
    except Exception as e:
        sys.stderr.write(f"Error adding task: {e}\n")
        sys.exit(1)

def handle_list(args):
    """Handle the 'list' command."""
    try:
        tasks = list_tasks(
            done=args.done,
            all_tasks=args.all,
            tag_filter=args.tag,
            sort_by_priority=args.sort_priority
        )
        
        # Determine if we should use colors (only when stdout is a TTY)
        use_colors = sys.stdout.isatty() and args.color
        
        for task in tasks:
            # Format the title with priority and due date
            title_parts = [task['title']]
            
            # Add priority info
            if task['priority'] != 'med':
                title_parts.append(f"(priority: {task['priority']})")
                
            # Add due date info
            if task['due']:
                title_parts.append(f"(due: {task['due']})")
                
            # Add tags info
            if task['tags']:
                title_parts.append(f"(tags: {','.join(task['tags'])})")
            
            title = " ".join(title_parts)
            
            # Format done status
            status_symbol = "✓" if task['done'] else "○"
            
            # Apply colors if needed
            if use_colors:
                if task['due'] and not task['done']:
                    today_str = os.environ.get('TASKCLI_TODAY', datetime.today().strftime('%Y-%m-%d'))
                    try:
                        due_date = datetime.strptime(task['due'], '%Y-%m-%d')
                        today = datetime.strptime(today_str, '%Y-%m-%d')
                        if due_date < today:
                            # Overdue task - red
                            title = f"\033[31m{title}\033[0m"
                    except ValueError:
                        pass  # Invalid date format, skip colorization
                elif task['done']:
                    # Done task - green
                    title = f"\033[32m{title}\033[0m"
            
            print(f"{task['id']}: {status_symbol} {title}")
    except Exception as e:
        sys.stderr.write(f"Error listing tasks: {e}\n")
        sys.exit(1)

def handle_done(args):
    """Handle the 'done' command."""
    try:
        if not mark_done(args.id):
            sys.stderr.write(f"No task found with id {args.id}\n")
            sys.exit(2)
    except Exception as e:
        sys.stderr.write(f"Error marking task done: {e}\n")
        sys.exit(1)

def handle_delete(args):
    """Handle the 'delete' command."""
    try:
        if not delete_task(args.id):
            sys.stderr.write(f"No task found with id {args.id}\n")
            sys.exit(2)
    except Exception as e:
        sys.stderr.write(f"Error deleting task: {e}\n")
        sys.exit(1)

def handle_edit(args):
    """Handle the 'edit' command."""
    try:
        # Build update parameters
        update_params = {}
        
        if args.title is not None:
            update_params['title'] = args.title
            
        if args.priority is not None:
            update_params['priority'] = parse_priority(args.priority)
            
        if args.due is not None:
            update_params['due'] = parse_date(args.due)
            
        if args.tag is not None:
            update_params['tags'] = args.tag
            
        # Check that at least one field to update was provided
        if not update_params:
            sys.stderr.write("No fields to update. Must specify --title, --priority, --due, or --tag.\n")
            sys.exit(2)
            
        if not edit_task(args.id, **update_params):
            sys.stderr.write(f"No task found with id {args.id}\n")
            sys.exit(2)
    except Exception as e:
        sys.stderr.write(f"Error editing task: {e}\n")
        sys.exit(1)

def handle_stats(args):
    """Handle the 'stats' command."""
    try:
        stats = get_stats()
        print(f"Total tasks: {stats['total']}")
        print(f"Done tasks:  {stats['done']}")
        print(f"Open tasks:  {stats['open']}")
        print(f"High priority: {stats['high_priority']}")
        print(f"Medium priority: {stats['med_priority']}")
        print(f"Low priority: {stats['low_priority']}")
    except Exception as e:
        sys.stderr.write(f"Error getting stats: {e}\n")
        sys.exit(1)

def handle_archive(args):
    """Handle the 'archive' command."""
    try:
        # Archive all done tasks
        tasks = list_tasks(done=True, all_tasks=True)
        for task in tasks:
            archive_task(task['id'])
    except Exception as e:
        sys.stderr.write(f"Error archiving tasks: {e}\n")
        sys.exit(1)

def handle_backup(args):
    """Handle the 'backup' command."""
    try:
        backup_db(args.path)
    except Exception as e:
        sys.stderr.write(f"Error creating backup: {e}\n")
        sys.exit(1)

def handle_export(args):
    """Handle the 'export' command."""
    try:
        export_tasks(args.path)
    except Exception as e:
        sys.stderr.write(f"Error exporting tasks: {e}\n")
        sys.exit(1)

def handle_compact(args):
    """Handle the 'compact' command."""
    try:
        compact_db()
    except Exception as e:
        sys.stderr.write(f"Error compacting database: {e}\n")
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(description="Minimal command-line task manager")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', default='med', choices=['low', 'med', 'high'], 
                           help='Task priority (default: med)')
    add_parser.add_argument('--due', type=parse_date, help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--tag', action='append', help='Add a tag to the task (repeatable)')

    # List command
    list_parser = subparsers.add_parser('list', help='List tasks')
    list_parser.add_argument('--done', action='store_true', help='Show only done tasks')
    list_parser.add_argument('--all', action='store_true', help='Show all tasks including archived')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--sort-priority', action='store_true', help='Sort by priority (high to low)')
    list_parser.add_argument('--color', action='store_true', help='Enable colored output')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Edit command
    edit_parser = subparsers.add_parser('edit', help='Edit an existing task')
    edit_parser.add_argument('id', type=int, help='Task ID to edit')
    edit_parser.add_argument('--title', help='New title for the task')
    edit_parser.add_argument('--priority', choices=['low', 'med', 'high'], help='New priority for the task')
    edit_parser.add_argument('--due', type=parse_date, help='New due date in YYYY-MM-DD format')
    edit_parser.add_argument('--tag', action='append', help='New tags for the task (repeatable)')

    # Stats command
    subparsers.add_parser('stats', help='Show task statistics')

    # Archive command
    subparsers.add_parser('archive', help='Archive done tasks')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Create a backup of the database')
    backup_parser.add_argument('path', help='Backup destination path')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export all tasks as JSON')
    export_parser.add_argument('path', help='Export destination path')

    # Compact command
    subparsers.add_parser('compact', help='Compact the database')

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    # Dispatch to appropriate handler
    handlers = {
        'add': handle_add,
        'list': handle_list,
        'done': handle_done,
        'delete': handle_delete,
        'edit': handle_edit,
        'stats': handle_stats,
        'archive': handle_archive,
        'backup': handle_backup,
        'export': handle_export,
        'compact': handle_compact
    }

    try:
        handlers[args.command](args)
    except SystemExit:
        raise  # Let exit calls propagate
    except Exception as e:
        sys.stderr.write(f"Unexpected error: {e}\n")
        sys.exit(1)

if __name__ == "__main__":
    main()

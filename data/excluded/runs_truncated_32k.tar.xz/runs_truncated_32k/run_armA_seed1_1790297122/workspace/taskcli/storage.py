import os
import sqlite3
from typing import List, Optional, Dict, Any
from contextlib import contextmanager

# Database schema version
SCHEMA_VERSION = 2

# Database file name
DB_FILE = "tasks.db"

# Default database connection settings
DEFAULT_TIMEOUT = 30.0

def init_db():
    """Initialize the database with the required schema."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Create items table with tags support
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS items (
            id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            done BOOLEAN DEFAULT FALSE,
            priority TEXT CHECK(priority IN ('low', 'med', 'high')) DEFAULT 'med',
            due DATE,
            archived BOOLEAN DEFAULT FALSE,
            kind TEXT NOT NULL DEFAULT 'task',
            tags TEXT DEFAULT ''
        )
    """)
    
    # Create index on done and archived for better query performance
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_done ON items(done)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_archived ON items(archived)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_items_priority ON items(priority)")
    
    conn.commit()
    conn.close()

@contextmanager
def get_db_connection():
    """Get a database connection with proper timeout handling."""
    conn = None
    try:
        conn = sqlite3.connect(DB_FILE, timeout=DEFAULT_TIMEOUT)
        yield conn
    except sqlite3.Error as e:
        if conn:
            conn.rollback()
        raise e
    finally:
        if conn:
            conn.close()

def get_next_id() -> int:
    """Get the next available task ID."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items")
        return cursor.fetchone()[0]

def add_task(title: str, priority: str = "med", due: Optional[str] = None, 
             tags: List[str] = None) -> int:
    """Add a new task to the database."""
    if tags is None:
        tags = []
    
    task_id = get_next_id()
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO items (id, title, priority, due, tags)
            VALUES (?, ?, ?, ?, ?)
        """, (task_id, title, priority, due, ",".join(tags)))
        conn.commit()
        return task_id

def list_tasks(done: Optional[bool] = None, all_tasks: bool = False, 
               tag_filter: Optional[str] = None, sort_by_priority: bool = False) -> List[Dict[str, Any]]:
    """List tasks with optional filtering and sorting."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        
        # Base query
        query = "SELECT id, title, done, priority, due, archived, tags FROM items WHERE kind = 'task'"
        params = []
        
        # Apply filters
        if not all_tasks:
            query += " AND archived = FALSE"
        if done is not None:
            query += " AND done = ?"
            params.append(done)
        if tag_filter:
            # For tag filtering, we need to match tasks that contain the exact tag
            # We'll use a LIKE pattern that matches comma-separated tags properly
            # This handles cases like: "work" in "work,urgent", "urgent" in "work,urgent"
            query += " AND (tags = ? OR tags LIKE ? OR tags LIKE ? OR tags LIKE ? OR tags LIKE ?)"
            # Match exact tag, tag at start, tag in middle, tag at end, or single tag
            params.extend([tag_filter, f"{tag_filter},%", f"%,{tag_filter}", f"%,{tag_filter},%", f"%{tag_filter}%"])
            
        # Apply sorting - smart list view: all open tasks first (by priority), then done tasks by priority
        if sort_by_priority:
            # When --sort-priority is explicitly used, sort by priority only
            query += " ORDER BY CASE priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 WHEN 'low' THEN 3 ELSE 4 END, id"
        else:
            # Default smart view: all open tasks first (by priority), then done tasks by priority
            if done is not None and not done:
                # For open tasks only, sort by priority
                query += " ORDER BY CASE priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 WHEN 'low' THEN 3 ELSE 4 END, id"
            elif done is not None and done:
                # For done tasks only, sort by priority
                query += " ORDER BY CASE priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 WHEN 'low' THEN 3 ELSE 4 END, id"
            else:
                # For all tasks (default), show open tasks first (by priority), then done tasks (by priority)
                query += " ORDER BY CASE WHEN done = FALSE THEN 0 ELSE 1 END, "
                query += "CASE priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 WHEN 'low' THEN 3 ELSE 4 END, id"
            
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        tasks = []
        for row in rows:
            task = {
                'id': row[0],
                'title': row[1],
                'done': row[2],
                'priority': row[3],
                'due': row[4],
                'archived': row[5],
                'tags': row[6].split(",") if row[6] else []
            }
            tasks.append(task)
            
        return tasks

def get_task(task_id: int) -> Optional[Dict[str, Any]]:
    """Retrieve a specific task by ID."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, title, done, priority, due, archived, tags FROM items WHERE id = ? AND kind = 'task'", (task_id,))
        row = cursor.fetchone()
        if row:
            return {
                'id': row[0],
                'title': row[1],
                'done': row[2],
                'priority': row[3],
                'due': row[4],
                'archived': row[5],
                'tags': row[6].split(",") if row[6] else []
            }
        return None

def mark_done(task_id: int) -> bool:
    """Mark a task as done."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE items SET done = TRUE WHERE id = ? AND kind = 'task'", (task_id,))
        conn.commit()
        return cursor.rowcount > 0

def delete_task(task_id: int) -> bool:
    """Delete a task."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM items WHERE id = ? AND kind = 'task'", (task_id,))
        conn.commit()
        return cursor.rowcount > 0

def edit_task(task_id: int, title: Optional[str] = None, 
              priority: Optional[str] = None, due: Optional[str] = None,
              tags: Optional[List[str]] = None) -> bool:
    """Edit an existing task."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        
        # Build dynamic update query
        updates = []
        params = []
        
        if title is not None:
            updates.append("title = ?")
            params.append(title)
        if priority is not None:
            updates.append("priority = ?")
            params.append(priority)
        if due is not None:
            updates.append("due = ?")
            params.append(due)
        if tags is not None:
            updates.append("tags = ?")
            params.append(",".join(tags))
            
        if not updates:
            return False
            
        # Add task ID to params
        params.append(task_id)
        
        query = f"UPDATE items SET {', '.join(updates)} WHERE id = ? AND kind = 'task'"
        cursor.execute(query, params)
        conn.commit()
        return cursor.rowcount > 0

def archive_task(task_id: int) -> bool:
    """Archive a task."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE items SET archived = TRUE WHERE id = ? AND kind = 'task'", (task_id,))
        conn.commit()
        return cursor.rowcount > 0

def list_archived_tasks() -> List[Dict[str, Any]]:
    """List all archived tasks."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, title, done, priority, due, archived, tags FROM items WHERE kind = 'task' AND archived = TRUE ORDER BY id")
        rows = cursor.fetchall()
        
        tasks = []
        for row in rows:
            task = {
                'id': row[0],
                'title': row[1],
                'done': row[2],
                'priority': row[3],
                'due': row[4],
                'archived': row[5],
                'tags': row[6].split(",") if row[6] else []
            }
            tasks.append(task)
        return tasks

def get_stats() -> Dict[str, int]:
    """Get statistics about tasks."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        
        # Total tasks
        cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task'")
        total = cursor.fetchone()[0]
        
        # Done tasks
        cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task' AND done = TRUE")
        done = cursor.fetchone()[0]
        
        # Open tasks
        open_tasks = total - done
        
        # Priority breakdowns
        cursor.execute("SELECT priority, COUNT(*) FROM items WHERE kind = 'task' GROUP BY priority")
        priority_counts = dict(cursor.fetchall())
        
        return {
            'total': total,
            'done': done,
            'open': open_tasks,
            'high_priority': priority_counts.get('high', 0),
            'med_priority': priority_counts.get('med', 0),
            'low_priority': priority_counts.get('low', 0)
        }

def backup_db(destination: str) -> None:
    """Create a backup of the database."""
    with get_db_connection() as conn:
        backup_conn = sqlite3.connect(destination)
        conn.backup(backup_conn)
        backup_conn.close()

def export_tasks(destination: str) -> None:
    """Export all tasks to a JSON file."""
    import json
    tasks = list_tasks(all_tasks=True)
    with open(destination, 'w') as f:
        json.dump(tasks, f, indent=2)

def compact_db() -> None:
    """Compact the database by running VACUUM."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("VACUUM")
        conn.commit()

def migrate_schema():
    """Migrate from older schema versions if needed."""
    # This function would handle any necessary migrations
    pass

"""A minimal command-line task manager."""

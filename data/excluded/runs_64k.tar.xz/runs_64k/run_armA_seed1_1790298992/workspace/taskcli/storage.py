import sqlite3
import json
import os
import shutil
import csv
from datetime import datetime, date
from contextlib import contextmanager

class TaskStorage:
    def __init__(self, db_path='tasks.db'):
        self.db_path = db_path
        self.init_database()
        
    def init_database(self):
        """Initialize the database with required tables and migrate data if needed."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if old 'tasks' table exists (migration case)
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='tasks'")
        if cursor.fetchone():
            # Migrate from old tasks table to new items table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT 0,
                    priority TEXT DEFAULT 'med',
                    due DATE,
                    archived BOOLEAN DEFAULT 0,
                    kind TEXT DEFAULT 'task'
                )
            """)
            
            # Migrate data
            cursor.execute("""
                INSERT INTO items (id, title, done, priority, due, archived, kind)
                SELECT id, title, done, priority, due, archived, 'task' FROM tasks
            """)
            
            # Drop old table
            cursor.execute("DROP TABLE tasks")
            
        else:
            # Create new items table if it doesn't exist
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    done BOOLEAN DEFAULT 0,
                    priority TEXT DEFAULT 'med',
                    due DATE,
                    archived BOOLEAN DEFAULT 0,
                    kind TEXT DEFAULT 'task'
                )
            """)
            
        conn.commit()
        conn.close()
        
    @contextmanager
    def get_connection(self):
        """Context manager for database connections."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row  # This allows us to access columns by name
        try:
            yield conn
        finally:
            conn.close()
            
    def add_task(self, title, priority='med', due=None, tags=None):
        """Add a new task and return its ID."""
        if due:
            try:
                datetime.strptime(due, '%Y-%m-%d')
            except ValueError:
                raise ValueError("Invalid date format. Use YYYY-MM-DD.")
                
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Get the maximum existing ID and increment it
            cursor.execute("SELECT MAX(id) FROM items")
            max_id = cursor.fetchone()[0]
            task_id = (max_id or 0) + 1
            
            # Insert the new task
            cursor.execute("""
                INSERT INTO items (id, title, priority, due, kind)
                VALUES (?, ?, ?, ?, ?)
            """, (task_id, title, priority, due, 'task'))
            
            conn.commit()
            return task_id
            
    def list_tasks(self, sort_by='id', show_all=False, show_overdue=False, tag_filter=None, smart=False):
        """List all tasks."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Base query
            query = "SELECT * FROM items WHERE kind = 'task'"
            params = []
            
            # Filter out archived tasks unless show_all is True
            if not show_all:
                query += " AND archived = 0"
                
            # Filter by tag if specified
            if tag_filter:
                query += " AND id IN (SELECT item_id FROM item_tags WHERE tag = ?)"
                params.append(tag_filter)
                
            # Filter overdue tasks if requested
            if show_overdue:
                query += " AND due IS NOT NULL AND due < ? AND done = 0"
                today = os.environ.get('TASKCLI_TODAY', str(date.today()))
                params.append(today)
                
            # Add sorting
            if smart:
                # Overdue first, then sort by priority (high, med, low), then by id
                query += """
                    ORDER BY 
                        CASE WHEN due IS NOT NULL AND due < ? AND done = 0 THEN 0 ELSE 1 END,
                        CASE priority WHEN 'high' THEN 0 WHEN 'med' THEN 1 WHEN 'low' THEN 2 ELSE 3 END,
                        id
                """
                today = os.environ.get('TASKCLI_TODAY', str(date.today()))
                params.append(today)
            elif sort_by == 'priority':
                # Sort by priority (high, med, low), then by id
                query += """
                    ORDER BY 
                        CASE priority WHEN 'high' THEN 0 WHEN 'med' THEN 1 WHEN 'low' THEN 2 ELSE 3 END,
                        id
                """
            else:
                # Default sort by id
                query += " ORDER BY id"
                
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Add overdue flag to each task for display purposes
            tasks = []
            today = os.environ.get('TASKCLI_TODAY', str(date.today()))
            for row in rows:
                task = dict(row)
                task['overdue'] = (
                    task['due'] is not None and 
                    task['due'] < today and 
                    not task['done']
                )
                tasks.append(task)
                
            return tasks
            
    def mark_done(self, task_id):
        """Mark a task as done."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"No task found with ID {task_id}")
                
            cursor.execute("UPDATE items SET done = 1 WHERE id = ?", (task_id,))
            conn.commit()
            
    def delete_task(self, task_id):
        """Delete a task."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"No task found with ID {task_id}")
                
            cursor.execute("DELETE FROM items WHERE id = ?", (task_id,))
            conn.commit()
            
    def edit_task_title(self, task_id, new_title):
        """Edit a task's title."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM items WHERE id = ? AND kind = 'task'", (task_id,))
            if not cursor.fetchone():
                raise ValueError(f"No task found with ID {task_id}")
                
            cursor.execute("UPDATE items SET title = ? WHERE id = ?", (new_title, task_id))
            conn.commit()
            
    def get_stats(self):
        """Get statistics about tasks."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Total tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE kind = 'task'")
            total = cursor.fetchone()[0]
            
            # Done tasks
            cursor.execute("SELECT COUNT(*) FROM items WHERE done = 1 AND kind = 'task'")
            done = cursor.fetchone()[0]
            
            # Open tasks
            open_tasks = total - done
            
            # Priority counts
            cursor.execute("SELECT priority, COUNT(*) FROM items WHERE kind = 'task' GROUP BY priority")
            priority_counts = dict(cursor.fetchall())
            
            return {
                'total': total,
                'done': done,
                'open': open_tasks,
                'priority_high': priority_counts.get('high', 0),
                'priority_med': priority_counts.get('med', 0),
                'priority_low': priority_counts.get('low', 0)
            }
            
    def archive_done_tasks(self):
        """Archive all done tasks."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE items SET archived = 1 WHERE done = 1 AND kind = 'task'")
            conn.commit()
            
    def backup_database(self, backup_path):
        """Create a backup of the database."""
        try:
            # Create temporary backup file
            temp_backup = f"{backup_path}.tmp"
            shutil.copy2(self.db_path, temp_backup)
            
            # Atomically replace original file
            os.replace(temp_backup, backup_path)
        except Exception as e:
            raise Exception(f"Failed to create backup: {e}")
            
    def export_to_json(self, export_path):
        """Export tasks to JSON."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # This is the exact same query logic as list_tasks but without any filtering
            # and always sorted by id (the default)
            query = "SELECT * FROM items WHERE kind = 'task' ORDER BY id"
            params = []
                
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            tasks = [dict(row) for row in rows]
            
            with open(export_path, 'w') as f:
                json.dump(tasks, f, indent=2)
                
    def export_to_csv(self, export_path):
        """Export tasks to CSV."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # This is the exact same query logic as list_tasks but without any filtering
            # and always sorted by id (the default)
            query = "SELECT * FROM items WHERE kind = 'task' ORDER BY id"
            params = []
                
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            if not rows:
                return
                
            # Get column names
            fieldnames = rows[0].keys()
            
            with open(export_path, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for row in rows:
                    writer.writerow(dict(row))
                    
    def compact_database(self):
        """Compact the database file."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("VACUUM")
            conn.commit()
            
    def list_tags(self):
        """List all unique tags."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT DISTINCT tag FROM item_tags ORDER BY tag
            """)
            rows = cursor.fetchall()
            return [row[0] for row in rows]
            
    def search_tasks(self, text):
        """Search tasks by title (case-insensitive)."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Search for tasks containing the text in title (case-insensitive)
            query = """
                SELECT * FROM items 
                WHERE kind = 'task' AND LOWER(title) LIKE ?
                ORDER BY id
            """
            params = [f'%{text.lower()}%']
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Add overdue flag to each task for display purposes
            tasks = []
            today = os.environ.get('TASKCLI_TODAY', str(date.today()))
            for row in rows:
                task = dict(row)
                task['overdue'] = (
                    task['due'] is not None and 
                    task['due'] < today and 
                    not task['done']
                )
                tasks.append(task)
                
            return tasks

import argparse
import os
import sys
from . import __version__
from .storage import TaskStorage

def create_parser():
    parser = argparse.ArgumentParser(
        prog='taskcli',
        description='A minimal command-line task manager.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""Commands:
  add <title>                     — add a new task
  list                            — list all tasks
  done <id>                       — mark a task as done
  delete <id>                     — delete a task
  edit <id> --title "new title"   — edit a task's title
  stats                           — show task statistics
  archive                         — archive completed tasks
  backup <path>                   — create database backup
  export <path>                   — export tasks to JSON
  compact                         — compact database file
  tags                            — list all tags
  search <text>                   — search tasks by title
"""
    )
    
    parser.add_argument('--version', action='version', version=f'%(prog)s {__version__}')
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['high', 'med', 'low'], default='med',
                           help='Task priority (default: med)')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--tag', action='append', help='Add a tag to the task')

    # List command
    list_parser = subparsers.add_parser('list', help='List tasks')
    list_parser.add_argument('--sort', choices=['id', 'priority'], default='id',
                            help='Sort by id or priority (default: id)')
    list_parser.add_argument('--all', action='store_true',
                            help='Show archived tasks too')
    list_parser.add_argument('--overdue', action='store_true',
                            help='Show only overdue tasks')
    list_parser.add_argument('--tag', help='Filter by tag')
    list_parser.add_argument('--color', choices=['auto', 'always', 'never'],
                            default='auto', help='Color output (default: auto)')
    list_parser.add_argument('--smart', action='store_true',
                            help='Show overdue tasks first, then sort by priority')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Edit command
    edit_parser = subparsers.add_parser('edit', help='Edit a task')
    edit_parser.add_argument('id', type=int, help='Task ID')
    edit_parser.add_argument('--title', help='New title for the task')

    # Stats command
    subparsers.add_parser('stats', help='Show task statistics')

    # Archive command
    subparsers.add_parser('archive', help='Archive completed tasks')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Create database backup')
    backup_parser.add_argument('path', help='Backup file path')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks to JSON')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json',
                              help='Export format (default: json)')

    # Compact command
    subparsers.add_parser('compact', help='Compact database file')

    # Tags command
    subparsers.add_parser('tags', help='List all tags')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Text to search for in task titles')

    return parser

def main():
    parser = create_parser()
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
        
    # Emit audit line at the start of command execution
    sys.stderr.write(f"AUDIT {args.command}\n")
    
    if args.command == 'add':
        try:
            storage = TaskStorage()
            task_id = storage.add_task(
                title=args.title,
                priority=args.priority,
                due=args.due,
                tags=args.tag or []
            )
            print(task_id)
        except ValueError as e:
            sys.stderr.write(f"Error: {e}\n")
            sys.exit(2)
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            sys.exit(1)
    elif args.command == 'list':
        try:
            storage = TaskStorage()
            tasks = storage.list_tasks(
                sort_by=args.sort,
                show_all=args.all,
                show_overdue=args.overdue,
                tag_filter=args.tag,
                smart=args.smart
            )
            
            if not tasks:
                return
                
            # Determine if we should use color
            use_color = False
            if args.color == 'always':
                use_color = True
            elif args.color == 'auto' and sys.stdout.isatty():
                use_color = True
                
            for task in tasks:
                done_str = "✓" if task['done'] else "○"
                priority_str = f"(priority: {task['priority']})" if task['priority'] else ""
                
                # Format due date
                due_str = ""
                if task['due']:
                    due_str = f" (due: {task['due']})"
                    
                # Format tags
                tags_str = ""
                if task['tags']:
                    tags_str = f" [tags: {', '.join(task['tags'])}]"
                
                # Colorize output if needed
                if use_color:
                    if task['overdue']:
                        print(f"\033[31m{task['id']}: {done_str} {task['title']} {priority_str}{due_str}{tags_str}\033[0m")
                    elif task['done']:
                        print(f"\033[32m{task['id']}: {done_str} {task['title']} {priority_str}{due_str}{tags_str}\033[0m")
                    else:
                        print(f"{task['id']}: {done_str} {task['title']} {priority_str}{due_str}{tags_str}")
                else:
                    print(f"{task['id']}: {done_str} {task['title']} {priority_str}{due_str}{tags_str}")
                    
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            sys.exit(1)
    elif args.command == 'done':
        try:
            storage = TaskStorage()
            storage.mark_done(args.id)
        except ValueError as e:
            sys.stderr.write(f"Error: {e}\n")
            sys.exit(2)
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            sys.exit(1)
    elif args.command == 'delete':
        try:
            storage = TaskStorage()
            storage.delete_task(args.id)
        except ValueError as e:
            sys.stderr.write(f"Error: {e}\n")
            sys.exit(2)
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            sys.exit(1)
    elif args.command == 'edit':
        try:
            storage = TaskStorage()
            if args.title is not None:
                storage.edit_task_title(args.id, args.title)
        except ValueError as e:
            sys.stderr.write(f"Error: {e}\n")
            sys.exit(2)
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            sys.exit(1)
    elif args.command == 'stats':
        try:
            storage = TaskStorage()
            stats = storage.get_stats()
            print(f"Total: {stats['total']}")
            print(f"Done: {stats['done']}")
            print(f"Open: {stats['open']}")
            print(f"Priority high: {stats['priority_high']}")
            print(f"Priority med: {stats['priority_med']}")
            print(f"Priority low: {stats['priority_low']}")
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            sys.exit(1)
    elif args.command == 'archive':
        try:
            storage = TaskStorage()
            storage.archive_done_tasks()
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            sys.exit(1)
    elif args.command == 'backup':
        try:
            storage = TaskStorage()
            storage.backup_database(args.path)
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            sys.exit(1)
    elif args.command == 'export':
        try:
            storage = TaskStorage()
            if args.format == 'csv':
                storage.export_to_csv(args.path)
            else:
                storage.export_to_json(args.path)
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            sys.exit(1)
    elif args.command == 'compact':
        try:
            storage = TaskStorage()
            storage.compact_database()
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            sys.exit(1)
    elif args.command == 'tags':
        try:
            storage = TaskStorage()
            tags = storage.list_tags()
            for tag in sorted(tags):
                print(tag)
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            sys.exit(1)
    elif args.command == 'search':
        try:
            storage = TaskStorage()
            tasks = storage.search_tasks(args.text)
            if not tasks:
                return
                
            # Determine if we should use color
            use_color = False
            if sys.stdout.isatty():
                use_color = True
                
            for task in tasks:
                done_str = "✓" if task['done'] else "○"
                priority_str = f"(priority: {task['priority']})" if task['priority'] else ""
                
                # Format due date
                due_str = ""
                if task['due']:
                    due_str = f" (due: {task['due']})"
                    
                # Format tags
                tags_str = ""
                if task['tags']:
                    tags_str = f" [tags: {', '.join(task['tags'])}]"
                
                # Colorize output if needed
                if use_color:
                    if task['overdue']:
                        print(f"\033[31m{task['id']}: {done_str} {task['title']} {priority_str}{due_str}{tags_str}\033[0m")
                    elif task['done']:
                        print(f"\033[32m{task['id']}: {done_str} {task['title']} {priority_str}{due_str}{tags_str}\033[0m")
                    else:
                        print(f"{task['id']}: {done_str} {task['title']} {priority_str}{due_str}{tags_str}")
                else:
                    print(f"{task['id']}: {done_str} {task['title']} {priority_str}{due_str}{tags_str}")
                    
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            sys.exit(1)

if __name__ == '__main__':
    main()

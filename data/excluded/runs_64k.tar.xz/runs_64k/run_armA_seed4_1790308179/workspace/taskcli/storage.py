#!/usr/bin/env python3

import json
import os
import sqlite3
import sys
import shutil
from datetime import datetime, date
import csv
from pathlib import Path

class TaskStorage:
    def __init__(self, db_path="tasks.db"):
        self.db_path = db_path
        self.init_db()
        
    def init_db(self):
        # Check if we have a legacy tasks.json file to migrate
        json_file = "tasks.json"
        if os.path.exists(json_file) and not os.path.exists(self.db_path):
            self.migrate_from_json(json_file)
            
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create the items table with all required columns
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                done BOOLEAN DEFAULT FALSE,
                priority TEXT DEFAULT 'med',
                due TEXT,
                archived BOOLEAN DEFAULT FALSE,
                kind TEXT DEFAULT 'task'
            )
        """)
        
        # Create tags table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tags (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL
            )
        """)
        
        # Create junction table for task-tags
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS task_tags (
                task_id INTEGER,
                tag_id INTEGER,
                PRIMARY KEY (task_id, tag_id),
                FOREIGN KEY (task_id) REFERENCES items (id),
                FOREIGN KEY (tag_id) REFERENCES tags (id)
            )
        """)
        
        conn.commit()
        conn.close()
        
    def migrate_from_json(self, json_file):
        """Migrate tasks from legacy JSON format to SQLite"""
        try:
            with open(json_file, 'r') as f:
                tasks = json.load(f)
                
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            for task in tasks:
                # Insert task
                cursor.execute("""
                    INSERT INTO items (id, title, done, priority, due, archived, kind)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (
                    task["id"],
                    task["title"],
                    task["done"],
                    task.get("priority", "med"),
                    task.get("due"),
                    False,  # Not archived
                    "task"
                ))
                
                # Insert tags if any
                if "tags" in task and task["tags"]:
                    for tag_name in task["tags"]:
                        # Insert or get tag
                        cursor.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (tag_name,))
                        cursor.execute("SELECT id FROM tags WHERE name = ?", (tag_name,))
                        tag_id = cursor.fetchone()[0]
                        
                        # Link task and tag
                        cursor.execute(
                            "INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?, ?)",
                            (task["id"], tag_id)
                        )
            
            conn.commit()
            conn.close()
            
            # Remove the legacy file
            os.remove(json_file)
            
        except Exception as e:
            raise Exception(f"Failed to migrate from JSON: {str(e)}")
    
    def get_next_id(self):
        """Get the next available task ID"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items")
        next_id = cursor.fetchone()[0]
        conn.close()
        return next_id
    
    def add_task(self, title, priority=None, due=None, tags=None):
        """Add a new task and return its ID"""
        if due:
            try:
                datetime.strptime(due, "%Y-%m-%d")
            except ValueError:
                raise Exception("Invalid date format. Use YYYY-MM-DD.")
        
        # Get default priority from config or use 'med'
        default_priority = self.get_default_priority()
        if priority is None:
            priority = default_priority
            
        task_id = self.get_next_id()
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO items (id, title, done, priority, due, kind)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (task_id, title, False, priority, due, "task"))
        
        # Add tags if any
        if tags:
            for tag_name in tags:
                # Insert or get tag
                cursor.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (tag_name,))
                cursor.execute("SELECT id FROM tags WHERE name = ?", (tag_name,))
                tag_id = cursor.fetchone()[0]
                
                # Link task and tag
                cursor.execute(
                    "INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?, ?)",
                    (task_id, tag_id)
                )
        
        conn.commit()
        conn.close()
        return task_id
    
    def _build_list_query(self, sort=False, overdue=False, all=False, tag=None):
        """Build the base query for listing tasks"""
        # Build base query
        if tag:
            # Join with task_tags and tags tables to filter by tag
            query = """
                SELECT DISTINCT i.id, i.title, i.done, i.priority, i.due, i.archived
                FROM items i
                JOIN task_tags tt ON i.id = tt.task_id
                JOIN tags t ON tt.tag_id = t.id
                WHERE t.name = ? AND i.archived = ?
            """
            params = [tag, all or False]
        else:
            query = "SELECT id, title, done, priority, due, archived FROM items WHERE archived = ?"
            params = [all or False]
            
        # Add overdue filter
        if overdue:
            today_str = self.get_today()
            query += " AND done = 0 AND due < ?"
            params.append(today_str)
        
        return query, params
    
    def list_tasks(self, sort=False, overdue=False, all=False, tag=None):
        """List all tasks"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Build base query
        query, params = self._build_list_query(sort=sort, overdue=overdue, all=all, tag=tag)
        
        # Add sorting
        if sort:
            # Sort by priority (high, med, low) then by id
            query += """
                ORDER BY 
                    CASE priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 ELSE 3 END,
                    id
            """
        else:
            # Default: show overdue first, then by priority, then by id
            today_str = self.get_today()
            query += f"""
                ORDER BY 
                    CASE WHEN done = 0 AND due < '{today_str}' THEN 1 ELSE 2 END,
                    CASE priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 ELSE 3 END,
                    id
            """
            
        cursor.execute(query, params)
        tasks = cursor.fetchall()
        
        # Convert to list of dictionaries with additional computed fields
        result = []
        for task in tasks:
            task_dict = {
                "id": task[0],
                "title": task[1],
                "done": task[2],
                "priority": task[3],
                "due": task[4],
                "archived": task[5]
            }
            
            # Add overdue flag for display
            if task_dict["due"] and not task_dict["done"]:
                today_str = self.get_today()
                if task_dict["due"] < today_str:
                    task_dict["overdue"] = True
                    
            result.append(task_dict)
            
        conn.close()
        return result
    
    def mark_done(self, task_id):
        """Mark a task as done"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("UPDATE items SET done = 1 WHERE id = ?", (task_id,))
        
        if cursor.rowcount == 0:
            raise Exception(f"Task with ID {task_id} not found")
            
        conn.commit()
        conn.close()
    
    def delete_task(self, task_id):
        """Delete a task"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM items WHERE id = ?", (task_id,))
        
        if cursor.rowcount == 0:
            raise Exception(f"Task with ID {task_id} not found")
            
        conn.commit()
        conn.close()
    
    def edit_task(self, task_id, title=None, priority=None, due=None, tags=None):
        """Edit a task"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Validate that task exists
        cursor.execute("SELECT id FROM items WHERE id = ?", (task_id,))
        if not cursor.fetchone():
            raise Exception(f"Task with ID {task_id} not found")
            
        # Update fields if provided
        if title is not None:
            cursor.execute("UPDATE items SET title = ? WHERE id = ?", (title, task_id))
            
        if priority is not None:
            cursor.execute("UPDATE items SET priority = ? WHERE id = ?", (priority, task_id))
            
        if due is not None:
            try:
                datetime.strptime(due, "%Y-%m-%d")
            except ValueError:
                raise Exception("Invalid date format. Use YYYY-MM-DD.")
            cursor.execute("UPDATE items SET due = ? WHERE id = ?", (due, task_id))
        
        # Handle tags
        if tags is not None:
            # Remove all existing tags for this task
            cursor.execute("DELETE FROM task_tags WHERE task_id = ?", (task_id,))
            
            # Add new tags
            for tag_name in tags:
                # Insert or get tag
                cursor.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (tag_name,))
                cursor.execute("SELECT id FROM tags WHERE name = ?", (tag_name,))
                tag_id = cursor.fetchone()[0]
                
                # Link task and tag
                cursor.execute(
                    "INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?, ?)",
                    (task_id, tag_id)
                )
        
        conn.commit()
        conn.close()
    
    def get_stats(self):
        """Get task statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Total tasks
        cursor.execute("SELECT COUNT(*) FROM items WHERE archived = 0")
        total = cursor.fetchone()[0]
        
        # Completed tasks
        cursor.execute("SELECT COUNT(*) FROM items WHERE done = 1 AND archived = 0")
        completed = cursor.fetchone()[0]
        
        # Pending tasks
        pending = total - completed
        
        # Overdue tasks
        today_str = self.get_today()
        cursor.execute("""
            SELECT COUNT(*) FROM items 
            WHERE done = 0 AND due < ? AND archived = 0
        """, (today_str,))
        overdue = cursor.fetchone()[0]
        
        conn.close()
        return {
            "total": total,
            "completed": completed,
            "pending": pending,
            "overdue": overdue
        }
    
    def archive_done_tasks(self):
        """Archive all done tasks"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("UPDATE items SET archived = 1 WHERE done = 1 AND archived = 0")
        conn.commit()
        conn.close()
    
    def backup(self, path):
        """Create a backup of the database"""
        try:
            # Create temporary file
            temp_path = path + ".tmp"
            shutil.copy2(self.db_path, temp_path)
            
            # Atomically rename to target path
            os.replace(temp_path, path)
            
        except Exception as e:
            raise Exception(f"Failed to create backup: {str(e)}")
    
    def export_tasks(self, path, format="json", tasks=None):
        """Export tasks to a file"""
        # If no tasks provided, get them using the same logic as list
        if tasks is None:
            tasks = self.list_tasks(all=True)  # Include archived tasks
            
        if format == "csv":
            with open(path, 'w', newline='') as csvfile:
                if not tasks:
                    csvfile.write("")  # Empty CSV
                else:
                    fieldnames = ["id", "title", "done", "priority", "due", "archived"]
                    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                    writer.writeheader()
                    for task in tasks:
                        # Convert done to boolean string
                        task["done"] = str(task["done"]).lower()
                        task["archived"] = str(task["archived"]).lower()
                        writer.writerow(task)
        else:  # JSON format
            with open(path, 'w') as jsonfile:
                json.dump(tasks, jsonfile, indent=2)
    
    def compact_database(self):
        """Compact the database to reclaim space"""
        conn = sqlite3.connect(self.db_path)
        conn.execute("VACUUM")
        conn.close()
        
    def search_tasks(self, text):
        """Search for tasks by title (case-insensitive)"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Search in titles (case-insensitive)
        query = """
            SELECT id, title, done, priority, due, archived 
            FROM items 
            WHERE LOWER(title) LIKE ?
            AND archived = 0
            ORDER BY 
                CASE priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 ELSE 3 END,
                id
        """
        
        cursor.execute(query, (f"%{text.lower()}%",))
        tasks = cursor.fetchall()
        
        # Convert to list of dictionaries with additional computed fields
        result = []
        for task in tasks:
            task_dict = {
                "id": task[0],
                "title": task[1],
                "done": task[2],
                "priority": task[3],
                "due": task[4],
                "archived": task[5]
            }
            
            # Add overdue flag for display
            if task_dict["due"] and not task_dict["done"]:
                today_str = self.get_today()
                if task_dict["due"] < today_str:
                    task_dict["overdue"] = True
                    
            result.append(task_dict)
            
        conn.close()
        return result
    
    def get_today(self):
        """Get today's date as string (YYYY-MM-DD)"""
        # Check for TASKCLI_TODAY environment variable first
        today_env = os.environ.get("TASKCLI_TODAY")
        if today_env:
            try:
                datetime.strptime(today_env, "%Y-%m-%d")
                return today_env
            except ValueError:
                # Invalid date format in env var, ignore it
                pass
                
        # Check for config.toml file
        config_file = "config.toml"
        if os.path.exists(config_file):
            try:
                import toml
                config = toml.load(config_file)
                today_config = config.get("today")
                if today_config:
                    try:
                        datetime.strptime(today_config, "%Y-%m-%d")
                        return today_config
                    except ValueError:
                        # Invalid date format in config, ignore it
                        pass
            except ImportError:
                # toml not available, continue with default
                pass
                
        # Default to current date
        return date.today().strftime("%Y-%m-%d")
        
    def get_default_priority(self):
        """Get default priority from config or use 'med'"""
        # Check for config.toml file
        config_file = "config.toml"
        if os.path.exists(config_file):
            try:
                import toml
                config = toml.load(config_file)
                priority = config.get("default_priority")
                if priority in ["low", "med", "high"]:
                    return priority
            except ImportError:
                # toml not available, continue with default
                pass
                
        # Default priority
        return "med"

#!/usr/bin/env python3

import argparse
import os
import sys
from .storage import TaskStorage

def create_parser():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("--priority", choices=["low", "med", "high"], default=None,
                           help="Task priority (default: med)")
    add_parser.add_argument("--due", help="Due date (YYYY-MM-DD)")
    add_parser.add_argument("--tag", action="append", help="Add a tag (can be used multiple times)")

    # List command
    list_parser = subparsers.add_parser("list", help="List all tasks")
    list_parser.add_argument("--sort", action="store_true", help="Sort by priority (high to low)")
    list_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")
    list_parser.add_argument("--all", action="store_true", help="Show archived tasks too")
    list_parser.add_argument("--color", action="store_true", help="Enable colored output")
    list_parser.add_argument("--tag", help="Filter by tag")

    # Done command
    done_parser = subparsers.add_parser("done", help="Mark a task as done")
    done_parser.add_argument("id", type=int, help="Task ID")

    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")

    # Edit command
    edit_parser = subparsers.add_parser("edit", help="Edit a task")
    edit_parser.add_argument("id", type=int, help="Task ID")
    edit_parser.add_argument("--title", help="New title")
    edit_parser.add_argument("--priority", choices=["low", "med", "high"], help="New priority")
    edit_parser.add_argument("--due", help="New due date (YYYY-MM-DD)")
    edit_parser.add_argument("--tag", action="append", help="Add or remove a tag (can be used multiple times)")

    # Stats command
    subparsers.add_parser("stats", help="Show task statistics")

    # Archive command
    subparsers.add_parser("archive", help="Archive all done tasks")

    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Create a backup of the database")
    backup_parser.add_argument("path", help="Backup file path")

    # Export command
    export_parser = subparsers.add_parser("export", help="Export tasks to a file")
    export_parser.add_argument("path", help="Export file path")
    export_parser.add_argument("--format", choices=["json", "csv"], default="json",
                              help="Export format (default: json)")
    export_parser.add_argument("--sort", action="store_true", help="Sort by priority (high to low)")
    export_parser.add_argument("--overdue", action="store_true", help="Show only overdue tasks")
    export_parser.add_argument("--all", action="store_true", help="Show archived tasks too")
    export_parser.add_argument("--tag", help="Filter by tag")

    # Compact command
    subparsers.add_parser("compact", help="Compact the database")

    # Search command
    search_parser = subparsers.add_parser("search", help="Search for tasks by title")
    search_parser.add_argument("text", help="Text to search for in task titles")

    return parser

def main():
    parser = create_parser()
    args = parser.parse_args()

    # Always emit audit line
    command_name = args.command if args.command else "help"
    print(f"AUDIT {command_name}", file=sys.stderr)

    if not args.command:
        parser.print_help()
        return 2

    storage = TaskStorage()
    
    try:
        if args.command == "add":
            task_id = storage.add_task(
                title=args.title,
                priority=args.priority,
                due=args.due,
                tags=args.tag or []
            )
            print(task_id)
            
        elif args.command == "list":
            tasks = storage.list_tasks(sort=args.sort, overdue=args.overdue, all=args.all, tag=args.tag)
            for task in tasks:
                done_str = "✓" if task["done"] else "○"
                if args.color and sys.stdout.isatty():
                    if task["done"]:
                        print(f"\033[32m{task['id']}: [{done_str}] {task['title']}\033[0m")
                    elif task.get("overdue", False):
                        print(f"\033[31m{task['id']}: [{done_str}] {task['title']}\033[0m")
                    else:
                        print(f"{task['id']}: [{done_str}] {task['title']}")
                else:
                    print(f"{task['id']}: [{done_str}] {task['title']}")
                    
        elif args.command == "done":
            storage.mark_done(args.id)
            
        elif args.command == "delete":
            storage.delete_task(args.id)
            
        elif args.command == "edit":
            storage.edit_task(
                task_id=args.id,
                title=args.title,
                priority=args.priority,
                due=args.due,
                tags=args.tag
            )
            
        elif args.command == "stats":
            stats = storage.get_stats()
            print(f"Total tasks: {stats['total']}")
            print(f"Completed tasks: {stats['completed']}")
            print(f"Pending tasks: {stats['pending']}")
            if stats['overdue']:
                print(f"\033[31mOverdue tasks: {stats['overdue']}\033[0m")
            else:
                print(f"Overdue tasks: {stats['overdue']}")
                
        elif args.command == "archive":
            storage.archive_done_tasks()
            
        elif args.command == "backup":
            storage.backup(args.path)
            
        elif args.command == "export":
            # Use the same filtering logic as list command
            tasks = storage.list_tasks(sort=args.sort, overdue=args.overdue, all=args.all, tag=args.tag)
            storage.export_tasks(args.path, format=args.format, tasks=tasks)
            
        elif args.command == "compact":
            storage.compact_database()
            
        elif args.command == "search":
            tasks = storage.search_tasks(args.text)
            for task in tasks:
                done_str = "✓" if task["done"] else "○"
                if sys.stdout.isatty():
                    if task["done"]:
                        print(f"\033[32m{task['id']}: [{done_str}] {task['title']}\033[0m")
                    elif task.get("overdue", False):
                        print(f"\033[31m{task['id']}: [{done_str}] {task['title']}\033[0m")
                    else:
                        print(f"{task['id']}: [{done_str}] {task['title']}")
                else:
                    print(f"{task['id']}: [{done_str}] {task['title']}")
                    
    except Exception as e:
        print(str(e), file=sys.stderr)
        return 1
        
    return 0

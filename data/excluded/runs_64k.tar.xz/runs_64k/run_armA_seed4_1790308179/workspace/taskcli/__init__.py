"""A minimal command-line task manager with friendly UX."""

__version__ = "1.0.0"

import json
import os
import shutil
import sqlite3
import sys
from datetime import date, datetime
from pathlib import Path

import toml

from . import __version__


class TaskStorage:
    def __init__(self, db_path='tasks.db'):
        self.db_path = db_path
        self._ensure_database()
        
    def _ensure_database(self):
        """Ensure database exists with proper schema."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if we have the old schema and migrate if needed
        try:
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='tasks'")
            if cursor.fetchone():
                self._migrate_from_legacy_schema(conn, cursor)
        except sqlite3.Error:
            pass
            
        # Create or update to new schema
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                done BOOLEAN DEFAULT FALSE,
                priority TEXT DEFAULT 'med',
                due DATE,
                archived BOOLEAN DEFAULT FALSE,
                kind TEXT DEFAULT 'task'
            )
        """)
        
        # Create tags table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tags (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL
            )
        """)
        
        # Create junction table for task-tags
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS task_tags (
                task_id INTEGER,
                tag_id INTEGER,
                PRIMARY KEY (task_id, tag_id),
                FOREIGN KEY (task_id) REFERENCES items (id),
                FOREIGN KEY (tag_id) REFERENCES tags (id)
            )
        """)
        
        conn.commit()
        conn.close()
        
    def _migrate_from_legacy_schema(self, conn, cursor):
        """Migrate from legacy tasks table to new schema."""
        try:
            # Get all tasks from old schema
            cursor.execute("SELECT id, title, done, priority, due FROM tasks")
            tasks = cursor.fetchall()
            
            for task in tasks:
                task_id, title, done, priority, due = task
                # Insert into new schema
                cursor.execute("""
                    INSERT OR REPLACE INTO items 
                    (id, title, done, priority, due, kind)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (task_id, title, done, priority, due, 'task'))
                
            # Drop old table
            cursor.execute("DROP TABLE tasks")
            
            conn.commit()
        except Exception:
            # If migration fails, continue with new schema
            pass
            
    def get_today(self):
        """Get today's date, potentially overridden by config."""
        # Check for config file
        try:
            if os.path.exists('config.toml'):
                config = toml.load('config.toml')
                if 'today' in config:
                    return date.fromisoformat(config['today'])
        except Exception:
            pass
            
        # Check deprecated environment variable
        today_str = os.environ.get('TASKCLI_TODAY')
        if today_str:
            try:
                return date.fromisoformat(today_str)
            except ValueError:
                pass
                
        return date.today()
        
    def add_task(self, title, priority='med', due=None, tags=None):
        """Add a new task and return it."""
        if due:
            try:
                date.fromisoformat(due)
            except ValueError:
                print(f"Error: Invalid date format '{due}'. Use YYYY-MM-DD.", file=sys.stderr)
                sys.exit(2)
                
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get next ID
        cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM items")
        task_id = cursor.fetchone()[0]
        
        # Insert task
        cursor.execute("""
            INSERT INTO items (id, title, priority, due, kind)
            VALUES (?, ?, ?, ?, ?)
        """, (task_id, title, priority, due, 'task'))
        
        # Handle tags
        if tags:
            for tag in tags:
                # Insert or get tag ID
                cursor.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (tag,))
                cursor.execute("SELECT id FROM tags WHERE name = ?", (tag,))
                tag_id = cursor.fetchone()[0]
                
                # Link task and tag
                cursor.execute(
                    "INSERT OR IGNORE INTO task_tags (task_id, tag_id) VALUES (?, ?)",
                    (task_id, tag_id)
                )
        
        conn.commit()
        conn.close()
        
        return self._get_task(task_id)
        
    def _get_task(self, task_id):
        """Get a single task by ID."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, title, done, priority, due, archived
            FROM items 
            WHERE id = ?
        """, (task_id,))
        
        row = cursor.fetchone()
        if not row:
            raise KeyError(f"Task {task_id} not found")
            
        task = {
            'id': row[0],
            'title': row[1],
            'done': bool(row[2]),
            'priority': row[3],
            'due': row[4],
            'archived': bool(row[5])
        }
        
        # Get tags
        cursor.execute("""
            SELECT t.name 
            FROM tags t 
            JOIN task_tags tt ON t.id = tt.tag_id 
            WHERE tt.task_id = ?
            ORDER BY t.name
        """, (task_id,))
        task['tags'] = [row[0] for row in cursor.fetchall()]
        
        conn.close()
        return task
        
    def get_tasks(self, sort_by='id', filter_tags=None, show_overdue=False, show_all=False):
        """Get tasks with consistent filtering and sorting."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Base query
        query = """
            SELECT id, title, done, priority, due, archived 
            FROM items 
            WHERE archived = ?
        """
        params = [show_all]
        
        # Apply tag filtering if needed
        if filter_tags:
            query += """
                AND id IN (
                    SELECT DISTINCT task_id FROM task_tags tt 
                    JOIN tags t ON tt.tag_id = t.id 
                    WHERE t.name IN ({})
                )
            """.format(','.join('?' * len(filter_tags)))
            params.extend(filter_tags)
            
        # Apply overdue filtering if needed
        if show_overdue:
            today = self.get_today()
            query += " AND due < ? AND done = 0"
            params.append(today)
            
        # Add sorting
        if sort_by == 'priority':
            # Sort by priority: high, med, low
            query += """
                ORDER BY 
                    CASE priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 ELSE 3 END,
                    id
            """
        else:
            query += " ORDER BY id"
            
        cursor.execute(query, params)
        
        tasks = []
        for row in cursor.fetchall():
            task = {
                'id': row[0],
                'title': row[1],
                'done': bool(row[2]),
                'priority': row[3],
                'due': row[4],
                'archived': bool(row[5])
            }
            
            # Get tags
            cursor.execute("""
                SELECT t.name 
                FROM tags t 
                JOIN task_tags tt ON t.id = tt.tag_id 
                WHERE tt.task_id = ?
                ORDER BY t.name
            """, (task['id'],))
            task['tags'] = [row[0] for row in cursor.fetchall()]
            
            tasks.append(task)
            
        # Apply smart sorting: overdue first, then priority
        if not show_overdue and sort_by == 'id':
            today = self.get_today()
            def sort_key(task):
                # Overdue tasks come first (negative number to put them before others)
                # Then sort by priority (high, med, low) 
                # Then by id for stable sorting
                if task['done']:
                    overdue_score = 1000  # Done tasks are last
                elif task.get('due') and date.fromisoformat(task['due']) < today:
                    overdue_score = -1  # Overdue tasks first
                else:
                    overdue_score = 0  # Non-overdue tasks second
                
                priority_order = {'high': 1, 'med': 2, 'low': 3}
                priority_score = priority_order.get(task['priority'], 2)
                
                return (overdue_score, priority_score, task['id'])
            
            tasks.sort(key=sort_key)
        
        conn.close()
        return tasks
        
    def mark_done(self, task_id):
        """Mark a task as done."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("UPDATE items SET done = 1 WHERE id = ?", (task_id,))
        
        if cursor.rowcount == 0:
            raise KeyError(f"Task {task_id} not found")
            
        conn.commit()
        conn.close()
        
    def delete_task(self, task_id):
        """Delete a task."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("DELETE FROM items WHERE id = ?", (task_id,))
        
        if cursor.rowcount == 0:
            raise KeyError(f"Task {task_id} not found")
            
        conn.commit()
        conn.close()
        
    def edit_task(self, task_id, title=None):
        """Edit a task's title."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if title is not None:
            cursor.execute("UPDATE items SET title = ? WHERE id = ?", (title, task_id))
            
        if cursor.rowcount == 0:
            raise KeyError(f"Task {task_id} not found")
            
        conn.commit()
        conn.close()
        
    def search_tasks(self, text):
        """Search tasks by title."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Case-insensitive search
        cursor.execute("""
            SELECT id, title, done, priority, due, archived 
            FROM items 
            WHERE LOWER(title) LIKE ?
            ORDER BY id
        """, (f'%{text.lower()}%',))
        
        tasks = []
        for row in cursor.fetchall():
            task = {
                'id': row[0],
                'title': row[1],
                'done': bool(row[2]),
                'priority': row[3],
                'due': row[4],
                'archived': bool(row[5])
            }
            
            # Get tags
            cursor.execute("""
                SELECT t.name 
                FROM tags t 
                JOIN task_tags tt ON t.id = tt.tag_id 
                WHERE tt.task_id = ?
                ORDER BY t.name
            """, (task['id'],))
            task['tags'] = [row[0] for row in cursor.fetchall()]
            
            tasks.append(task)
            
        conn.close()
        return tasks
        
    def get_stats(self):
        """Get statistics about tasks."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Total tasks
        cursor.execute("SELECT COUNT(*) FROM items")
        total = cursor.fetchone()[0]
        
        # Done tasks
        cursor.execute("SELECT COUNT(*) FROM items WHERE done = 1")
        done = cursor.fetchone()[0]
        
        # Open tasks (not done and not archived)
        cursor.execute("SELECT COUNT(*) FROM items WHERE done = 0 AND archived = 0")
        open_tasks = cursor.fetchone()[0]
        
        # Overdue tasks
        today = self.get_today()
        cursor.execute("""
            SELECT COUNT(*) FROM items 
            WHERE done = 0 AND archived = 0 AND due < ?
        """, (today,))
        overdue = cursor.fetchone()[0]
        
        # Priority counts
        cursor.execute("SELECT COUNT(*) FROM items WHERE priority = 'high'")
        priority_high = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM items WHERE priority = 'med'")
        priority_med = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM items WHERE priority = 'low'")
        priority_low = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            'total': total,
            'done': done,
            'open': open_tasks,
            'overdue': overdue,
            'priority_high': priority_high,
            'priority_med': priority_med,
            'priority_low': priority_low
        }
        
    def archive_done_tasks(self):
        """Archive all done tasks."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("UPDATE items SET archived = 1 WHERE done = 1")
        
        conn.commit()
        conn.close()
        
    def backup_database(self, path):
        """Create a backup of the database."""
        # Ensure directory exists
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        
        # Create temporary file and then rename it atomically
        temp_path = path + '.tmp'
        shutil.copy2(self.db_path, temp_path)
        os.rename(temp_path, path)
        
    def export_to_json(self, path, tasks):
        """Export tasks to JSON."""
        with open(path, 'w') as f:
            json.dump(tasks, f, indent=2)
            
    def export_to_csv(self, path, tasks):
        """Export tasks to CSV."""
        import csv
        
        with open(path, 'w', newline='') as csvfile:
            fieldnames = ['id', 'title', 'done', 'priority', 'due', 'archived', 'tags']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            
            writer.writeheader()
            for task in tasks:
                # Convert boolean values to lowercase strings
                row = {
                    'id': task['id'],
                    'title': task['title'],
                    'done': str(task['done']).lower(),
                    'priority': task['priority'],
                    'due': task['due'],
                    'archived': str(task['archived']).lower(),
                    'tags': ','.join(task.get('tags', []))
                }
                writer.writerow(row)
                
    def compact_database(self):
        """Compact the database."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("VACUUM")
        
        conn.commit()
        conn.close()

import argparse
import os
import sys
from datetime import date

from . import __version__
from .storage import TaskStorage


def get_parser():
    parser = argparse.ArgumentParser(
        prog='taskcli',
        description='A minimal command-line task manager.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""Commands

- `python -m taskcli add <title>` — add a new task. Prints the assigned id.
- `python -m taskcli list` — list all tasks, in insertion order, showing id,
  done status, and title.
- `python -m taskcli done <id>` — mark the task with the given integer id as
  done.
- `python -m taskcli delete <id>` — delete the task with the given integer id.
- `python -m taskcli edit <id> --title "new title"` — edit a task's title.
- `python -m taskcli search <text>` — search tasks by title.
- `python -m taskcli stats` — print statistics about tasks.
- `python -m taskcli archive` — archive all done tasks.
- `python -m taskcli backup <path>` — create a backup of the database.
- `python -m taskcli export <path>` — export tasks as JSON.
- `python -m taskcli compact` — compact the database.
"""
    )
    parser.add_argument('--version', action='version', version=f'%(prog)s {__version__}')

    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['low', 'med', 'high'], default='med',
                           help='Task priority (default: med)')
    add_parser.add_argument('--due', help='Due date (YYYY-MM-DD)')
    add_parser.add_argument('--tag', action='append', help='Add a tag (repeatable)')

    # List command
    list_parser = subparsers.add_parser('list', help='List tasks')
    list_parser.add_argument('--sort', choices=['priority', 'id'], default='id',
                            help='Sort order (default: id)')
    list_parser.add_argument('--tag', action='append', help='Filter by tag (repeatable)')
    list_parser.add_argument('--overdue', action='store_true',
                            help='Show only overdue tasks')
    list_parser.add_argument('--all', action='store_true',
                            help='Show archived tasks too')
    list_parser.add_argument('--color', choices=['auto', 'always', 'never'],
                            default='auto', help='Color output (default: auto)')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Edit command
    edit_parser = subparsers.add_parser('edit', help='Edit a task')
    edit_parser.add_argument('id', type=int, help='Task ID')
    edit_parser.add_argument('--title', required=True, help='New title')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Search text')

    # Stats command
    subparsers.add_parser('stats', help='Show statistics')

    # Archive command
    subparsers.add_parser('archive', help='Archive done tasks')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup database')
    backup_parser.add_argument('path', help='Backup file path')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json',
                              help='Export format (default: json)')

    # Compact command
    subparsers.add_parser('compact', help='Compact database')

    return parser


def handle_add(args, storage):
    task = storage.add_task(
        title=args.title,
        priority=args.priority,
        due=args.due,
        tags=args.tag or []
    )
    print(task['id'])


def handle_list(args, storage):
    tasks = storage.get_tasks(
        sort_by=args.sort,
        filter_tags=args.tag or [],
        show_overdue=args.overdue,
        show_all=args.all
    )
    
    color_enabled = (
        args.color == 'always' or 
        (args.color == 'auto' and sys.stdout.isatty())
    )
    
    for task in tasks:
        if task['done']:
            status = '[x]'
            if color_enabled:
                status = '\033[32m[x]\033[0m'  # green
        else:
            status = '[ ]'
            
        if task.get('due') and not task['done']:
            due_date = date.fromisoformat(task['due'])
            today = storage.get_today()
            if due_date < today:
                overdue = True
                if color_enabled:
                    status = '\033[31m[x]\033[0m'  # red for overdue
            else:
                overdue = False
        else:
            overdue = False
            
        priority_str = f" (priority: {task['priority']})" if task['priority'] != 'med' else ""
        
        title = task['title']
        if overdue and color_enabled:
            title = f"\033[31m{title}\033[0m"
            
        print(f"{task['id']}: {status} {title}{priority_str}")


def handle_done(args, storage):
    try:
        storage.mark_done(args.id)
    except KeyError:
        print(f"Error: No task with id {args.id}", file=sys.stderr)
        sys.exit(2)


def handle_delete(args, storage):
    try:
        storage.delete_task(args.id)
    except KeyError:
        print(f"Error: No task with id {args.id}", file=sys.stderr)
        sys.exit(2)
        

def handle_edit(args, storage):
    try:
        storage.edit_task(args.id, title=args.title)
    except KeyError:
        print(f"Error: No task with id {args.id}", file=sys.stderr)
        sys.exit(2)


def handle_search(args, storage):
    tasks = storage.search_tasks(args.text)
    for task in tasks:
        if task['done']:
            status = '[x]'
        else:
            status = '[ ]'
            
        priority_str = f" (priority: {task['priority']})" if task['priority'] != 'med' else ""
        
        print(f"{task['id']}: {status} {task['title']}{priority_str}")


def handle_stats(args, storage):
    stats = storage.get_stats()
    print(f"Total: {stats['total']}")
    print(f"Done: {stats['done']}")
    print(f"Open: {stats['open']}")
    if stats['overdue'] > 0:
        print(f"\033[31mOverdue: {stats['overdue']}\033[0m")
    else:
        print(f"Overdue: {stats['overdue']}")
    print(f"Priority high: {stats['priority_high']}")
    print(f"Priority med: {stats['priority_med']}")
    print(f"Priority low: {stats['priority_low']}")


def handle_archive(args, storage):
    storage.archive_done_tasks()


def handle_backup(args, storage):
    try:
        storage.backup_database(args.path)
    except OSError as e:
        print(f"Error: Failed to write backup: {e}", file=sys.stderr)
        sys.exit(1)


def handle_export(args, storage):
    try:
        tasks = storage.get_tasks()
        if args.format == 'csv':
            storage.export_to_csv(args.path, tasks)
        else:
            storage.export_to_json(args.path, tasks)
    except OSError as e:
        print(f"Error: Failed to write export: {e}", file=sys.stderr)
        sys.exit(1)


def handle_compact(args, storage):
    storage.compact_database()


def main():
    parser = get_parser()
    args = parser.parse_args()
    
    # Emit audit line for every command invocation
    if args.command:
        print(f"AUDIT {args.command}", file=sys.stderr)
    else:
        # For help/usage cases, we don't emit an audit line since no actual command is run
        # But let's make sure we handle this correctly by just not calling the handlers
        parser.print_help()
        return
        
    storage = TaskStorage()
    
    try:
        if args.command == 'add':
            handle_add(args, storage)
        elif args.command == 'list':
            handle_list(args, storage)
        elif args.command == 'done':
            handle_done(args, storage)
        elif args.command == 'delete':
            handle_delete(args, storage)
        elif args.command == 'edit':
            handle_edit(args, storage)
        elif args.command == 'search':
            handle_search(args, storage)
        elif args.command == 'stats':
            handle_stats(args, storage)
        elif args.command == 'archive':
            handle_archive(args, storage)
        elif args.command == 'backup':
            handle_backup(args, storage)
        elif args.command == 'export':
            handle_export(args, storage)
        elif args.command == 'compact':
            handle_compact(args, storage)
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()

import os
import sqlite3
import json
import csv
import shutil
import sys
from datetime import datetime
from dateutil.parser import parse as parse_date
from . import __version__

class Storage:
    def __init__(self, config):
        self.config = config
        self.db_path = 'tasks.db'
        self.init_db()
        
    def init_db(self):
        # Check if database exists
        db_exists = os.path.exists(self.db_path)
        
        conn = sqlite3.connect(self.db_path)
        conn.execute('PRAGMA foreign_keys = ON')
        cursor = conn.cursor()
        
        # Create items table with kind column
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                done BOOLEAN DEFAULT FALSE,
                priority TEXT DEFAULT 'med',
                due DATE,
                archived BOOLEAN DEFAULT FALSE,
                kind TEXT NOT NULL DEFAULT 'task'
            )
        ''')
        
        # Create tags table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS tags (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL
            )
        ''')
        
        # Create task_tags junction table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS task_tags (
                task_id INTEGER,
                tag_id INTEGER,
                PRIMARY KEY (task_id, tag_id),
                FOREIGN KEY (task_id) REFERENCES items (id) ON DELETE CASCADE,
                FOREIGN KEY (tag_id) REFERENCES tags (id) ON DELETE CASCADE
            )
        ''')
        
        # Migrate from old schema if needed
        if not db_exists:
            # If tasks.json exists, migrate it
            if os.path.exists('tasks.json'):
                self.migrate_from_json()
        else:
            # Check if we need to upgrade from old schema
            try:
                cursor.execute("SELECT * FROM items LIMIT 1")
                cursor.fetchall()
                # Check if kind column exists
                cursor.execute("PRAGMA table_info(items)")
                columns = [col[1] for col in cursor.fetchall()]
                if 'kind' not in columns:
                    # Upgrade existing database
                    cursor.execute("ALTER TABLE items ADD COLUMN kind TEXT DEFAULT 'task'")
                    conn.commit()
            except sqlite3.OperationalError:
                pass  # Table doesn't exist yet, which is fine
        
        conn.commit()
        conn.close()

    def migrate_from_json(self):
        try:
            with open('tasks.json', 'r') as f:
                tasks = json.load(f)
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            for task in tasks:
                # Handle old format tasks without priority or due date
                priority = task.get('priority', 'med')
                due = task.get('due')
                if due:
                    try:
                        due = parse_date(due).date().isoformat()
                    except:
                        due = None
                
                cursor.execute('''
                    INSERT INTO items (id, title, done, priority, due, kind)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (task['id'], task['title'], task['done'], priority, due, 'task'))
                
                # Handle tags if present
                if 'tags' in task and task['tags']:
                    for tag_name in task['tags']:
                        cursor.execute('INSERT OR IGNORE INTO tags (name) VALUES (?)', (tag_name,))
                        cursor.execute('SELECT id FROM tags WHERE name = ?', (tag_name,))
                        tag_id = cursor.fetchone()[0]
                        cursor.execute('INSERT OR REPLACE INTO task_tags (task_id, tag_id) VALUES (?, ?)', 
                                     (task['id'], tag_id))
            
            conn.commit()
            conn.close()
            os.remove('tasks.json')
        except Exception as e:
            raise Exception(f"Failed to migrate from tasks.json: {e}")

    def _build_tasks_query(self, sort=None, overdue=False, all=False, tags=None):
        """Build the base query for retrieving tasks"""
        # Base query
        query = '''
            SELECT i.*, GROUP_CONCAT(t.name) as tag_names
            FROM items i
            LEFT JOIN task_tags tt ON i.id = tt.task_id
            LEFT JOIN tags t ON tt.tag_id = t.id
        '''
        
        params = []
        
        if not all:
            query += ' WHERE i.archived = FALSE'
            
        if overdue:
            today_str = self.get_today()
            query += ' AND i.due < ? AND i.done = FALSE'
            params.append(today_str)
            
        if tags:
            # Join with task_tags and tags for filtering
            query += '''
                AND i.id IN (
                    SELECT DISTINCT tt.task_id 
                    FROM task_tags tt 
                    JOIN tags t ON tt.tag_id = t.id 
                    WHERE t.name IN ({})
                )
            '''.format(','.join('?' * len(tags)))
            params.extend(tags)
            
        query += ' GROUP BY i.id'
        
        return query, params

    def _get_sorted_tasks(self, sort=None, overdue=False, all=False, tags=None):
        """Get tasks with proper sorting"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        query, params = self._build_tasks_query(sort, overdue, all, tags)
        
        # Add ordering
        if sort == 'priority':
            # Order by priority (high, med, low) then by id
            query += '''
                ORDER BY 
                CASE i.priority 
                    WHEN 'high' THEN 1 
                    WHEN 'med' THEN 2 
                    WHEN 'low' THEN 3 
                    ELSE 4 
                END,
                i.id
            '''
        elif sort == 'id':
            query += ' ORDER BY i.id'
        else:
            # Default smart sorting: overdue first, then priority, then id
            today_str = self.get_today()
            query += '''
                ORDER BY 
                CASE 
                    WHEN i.due < ? AND i.done = FALSE THEN 1 
                    ELSE 2 
                END,
                CASE i.priority 
                    WHEN 'high' THEN 1 
                    WHEN 'med' THEN 2 
                    WHEN 'low' THEN 3 
                    ELSE 4 
                END,
                i.id
            '''
            params.append(today_str)
            
        cursor.execute(query, params)
        tasks = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        # Add tag list to each task
        for task in tasks:
            if task['tag_names']:
                task['tags'] = sorted(task['tag_names'].split(','))
            else:
                task['tags'] = []
                
        return tasks

    def add_task(self, title, priority, due, tags):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get next ID
        cursor.execute('SELECT COALESCE(MAX(id), 0) + 1 FROM items')
        task_id = cursor.fetchone()[0]
        
        # Insert task
        cursor.execute('''
            INSERT INTO items (id, title, priority, due, kind)
            VALUES (?, ?, ?, ?, ?)
        ''', (task_id, title, priority, due, 'task'))
        
        # Add tags
        for tag_name in tags:
            cursor.execute('INSERT OR IGNORE INTO tags (name) VALUES (?)', (tag_name,))
            cursor.execute('SELECT id FROM tags WHERE name = ?', (tag_name,))
            tag_id = cursor.fetchone()[0]
            cursor.execute('INSERT OR REPLACE INTO task_tags (task_id, tag_id) VALUES (?, ?)', 
                         (task_id, tag_id))
        
        conn.commit()
        conn.close()
        return task_id

    def list_tasks(self, sort=None, overdue=False, all=False, tags=None):
        return self._get_sorted_tasks(sort, overdue, all, tags)

    def mark_done(self, task_id):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if task exists
        cursor.execute('SELECT id FROM items WHERE id = ? AND kind = ?', (task_id, 'task'))
        if not cursor.fetchone():
            raise Exception(f"No task with id {task_id}")
            
        cursor.execute('UPDATE items SET done = TRUE WHERE id = ?', (task_id,))
        conn.commit()
        conn.close()

    def delete_task(self, task_id):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if task exists
        cursor.execute('SELECT id FROM items WHERE id = ? AND kind = ?', (task_id, 'task'))
        if not cursor.fetchone():
            raise Exception(f"No task with id {task_id}")
            
        cursor.execute('DELETE FROM items WHERE id = ?', (task_id,))
        conn.commit()
        conn.close()

    def edit_task(self, task_id, new_title):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if task exists
        cursor.execute('SELECT id FROM items WHERE id = ? AND kind = ?', (task_id, 'task'))
        if not cursor.fetchone():
            raise Exception(f"No task with id {task_id}")
            
        if new_title is not None:
            cursor.execute('UPDATE items SET title = ? WHERE id = ?', (new_title, task_id))
        conn.commit()
        conn.close()

    def get_stats(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Get total tasks
        cursor.execute('SELECT COUNT(*) as count FROM items WHERE kind = ?', ('task',))
        total = cursor.fetchone()['count']
        
        # Get done tasks
        cursor.execute('SELECT COUNT(*) as count FROM items WHERE done = TRUE AND kind = ?', ('task',))
        done = cursor.fetchone()['count']
        
        # Get open tasks
        open_tasks = total - done
        
        # Get priority counts
        cursor.execute('''
            SELECT priority, COUNT(*) as count 
            FROM items 
            WHERE kind = ? 
            GROUP BY priority
        ''', ('task',))
        priority_counts = {row['priority']: row['count'] for row in cursor.fetchall()}
        
        # Get overdue tasks
        today_str = self.get_today()
        cursor.execute('''
            SELECT COUNT(*) as count 
            FROM items 
            WHERE due < ? AND done = FALSE AND kind = ?
        ''', (today_str, 'task'))
        overdue = cursor.fetchone()['count']
        
        conn.close()
        
        stats = [
            f"Total: {total}",
            f"Done: {done}",
            f"Open: {open_tasks}"
        ]
        
        if overdue > 0:
            stats.append(f"\033[31mOverdue: {overdue}\033[0m")
        else:
            stats.append(f"Overdue: {overdue}")
            
        for priority in ['high', 'med', 'low']:
            count = priority_counts.get(priority, 0)
            stats.append(f"Priority {priority}: {count}")
            
        return stats

    def archive_tasks(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Archive all done tasks
        cursor.execute('UPDATE items SET archived = TRUE WHERE done = TRUE AND kind = ?', ('task',))
        conn.commit()
        conn.close()

    def backup(self, path):
        try:
            shutil.copy2(self.db_path, path)
        except Exception as e:
            raise Exception(f"Failed to create backup: {e}")

    def export_tasks(self, path, format='json'):
        tasks = self._get_sorted_tasks(all=True)
        
        if format == 'csv':
            with open(path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                # Write header
                writer.writerow(['id', 'title', 'done', 'priority', 'due', 'tags'])
                for task in tasks:
                    tags_str = ','.join(task.get('tags', []))
                    writer.writerow([
                        task['id'],
                        task['title'],
                        task['done'],
                        task['priority'],
                        task['due'],
                        tags_str
                    ])
        else:  # json
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(tasks, f, indent=2, default=str)

    def compact(self):
        conn = sqlite3.connect(self.db_path)
        conn.execute('VACUUM')
        conn.close()

    def search_tasks(self, text):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Search in title (case insensitive)
        query = '''
            SELECT i.*, GROUP_CONCAT(t.name) as tag_names
            FROM items i
            LEFT JOIN task_tags tt ON i.id = tt.task_id
            LEFT JOIN tags t ON tt.tag_id = t.id
            WHERE LOWER(i.title) LIKE ?
            AND i.kind = ?
            GROUP BY i.id
            ORDER BY i.id
        '''
        
        cursor.execute(query, (f'%{text.lower()}%', 'task'))
        tasks = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        # Add tag list to each task
        for task in tasks:
            if task['tag_names']:
                task['tags'] = sorted(task['tag_names'].split(','))
            else:
                task['tags'] = []
                
        return tasks

    def format_task(self, task, color='auto'):
        # Determine if we should use colors
        use_color = False
        if color == 'always':
            use_color = True
        elif color == 'auto' and sys.stdout.isatty():
            use_color = True
            
        # Format priority
        priority_str = f"(priority: {task['priority']})"
        
        # Format due date
        due_str = ""
        if task['due']:
            due_str = f" (due: {task['due']})"
            
        # Format tags
        tags_str = ""
        if task.get('tags'):
            tags_str = " [" + ",".join(task['tags']) + "]"
            
        # Build title with priority and due date
        title = f"{task['title']} {priority_str}{due_str}{tags_str}"
        
        # Add done status
        if task['done']:
            if use_color:
                title = f"\033[32m{title}\033[0m"
            title = f"[DONE] {title}"
        elif task['due'] and self.is_overdue(task['due']):
            if use_color:
                title = f"\033[31m{title}\033[0m"
                
        return title

    def get_today(self):
        if 'today' in self.config:
            try:
                return parse_date(self.config['today']).date().isoformat()
            except:
                raise Exception(f"Invalid date format in config: {self.config['today']}")
        return datetime.now().date().isoformat()

    def is_overdue(self, due_date_str):
        today = self.get_today()
        try:
            due_date = parse_date(due_date_str).date()
            return due_date < datetime.strptime(today, '%Y-%m-%d').date()
        except:
            return False

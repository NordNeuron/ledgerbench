import argparse
import os
import sys
import toml
from .storage import Storage

def get_config():
    config = {}
    if os.path.exists('config.toml'):
        with open('config.toml', 'r') as f:
            try:
                config = toml.load(f)
            except Exception as e:
                print(f"Error reading config.toml: {e}", file=sys.stderr)
                sys.exit(1)
    
    # TASKCLI_TODAY is deprecated, but still supported for backward compatibility
    if 'TASKCLI_TODAY' in os.environ and 'today' not in config:
        config['today'] = os.environ['TASKCLI_TODAY']
    
    return config

def main():
    config = get_config()
    storage = Storage(config)
    
    parser = argparse.ArgumentParser(description='Minimal command-line task manager')
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['low', 'med', 'high'], default='med',
                           help='Task priority (default: med)')
    add_parser.add_argument('--due', help='Due date (YYYY-MM-DD)')
    add_parser.add_argument('--tag', action='append', help='Add a tag (can be used multiple times)')

    # List command
    list_parser = subparsers.add_parser('list', help='List all tasks')
    list_parser.add_argument('--sort', choices=['priority', 'id'], help='Sort order')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')
    list_parser.add_argument('--all', action='store_true', help='Show archived tasks too')
    list_parser.add_argument('--tag', action='append', help='Filter by tag (can be used multiple times)')
    list_parser.add_argument('--color', choices=['auto', 'always', 'never'], default='auto',
                            help='Color output (default: auto)')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    # Edit command
    edit_parser = subparsers.add_parser('edit', help='Edit a task')
    edit_parser.add_argument('id', type=int, help='Task ID')
    edit_parser.add_argument('--title', help='New title')

    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show statistics')

    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive completed tasks')

    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Backup database')
    backup_parser.add_argument('path', help='Backup file path')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export tasks')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json',
                              help='Export format (default: json)')

    # Compact command
    compact_parser = subparsers.add_parser('compact', help='Compact database')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks by title')
    search_parser.add_argument('text', help='Search text')

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        print(f"AUDIT help", file=sys.stderr)
        return 0

    try:
        if args.command == 'add':
            task_id = storage.add_task(args.title, args.priority, args.due, args.tag or [])
            print(task_id)
        elif args.command == 'list':
            tasks = storage.list_tasks(args.sort, args.overdue, args.all, args.tag or [])
            for task in tasks:
                print(storage.format_task(task, args.color))
        elif args.command == 'done':
            storage.mark_done(args.id)
        elif args.command == 'delete':
            storage.delete_task(args.id)
        elif args.command == 'edit':
            storage.edit_task(args.id, args.title)
        elif args.command == 'stats':
            stats = storage.get_stats()
            for line in stats:
                print(line)
        elif args.command == 'archive':
            storage.archive_tasks()
        elif args.command == 'backup':
            storage.backup(args.path)
        elif args.command == 'export':
            storage.export_tasks(args.path, args.format)
        elif args.command == 'compact':
            storage.compact()
        elif args.command == 'search':
            tasks = storage.search_tasks(args.text)
            for task in tasks:
                print(storage.format_task(task, 'never'))
    except Exception as e:
        print(str(e), file=sys.stderr)
        print(f"AUDIT {args.command}", file=sys.stderr)
        return 2

    # Always emit audit line at the end
    print(f"AUDIT {args.command}", file=sys.stderr)
    return 0

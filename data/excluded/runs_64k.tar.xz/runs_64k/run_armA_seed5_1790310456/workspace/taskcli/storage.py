"""
Storage layer for taskcli, using SQLite database.
"""

import json
import os
import sqlite3
from contextlib import contextmanager
from datetime import date
from typing import List, Optional

from . import __version__

SCHEMA_VERSION = 4
DB_NAME = "tasks.db"
JSON_DB_NAME = "tasks.json"

# Migration SQL statements
MIGRATIONS = [
    # Version 1: Initial schema
    """
    CREATE TABLE IF NOT EXISTS items (
        id INTEGER PRIMARY KEY,
        kind TEXT NOT NULL,
        title TEXT NOT NULL,
        done BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """,
    
    # Version 2: Add priority and due_date columns
    """
    ALTER TABLE items ADD COLUMN priority TEXT DEFAULT 'med';
    ALTER TABLE items ADD COLUMN due_date DATE;
    """,
    
    # Version 3: Add tags table
    """
    CREATE TABLE IF NOT EXISTS tags (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL
    );
    
    CREATE TABLE IF NOT EXISTS item_tags (
        item_id INTEGER,
        tag_id INTEGER,
        FOREIGN KEY (item_id) REFERENCES items (id),
        FOREIGN KEY (tag_id) REFERENCES tags (id),
        PRIMARY KEY (item_id, tag_id)
    );
    """,
    
    # Version 4: Add archived column to items
    """
    ALTER TABLE items ADD COLUMN archived BOOLEAN DEFAULT FALSE;
    """
]

def get_db_path() -> str:
    """Get the path to the database file."""
    return os.path.join(os.getcwd(), DB_NAME)

def get_json_db_path() -> str:
    """Get the path to the JSON database file."""
    return os.path.join(os.getcwd(), JSON_DB_NAME)

@contextmanager
def get_db():
    """Context manager for database connections."""
    db_path = get_db_path()
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row  # Enable column access by name
    try:
        yield conn
    finally:
        conn.close()

def init_db():
    """Initialize the database with the current schema."""
    with get_db() as conn:
        # Get current schema version
        try:
            version_row = conn.execute("SELECT version FROM schema_version").fetchone()
            current_version = version_row['version'] if version_row else 0
        except sqlite3.OperationalError:
            # schema_version table doesn't exist yet
            current_version = 0
            
        # Apply migrations as needed
        if current_version < SCHEMA_VERSION:
            # Migrate from JSON if needed
            migrate_from_json(conn)
            
            # Apply all pending migrations
            for version in range(current_version + 1, SCHEMA_VERSION + 1):
                conn.execute(MIGRATIONS[version - 1])
                
            # Update schema version
            conn.execute("CREATE TABLE IF NOT EXISTS schema_version (version INTEGER)")
            conn.execute("INSERT OR REPLACE INTO schema_version VALUES (?)", (SCHEMA_VERSION,))
            
        conn.commit()

def migrate_from_json(conn):
    """Migrate data from old JSON format to new SQLite format."""
    json_path = get_json_db_path()
    
    if not os.path.exists(json_path):
        return
        
    try:
        with open(json_path, 'r') as f:
            tasks = json.load(f)
            
        # Create a mapping of tag names to IDs
        tag_id_map = {}
        
        for task in tasks:
            # Insert the item
            conn.execute("""
                INSERT INTO items (id, kind, title, done, priority, due_date)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                task['id'],
                'task',
                task['title'],
                task['done'],
                task.get('priority', 'med'),
                task.get('due_date')
            ))
            
            # Handle tags
            if 'tags' in task and task['tags']:
                for tag_name in task['tags']:
                    # Get or create tag
                    tag_row = conn.execute("SELECT id FROM tags WHERE name = ?", (tag_name,)).fetchone()
                    if not tag_row:
                        conn.execute("INSERT INTO tags (name) VALUES (?)", (tag_name,))
                        tag_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
                        tag_id_map[tag_name] = tag_id
                    else:
                        tag_id = tag_row['id']
                        tag_id_map[tag_name] = tag_id
                    
                    # Link item to tag
                    conn.execute("""
                        INSERT OR IGNORE INTO item_tags (item_id, tag_id)
                        VALUES (?, ?)
                    """, (task['id'], tag_id))
                    
        os.remove(json_path)  # Remove old JSON file after successful migration
        
    except Exception:
        # If migration fails, we continue with empty database
        pass

def get_items(
    include_archived: bool = False,
    tags: Optional[List[str]] = None,
    sort_by_priority: bool = False,
    overdue_only: bool = False
) -> List[dict]:
    """Get all items, optionally filtered by tags or other criteria."""
    with get_db() as conn:
        # Base query
        base_query = """
            SELECT i.id, i.kind, i.title, i.done, i.created_at, i.updated_at,
                   i.priority, i.due_date, i.archived,
                   GROUP_CONCAT(t.name) as tags
            FROM items i
            LEFT JOIN item_tags it ON i.id = it.item_id
            LEFT JOIN tags t ON it.tag_id = t.id
        """
        
        # Add WHERE clause if filtering by tags or archived status
        where_clauses = []
        params = []
        
        if not include_archived:
            where_clauses.append("i.archived = FALSE")
            
        if tags:
            # For multiple tags, we need to ensure the item has ALL of them
            # Build a subquery that finds items with all specified tags
            tag_conditions = []
            for i, tag in enumerate(tags):
                tag_conditions.append(f"tag{i} = ?")
                params.append(tag)
                
            # Create a query that finds items having ALL specified tags
            base_query += " WHERE i.id IN ("
            base_query += "SELECT i2.id FROM items i2"
            base_query += " LEFT JOIN item_tags it2 ON i2.id = it2.item_id"
            base_query += " LEFT JOIN tags t2 ON it2.tag_id = t2.id"
            base_query += " WHERE t2.name IN ({})".format(','.join(['?'] * len(tags)))
            base_query += " GROUP BY i2.id"
            base_query += " HAVING COUNT(DISTINCT t2.name) = ?"
            params.extend(tags)
            params.append(len(tags))
            base_query += ")"
        else:
            base_query += " WHERE 1=1"
            
        if overdue_only:
            # Only include tasks that are not done and have a due date that has passed
            where_clauses.append("i.done = FALSE AND i.due_date < ?")
            params.append(date.today().isoformat())
            
        if where_clauses:
            base_query += " AND " + " AND ".join(where_clauses)
            
        base_query += " GROUP BY i.id"
        
        # Apply sorting based on parameters
        if sort_by_priority:
            # Sort by priority (high, med, low) then by id
            base_query += " ORDER BY CASE i.priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 WHEN 'low' THEN 3 ELSE 4 END, i.id"
        elif overdue_only:
            # When --overdue is used, sort by due date first (overdue first) then priority
            base_query += " ORDER BY CASE WHEN i.due_date < ? AND i.done = FALSE THEN 0 ELSE 1 END, "
            base_query += "CASE i.priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 WHEN 'low' THEN 3 ELSE 4 END, i.id"
            params.append(date.today().isoformat())
        else:
            # Default smart sorting: overdue first, then by priority, then by id
            base_query += " ORDER BY CASE WHEN i.due_date < ? AND i.done = FALSE THEN 0 ELSE 1 END, "
            base_query += "CASE i.priority WHEN 'high' THEN 1 WHEN 'med' THEN 2 WHEN 'low' THEN 3 ELSE 4 END, i.id"
            params.append(date.today().isoformat())
        
        rows = conn.execute(base_query, params).fetchall()
        
        # Convert to list of dicts
        result = []
        for row in rows:
            item = dict(row)
            if item['tags']:
                item['tags'] = item['tags'].split(',')
            else:
                item['tags'] = []
            result.append(item)
            
        return result

def get_item(item_id: int) -> Optional[dict]:
    """Get a specific item by ID."""
    with get_db() as conn:
        row = conn.execute("""
            SELECT i.id, i.kind, i.title, i.done, i.created_at, i.updated_at,
                   i.priority, i.due_date, i.archived,
                   GROUP_CONCAT(t.name) as tags
            FROM items i
            LEFT JOIN item_tags it ON i.id = it.item_id
            LEFT JOIN tags t ON it.tag_id = t.id
            WHERE i.id = ?
            GROUP BY i.id
        """, (item_id,)).fetchone()
        
        if row:
            item = dict(row)
            if item['tags']:
                item['tags'] = item['tags'].split(',')
            else:
                item['tags'] = []
            return item
        return None

def add_item(title: str, priority: str = 'med', due_date: Optional[str] = None, tags: List[str] = None) -> int:
    """Add a new item and return its ID."""
    with get_db() as conn:
        # Insert the item
        conn.execute("""
            INSERT INTO items (kind, title, priority, due_date)
            VALUES (?, ?, ?, ?)
        """, ('task', title, priority, due_date))
        
        item_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        
        # Handle tags
        if tags:
            for tag_name in tags:
                # Get or create tag
                tag_row = conn.execute("SELECT id FROM tags WHERE name = ?", (tag_name,)).fetchone()
                if not tag_row:
                    conn.execute("INSERT INTO tags (name) VALUES (?)", (tag_name,))
                    tag_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
                else:
                    tag_id = tag_row['id']
                
                # Link item to tag
                conn.execute("""
                    INSERT OR IGNORE INTO item_tags (item_id, tag_id)
                    VALUES (?, ?)
                """, (item_id, tag_id))
        
        conn.commit()
        return item_id

def update_item(item_id: int, title: Optional[str] = None, done: Optional[bool] = None, 
               priority: Optional[str] = None, due_date: Optional[str] = None, tags: Optional[List[str]] = None) -> bool:
    """Update an existing item."""
    with get_db() as conn:
        # Build update query
        updates = []
        params = []
        
        if title is not None:
            updates.append("title = ?")
            params.append(title)
            
        if done is not None:
            updates.append("done = ?")
            params.append(done)
            
        if priority is not None:
            updates.append("priority = ?")
            params.append(priority)
            
        if due_date is not None:
            updates.append("due_date = ?")
            params.append(due_date)
            
        if not updates:
            return True  # Nothing to update
            
        params.append(item_id)
        
        query = f"UPDATE items SET {', '.join(updates)} WHERE id = ?"
        result = conn.execute(query, params)
        
        # Handle tags
        if tags is not None:
            # Remove existing tags for this item
            conn.execute("DELETE FROM item_tags WHERE item_id = ?", (item_id,))
            
            # Add new tags
            for tag_name in tags:
                # Get or create tag
                tag_row = conn.execute("SELECT id FROM tags WHERE name = ?", (tag_name,)).fetchone()
                if not tag_row:
                    conn.execute("INSERT INTO tags (name) VALUES (?)", (tag_name,))
                    tag_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
                else:
                    tag_id = tag_row['id']
                
                # Link item to tag
                conn.execute("""
                    INSERT OR IGNORE INTO item_tags (item_id, tag_id)
                    VALUES (?, ?)
                """, (item_id, tag_id))
        
        conn.commit()
        return result.rowcount > 0

def delete_item(item_id: int) -> bool:
    """Delete an item."""
    with get_db() as conn:
        # Delete from item_tags first to maintain referential integrity
        conn.execute("DELETE FROM item_tags WHERE item_id = ?", (item_id,))
        
        # Then delete the item itself
        result = conn.execute("DELETE FROM items WHERE id = ?", (item_id,))
        conn.commit()
        return result.rowcount > 0

def archive_item(item_id: int) -> bool:
    """Archive an item."""
    with get_db() as conn:
        result = conn.execute("UPDATE items SET archived = TRUE WHERE id = ?", (item_id,))
        conn.commit()
        return result.rowcount > 0

def get_stats() -> dict:
    """Get statistics about tasks by priority and status."""
    with get_db() as conn:
        # Get counts by priority
        priority_counts = conn.execute("""
            SELECT priority, COUNT(*) as count
            FROM items 
            WHERE archived = FALSE
            GROUP BY priority
        """).fetchall()
        
        # Get counts by status
        status_counts = conn.execute("""
            SELECT done, COUNT(*) as count
            FROM items 
            WHERE archived = FALSE
            GROUP BY done
        """).fetchall()
        
        # Get total count
        total_count = conn.execute("SELECT COUNT(*) as count FROM items WHERE archived = FALSE").fetchone()['count']
        
        return {
            'total': total_count,
            'by_priority': {row['priority']: row['count'] for row in priority_counts},
            'by_status': {row['done']: row['count'] for row in status_counts}
        }

def backup_db(path: str) -> bool:
    """Create a backup of the database to the given path."""
    db_path = get_db_path()
    
    try:
        import shutil
        shutil.copy2(db_path, path)
        return True
    except Exception:
        return False

def export_db(path: str, format: str = 'json') -> bool:
    """Export the complete database (including archived items) to a file."""
    with get_db() as conn:
        if format == 'csv':
            # Export as CSV - include all tasks (archived and non-archived)
            rows = conn.execute("""
                SELECT i.id, i.kind, i.title, i.done, i.created_at, i.updated_at,
                       i.priority, i.due_date, i.archived,
                       GROUP_CONCAT(t.name) as tags
                FROM items i
                LEFT JOIN item_tags it ON i.id = it.item_id
                LEFT JOIN tags t ON it.tag_id = t.id
                GROUP BY i.id
                ORDER BY i.id
            """).fetchall()
            
            try:
                with open(path, 'w') as f:
                    # Write header
                    f.write("id,kind,title,done,created_at,updated_at,priority,due_date,archived,tags\n")
                    
                    # Write data rows - simpler approach without complex escaping
                    for row in rows:
                        item = dict(row)
                        
                        # Convert all fields to strings and handle NULLs
                        id_val = str(item['id']) if item['id'] is not None else ""
                        kind_val = str(item['kind']) if item['kind'] is not None else ""
                        title_val = str(item['title']) if item['title'] is not None else ""
                        done_val = str(item['done']) if item['done'] is not None else ""
                        created_at_val = str(item['created_at']) if item['created_at'] is not None else ""
                        updated_at_val = str(item['updated_at']) if item['updated_at'] is not None else ""
                        priority_val = str(item['priority']) if item['priority'] is not None else ""
                        due_date_val = str(item['due_date']) if item['due_date'] is not None else ""
                        archived_val = str(item['archived']) if item['archived'] is not None else ""
                        
                        # Handle tags - if there are tags, use them; otherwise empty string
                        if item['tags']:
                            tags_val = item['tags']
                        else:
                            tags_val = ""
                        
                        # Write the row with comma-separated values
                        f.write(f"{id_val},{kind_val},{title_val},{done_val},{created_at_val},{updated_at_val},{priority_val},{due_date_val},{archived_val},{tags_val}\n")
                return True
            except Exception:
                return False
        else:
            # Export as JSON (default behavior)
            rows = conn.execute("""
                SELECT i.id, i.kind, i.title, i.done, i.created_at, i.updated_at,
                       i.priority, i.due_date, i.archived,
                       GROUP_CONCAT(t.name) as tags
                FROM items i
                LEFT JOIN item_tags it ON i.id = it.item_id
                LEFT JOIN tags t ON it.tag_id = t.id
                GROUP BY i.id
                ORDER BY i.id
            """).fetchall()
            
            # Convert to list of dicts
            result = []
            for row in rows:
                item = dict(row)
                if item['tags']:
                    item['tags'] = item['tags'].split(',')
                else:
                    item['tags'] = []
                result.append(item)
                
            try:
                with open(path, 'w') as f:
                    json.dump(result, f, indent=2)
                return True
            except Exception:
                return False

def compact_db() -> bool:
    """Compact the database by removing deleted rows."""
    with get_db() as conn:
        try:
            # This is a no-op in SQLite since it doesn't require compaction,
            # but we'll do a VACUUM to reclaim space
            conn.execute("VACUUM")
            return True
        except Exception:
            return False

def get_tags() -> List[str]:
    """Get all existing tags."""
    with get_db() as conn:
        rows = conn.execute("SELECT name FROM tags ORDER BY name").fetchall()
        return [row['name'] for row in rows]

def search_items(query: str) -> List[dict]:
    """Search items by title or tags."""
    with get_db() as conn:
        rows = conn.execute("""
            SELECT i.id, i.kind, i.title, i.done, i.created_at, i.updated_at,
                   i.priority, i.due_date, i.archived,
                   GROUP_CONCAT(t.name) as tags
            FROM items i
            LEFT JOIN item_tags it ON i.id = it.item_id
            LEFT JOIN tags t ON it.tag_id = t.id
            WHERE i.title LIKE ? OR t.name LIKE ?
            GROUP BY i.id
            ORDER BY i.id
        """, (f'%{query}%', f'%{query}%')).fetchall()
        
        # Convert to list of dicts
        result = []
        for row in rows:
            item = dict(row)
            if item['tags']:
                item['tags'] = item['tags'].split(',')
            else:
                item['tags'] = []
            result.append(item)
            
        return result

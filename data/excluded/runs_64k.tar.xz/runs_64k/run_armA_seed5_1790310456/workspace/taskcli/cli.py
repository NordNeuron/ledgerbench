"""
Command-line interface for taskcli.
"""

import argparse
import os
import sys
from datetime import date

from . import __version__
from .storage import (
    add_item, 
    archive_item, 
    delete_item, 
    get_items, 
    get_item, 
    get_stats, 
    update_item,
    backup_db,
    export_db,
    compact_db,
    get_tags,
    search_items
)

def print_error(message: str):
    """Print an error message to stderr."""
    print(f"Error: {message}", file=sys.stderr)

def handle_add(args):
    """Handle the 'add' command."""
    try:
        item_id = add_item(
            title=args.title,
            priority=args.priority,
            due_date=args.due,
            tags=args.tag or []
        )
        print(item_id)
        return 0
    except Exception as e:
        print_error(f"Failed to add task: {e}")
        return 1

def handle_list(args):
    """Handle the 'list' command."""
    try:
        items = get_items(
            include_archived=args.archived,
            tags=args.tag,
            sort_by_priority=args.sort == 'priority',
            overdue_only=args.overdue
        )
        
        for item in items:
            done_char = 'x' if item['done'] else ' '
            priority_char = {'high': 'H', 'med': 'M', 'low': 'L'}[item['priority']]
            
            # Format due date
            due_str = ''
            if item['due_date']:
                due_str = f" (due {item['due_date']})"
                
            # Format tags
            tags_str = ''
            if item['tags']:
                tags_str = f" [{', '.join(item['tags'])}]"
            
            print(f"[{item['id']}] [{done_char}] {priority_char} {item['title']}{due_str}{tags_str}")
        
        return 0
    except Exception as e:
        print_error(f"Failed to list tasks: {e}")
        return 1

def handle_done(args):
    """Handle the 'done' command."""
    try:
        item = get_item(args.id)
        if not item:
            print_error(f"No task with id {args.id}")
            return 2
            
        update_item(args.id, done=True)
        return 0
    except Exception as e:
        print_error(f"Failed to mark task as done: {e}")
        return 1

def handle_delete(args):
    """Handle the 'delete' command."""
    try:
        item = get_item(args.id)
        if not item:
            print_error(f"No task with id {args.id}")
            return 2
            
        delete_item(args.id)
        return 0
    except Exception as e:
        print_error(f"Failed to delete task: {e}")
        return 1

def handle_edit(args):
    """Handle the 'edit' command."""
    try:
        item = get_item(args.id)
        if not item:
            print_error(f"No task with id {args.id}")
            return 2
            
        # Build update parameters
        update_params = {}
        if args.title is not None:
            update_params['title'] = args.title
            
        # For now, we don't support editing priority or due date via edit command
        # but we could add that later
        
        update_item(args.id, **update_params)
        return 0
    except Exception as e:
        print_error(f"Failed to edit task: {e}")
        return 1

def handle_archive(args):
    """Handle the 'archive' command."""
    try:
        item = get_item(args.id)
        if not item:
            print_error(f"No task with id {args.id}")
            return 2
            
        archive_item(args.id)
        return 0
    except Exception as e:
        print_error(f"Failed to archive task: {e}")
        return 1

def handle_stats(args):
    """Handle the 'stats' command."""
    try:
        stats = get_stats()
        
        print(f"Total tasks: {stats['total']}")
        print("By priority:")
        for priority, count in stats['by_priority'].items():
            print(f"  {priority}: {count}")
        print("By status:")
        for done, count in stats['by_status'].items():
            print(f"  {'Done' if done else 'Not done'}: {count}")
        
        return 0
    except Exception as e:
        print_error(f"Failed to get stats: {e}")
        return 1

def handle_backup(args):
    """Handle the 'backup' command."""
    try:
        if backup_db(args.path):
            print(f"Backup created at {args.path}")
            return 0
        else:
            print_error("Failed to create backup")
            return 1
    except Exception as e:
        print_error(f"Failed to create backup: {e}")
        return 1

def handle_export(args):
    """Handle the 'export' command."""
    try:
        if export_db(args.path, format=args.format):
            print(f"Exported to {args.path}")
            return 0
        else:
            print_error("Failed to export tasks")
            return 1
    except Exception as e:
        print_error(f"Failed to export tasks: {e}")
        return 1

def handle_compact(args):
    """Handle the 'compact' command."""
    try:
        if compact_db():
            print("Database compacted successfully")
            return 0
        else:
            print_error("Failed to compact database")
            return 1
    except Exception as e:
        print_error(f"Failed to compact database: {e}")
        return 1

def handle_tags(args):
    """Handle the 'tags' command."""
    try:
        tags = get_tags()
        if tags:
            for tag in sorted(tags):
                print(tag)
        else:
            print("No tags found.")
        return 0
    except Exception as e:
        print_error(f"Failed to list tags: {e}")
        return 1

def handle_search(args):
    """Handle the 'search' command."""
    try:
        items = search_items(args.query)
        for item in items:
            done_char = 'x' if item['done'] else ' '
            priority_char = {'high': 'H', 'med': 'M', 'low': 'L'}[item['priority']]
            
            # Format due date
            due_str = ''
            if item['due_date']:
                due_str = f" (due {item['due_date']})"
                
            # Format tags
            tags_str = ''
            if item['tags']:
                tags_str = f" [{', '.join(item['tags'])}]"
            
            print(f"[{item['id']}] [{done_char}] {priority_char} {item['title']}{due_str}{tags_str}")
        return 0
    except Exception as e:
        print_error(f"Failed to search tasks: {e}")
        return 1

def main():
    """Main entry point for the CLI."""
    parser = argparse.ArgumentParser(
        prog='taskcli',
        description='A minimal command-line task manager.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Commands:
  add <title>                 Add a new task
  list                        List all tasks
  done <id>                   Mark a task as done
  delete <id>                 Delete a task
  edit <id>                   Edit a task
  archive <id>                Archive a task
  stats                       Show statistics
  backup <path>               Create a backup
  export <path>               Export to JSON
  compact                     Compact database
  tags                        List all tags
  search <query>              Search tasks by title or tags

Examples:
  python -m taskcli add "Buy milk" --priority high --due 2023-12-31 --tag shopping --tag groceries
  python -m taskcli list --tag shopping
  python -m taskcli list --sort priority
  python -m taskcli search "report"
        """
    )
    
    parser.add_argument('--version', action='version', version=f'%(prog)s {__version__}')
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['low', 'med', 'high'], default='med',
                           help='Task priority (default: med)')
    add_parser.add_argument('--due', help='Due date in YYYY-MM-DD format')
    add_parser.add_argument('--tag', action='append', help='Tag for the task (repeatable)')
    
    # List command
    list_parser = subparsers.add_parser('list', help='List all tasks')
    list_parser.add_argument('--tag', action='append', help='Filter by tag (repeatable)')
    list_parser.add_argument('--sort', choices=['priority'], help='Sort order')
    list_parser.add_argument('--overdue', action='store_true', help='Show only overdue tasks')
    list_parser.add_argument('--archived', action='store_true', help='Include archived tasks')
    
    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', type=int, help='Task ID')
    
    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')
    
    # Edit command
    edit_parser = subparsers.add_parser('edit', help='Edit a task')
    edit_parser.add_argument('id', type=int, help='Task ID')
    edit_parser.add_argument('--title', help='New title for the task')
    
    # Archive command
    archive_parser = subparsers.add_parser('archive', help='Archive a task')
    archive_parser.add_argument('id', type=int, help='Task ID')
    
    # Stats command
    subparsers.add_parser('stats', help='Show statistics')
    
    # Backup command
    backup_parser = subparsers.add_parser('backup', help='Create a backup')
    backup_parser.add_argument('path', help='Backup file path')
    
    # Export command
    export_parser = subparsers.add_parser('export', help='Export to JSON')
    export_parser.add_argument('path', help='Export file path')
    export_parser.add_argument('--format', choices=['json', 'csv'], default='json',
                              help='Export format (default: json)')
    
    # Compact command
    subparsers.add_parser('compact', help='Compact database')
    
    # Tags command
    subparsers.add_parser('tags', help='List all tags')
    
    # Search command
    search_parser = subparsers.add_parser('search', help='Search tasks')
    search_parser.add_argument('query', help='Search query')
    
    args = parser.parse_args()
    
    # Initialize database
    try:
        from .storage import init_db
        init_db()
    except Exception as e:
        print_error(f"Failed to initialize database: {e}")
        sys.exit(1)
    
    # Dispatch command
    if args.command == 'add':
        return handle_add(args)
    elif args.command == 'list':
        return handle_list(args)
    elif args.command == 'done':
        return handle_done(args)
    elif args.command == 'delete':
        return handle_delete(args)
    elif args.command == 'edit':
        return handle_edit(args)
    elif args.command == 'archive':
        return handle_archive(args)
    elif args.command == 'stats':
        return handle_stats(args)
    elif args.command == 'backup':
        return handle_backup(args)
    elif args.command == 'export':
        return handle_export(args)
    elif args.command == 'compact':
        return handle_compact(args)
    elif args.command == 'tags':
        return handle_tags(args)
    elif args.command == 'search':
        return handle_search(args)
    else:
        parser.print_help()
        return 0

if __name__ == '__main__':
    sys.exit(main())

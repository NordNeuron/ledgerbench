import argparse
import sys
from .storage import load_tasks, save_tasks

def add_task(title, priority):
    tasks = load_tasks()
    if not tasks:
        new_id = 1
    else:
        new_id = max(task['id'] for task in tasks) + 1
    
    new_task = {
        'id': new_id,
        'title': title,
        'done': False,
        'priority': priority
    }
    
    tasks.append(new_task)
    save_tasks(tasks)
    print(new_id)

def list_tasks(sort_by_priority=False):
    tasks = load_tasks()
    if sort_by_priority:
        # Sort by priority: high, med, low
        priority_order = {'high': 0, 'med': 1, 'low': 2}
        tasks.sort(key=lambda task: (priority_order[task['priority']], task['id']))
    
    for task in tasks:
        done_status = "✓" if task['done'] else "○"
        print(f"{task['id']} {done_status} {task['title']} (priority: {task['priority']})")

def mark_done(task_id):
    tasks = load_tasks()
    for task in tasks:
        if task['id'] == task_id:
            task['done'] = True
            save_tasks(tasks)
            return
    sys.stderr.write(f"Error: No task with id {task_id}\n")
    sys.exit(1)

def delete_task(task_id):
    tasks = load_tasks()
    for i, task in enumerate(tasks):
        if task['id'] == task_id:
            del tasks[i]
            save_tasks(tasks)
            return
    sys.stderr.write(f"Error: No task with id {task_id}\n")
    sys.exit(1)

def main():
    parser = argparse.ArgumentParser(description="A minimal command-line task manager.")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Add command
    add_parser = subparsers.add_parser('add', help='Add a new task')
    add_parser.add_argument('title', help='Task title')
    add_parser.add_argument('--priority', choices=['low', 'med', 'high'], default='med',
                           help='Task priority (default: med)')

    # List command
    list_parser = subparsers.add_parser('list', help='List all tasks')
    list_parser.add_argument('--sort', choices=['priority'], help='Sort tasks')

    # Done command
    done_parser = subparsers.add_parser('done', help='Mark a task as done')
    done_parser.add_argument('id', type=int, help='Task ID')

    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete a task')
    delete_parser.add_argument('id', type=int, help='Task ID')

    args = parser.parse_args()

    if args.command == 'add':
        add_task(args.title, args.priority)
    elif args.command == 'list':
        list_tasks(sort_by_priority=args.sort == 'priority')
    elif args.command == 'done':
        mark_done(args.id)
    elif args.command == 'delete':
        delete_task(args.id)
    else:
        parser.print_help()
        sys.exit(1)

import json
import os

def load_tasks():
    if not os.path.exists('tasks.json'):
        return []
    
    with open('tasks.json', 'r') as f:
        try:
            tasks = json.load(f)
            # Ensure all tasks have a priority field for backward compatibility
            for task in tasks:
                if 'priority' not in task:
                    task['priority'] = 'med'
            return tasks
        except json.JSONDecodeError:
            return []

def save_tasks(tasks):
    with open('tasks.json', 'w') as f:
        json.dump(tasks, f, indent=2)

import json
import sys
import os
from typing import List, Dict, Any

TASKS_FILE = "tasks.json"

def load_tasks() -> List[Dict[str, Any]]:
    if not os.path.exists(TASKS_FILE):
        return []
    with open(TASKS_FILE, 'r') as f:
        return json.load(f)

def save_tasks(tasks: List[Dict[str, Any]]) -> None:
    with open(TASKS_FILE, 'w') as f:
        json.dump(tasks, f, indent=2)

def get_next_id(tasks: List[Dict[str, Any]]) -> int:
    if not tasks:
        return 1
    return max(task['id'] for task in tasks) + 1

def add_task(title: str, priority: str = "med") -> None:
    if priority not in ["low", "med", "high"]:
        print("Error: priority must be low, med, or high", file=sys.stderr)
        sys.exit(1)
    
    tasks = load_tasks()
    new_id = get_next_id(tasks)
    new_task = {
        "id": new_id,
        "title": title,
        "done": False,
        "priority": priority
    }
    tasks.append(new_task)
    save_tasks(tasks)
    print(new_id)

def list_tasks(sort_by_priority: bool = False) -> None:
    tasks = load_tasks()
    
    if sort_by_priority:
        # Sort by priority: high, med, low (stable sort preserves insertion order for ties)
        # We use a reverse priority mapping so that high gets lowest sort value
        priority_order = {"high": 0, "med": 1, "low": 2}
        tasks.sort(key=lambda task: (priority_order[task['priority']], task['id']))
    
    for task in tasks:
        done_status = "✓" if task['done'] else "○"
        print(f"{task['id']} {done_status} {task['title']} (priority: {task['priority']})")

def mark_done(task_id: int) -> None:
    tasks = load_tasks()
    for task in tasks:
        if task['id'] == task_id:
            task['done'] = True
            save_tasks(tasks)
            return
    print(f"Error: no task with id {task_id}", file=sys.stderr)
    sys.exit(1)

def delete_task(task_id: int) -> None:
    tasks = load_tasks()
    for i, task in enumerate(tasks):
        if task['id'] == task_id:
            del tasks[i]
            save_tasks(tasks)
            return
    print(f"Error: no task with id {task_id}", file=sys.stderr)
    sys.exit(1)

def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python -m taskcli <command> [arguments...]", file=sys.stderr)
        sys.exit(1)

    command = sys.argv[1]

    if command == "add":
        if len(sys.argv) < 3:
            print("Usage: python -m taskcli add <title> [--priority low|med|high]", file=sys.stderr)
            sys.exit(1)
        
        title = sys.argv[2]
        priority = "med"
        
        # Check for --priority flag
        if "--priority" in sys.argv:
            try:
                index = sys.argv.index("--priority")
                if index + 1 < len(sys.argv):
                    priority = sys.argv[index + 1]
                    # Validate priority value
                    if priority not in ["low", "med", "high"]:
                        print("Error: priority must be low, med, or high", file=sys.stderr)
                        sys.exit(1)
                else:
                    print("Error: --priority flag requires an argument", file=sys.stderr)
                    sys.exit(1)
            except ValueError:
                print("Error: invalid usage of --priority flag", file=sys.stderr)
                sys.exit(1)
        
        add_task(title, priority)
    
    elif command == "list":
        sort_by_priority = False
        if "--sort" in sys.argv:
            try:
                index = sys.argv.index("--sort")
                if index + 1 < len(sys.argv):
                    sort_type = sys.argv[index + 1]
                    if sort_type == "priority":
                        sort_by_priority = True
                    else:
                        print("Error: --sort only supports 'priority' option", file=sys.stderr)
                        sys.exit(1)
                else:
                    print("Error: --sort flag requires an argument", file=sys.stderr)
                    sys.exit(1)
            except ValueError:
                print("Error: invalid usage of --sort flag", file=sys.stderr)
                sys.exit(1)
        list_tasks(sort_by_priority)
    
    elif command == "done":
        if len(sys.argv) < 3:
            print("Usage: python -m taskcli done <id>", file=sys.stderr)
            sys.exit(1)
        try:
            task_id = int(sys.argv[2])
        except ValueError:
            print("Error: id must be an integer", file=sys.stderr)
            sys.exit(1)
        mark_done(task_id)
    
    elif command == "delete":
        if len(sys.argv) < 3:
            print("Usage: python -m taskcli delete <id>", file=sys.stderr)
            sys.exit(1)
        try:
            task_id = int(sys.argv[2])
        except ValueError:
            print("Error: id must be an integer", file=sys.stderr)
            sys.exit(1)
        delete_task(task_id)
    
    else:
        print(f"Unknown command: {command}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
